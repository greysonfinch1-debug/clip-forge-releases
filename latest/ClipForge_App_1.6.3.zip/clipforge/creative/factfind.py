"""Automatic fact research for narrated Shorts (1.6.1).

When the user supplies no notes or links and the video states facts (gaming secrets, history,
science, news…), ClipForge looks the subject up in public wikis through their official MediaWiki
APIs, the same text anyone can read in a browser:

  * Wikipedia (en.wikipedia.org)
  * the game's own wiki for gaming topics (e.g. gta.fandom.com, minecraft.wiki)

It keeps only the most relevant paragraphs, labelled [S1], [S2]… with their page and link, and
gives them to the scriptwriter, who must base every specific (a mode, a button, a place, a
number, a reward) on them. The links are listed in the video's description notes.

Why: a small local language model writing "secrets" from memory invents them (the user's
"5 GTA 5 Secrets" Short claimed a GTA Online "Gang War" mode and F12/F11 quick-save keys; neither
exists). Nothing here signs in, gets around paywalls, or keeps more than the page text.
"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from typing import Optional

UA = "ClipForge/1.6 (YouTube Shorts editor; fact research via the MediaWiki API)"
TIMEOUT = 12.0
MAX_TOTAL = 9000
MAX_PER_PAGE = 1600
FACTUAL = {"gaming", "gaming_news", "history", "facts", "science", "technology", "education", "news", "mystery",
           "documentary", "commentary", "list"}

# game -> its wiki's MediaWiki API (public, read-only)
GAME_WIKIS = [
    (r"\bgta\b|grand theft auto|los santos", "https://gta.fandom.com/api.php", "GTA Wiki"),
    (r"\bminecraft\b", "https://minecraft.wiki/api.php", "Minecraft Wiki"),
    (r"\bfortnite\b", "https://fortnite.fandom.com/api.php", "Fortnite Wiki"),
    (r"red dead", "https://reddead.fandom.com/api.php", "Red Dead Wiki"),
    (r"\broblox\b", "https://roblox.fandom.com/api.php", "Roblox Wiki"),
    (r"call of duty|\bwarzone\b|\bcod\b", "https://callofduty.fandom.com/api.php", "Call of Duty Wiki"),
    (r"\bzelda\b|hyrule", "https://zelda.fandom.com/api.php", "Zelda Wiki"),
    (r"\bvalorant\b", "https://valorant.fandom.com/api.php", "Valorant Wiki"),
    (r"elden ring", "https://eldenring.fandom.com/api.php", "Elden Ring Wiki"),
    (r"\bskyrim\b|elder scrolls", "https://elderscrolls.fandom.com/api.php", "Elder Scrolls Wiki"),
    (r"\bterraria\b", "https://terraria.wiki.gg/api.php", "Terraria Wiki"),
    (r"\bpokemon\b|pokémon", "https://bulbapedia.bulbagarden.net/w/api.php", "Bulbapedia"),
]
WIKIPEDIA = ("https://en.wikipedia.org/w/api.php", "Wikipedia")

_STOP = set("a an the of in on at to for and or with about from by is are was be this that it its as into than "
            "then so very more most can could will would should do does did not no your you my his her their our "
            "they them we i he she how what why who which make video short shorts youtube create titled use "
            "footage gameplay background players player know things thing secrets secret tips tip most don't".split())


class Source:
    def __init__(self, sid: str, title: str, url: str, site: str, text: str):
        self.sid, self.title, self.url, self.site, self.text = sid, title, url, site, text

    def block(self) -> str:
        return f"[{self.sid}] {self.title} ({self.site}, {self.url})\n{self.text}"


def _get(url: str, params: dict, opener=None) -> dict:
    q = url + "?" + urllib.parse.urlencode({**params, "format": "json"})
    req = urllib.request.Request(q, headers={"User-Agent": UA, "Accept": "application/json"})
    with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def wikis_for(text: str) -> list[tuple[str, str]]:
    low = (text or "").lower()
    out = [(api, name) for pat, api, name in GAME_WIKIS if re.search(pat, low)]
    return out + [WIKIPEDIA]


def keywords(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9']+", (text or "").lower()) if w not in _STOP and len(w) > 1]


def default_queries(subject: str, prompt: str, category: str) -> list[str]:
    """Search queries without a language model: the subject, plus the kinds of page that hold
    lesser-known facts for this category."""
    base = subject.strip() or " ".join(keywords(prompt)[:5])
    extra = {"gaming": ["easter eggs", "secrets", "cheats", "hidden features"],
             "gaming_news": ["release", "announcement"], "history": ["history"], "facts": ["facts"],
             "science": [], "technology": ["features"], "mystery": ["mystery"], "list": []}.get(category, [])
    roman = {"2": "II", "3": "III", "4": "IV", "5": "V", "6": "VI", "7": "VII", "8": "VIII"}
    alt = re.sub(r"\b(gta|grand theft auto|final fantasy|resident evil|call of duty|far cry|assassin's creed)\s+"
                 r"([2-8])\b", lambda m: f"{m.group(1)} {roman[m.group(2)]}", base, flags=re.I)
    alt = re.sub(r"\b(secrets?|tips?|things|facts?|hidden|most|players|know|don't)\b", "", alt, flags=re.I).strip()
    qs = [base] + ([alt] if alt and alt.lower() != base.lower() else []) + [f"{alt or base} {e}" for e in extra]
    return list(dict.fromkeys(" ".join(q.split()) for q in qs if q.strip()))[:6]


def search(api: str, query: str, limit: int = 3, opener=None) -> list[str]:
    d = _get(api, {"action": "query", "list": "search", "srsearch": query, "srlimit": limit, "srprop": ""}, opener)
    return [x["title"] for x in (d.get("query") or {}).get("search", []) if x.get("title")]


def page_text(api: str, title: str, opener=None) -> str:
    """Plain text of a wiki page (Wikipedia: TextExtracts; other wikis: the parsed HTML)."""
    if "wikipedia.org" in api:
        d = _get(api, {"action": "query", "prop": "extracts", "explaintext": 1, "redirects": 1, "titles": title},
                 opener)
        pages = (d.get("query") or {}).get("pages") or {}
        return "\n".join(p.get("extract", "") for p in pages.values())
    d = _get(api, {"action": "parse", "page": title, "prop": "text", "redirects": 1, "formatversion": 2}, opener)
    html = (d.get("parse") or {}).get("text") or ""
    from .research import page_text as html_text

    return html_text(html)[1] if html else ""


def page_url(api: str, title: str) -> str:
    base = api.rsplit("/", 1)[0]
    if base.endswith("/w"):
        base = base[:-2]
    return f"{base}/wiki/{urllib.parse.quote(title.replace(' ', '_'))}"


def best_passages(text: str, words: list[str], limit: int = MAX_PER_PAGE) -> str:
    """The paragraphs of a page that share the most words with the request (in page order)."""
    paras = [p.strip() for p in re.split(r"\n\s*\n|\n(?=[A-Z])", text) if len(p.strip()) > 60]
    paras = [p for p in paras if not re.match(r"^(references|see also|external links|navigation|gallery)\b", p,
                                              re.I)]
    ws = set(words)
    scored = sorted(range(len(paras)), key=lambda i: -sum(1 for w in keywords(paras[i]) if w in ws))
    keep, total = set(), 0
    for i in scored:
        if total + len(paras[i]) > limit and keep:
            break
        keep.add(i)
        total += len(paras[i])
    return "\n".join(paras[i][:limit] for i in sorted(keep))


# entries of a series: a page about another entry is the wrong game (1.6.3: a GTA 6 video got
# "secrets" from Vice City Stories)
SERIES = {
    "gta": [("6", r"\b(gta|grand theft auto)\s*(6|vi)\b|\bleonida\b|\bjason\b.*\blucia\b|\blucia\b"),
            ("5", r"\b(gta|grand theft auto)\s*(5|v)\b|\bgta online\b|\blos santos\b"),
            ("4", r"\b(gta|grand theft auto)\s*(4|iv)\b|\bliberty city\b(?! stories)"),
            ("sa", r"\bsan andreas\b"), ("vc", r"\bvice city\b(?! stories)"),
            ("vcs", r"\bvice city stories\b"), ("lcs", r"\bliberty city stories\b"),
            ("ctw", r"\bchinatown wars\b"), ("3", r"\b(gta|grand theft auto)\s*(3|iii)\b")],
}


def entry_of(text: str, series: str = "gta") -> Optional[str]:
    low = (text or "").lower()
    for eid, pat in SERIES.get(series, []):
        if re.search(pat, low):
            return eid
    return None


def same_entry(title: str, subject: str, series: str = "gta") -> bool:
    """Is a page about the entry the video is about? Pages naming no entry (general topics) pass."""
    want, got = entry_of(subject, series), entry_of(title, series)
    if want is None or got is None:
        return True
    if want == "6" and got == "vc":          # GTA 6 is set in (a new) Vice City, but not the 2002 game
        return not re.search(r"\b(gta|grand theft auto:?)\s+vice city\b", (title or "").lower())
    return want == got


def find_sources(prompt: str, subject: str, category: str, queries: Optional[list[str]] = None,
                 opener=None, log=None) -> list[Source]:
    """Look the subject up; returns [] (and says why through ``log``) when nothing is reachable."""
    if category not in FACTUAL:
        return []
    queries = queries or default_queries(subject, prompt, category)
    words = keywords(subject + " " + prompt)
    out: list[Source] = []
    seen: set[str] = set()
    total = 0
    for api, site in wikis_for(subject + " " + prompt):
        for q in queries:
            try:
                titles = search(api, q, 3, opener)
            except Exception as e:  # noqa: BLE001  (offline, blocked, rate-limited)
                if log:
                    log(f"Fact research: {site} not reachable ({type(e).__name__})")
                break
            for t in titles:
                if (site, t) in seen or total >= MAX_TOTAL:
                    continue
                if "gta" in api and not same_entry(t, subject + " " + prompt):
                    if log:
                        log(f"Fact research: skipped '{t}' (a different game in the series)")
                    seen.add((site, t))
                    continue
                seen.add((site, t))
                try:
                    txt = best_passages(page_text(api, t, opener), words)
                except Exception:  # noqa: BLE001
                    continue
                if len(txt) < 120:
                    continue
                txt = txt[: MAX_TOTAL - total]
                out.append(Source(f"S{len(out) + 1}", t, page_url(api, t), site, txt))
                total += len(txt)
            if total >= MAX_TOTAL:
                break
    return out


def as_text(sources: list[Source]) -> str:
    return "\n\n".join(s.block() for s in sources)


FACT_SYSTEM = """You pick facts for a YouTube Short from source pages. Rules: only facts the sources state; each fact is ONE concrete, specific detail (a name, place, character, item, mechanic, date or number) in one short sentence; prefer details a regular viewer wouldn't already know; no two facts about the same thing; nothing about a different game, person or topic than the request. Reply with JSON only."""

FACT_PROMPT = """The video: "{prompt}"

Sources:
{sources}

Return {{"facts": [{{"fact": "one short sentence", "source": "S#"}}]}} with up to {n} facts, most interesting first.
If the sources say little about the request, return fewer facts - never invent."""


def extract_facts(prompt: str, sources: list[Source], llm, n: int = 12) -> list[dict]:
    """The concrete, checkable facts in the sources that fit this video (one short AI call), so the
    script uses real details instead of paraphrasing whole pages."""
    if not sources:
        return []
    try:
        d = llm.complete_json(FACT_SYSTEM, FACT_PROMPT.format(prompt=prompt[:1500], sources=as_text(sources)[:7000],
                                                               n=n), max_tokens=900)
    except Exception:  # noqa: BLE001
        return []
    out, seen = [], set()
    ids = {s.sid for s in sources}
    for x in (d.get("facts") if isinstance(d, dict) else None) or []:
        if not isinstance(x, dict):
            continue
        f = " ".join(str(x.get("fact") or "").split())[:220]
        sid = str(x.get("source") or "").strip().strip("[]")
        key = " ".join(sorted(set(keywords(f))))[:80]
        if len(f) < 12 or key in seen:
            continue
        seen.add(key)
        out.append({"fact": f, "source": sid if sid in ids else ""})
    return out[:n]


def facts_text(facts: list[dict]) -> str:
    return "\n".join(f"- {f['fact']}" + (f" [{f['source']}]" if f["source"] else "") for f in facts)
