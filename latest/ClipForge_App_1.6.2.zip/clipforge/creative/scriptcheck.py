"""Script review: catch what made the user's "5 GTA 5 Secrets" script weak, before any video is made.

Measured problems (no AI needed):
  duplicate    two points say the same thing (same named feature, or most of the same words)
  shallow      a point too short to explain anything, or with no "how" / "why"
  stock        filler / AI-sounding stock phrases
  count        fewer distinct points than the request asks for
  unsupported  a specific (a quoted name, a key or button, a number, a named mode) that the
               sources don't contain — or, with no sources, a specific nobody checked
  numbering    "Fourth" after two points, a missing "Tip three"…

``repair`` sends the script, the problems and the sources back to the language model once or twice
for a corrected version; whatever is still duplicated afterwards is dropped (never shown twice), and
the spoken numbering is redone so it matches what remains.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from ..knowledge.kb import STOCK_PHRASES

MIN_POINT_WORDS = 14            # a point that explains something takes more than a slogan
_STOP = set("a an the of in on at to for and or with about from by is are was be this that it its as into than then "
            "so very more most can could will would should do does did not no your you my his her their our they them "
            "we i he she just here there what when how why who which out up get got also even one first second third "
            "fourth fifth last tip number did know".split())
_COMMON = {"did", "you", "the", "in", "on", "this", "it", "there", "when", "if", "after", "a", "an", "if", "once",
           "most", "some", "every", "your", "players", "at", "on", "with", "for", "to", "here"}
_ORD = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]
_ORDINAL_WORDS = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth"]
_LEAD = re.compile(r"^\s*(?:(?:tip|secret|step|fact|reason|number|no\.?|#)\s*(?:\d+|one|two|three|four|five|six|seven|"
                   r"eight|nine|ten)|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|next|"
                   r"last(?: one)?|finally|and finally)\s*[:,.!-]?\s*", re.I)
_HOW_WHY = re.compile(r"\b(because|so|since|which|by|when|if|after|before|once|then|to (?:get|unlock|find|make|"
                      r"save|earn|stop|avoid)|means|lets you|allows|that way|where|while|until|instead)\b", re.I)
_SPECIFIC = re.compile(r"(['\"‘“])([^'\"’”]{2,40})\1|\b(F\d{1,2}|Ctrl|Alt|Shift|Tab|Esc|L[123]|R[123]|[LR]B|[LR]T|"
                       r"D-?pad)\b|(?<![\w.])(~)(?!\w)|\b\d[\d,.]*\b", re.I)


@dataclass
class Problem:
    index: int
    kind: str
    detail: str
    other: Optional[int] = None

    def text(self) -> str:
        return f"part {self.index + 1}: {self.kind} — {self.detail}"


def words(s: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", (s or "").lower())


def content(s: str) -> set[str]:
    return {w for w in words(_LEAD.sub("", s or "")) if w not in _STOP and len(w) > 2}


def specifics(s: str) -> list[str]:
    """Things a viewer would take as hard facts: quoted names, keys and buttons, numbers."""
    out = []
    for m in _SPECIFIC.finditer(s or ""):
        v = m.group(2) or m.group(3) or m.group(4) or m.group(0)
        v = v.strip()
        if v and not (v.isdigit() and int(v) <= 10):      # "these 5 things" is a count, not a claim
            out.append(v)
    return out


def _sim(a: str, b: str) -> float:
    x, y = content(a), content(b)
    return len(x & y) / min(len(x), len(y)) if x and y else 0.0


def _named(s: str) -> set[str]:
    q = {m.group(2).lower() for m in re.finditer(r"(['\"‘“])([^'\"’”]{2,40})\1", s or "")}
    return q


def find_problems(sections, points: int = 0, sources_text: str = "", factual: bool = True) -> list[Problem]:
    narr = [(i, s) for i, s in enumerate(sections) if s.kind == "narration"]
    pts = [(i, s) for i, s in narr if s.role == "point"]
    out: list[Problem] = []
    for a in range(len(narr)):
        for b in range(a):
            i, si = narr[a]
            j, sj = narr[b]
            shared = _named(si.text) & _named(sj.text)
            if _sim(si.text, sj.text) >= 0.6 or (shared and si.role == sj.role == "point"):
                why = (f"names {', '.join(sorted(shared))} again" if shared else "says mostly the same as")
                out.append(Problem(i, "duplicate", f"{why} part {j + 1}", j))
                break
    for i, s in pts:
        n = len(words(_LEAD.sub("", s.text)))
        if n < MIN_POINT_WORDS:
            out.append(Problem(i, "shallow", f"only {n} words: say what it is, exactly how or where, and why it "
                                             "matters"))
        elif not _HOW_WHY.search(s.text):
            out.append(Problem(i, "shallow", "says what but not how to do it or why it's worth knowing"))
    for i, s in narr:
        low = s.text.lower()
        hit = [p for p in STOCK_PHRASES if p in low]
        if hit:
            out.append(Problem(i, "stock", f"stock phrase '{hit[0]}'"))
    distinct = len(pts) - sum(1 for p in out if p.kind == "duplicate" and sections[p.index].role == "point")
    if points and distinct < points:
        out.append(Problem(pts[-1][0] if pts else 0, "count", f"{distinct} distinct points; the request asks for "
                                                              f"{points}"))
    if factual:
        src = (sources_text or "").lower()
        for i, s in narr:
            for sp in specifics(s.text):
                if not src:
                    out.append(Problem(i, "unsupported", f"'{sp}' is a specific nobody has checked (no sources)"))
                elif sp.lower() not in src:
                    out.append(Problem(i, "unsupported", f"'{sp}' isn't in the sources"))
    return out


def renumber(sections) -> None:
    """Make the spoken numbering match the points that remain ("Tip one", "Second", "Last one")."""
    pts = [s for s in sections if s.kind == "narration" and s.role == "point"]
    styled = [s for s in pts if _LEAD.match(s.text)]
    if len(styled) < max(2, len(pts) - 1):
        return
    use_tip = sum(1 for s in styled if re.match(r"\s*tip\b", s.text, re.I)) >= len(styled) / 2
    for k, s in enumerate(pts):
        body = _LEAD.sub("", s.text, count=1).lstrip()
        if k == len(pts) - 1 and len(pts) >= 3:
            lead = "Last one:"
        elif use_tip:
            lead = f"Tip {_ORD[k] if k < len(_ORD) else k + 1}:"
        else:
            lead = (_ORDINAL_WORDS[k] if k < len(_ORDINAL_WORDS) else f"Number {k + 1}") + ","
        first = body.split(" ", 1)[0]
        if lead.endswith(",") and first.lower() in _COMMON:
            body = body[:1].lower() + body[1:]
        elif body:
            body = body[:1].upper() + body[1:]
        s.text = f"{lead} {body}"
        if s.label and re.match(r"^\s*(tip|#|\d|secret|step)", s.label, re.I):
            s.label = f"#{k + 1}"


def drop_duplicates(sections) -> list[str]:
    """Remove later copies of a point that still repeats an earlier one (after repair)."""
    removed = []
    for p in sorted([p for p in find_problems(sections, factual=False) if p.kind == "duplicate"],
                    key=lambda p: -p.index):
        s = sections[p.index]
        if s.kind == "narration" and s.role == "point":
            removed.append(s.text[:60])
            del sections[p.index]
    return removed


REVIEW_SYSTEM = """You are the script editor of a YouTube Shorts channel. You fix scripts before they are recorded.
Rules:
- Every point must be DIFFERENT: a different feature, place or idea. Never repeat a point in other words.
- Every point is 2-3 complete sentences: WHAT it is, exactly HOW or WHERE (steps, location, conditions), and WHY it's worth knowing. Concrete, not vague.
- Facts: a specific (a named mode or item, a button or key, a place, a number, a reward) may only appear if the sources below contain it. If the sources don't support a point, replace it with a different point the sources DO support. With no sources, keep only facts you are certain of, and drop buttons, numbers and names you aren't sure of.
- If there aren't enough supported facts for the number of points asked for, write fewer points. Never invent.
- Keep the hook first and the ending last; keep the on-screen labels short; no stock phrases ("did you know", "in this video", "let's dive in").
Reply with JSON only."""

REVIEW_PROMPT = """The creator's request: "{prompt}"

The script (JSON sections, in order):
{script}

Problems found:
{problems}

Sources (the only facts you may state; cite the [S#] you used for each point):
{sources}

Return the WHOLE corrected script:
{{"sections": [{{"role": "hook|point|conclusion", "label": "", "text": "...", "visuals": ["...", "..."], "source": "S#|none"}}],
  "notes": "what you changed, one line"}}"""


def repair(prompt: str, sections, problems: list[Problem], sources_text: str, llm) -> Optional[list[dict]]:
    """One language-model pass that fixes the listed problems. Returns new section dicts, or None."""
    import json

    narr = [s for s in sections if s.kind == "narration"]
    script = json.dumps([{"role": s.role, "label": s.label, "text": s.text, "visuals": s.visuals[:3]} for s in narr],
                        ensure_ascii=False, indent=0)
    idx = {id(s): k for k, s in enumerate(narr)}
    probs = []
    for p in problems:
        s = sections[p.index]
        k = idx.get(id(s))
        if k is not None:
            probs.append(f"- section {k + 1}: {p.kind}: {p.detail}")
    try:
        d = llm.complete_json(REVIEW_SYSTEM, REVIEW_PROMPT.format(
            prompt=prompt[:2500], script=script[:6000], problems="\n".join(probs) or "- none found by the checks; "
            "still check facts against the sources", sources=sources_text[:7000] or "(none could be found)"),
            max_tokens=2400)
    except Exception:  # noqa: BLE001
        return None
    secs = d.get("sections") if isinstance(d, dict) else None
    if not isinstance(secs, list) or not any(isinstance(x, dict) and str(x.get("text", "")).strip() for x in secs):
        return None
    return [x for x in secs if isinstance(x, dict) and str(x.get("text", "")).strip()]
