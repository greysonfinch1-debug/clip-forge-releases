"""The hard rules in a creator's prompt (2.0.9).

From the creator's "Vice City: 2002 vs 2026" Short: the prompt said "Video type: Hybrid", "Length: 30
seconds", gave six narration lines "use exactly, do not rewrite", "Don't add an outro" and "game audio
muted". ClipForge followed none of it: the Video type and Target length options won over the prompt,
clip-driven mode had the AI write its own narration, two default calls to action were added, and it
made a "2002 vs 2026" video from GTA 6 footage only.

``parse`` reads those rules from the prompt text (no AI involved, so it can't drift); the pipeline
applies them over the options, and ``unmet`` lists what this ClipForge can't produce, so the job stops
with a clear message instead of a video that only pretends to follow the prompt.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

_QUOTE = "\"“”„«»"
_VERBATIM = re.compile(r"\b(use (it |them |this |these )?(exactly|word[- ]for[- ]word|verbatim)|word[- ]for[- ]word|"
                       r"verbatim|do ?n[o'’]t rewrite|don['’]?t (change|rewrite|edit)|as written|exactly as written)\b", re.I)
_SCRIPT_HEAD = re.compile(r"^\s*(narration|script|voice[- ]?over|vo|lines?)\b[^\n]*", re.I)
_LIST_ITEM = re.compile(r"^\s*(?:\d+\s*[.)]|[-•*])\s*(.+?)\s*$")
_SECTION = re.compile(r"^\s*[A-Z][A-Za-z /&-]{2,40}:\s*$")          # "Clip matching:" starts a new section
_TYPE = re.compile(r"\bvideo type\s*[:=-]\s*(hybrid|narration[- ]driven|narration|narrated|clip[- ]driven|clips?)\b",
                   re.I)
_LENGTH = re.compile(r"\b(?:length|duration|runtime)\s*[:=-]\s*(\d{1,3})\s*(?:s\b|sec|seconds)", re.I)
_LENGTH2 = re.compile(r"\b(\d{1,3})[- ]?(?:s|sec|second)s?\b(?:[- ](?:long|video|short))", re.I)
_NO_CTA = re.compile(r"\b(?:do ?n[o'’]?t|do not|never|no|without)\s+(?:add\s+|include\s+|use\s+|put\s+)?(?:an?\s+|any\s+)?"
                     r"(?:outro|end ?card|cta|call[- ]to[- ]action|follow\b[^.\n]*|subscribe\b[^.\n]*)", re.I)
_CTA = re.compile(r"\b(?:end (?:it |the video )?with|outro|call[- ]to[- ]action|\bcta\b|follow (?:\w+ ){0,3}for|"
                  r"subscribe|like and)\b", re.I)
_MUTE = re.compile(r"\b(?:game|original|clip|in-?game) (?:audio|sound)s? (?:muted|off)|\bmute (?:the )?(?:game|original|"
                   r"clip) (?:audio|sound)|\bno (?:game|original) (?:audio|sound)", re.I)
_MUSIC = re.compile(r"\b(?:add|with|use|over|put)\b[^.\n]{0,40}\b(?:music|beat|soundtrack|synthwave|lo-?fi|track)\b", re.I)
_VS_YEARS = re.compile(rf"\b((?:19|20)\d{{2}})[{_QUOTE}]?\s*(?:vs\.?|versus|/|→|->|or)\s*[{_QUOTE}]?((?:19|20)\d{{2}})\b",
                       re.I)
_OLD_NEW = re.compile(r"\bold\b[^.\n]{0,40}\bnew\b|\b(?:original|classic)\b[^.\n]{0,30}\b(?:remake|remaster|vs)\b",
                      re.I)
_SPLIT = re.compile(r"\bsplit[- ]?screen\b|\bside[- ]by[- ]side\b|\bold on top\b", re.I)
_CORNER = re.compile(r"\blabels?\b[^.\n]{0,40}\bcorner\b|\bcorner\b[^.\n]{0,40}\blabels?\b", re.I)
_LOWER_THIRD = re.compile(r"\blower third\b", re.I)


@dataclass
class PromptSpec:
    verbatim_lines: list[str] = field(default_factory=list)   # narration to use exactly
    video_type: str = ""          # "", "clip", "narration", "hybrid"
    seconds: float = 0.0          # 0 = not stated
    cta: str = ""                 # "requested", "forbidden" or "" (not mentioned: none is added)
    mute_game_audio: bool = False
    music: bool = False
    compare: list[str] = field(default_factory=list)          # e.g. ["2002", "2026"]
    split_screen: bool = False
    corner_labels: bool = False
    lower_third: bool = False

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict | None) -> "PromptSpec":
        d = d or {}
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


def _strip_quotes(s: str) -> str:
    s = s.strip()
    m = re.match(rf"^[{_QUOTE}](.+?)[{_QUOTE}]\s*$", s)
    return (m.group(1) if m else s).strip()


def verbatim_lines(prompt: str) -> list[str]:
    """Narration the creator wants used exactly: the list under a "Narration (use exactly…)" heading,
    or the quoted lines after it. Empty when the prompt doesn't ask for exact narration."""
    lines = (prompt or "").splitlines()
    for k, ln in enumerate(lines):
        if not (_SCRIPT_HEAD.match(ln) and _VERBATIM.search(ln)):
            continue
        out = []
        for nxt in lines[k + 1:]:
            if not nxt.strip():
                if out:
                    # a blank line inside the list is fine; a blank line then a new section ends it
                    continue
                continue
            item = _LIST_ITEM.match(nxt)
            if item:
                out.append(_strip_quotes(item.group(1)))
                continue
            if out and (_SECTION.match(nxt) or nxt.rstrip().endswith(":")):
                break
            if re.match(rf"^\s*[{_QUOTE}]", nxt):
                out.append(_strip_quotes(nxt))
                continue
            if out:
                break
        out = [x for x in out if x]
        if out:
            return out
    return []


def parse(prompt: str) -> PromptSpec:
    spec = PromptSpec(verbatim_lines=verbatim_lines(prompt or ""))
    # the narration lines are things to SAY, not rules ("Comment 2002 or 2026." isn't a comparison request)
    p = prompt or ""
    for ln in spec.verbatim_lines:
        p = p.replace(ln, " ")
    m = _TYPE.search(p)
    if m:
        t = m.group(1).lower()
        spec.video_type = "hybrid" if t.startswith("hybrid") else ("clip" if t.startswith("clip") else "narration")
    m = _LENGTH.search(p) or _LENGTH2.search(p)
    if m and 5 <= int(m.group(1)) <= 180:
        spec.seconds = float(m.group(1))
    if _NO_CTA.search(p):
        spec.cta = "forbidden"
    elif _CTA.search(_NO_CTA.sub(" ", p)):
        spec.cta = "requested"
    spec.mute_game_audio = bool(_MUTE.search(p))
    spec.music = bool(_MUSIC.search(p))
    m = _VS_YEARS.search(p)
    if m and m.group(1) != m.group(2):
        spec.compare = [m.group(1), m.group(2)]
    elif _OLD_NEW.search(p) and re.search(r"\b(?:footage|clips?|version|graphics)\b", p, re.I):
        spec.compare = ["old", "new"]
    spec.split_screen = bool(_SPLIT.search(p))
    spec.corner_labels = bool(_CORNER.search(p))
    spec.lower_third = bool(_LOWER_THIRD.search(p))
    return spec


def cta_requested(prompt: str) -> bool:
    """A call to action ("Follow for more", an end card) only when the prompt asks for one (2.0.9: two
    default CTAs were added to a prompt that said "Don't add an outro")."""
    return parse(prompt).cta == "requested"


def unmet(spec: PromptSpec, footage_titles: list[str], music_ready: bool) -> list[str]:
    """What the prompt requires that this ClipForge can't produce. The job stops with this list rather
    than making a video that only pretends to follow the prompt."""
    out = []
    if spec.compare:
        a, b = spec.compare
        have = [t for t in footage_titles if a in t or (a == "old" and re.search(r"\b(19|200)\d\b", t))]
        missing = "" if have else f" There is no {a} footage in this project at all (only: {', '.join(footage_titles)[:200]})."
        out.append(f"An old-vs-new comparison ({a} vs {b}) needs matched {a} and {b} clips of the same places. "
                   f"ClipForge can't pair footage by era or build a comparison yet.{missing}")
    if spec.split_screen:
        out.append("A split screen (one video on top, another below) isn't something ClipForge can make yet.")
    if spec.corner_labels:
        out.append("Corner labels on every clip (e.g. \"2002\" / \"2026\") aren't something ClipForge can add yet.")
    if spec.music and not music_ready:
        out.append("The prompt asks for music, but no music file or folder is set up. ClipForge doesn't include "
                   "music: choose your own on step 5 (Edit & Captions) or in Settings, then try again.")
    return out
