"""Text-to-speech backends.

* ``kokoro`` – Kokoro-82M (Apache-2.0) via kokoro-onnx. Runs locally on CPU, natural
  voices, free for commercial use. Model files download once from GitHub (~120 MB).
Pre-made voices only; no voice cloning of other people is implemented.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .base import TTS, ProgressFn, ProviderUnavailable, download_file, register

KOKORO_RELEASE = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"

# a blend mixes two voices' style vectors (Kokoro supports this natively). "Michael + Fenrir" keeps
# Michael's sound with more pitch movement: 12.3 vs 10.7 semitones of range on the same script, and
# the best quality score of the male voices tested (DNSMOS 3.59), 2026-11-18.
BLENDS = {"am_michael:0.6+am_fenrir:0.4": "Michael + Fenrir (US male, livelier, recommended)",
          "am_michael:0.5+am_puck:0.5": "Michael + Puck (US male, brighter)"}
VOICE_LABELS = {
    **BLENDS,
    "am_michael": "Michael (US male, warm)", "am_adam": "Adam (US male)", "am_eric": "Eric (US male, upbeat)",
    "am_liam": "Liam (US male, young)", "am_onyx": "Onyx (US male, deep)", "am_puck": "Puck (US male, energetic)",
    "am_fenrir": "Fenrir (US male, bold)", "am_echo": "Echo (US male)",
    "af_heart": "Heart (US female, warm)", "af_bella": "Bella (US female, lively)",
    "af_nicole": "Nicole (US female, soft)", "af_sarah": "Sarah (US female)", "af_nova": "Nova (US female)",
    "af_sky": "Sky (US female)", "af_river": "River (US female)", "af_jessica": "Jessica (US female)",
    "bm_george": "George (UK male)", "bm_lewis": "Lewis (UK male)", "bm_daniel": "Daniel (UK male)",
    "bf_emma": "Emma (UK female)", "bf_isabella": "Isabella (UK female)",
}


@register("tts", "kokoro")
class KokoroTTS(TTS):
    def __init__(self, models_dir: str, progress: ProgressFn = None, **_):
        try:
            from kokoro_onnx import Kokoro  # type: ignore
        except ImportError as e:
            raise ProviderUnavailable("kokoro-onnx is not installed") from e
        from ..model_manager import ModelError, ensure

        try:
            ensure("kokoro_model", models_dir, progress)
            ensure("kokoro_voices", models_dir, progress)
        except ModelError as e:
            raise ProviderUnavailable(str(e)) from e
        d = Path(models_dir) / "kokoro"
        # 1.8.0: the full-precision model (fp16). The int8 one was 2.6x slower on a CPU without int8
        # instructions (47 s vs 18 s for 22 s of speech) and no better. It stays as the fallback.
        model = d / "kokoro-v1.0.int8.onnx"
        try:
            ensure("kokoro_model_hq", models_dir, progress)
            model = d / "kokoro-v1.0.fp16.onnx"
        except ModelError:
            pass
        self.model_file = model.name
        self.k = Kokoro(str(model), str(d / "voices-v1.0.bin"))
        self.name = "kokoro-hq" if "fp16" in model.name else "kokoro"

    def style(self, voice: str):
        """A voice name, or a blend "am_michael:0.6+am_fenrir:0.4", as Kokoro's style matrix."""
        if "+" not in voice and ":" not in voice:
            return voice
        total, acc = 0.0, None
        for part in voice.split("+"):
            name, _, w = part.partition(":")
            w = float(w or 1.0)
            v = self.k.get_voice_style(name.strip()) * w
            acc = v if acc is None else acc + v
            total += w
        return acc / (total or 1.0)

    def phonemize(self, text: str, lang: str = "en-us") -> str:
        return self.k.tokenizer.phonemize(text, lang)

    def synthesize_phonemes(self, phonemes: str, voice: str, speed: float = 1.0) -> tuple[np.ndarray, int]:
        samples, sr = self.k.create(phonemes, voice=self.style(voice), speed=float(speed), is_phonemes=True)
        return np.asarray(samples, dtype=np.float32), int(sr)

    def voices(self) -> list[str]:
        vs = set(self.k.get_voices())
        ordered = [v for v in BLENDS] + [v for v in VOICE_LABELS if v in vs]
        return ordered + sorted(v for v in vs if v not in VOICE_LABELS and v[:2] in ("am", "af", "bm", "bf"))

    def synthesize(self, text: str, voice: str, speed: float = 1.0) -> tuple[np.ndarray, int]:
        lang = "en-gb" if voice.startswith("b") else "en-us"
        samples, sr = self.k.create(text, voice=self.style(voice), speed=float(speed), lang=lang)
        return np.asarray(samples, dtype=np.float32), int(sr)
