"""ClipForge's script writer (1.7.0). See ``engine`` for how it works and why.

``research`` finds the facts, ``Writer.write`` plans, hooks, drafts, reviews and rewrites, and
``to_sections`` turns a passed script into the sections the rest of the pipeline already uses
(footage matching, voice, captions are unchanged).
"""
from __future__ import annotations

from typing import Callable, Optional

from ..core.models import Section
from .engine import (AREAS, THRESHOLDS, ScriptRejected, ScriptResult, Writer, classify, game_note,  # noqa: F401
                     requested_count, requested_ending, word_range)


def research(prompt: str, subject: str, category: str, llm, log: Optional[Callable[[str], None]] = None,
             opener=None) -> tuple[list, list[dict]]:
    """Look the topic up (GTA Wiki + Wikipedia), asking the model which wiki pages to read first.
    Returns (sources, facts)."""
    from ..creative import factfind
    from . import prompts as P

    import copy
    import re

    queries: list[str] = []
    if llm is not None and hasattr(llm, "temperature"):      # looking things up is not a creative job
        llm = copy.copy(llm)
        llm.temperature = 0.2

    game = any(re.search(pat, (subject + " " + prompt).lower()) for pat, _api, _site in factfind.GAME_WIKIS)
    if llm is not None and game:
        try:
            d = llm.complete_json(P.SEARCH_SYSTEM, P.SEARCH_PROMPT.format(prompt=prompt[:600]), max_tokens=300)
            queries = [str(x).strip() for x in (d.get("pages") or []) + (d.get("searches") or [])
                       if str(x).strip()][:6]
        except Exception:  # noqa: BLE001
            queries = []
    secrets = bool(re.search(r"secret|easter egg|hidden|cheat", prompt or "", re.I))
    queries = list(dict.fromkeys(queries + factfind.default_queries(subject or prompt, prompt,
                                                                     "gaming" if secrets else "")))
    srcs = factfind.find_sources(prompt, subject or prompt, category or "gaming", queries=queries[:8], opener=opener,
                                 log=log)
    srcs = relevant(prompt, srcs, log)
    facts = factfind.extract_facts(prompt, srcs, llm, n=14) if (srcs and llm is not None) else []
    return srcs, facts


_GENERIC = set("""gta online story mode game games player players make makes making money fastest best fast quick
quickly explain explains what when where which while does work works worth buying buy most common mistake mistakes
tips tip secret secrets hidden mechanic mechanics feature features strategy finale using use your with that this from
into about short video channel understand""".split())


def keywords(prompt: str) -> set[str]:
    import re

    return {w for w in re.findall(r"[a-z0-9]+", (prompt or "").lower()) if len(w) > 3 and w not in _GENERIC}


def relevant(prompt: str, srcs: list, log=None) -> list:
    """2.0.2: keep pages that are actually about the request. For "the fastest way to lose a wanted
    level", the search had also returned the Scramjet, LF-22 Starling and a stunt race, and their
    "facts" ended up in the script."""
    keys = keywords(prompt)
    if not keys or not srcs:
        return srcs
    scored = []
    for s in srcs:
        title = (getattr(s, "title", "") or "").lower()
        text = (getattr(s, "text", "") or "").lower()
        hits = {k for k in keys if k in text}
        in_title = any(k in title for k in keys)
        need = 1 if len(keys) <= 2 else 2
        if in_title or len(hits) >= need:
            scored.append((in_title, len(hits), s))
        elif log:
            log(f"Fact research: left out '{getattr(s, 'title', '')}' (not about {', '.join(sorted(keys)[:4])})")
    scored.sort(key=lambda x: (-x[0], -x[1]))
    return [s for _, _, s in scored]


def to_sections(lines: list[str], claims: str = "") -> list[Section]:
    from ..creative.narration import clean_line, visuals_from_text

    secs = []
    for k, t in enumerate(lines):
        t = clean_line(t)
        if not t:
            continue
        role = "hook" if k == 0 else ("conclusion" if k == len(lines) - 1 and len(lines) > 2 else "point")
        secs.append(Section(sid=f"s{k + 1}", role=role, text=t, visuals=visuals_from_text(t), claims=claims))
    return secs
