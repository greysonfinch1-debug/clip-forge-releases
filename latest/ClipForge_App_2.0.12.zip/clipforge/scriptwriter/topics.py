"""Topic ideas (2.0.0): ideas for Shorts worth making, each checked against real sources.

1. The language model proposes ideas for the niche (it's told what was already made, so it
   doesn't repeat them), each with an angle, a reason to watch and the wiki pages that cover it.
2. A strict judge scores each idea 1-5 on: audience relevance, novelty, information value,
   curiosity, visual potential and timeliness.
3. Each of the best ideas is looked up (GTA Wiki / Wikipedia). Accuracy is scored from what was
   actually found: an idea nobody can source scores low and is marked "unverified".
4. Ideas too close to a video already made are dropped.

What this can't do (said in the window, not hidden): ClipForge has no access to YouTube's trend or
search data, so "timeliness" and "competition" are the model's judgement, not measurements.
"""
from __future__ import annotations

import copy
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

CRITERIA = ("relevance", "novelty", "value", "curiosity", "visual", "timeliness")
WEIGHTS = {"relevance": 1.2, "novelty": 1.0, "value": 1.5, "curiosity": 1.2, "visual": 0.8, "timeliness": 0.8,
           "accuracy": 1.5}
FORMATS = ("one specific tip", "hidden mechanic", "money-making method", "mistake players make",
           "feature explained", "mission strategy", "interesting discovery", "vehicle")

IDEAS_SYSTEM = """You find ideas for YouTube Shorts for a channel about {niche}. A good idea gives a player something worth knowing in under a minute: one specific mechanic, method, place, vehicle, mission or mistake, explained so they can use it. Not vague themes ("GTA secrets"), not news you can't check. Reply with JSON only."""

IDEAS_PROMPT = """Today is {today}. Channel niche: {niche}.
Already made (don't repeat these or near-copies): {done}

Give {n} different ideas, spread across these formats: {formats}.
For each: the topic as one specific line, the angle that makes it worth watching, why a player would stay to the end, which game it's about (GTA 5 Story Mode, GTA Online, GTA 6, ...), and 1-3 GTA Wiki page titles that would have the facts.
Return {{"ideas": [{{"topic": "...", "format": "...", "angle": "...", "why_watch": "...", "game": "...", "pages": ["..."]}}]}}"""

JUDGE_SYSTEM = """You judge YouTube Shorts ideas for a GTA channel, strictly. Most ideas are average: use the full 1-5 range and don't give everything 4s and 5s. Reply with JSON only."""

JUDGE_PROMPT = """Today is {today}. Score each idea 1-5 on:
relevance (do players of this game care?), novelty (not the same thing every channel says), value (does the viewer learn something they can use?), curiosity (would the first line make someone stop scrolling?), visual (can gameplay footage show it?), timeliness (does it matter right now?).

Ideas:
{ideas}

Return {{"scores": [{{"n": 1, "relevance": 3, "novelty": 3, "value": 3, "curiosity": 3, "visual": 3, "timeliness": 3, "weakness": "the main problem with this idea"}}]}}"""


@dataclass
class Idea:
    topic: str
    format: str = ""
    angle: str = ""
    why_watch: str = ""
    game: str = ""
    pages: list = field(default_factory=list)
    scores: dict = field(default_factory=dict)
    weakness: str = ""
    sources: list = field(default_factory=list)      # titles actually found
    total: float = 0.0

    @property
    def verified(self) -> bool:
        return len(self.sources) > 0

    def prompt(self) -> str:
        """A ready ClipForge prompt for this idea."""
        bits = [self.topic.rstrip(".") + "."]
        if self.angle:
            bits.append(f"Angle: {self.angle.rstrip('.')}.")
        if self.why_watch:
            bits.append(f"The viewer should come away knowing: {self.why_watch.rstrip('.')}.")
        bits.append("Talk like a creator explaining it to a friend who plays. Use gameplay footage as the background.")
        return " ".join(bits)

    def to_dict(self) -> dict:
        return {"topic": self.topic, "format": self.format, "angle": self.angle, "why_watch": self.why_watch,
                "game": self.game, "pages": self.pages, "scores": self.scores, "weakness": self.weakness,
                "sources": self.sources, "total": self.total, "prompt": self.prompt()}


def made_before() -> list[str]:
    """Titles and prompts of Shorts already exported (performance log) and projects."""
    out = []
    try:
        from ..performance import folder

        p = folder() / "exports.jsonl"
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                for k in ("title", "prompt"):
                    if d.get(k):
                        out.append(str(d[k])[:120])
    except Exception:  # noqa: BLE001
        pass
    return list(dict.fromkeys(out))[-40:]


def _words(t: str) -> set:
    stop = {"the", "a", "an", "in", "of", "to", "and", "for", "how", "why", "what", "gta", "5", "6", "online", "your",
            "you", "is", "on", "with", "this", "that", "most", "players"}
    return {w for w in re.findall(r"[a-z0-9]+", t.lower()) if w not in stop and len(w) > 2}


def too_close(topic: str, done: list[str], limit: float = 0.5) -> bool:
    a = _words(topic)
    for d in done:
        b = _words(d)
        if a and b and len(a & b) / min(len(a), len(b)) >= limit:
            return True
    return False


def _cool(llm, t: float):
    m = copy.copy(llm)
    if hasattr(m, "temperature"):
        m.temperature = t
    if hasattr(m, "on_text"):
        m.on_text = None
    return m


def find_ideas(llm, niche: str = "GTA 6, GTA 5 and GTA Online", n: int = 12, check: int = 8,
               progress: Optional[Callable[[float, str], None]] = None, opener=None,
               log: Optional[Callable[[str], None]] = None) -> list[Idea]:
    progress = progress or (lambda f, m: None)
    today = time.strftime("%B %d, %Y")
    done = made_before()
    progress(0.05, "Thinking of ideas")
    d = _cool(llm, 0.9).complete_json(IDEAS_SYSTEM.format(niche=niche),
                                       IDEAS_PROMPT.format(today=today, niche=niche, n=n,
                                                           done="; ".join(done[-25:]) or "nothing yet",
                                                           formats=", ".join(FORMATS)), max_tokens=2500)
    ideas = []
    for x in (d.get("ideas") or []) if isinstance(d, dict) else []:
        if not isinstance(x, dict) or not str(x.get("topic") or "").strip():
            continue
        it = Idea(topic=" ".join(str(x["topic"]).split())[:160], format=str(x.get("format") or "")[:40],
                  angle=str(x.get("angle") or "")[:240], why_watch=str(x.get("why_watch") or "")[:240],
                  game=str(x.get("game") or "")[:40],
                  pages=[str(p)[:80] for p in (x.get("pages") or []) if str(p).strip()][:3])
        if too_close(it.topic, done) or too_close(it.topic, [i.topic for i in ideas], 0.7):
            continue
        ideas.append(it)
    if not ideas:
        return []
    progress(0.3, f"Judging {len(ideas)} ideas")
    listing = "\n".join(f"{k}. {i.topic} | angle: {i.angle} | {i.game}" for k, i in enumerate(ideas, 1))
    try:
        j = _cool(llm, 0.1).complete_json(JUDGE_SYSTEM, JUDGE_PROMPT.format(today=today, ideas=listing),
                                          max_tokens=2000)
    except Exception:  # noqa: BLE001
        j = {}
    for r in (j.get("scores") or []) if isinstance(j, dict) else []:
        try:
            k = int(r.get("n")) - 1
        except (TypeError, ValueError, AttributeError):
            continue
        if 0 <= k < len(ideas):
            for c in CRITERIA:
                try:
                    ideas[k].scores[c] = max(1, min(5, int(r.get(c))))
                except (TypeError, ValueError):
                    pass
            ideas[k].weakness = str(r.get("weakness") or "")[:200]
    for i in ideas:
        for c in CRITERIA:
            i.scores.setdefault(c, 2)          # not judged = not assumed good
        i.total = _total(i)
    ideas.sort(key=lambda i: -i.total)
    # look the best ones up: accuracy comes from what's actually found
    from ..creative import factfind

    for k, i in enumerate(ideas[:check]):
        progress(0.4 + 0.55 * k / max(1, min(check, len(ideas))), f"Checking sources: {i.topic[:60]}")
        try:
            srcs = factfind.find_sources(i.topic, i.topic, "gaming", queries=(i.pages or [i.topic])[:2],
                                         opener=opener, log=log)
        except Exception:  # noqa: BLE001
            srcs = []
        i.sources = [s.title for s in srcs][:4]
        i.scores["accuracy"] = 5 if len(i.sources) >= 2 else 3 if i.sources else 1
        i.total = _total(i)
    for i in ideas[check:]:
        i.scores["accuracy"] = 1                   # not checked: can't be called verified
        i.total = _total(i)
    ideas.sort(key=lambda i: (-i.verified, -i.total))
    progress(1.0, "Done")
    return ideas


def _total(i: Idea) -> float:
    w = sum(WEIGHTS[c] for c in i.scores)
    return round(sum(WEIGHTS[c] * v for c, v in i.scores.items()) / (w or 1) * 2, 1)    # out of 10


def save(ideas: list[Idea], path: Path) -> None:
    path.write_text(json.dumps([i.to_dict() for i in ideas], indent=1, ensure_ascii=False), encoding="utf-8")
