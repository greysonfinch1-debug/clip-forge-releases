"""Topic ideas window (2.0.0): ideas checked against real sources; one click puts one in the prompt."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout)


class TopicIdeasDialog(QDialog):
    def __init__(self, page):
        super().__init__(page)
        self.page, self.win = page, page.win
        self.ideas = []
        self.setWindowTitle("Topic ideas")
        self.resize(1000, 640)
        lay = QVBoxLayout(self)
        intro = QLabel("ClipForge's AI suggests Short ideas, a strict second pass scores them, and the best ones are "
                       "looked up on the GTA Wiki and Wikipedia. Ideas with sources are marked ✓. Ideas close to "
                       "videos you've already exported are left out.\nClipForge can't see YouTube's trend or search "
                       "data, so timeliness is the AI's judgement, not a measurement.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        row = QHBoxLayout()
        row.addWidget(QLabel("Channel niche"))
        self.niche = QLineEdit("GTA 6, GTA 5 and GTA Online")
        row.addWidget(self.niche, 1)
        self.go = QPushButton("Find ideas")
        self.go.clicked.connect(self.find)
        row.addWidget(self.go)
        lay.addLayout(row)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Score", "Sources", "Format", "Idea", "Why watch / weakness"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setWordWrap(True)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.itemSelectionChanged.connect(self._show)
        self.table.cellDoubleClicked.connect(lambda *_: self.use())
        lay.addWidget(self.table, 1)
        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setMaximumHeight(130)
        lay.addWidget(self.detail)
        b = QHBoxLayout()
        b.addStretch(1)
        self.use_btn = QPushButton("Use this topic")
        self.use_btn.setEnabled(False)
        self.use_btn.clicked.connect(self.use)
        b.addWidget(self.use_btn)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        b.addWidget(close)
        lay.addLayout(b)

    def find(self):
        from ..scriptwriter.topics import find_ideas

        sv = self.win.pipeline.services
        if not sv.llm_available():
            self.detail.setPlainText("No language model is reachable. Start Ollama (or set up an API in Settings), "
                                     "then try again.")
            return
        llm = sv.writer_llm()
        niche = self.niche.text().strip() or "GTA"
        self.detail.setPlainText("Finding ideas… (about 1-3 minutes: ideas, scoring, then looking each one up)")
        self.go.setEnabled(False)

        def job(progress=None):
            return find_ideas(llm, niche, progress=(lambda f, m: progress("ideas", f, m)) if progress else None,
                              log=self.win.pipeline.log)

        def done(ideas):
            self.go.setEnabled(True)
            self.fill(ideas)

        self.win.run(job, done, title="Finding topic ideas", on_fail=lambda *_: self.go.setEnabled(True))

    def fill(self, ideas):
        self.ideas = ideas
        self.table.setRowCount(len(ideas))
        for r, i in enumerate(ideas):
            cells = (f"{i.total:.1f}", ("✓ " + str(len(i.sources))) if i.verified else "unverified", i.format,
                     i.topic, i.why_watch + (f"  (weak spot: {i.weakness})" if i.weakness else ""))
            for c, v in enumerate(cells):
                it = QTableWidgetItem(v)
                if c < 2:
                    it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(r, c, it)
        self.table.resizeRowsToContents()
        self.detail.setPlainText(f"{len(ideas)} ideas. Select one to see its scores and sources; double-click or "
                                 f"'Use this topic' puts it in the prompt box." if ideas else
                                 "No ideas came back from the language model. Try again, or try a bigger model.")

    def _show(self):
        r = self.table.currentRow()
        self.use_btn.setEnabled(0 <= r < len(self.ideas))
        if not 0 <= r < len(self.ideas):
            return
        i = self.ideas[r]
        sc = ", ".join(f"{k} {v}/5" for k, v in i.scores.items())
        self.detail.setPlainText(f"{i.topic}\nGame: {i.game}   Angle: {i.angle}\nScores: {sc}\n"
                                 f"Sources found: {', '.join(i.sources) or 'none (unverified: facts would need your notes)'}"
                                 f"\n\nPrompt it will use:\n{i.prompt()}")

    def use(self):
        r = self.table.currentRow()
        if 0 <= r < len(self.ideas):
            self.page.topic.setPlainText(self.ideas[r].prompt())
            self.accept()
