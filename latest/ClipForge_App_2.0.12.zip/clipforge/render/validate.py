"""Prompt validation of a finished render, before it counts as exported (2.0.9).

The technical QC (render/qc.py) checks the file; this checks the video against what the creator
asked for. From the creator's "Vice City" Short, which passed every technical check while breaking
the prompt: rewritten narration, two calls to action the prompt ruled out, 17.9 s for 30 s, two
caption styles, and the audio cut mid-word at the end.

Checks:
  narration   the voice says the given narration (word for word when "use exactly" is set): the
              plan's text exactly, and the rendered audio transcribed and compared
  length      within ±1 s of a length written in the prompt
  cta         no call to action / outro unless the prompt asks for one
  captions    one caption track (no two caption groups at once, no in-game speech when the game
              audio is muted) and one caption style
  overlap     no two pieces of on-screen text overlap
  ending      the audio doesn't stop in the middle of a word
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path

_CTA = re.compile(r"\b(follow|subscribe|like and)\b", re.I)
_W = re.compile(r"[a-z0-9]+")


@dataclass
class Check:
    name: str
    ok: bool
    detail: str


@dataclass
class Validation:
    checks: list[Check] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(c.ok for c in self.checks)

    def failures(self) -> list[Check]:
        return [c for c in self.checks if not c.ok]

    def summary(self) -> str:
        return "\n".join(f"{'PASS' if c.ok else 'FAIL'}  {c.name}: {c.detail}" for c in self.checks)


class ExportCheckFailed(ValueError):
    """The render doesn't follow the prompt. The file is kept, renamed, with the reasons."""


def _words(text: str) -> list[str]:
    t = (text or "").lower().replace("’", "'").replace("'", "")
    return _W.findall(t)


def _num_words(ws: list[str]) -> list[str]:
    """'24' and 'twenty four' compare equal enough: digits are kept as one token each."""
    return ws


def compare_words(expected: list[str], heard: list[str]) -> float:
    if not expected:
        return 1.0
    return difflib.SequenceMatcher(a=expected, b=heard, autojunk=False).ratio()


def _boxes(overlays, chunks, es) -> list[tuple[str, float, float, float, float]]:
    """(label, t0, t1, y_top, y_bottom) of every piece of on-screen text, in 1920-high pixels."""
    H = 1920
    cap_h = es.caption_size * 1.35
    cap_y = min(es.caption_position * H, H - 260)
    head_y = max(es.headline_position * H, 140)
    out = []
    for c in chunks:
        if c.words and c.end > c.start:
            out.append((f"caption {c.start:.1f}s", c.start, c.end, cap_y - cap_h / 2, cap_y + cap_h / 2))
    for o in overlays:
        if o.t_end <= o.t_start or not o.text.strip():
            continue
        size = es.headline_size
        if o.kind == "headline":
            top = o.position * H if o.position >= 0 else head_y
            lines = 1 + len(o.text) // 22
            out.append((f"title '{o.text[:30]}'", o.t_start, o.t_end, top, top + size * 1.4 * lines + 36))
        elif o.kind == "context" and re.match(r"#\d+\b", o.text.strip()):
            top = o.position * H if o.position >= 0 else head_y
            out.append((f"rank '{o.text[:12]}'", o.t_start, o.t_end, top, top + size * 2.4 * 1.2))
        elif o.kind == "context":
            top = o.position * H if o.position >= 0 else head_y + size * 2.6
            out.append((f"label '{o.text[:30]}'", o.t_start, o.t_end, top, top + es.caption_size * 0.9))
        elif o.kind == "end":
            y = o.position * H if o.position >= 0 else H * 0.45
            out.append((f"end card '{o.text[:30]}'", o.t_start, o.t_end, y - size * 0.7, y + size * 0.7))
        else:
            y = o.position * H if o.position >= 0 else H * 0.5
            out.append((f"text '{o.text[:30]}'", o.t_start, o.t_end, y - size * 0.7, y + size * 0.7))
    return out


def caption_styles(chunks, es) -> set[str]:
    """The subtitle styles the captions are actually drawn with (from the same writer the render uses)."""
    import tempfile

    from .captions import write_ass

    p = Path(tempfile.mkdtemp()) / "check.ass"
    try:
        txt = write_ass(p, chunks, [], es).read_text(encoding="utf-8")
    finally:
        p.unlink(missing_ok=True)
    return {m.group(1) for m in re.finditer(r"^Dialogue: \d+,[^,]*,[^,]*,([^,]+),", txt, re.M)}


def transcribe_file(path: str, transcriber) -> list:
    """Word timings of a rendered video (ClipForge's own speech model). [] if it can't run."""
    import subprocess
    import tempfile

    import numpy as np
    import soundfile as sf

    from ..core import ffmpeg as ff

    wav = Path(tempfile.mkdtemp()) / "check.wav"
    subprocess.run([ff.ffmpeg_bin(), "-v", "error", "-y", "-i", str(path), "-ac", "1", "-ar", "16000", str(wav)],
                   capture_output=True, creationflags=ff._NO_WINDOW)
    try:
        audio, _sr = sf.read(str(wav), dtype="float32")
        return list(transcriber._decode(np.asarray(audio, np.float32), 0.0))
    finally:
        wav.unlink(missing_ok=True)


def validate(path: str, plan, tl, chunks, overlays, es, spec, heard: list | None) -> Validation:
    """``heard``: word timings of the rendered audio (None = the speech model wasn't available)."""
    v = Validation()
    narr_text = " ".join(ln.text for ln in plan.narration)
    # 1. narration
    if spec.verbatim_lines:
        given = " ".join(spec.verbatim_lines)
        same = _words(narr_text) == _words(given)
        v.checks.append(Check("Narration is your exact text", same,
                              "the script is your lines, unchanged" if same else
                              f"expected \"{given[:120]}\", the script says \"{narr_text[:120]}\""))
    if heard is not None and narr_text.strip():
        exp = _words(narr_text) if spec.verbatim_lines or es.original_audio_db <= -60 else []
        if exp:
            got = _words(" ".join(w.text for w in heard))
            r = compare_words(exp, got)
            extra = max(0, len(got) - len(exp))
            ok = r >= 0.85 and extra <= max(2, 0.15 * len(exp))
            v.checks.append(Check("The voice says the narration (and nothing else)", ok,
                                  f"{r * 100:.0f}% word match, {len(got)} words heard for {len(exp)} expected"
                                  + ("" if ok else f'; heard: "{" ".join(got)[:160]}"')))
    elif heard is None:
        v.checks.append(Check("The voice says the narration", True, "not checked: the speech model isn't available"))
    # 2. length
    if spec.seconds:
        ok = abs(tl.duration - spec.seconds) <= 1.0
        v.checks.append(Check("Length", ok, f"{tl.duration:.1f} s for the {spec.seconds:.0f} s asked for"))
    # 3. call to action
    if spec.cta != "requested":
        texts = [("narration", ln.text) for ln in plan.narration] + [(f"{o.kind} text", o.text) for o in overlays]
        bad = [f"{k}: \"{t[:50]}\"" for k, t in texts if _CTA.search(t or "")]
        given = " ".join(spec.verbatim_lines)
        bad = [b for b in bad if not (given and _CTA.search(given) and b.startswith("narration"))]
        v.checks.append(Check("No call to action / outro (none asked for)", not bad,
                              "none" if not bad else "; ".join(bad)))
    # 4. captions: one track, one style
    shown = sorted((c for c in chunks if c.words and c.end > c.start), key=lambda c: c.start)
    clash = [(a, b) for a, b in zip(shown, shown[1:]) if b.start < a.end - 0.02]
    kinds = {c.kind for c in shown}
    muted_speech = es.original_audio_db <= -60 and any(c.kind != "narration" for c in shown)
    v.checks.append(Check("One caption track", not clash and not muted_speech,
                          "one caption at a time" if not (clash or muted_speech) else
                          (f"{len(clash)} time(s) two captions are on screen together" if clash else
                           "captions of in-game speech while the game audio is muted")))
    styles = caption_styles(chunks, es)
    one_style = len(styles) <= 1
    v.checks.append(Check("One caption style", one_style,
                          f"all captions use {next(iter(styles), 'the caption style')} ({', '.join(sorted(kinds)) or '-'})"
                          if one_style else f"styles used: {', '.join(sorted(styles))}"))
    # 5. overlapping text
    boxes = _boxes(overlays, chunks, es)
    over = []
    for i, a in enumerate(boxes):
        for b in boxes[i + 1:]:
            if a[0].startswith("caption") and b[0].startswith("caption"):
                continue              # (caption groups are checked above)
            if min(a[2], b[2]) - max(a[1], b[1]) > 0.05 and min(a[4], b[4]) - max(a[3], b[3]) > 4:
                over.append(f"{a[0]} and {b[0]} at {max(a[1], b[1]):.1f}s")
    v.checks.append(Check("No overlapping text", not over, "none" if not over else "; ".join(over[:4])))
    # 6. the end
    end_ok, why = True, "the last words finish before the video ends"
    last_narr = max((p.out_start + p.line.duration for p in tl.narration), default=0.0)
    if last_narr > tl.duration - 0.05:
        end_ok, why = False, f"the narration runs to {last_narr:.2f} s, past the end ({tl.duration:.2f} s)"
    if es.original_audio_db > -60:
        cut = [w for w, _ in tl.dialogue_words if w.start < tl.duration - 0.05 < w.end]
        if cut:
            end_ok, why = False, f"speech in the clip is cut off at the end (\"{cut[-1].text}\")"
    if heard:
        lw = heard[-1]
        if lw.end >= tl.duration - 0.08 and lw.end - lw.start > 0:
            end_ok, why = False, f"the audio stops while \"{lw.text}\" is being said ({lw.end:.2f} s of {tl.duration:.2f} s)"
    v.checks.append(Check("Audio doesn't stop mid-word", end_ok, why))
    return v


def fail_export(path: Path, v: Validation) -> Path:
    """Rename the render so it can't be mistaken for a finished export, and raise with the reasons."""
    bad = path.with_name(path.stem + "_CHECK-FAILED" + path.suffix)
    try:
        path.replace(bad)
        side = path.with_suffix(".txt")
        if side.exists():
            side.replace(bad.with_suffix(".txt"))
    except OSError:
        bad = path
    raise ExportCheckFailed(
        "The video doesn't follow your prompt, so it wasn't exported as finished:\n- "
        + "\n- ".join(f"{c.name}: {c.detail}" for c in v.failures())
        + f"\n\nThe render was kept for you to look at: {bad.name}")
