"""Voice direction (1.8.0): what ClipForge decides about HOW each line is read, before the voice
engine sees it. Only levers the engine really has are used (measured on Kokoro, 2026-11-18):

  * pace: Kokoro's own speed input (a real tempo change, no pitch tricks);
  * question intonation: "?" gives a real rise at the end (+2.6 semitones vs -1.6 without);
  * pauses: between thoughts, chosen per line (short between connected lines, longer before a
    reveal or the call to action) instead of the same gap after every line;
  * continuity: consecutive lines with the same pace are spoken in ONE recording, so sentences flow
    into each other, and cut apart at the voice's own pauses;
  * pronunciation: a GTA lexicon (phonemes) and number/money/unit normalisation, for the voice only:
    captions keep the script's own words.

What Kokoro can NOT do (tested, so not pretended): "!" changes nothing, there is no emotion or
emphasis control, and pitch can't be steered without degrading the audio.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# ------------------------------------------------------------------ pronunciation
# term -> phonemes in Kokoro's (espeak-style IPA) alphabet. Only words espeak gets wrong.
LEXICON = {
    "Leonida": "lˌiːoʊnˈiːdə",
    "Cayo Perico": "kˈaɪoʊ pəɹˈiːkoʊ",
    "Kosatka": "koʊsˈɑːtkə",
    "Paleto": "pəlˈɛɾoʊ",
    "Akula": "ɐkˈuːlə",
    "Pegassi": "pəɡˈɑːsi",
    "Kuruma": "kʊɹˈuːmə",
    "Lucia": "luːsˈiːə",
    "Chiliad": "tʃˈɪliˌæd",
    "Vinewood": "vˈaɪnwʊd",
    "Pfister": "fˈɪstɚ",
    "Ocelot": "ˈɑːsəlˌɑːt",
}
_LEX_RE = re.compile(r"\b(" + "|".join(re.escape(k) for k in sorted(LEXICON, key=len, reverse=True)) + r")\b")

_NUM = r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?"
_SCALE = {"k": "thousand", "m": "million", "b": "billion", "thousand": "thousand", "million": "million",
          "billion": "billion", "mil": "million"}
_ROMAN = {"II": "two", "III": "three", "IV": "four", "V": "five", "2": "two", "3": "three", "4": "four", "5": "five"}


def _money(m: re.Match) -> str:
    n, scale = m.group(1), (m.group(2) or "").lower()
    word = _SCALE.get(scale, "")
    return f"{n} {word} dollars".replace("  ", " ") if word else f"{n} dollars"


def speakable(text: str) -> str:
    """The script line as the voice should say it (captions never see this)."""
    t = text
    t = re.sub(r"\$\s?(" + _NUM + r")(?:\s?(k|m|b|mil|thousand|million|billion)\b)?", _money, t, flags=re.I)
    t = re.sub(r"\b(" + _NUM + r")(k|m|b)\b", lambda m: f"{m.group(1)} {_SCALE[m.group(2).lower()]}", t)
    t = re.sub(r"\bMk\.?\s?(II|III|IV|V|2|3|4|5)\b", lambda m: "Mark " + _ROMAN[m.group(1)], t)
    t = re.sub(r"\b2x\b", "double", t, flags=re.I)
    t = re.sub(r"\b3x\b", "triple", t, flags=re.I)
    t = re.sub(r"\b(\d+)x\b", r"\1 times", t, flags=re.I)
    t = t.replace("&", " and ").replace("%", " percent").replace("+", " plus ")
    t = t.replace("…", "...").replace("!", ".")           # "!" does nothing in Kokoro; avoid odd phrasing
    # 2.0.12: Kokoro stops for a long beat at a colon ("One: robbing…"); a comma keeps the flow
    t = re.sub(r"(?<=\w):\s+", ", ", t)
    t = re.sub(r"\.{4,}", "...", t)
    return re.sub(r"\s+", " ", t).strip()


def lexicon_parts(text: str) -> list[tuple[str, bool]]:
    """Split a speakable line into (text, False) chunks and (phonemes, True) lexicon terms."""
    out, pos = [], 0
    for m in _LEX_RE.finditer(text):
        if m.start() > pos:
            out.append((text[pos:m.start()], False))
        out.append((LEXICON[m.group(1)], True))
        pos = m.end()
    if pos < len(text):
        out.append((text[pos:], False))
    return out


# ------------------------------------------------------------------ direction
@dataclass
class Direction:
    intent: str          # hook / question / reveal / mistake / step / explain / payoff / cta
    pace: float          # speed factor on top of the creator's speed
    pause_after: float   # seconds of picture/silence after the line, before the next one
    text: str            # what the voice says


PACE = {"hook": 1.05, "question": 1.0, "reveal": 0.96, "mistake": 1.03, "step": 1.0, "explain": 1.0,
        "payoff": 0.96, "cta": 1.03}
_REVEAL = re.compile(r"\b(but|actually|turns out|the (?:catch|trick|secret|reason)|here'?s (?:the|why|how|what)|"
                     r"most (?:players|people)|nobody|no one|never|instead|the best part|that'?s why|which means)\b",
                     re.I)
_MISTAKE = re.compile(r"^\s*(stop|don'?t|never|avoid|quit)\b|\b(mistake|wasting|you'?re losing|you lose)\b", re.I)
_STEP = re.compile(r"^\s*(first|then|next|after that|now|finally|step \w+|go to|open|assign|buy|grab|head)\b", re.I)
_CTA = re.compile(r"\b(follow|subscribe|like and|comment|part two|next video)\b", re.I)
_FLOW = re.compile(r"^\s*(so|and|then|that means|which|because|plus|also|that way|this way)\b", re.I)


def intent_of(text: str, role: str, k: int, n: int) -> str:
    if role == "hook" or (k == 0 and n > 1 and not role):
        return "hook"
    if text.rstrip().endswith("?"):
        return "question"
    if _CTA.search(text) and k >= n - 2:
        return "cta"
    if _MISTAKE.search(text):
        return "mistake"
    if _STEP.search(text):
        return "step"
    if _REVEAL.search(text):
        return "reveal"
    if role == "payoff" or (k == n - 2 and n >= 4):
        return "payoff"
    return "explain"


def direct(texts: list[str], roles: list[str] | None = None) -> list[Direction]:
    """One Direction per narration line, from what each line says and where it sits."""
    roles = roles or [""] * len(texts)
    n = len(texts)
    out = []
    for k, (t, r) in enumerate(zip(texts, roles)):
        it = intent_of(t, r, k, n)
        out.append(Direction(it, PACE[it], PAUSE["base"], speakable(t)))
    # pauses: a breath after the hook, short into a line that continues the thought, a little longer
    # before a reveal, the payoff and the call to action. 2.0.12: all shorter (the creator heard "random
    # small pauses", the longest 0.62 s straight after the hook); a Short's narration runs on.
    for k in range(n - 1):
        nxt_t, nxt = texts[k + 1], out[k + 1]
        p = PAUSE["base"]
        if out[k].intent == "hook":
            p = PAUSE["hook"]
        if _FLOW.search(nxt_t):
            p = PAUSE["flow"]
        if nxt.intent in ("reveal", "payoff"):
            p = PAUSE["reveal"]
        if nxt.intent == "cta":
            p = PAUSE["cta"]
        if out[k].intent == "question":
            p = PAUSE["question"]
        out[k].pause_after = p
    if out:
        # the video ends this long after the last word (2.0.12: with the shorter pauses the last word ran
        # into the end of the video; the prompt check caught it)
        out[-1].pause_after = PAUSE["end"]
    return out


# seconds of silence after a line (1.8.0 used 0.40 / 0.50 / 0.28 / 0.55 / 0.50 / 0.45)
PAUSE = {"base": 0.20, "hook": 0.22, "flow": 0.12, "reveal": 0.30, "cta": 0.25, "question": 0.28, "end": 0.60}
