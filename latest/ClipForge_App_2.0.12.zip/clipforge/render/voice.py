"""Narration audio: synthesis (cached per line) and word timing for captions."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import numpy as np

from ..core.cache import SourceCache, stable_id
from ..core.models import NarrationLine, Word


ENGINE = "dir3"          # bump when the way narration is made changes (new audio, old cache unused)
# 2.0.12: longest silence kept inside a line. Kokoro breaks phrases with silences of 0.18-0.4 s (one after
# "These four mistakes" in the creator's hook, heard as a pause "at the beginning"); 0.12 s is still longer
# than a stop consonant's closure, so words are never shortened.
MAX_INNER_PAUSE = 0.12
GROUP_CHARS = 380         # one recording stays inside one Kokoro batch (~510 phonemes)
TARGET_RMS_DB = -20.0     # speech level of every recording (RMS of the voiced part), not per-line peaks
# kept so older code and projects still import it; 1.8.0 direction replaces the 1.6.4 table
DELIVERY = {"hook": (1.05, 0.0, 1.0), "point": (1.0, 0.0, 1.0), "point2": (1.0, 0.0, 1.0),
            "payoff": (0.96, 0.0, 1.0), "end": (1.03, 0.0, 1.0)}
SPELL: set = set()


def tts_text(text: str) -> str:
    """What the voice says for a script line (numbers, money, units, Mk II…). Captions keep the
    script's words. 1.8.0: initialisms are left as written: espeak already says "GTA" as G-T-A, and
    1.6.4's "G T A" spacing made it say "gee tee uh" (heard as "GTI")."""
    from .voice_direction import speakable

    return speakable(text)


def _speak(tts, text: str, voice: str, speed: float) -> tuple[np.ndarray, int]:
    """One recording. GTA names from the lexicon are given to the voice as phonemes."""
    from .voice_direction import lexicon_parts

    parts = lexicon_parts(text)
    if hasattr(tts, "synthesize_phonemes") and any(is_ph for _, is_ph in parts):
        ph = " ".join((chunk if is_ph else tts.phonemize(chunk)).strip() for chunk, is_ph in parts if chunk.strip())
        return tts.synthesize_phonemes(ph, voice, speed)
    return tts.synthesize(text, voice, speed)


def _pauses(x: np.ndarray, sr: int, min_len: float = 0.10) -> list[tuple[float, float]]:
    hop = int(0.01 * sr)
    if len(x) < hop * 3:
        return []
    fr = x[: len(x) // hop * hop].reshape(-1, hop)
    db = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-9)
    quiet = db < db.max() - 38
    out, run = [], 0
    for k, q in enumerate(list(quiet) + [False]):
        if q:
            run += 1
        else:
            if run * 0.01 >= min_len and k - run > 0 and k < len(quiet):
                out.append(((k - run) * 0.01, k * 0.01))
            run = 0
    return out


def _split(x: np.ndarray, sr: int, texts: list[str]) -> list[np.ndarray] | None:
    """Cut one recording of several lines back into lines, at the pause nearest each expected
    boundary (expected from the length of each line). None if a boundary has no clear pause."""
    total = len(x) / sr
    w = np.array([max(1, len(t)) for t in texts], float)
    expect = np.cumsum(w)[:-1] / w.sum() * total
    ps = _pauses(x, sr)
    cuts, used = [], -1
    for e in expect:
        best = None
        for j, (a, b) in enumerate(ps):
            if j <= used:
                continue
            c = (a + b) / 2
            if abs(c - e) > max(0.8, total * 0.12):
                continue
            score = abs(c - e) - 1.5 * (b - a)
            if best is None or score < best[0]:
                best = (score, j, c)
        if best is None:
            return None
        used = best[1]
        cuts.append(best[2])
    bounds = [0] + [int(c * sr) for c in cuts] + [len(x)]
    pieces = [x[a:b] for a, b in zip(bounds, bounds[1:])]
    return pieces if all(len(p) > 0.3 * sr for p in pieces) else None


def _groups(dirs) -> list[list[int]]:
    """Consecutive lines read at the same pace become one recording (natural joins); a pace change,
    a long pause or the length limit starts a new one."""
    out: list[list[int]] = []
    for i, d in enumerate(dirs):
        if out:
            g = out[-1]
            prev = dirs[g[-1]]
            chars = sum(len(dirs[j].text) for j in g) + len(d.text)
            if abs(prev.pace - d.pace) < 0.015 and prev.pause_after < 0.5 and chars <= GROUP_CHARS and len(g) < 4:
                g.append(i)
                continue
        out.append([i])
    return out


def _level(pieces: list[np.ndarray], gain: float) -> list[np.ndarray]:
    allx = np.concatenate(pieces) if pieces else np.zeros(1, np.float32)
    voiced = allx[np.abs(allx) > 0.02 * (np.abs(allx).max() or 1)]
    rms = float(np.sqrt(np.mean(voiced ** 2))) if len(voiced) else 0.0
    peak = float(np.abs(allx).max()) or 1.0
    g = (10 ** (TARGET_RMS_DB / 20) / rms) if rms > 0 else 1.0
    g = min(g * gain, 0.95 / peak)            # never clip; no compression
    return [(p * g).astype(np.float32) for p in pieces]


def synthesize_lines(lines: list[NarrationLine], tts, voice: str, speed: float, volume_db: float,
                     cache: SourceCache, progress=None) -> None:
    """Voice every narration line (1.8.0): direct the script (pace, pauses, pronunciation), speak
    runs of same-pace lines as one recording, cut them back into lines at the voice's own pauses,
    and give every recording the same speech level. Each line still gets its own file, so the
    timeline and captions work exactly as before."""
    import soundfile as sf

    from .. import cancel
    from .voice_direction import direct

    out_dir = cache.subdir("narration")
    gain = 10 ** (volume_db / 20)
    dirs = direct([ln.text for ln in lines], [getattr(ln, "delivery", "") or "" for ln in lines])
    for ln, d in zip(lines, dirs):
        ln.pause_after = d.pause_after
    done = 0
    for g in _groups(dirs):
        cancel.check()
        texts = [dirs[i].text for i in g]
        pace = dirs[g[0]].pace
        key = stable_id(ENGINE, voice, f"{speed * pace:.3f}", f"{volume_db:.1f}", getattr(tts, "name", "tts"), *texts)
        paths = [out_dir / f"n_{key}_{j}.wav" for j in range(len(g))]
        if not all(p.exists() for p in paths):
            pieces, sr = None, 24000
            if len(g) > 1:
                joined = " ".join(t if t[-1:] in ".?!" else t + "." for t in texts)
                x, sr = _speak(tts, joined, voice, speed * pace)
                pieces = _split(x, sr, texts)
            if pieces is None:            # one line, or no clean pause to cut at: each line on its own
                pieces = []
                for t in texts:
                    cancel.check()                # Cancel stops before the next line, as before
                    x, sr = _speak(tts, t, voice, speed * pace)
                    pieces.append(x)
            pieces = [tighten_pauses(_trim_silence(p, sr), sr) for p in pieces]
            pieces = _level(pieces, gain)
            fade = int(0.01 * sr)
            for p, path in zip(pieces, paths):
                if len(p) > 2 * fade:
                    p[:fade] *= np.linspace(0, 1, fade)
                    p[-fade:] *= np.linspace(1, 0, fade)
                tmp = path.with_name(path.stem + ".partial.wav")
                sf.write(tmp, p.astype(np.float32), sr)
                tmp.replace(path)
        for i, path in zip(g, paths):
            info = sf.info(str(path))
            lines[i].audio_path = str(path)
            lines[i].duration = float(info.duration)
            done += 1
            if progress:
                progress(done / max(1, len(lines)), f"Voicing line {done}/{len(lines)}")
    check_voiced(lines, tts, voice, speed, volume_db, out_dir)


def check_voiced(lines, tts, voice, speed, volume_db, out_dir) -> None:
    """2.0.0: no line goes into the edit without real audio. A line whose file is missing, empty or
    far too short for its words is voiced once more on its own; if that fails too, the step stops
    with a message naming the line (instead of a silent gap and missing captions in the video)."""
    import soundfile as sf

    for k, ln in enumerate(lines, 1):
        if not (ln.text or "").strip():
            continue
        n = len(ln.text.split())
        ok = bool(ln.audio_path) and Path(ln.audio_path).exists() and ln.duration >= max(0.25, 0.12 * n)
        if ok:
            continue
        try:
            x, sr = _speak(tts, tts_text(ln.text), voice, speed)
            x = _level([_trim_silence(x, sr)], 10 ** (volume_db / 20))[0]
            path = Path(out_dir) / f"n_retry_{stable_id(ENGINE, voice, ln.text)}.wav"
            sf.write(path, x, sr)
            ln.audio_path, ln.duration = str(path), len(x) / sr
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"The voice produced no usable audio for line {k} (\"{ln.text[:60]}\"): {e}. "
                               f"Try again, or pick another voice in Script & Voice.") from e
        if ln.duration < max(0.25, 0.12 * n):
            raise RuntimeError(f"The voice produced only {ln.duration:.2f} s of audio for line {k} "
                               f"(\"{ln.text[:60]}\"). Try again, or pick another voice in Script & Voice.")


def tighten_pauses(x: np.ndarray, sr: int, max_gap: float = MAX_INNER_PAUSE) -> np.ndarray:
    """Shorten every silence inside a recording to at most ``max_gap`` seconds (2.0.12: the creator heard
    "random small pauses"). The cut is made in the middle of the silence with a short crossfade, so no
    word is touched and there's no click."""
    hop = int(0.01 * sr)
    if len(x) < hop * 10:
        return x
    fr = x[: len(x) // hop * hop].reshape(-1, hop)
    db = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-9)
    quiet = db < db.max() - 40
    keep_frames = int(max_gap / 0.01)
    out, pos, k, n = [], 0, 0, len(quiet)
    while k < n:
        if not quiet[k]:
            k += 1
            continue
        j = k
        while j < n and quiet[j]:
            j += 1
        if k > 0 and j < n and j - k > keep_frames:          # a pause inside speech, longer than allowed
            a = (k + keep_frames // 2) * hop                 # keep half the allowed pause on each side
            b = (j - (keep_frames - keep_frames // 2)) * hop
            out.append(x[pos:a])
            pos = b
        k = j
    if not out:
        return x
    out.append(x[pos:])
    fade = int(0.008 * sr)
    y = out[0]
    for seg in out[1:]:
        if len(y) > fade and len(seg) > fade:
            ramp = np.linspace(0, 1, fade, dtype=np.float32)
            y = np.concatenate([y[:-fade], y[-fade:] * (1 - ramp) + seg[:fade] * ramp, seg[fade:]])
        else:
            y = np.concatenate([y, seg])
    return y.astype(np.float32)


def _trim_silence(x: np.ndarray, sr: int, thr: float = 0.01) -> np.ndarray:
    idx = np.where(np.abs(x) > thr * (float(np.abs(x).max()) or 1.0) / 0.5)[0] if len(x) else []
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(0.03 * sr))
    b = min(len(x), idx[-1] + int(0.06 * sr))          # (2.0.12: 0.10 s of trailing silence added to every gap)
    return x[a:b]


def narration_word_times(line: NarrationLine, transcriber=None) -> list[Word]:
    """Word timings inside a narration clip. Uses the speech recogniser for exact timings when
    available (it is already loaded), otherwise distributes time by syllable estimate."""
    words = line.text.split()
    if not words:
        return []
    if transcriber is not None and getattr(transcriber, "name", "") == "parakeet":
        try:
            import soundfile as sf

            audio, sr = sf.read(line.audio_path, dtype="float32")
            if sr != 16000:
                n = int(len(audio) * 16000 / sr)
                audio = np.interp(np.linspace(0, len(audio), n, endpoint=False), np.arange(len(audio)), audio
                                  ).astype(np.float32)
            rec_words = transcriber._decode(audio, 0.0)
            if rec_words and abs(len(rec_words) - len(words)) <= max(2, len(words) // 4):
                return _align(words, rec_words, line.duration)
        except Exception:
            pass
    return _estimate(words, line.duration)


def _syllables(w: str) -> int:
    w = re.sub(r"[^a-z]", "", w.lower())
    if not w:
        return 1
    return max(1, len(re.findall(r"[aeiouy]+", w)) - (1 if w.endswith("e") and len(w) > 3 else 0))


def _estimate(words: list[str], dur: float) -> list[Word]:
    weights = np.array([_syllables(w) + (0.6 if re.search(r"[,.!?]$", w) else 0) for w in words], float)
    t = np.concatenate([[0], np.cumsum(weights)]) / weights.sum() * dur
    return [Word(w, float(t[i]), float(t[i + 1])) for i, w in enumerate(words)]


def _align(script_words: list[str], rec: list[Word], dur: float) -> list[Word]:
    """Use the script's spelling with the recogniser's timings (sequence alignment by position)."""
    import difflib

    a = [re.sub(r"[^a-z0-9]", "", w.lower()) for w in script_words]
    b = [re.sub(r"[^a-z0-9]", "", w.text.lower()) for w in rec]
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    times: list[Optional[tuple[float, float]]] = [None] * len(a)
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            r = rec[blk.b + k]
            times[blk.a + k] = (r.start, r.end)
    # fill gaps by interpolation
    est = _estimate(script_words, dur)
    out = []
    for i, w in enumerate(script_words):
        if times[i] is not None:
            out.append(Word(w, *times[i]))
        else:
            prev_end = out[-1].end if out else 0.0
            nxt = next((times[j][0] for j in range(i + 1, len(a)) if times[j] is not None), dur)
            span = max(0.12, (nxt - prev_end))
            missing = next((j for j in range(i + 1, len(a)) if times[j] is not None), len(a)) - i
            out.append(Word(w, prev_end, prev_end + span / max(1, missing)))
    for i in range(len(out) - 1):
        out[i].end = min(max(out[i].end, out[i].start + 0.08), out[i + 1].start + 0.02)
    _ = est
    return out
