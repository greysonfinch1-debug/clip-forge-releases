"""Storytelling: clip order, hook options and grounded narration.

The language model sees every selected clip's verified description and transcript and
arranges them into hook → context → escalation → peak → payoff, explaining each
placement. It then writes hooks and narration that may only describe what the evidence
shows. Narration is checked afterwards: quotes that don't appear in the transcript are
removed, and the total length is kept inside the word budget for the Short.
"""
from __future__ import annotations

import re
from typing import Optional

from ..core.models import Candidate, HookOption, NarrationLine, StoryItem, TopicSpec, Transcript
from ..providers.base import LLM, ProviderUnavailable

WORDS_PER_SECOND = 2.6

# ----------------------------------------------------------------------------- ordering

ORDER_SYSTEM = """You are the editor of a YouTube Short built from gameplay livestream clips.
Arrange the clips into the most engaging, coherent sequence:
- Open with the clip whose first seconds grab attention best (hook). The editor automatically opens the Short with a 2-3 second flash-forward of the LAST clip's peak, so save the single strongest moment for the end.
- Then build: context, escalation, and finish on the strongest moment (payoff).
- If clips are parts of the SAME continuous event (close in source time and the evidence shows it continues), keep them in chronological order.
- Never put two near-identical moments back to back.
- Base every decision only on the descriptions given. Reply with JSON only."""

ORDER_PROMPT = """Short topic: {topic}

Clips (source_time = where it happens in the original video):
{clips}

Return JSON: {{"order": [{{"id": clip id, "role": "hook|context|escalation|peak|payoff", "rationale": one sentence why it goes here}}, ...]}}
Use every clip id exactly once."""


def order_story(chosen: list[Candidate], spec: TopicSpec, llm: LLM) -> tuple[list[StoryItem], str]:
    if not chosen:
        return [], "none"
    if spec.format == "countdown":
        return countdown_order(chosen), "countdown"
    if spec.format == "story":
        return [StoryItem(cid=c.cid, role=f"part {i + 1}", rationale="In the order it happened (the request asks for "
                          "the story).", start=c.start, end=c.end)
                for i, c in enumerate(sorted(chosen, key=lambda c: c.start))], "chronological"
    if len(chosen) == 1:
        c = chosen[0]
        return [StoryItem(cid=c.cid, role="peak", rationale="Only clip selected.", start=c.start, end=c.end)], "rules"
    by_id = {c.cid: c for c in chosen}
    try:
        clips = "\n".join(
            f"- id={c.cid} source_time={c.start:.0f}s duration={c.duration:.0f}s entertainment={c.entertainment:.0f}/10 "
            f"hook_potential={c.hook_potential:.0f}/10: {c.description}" for c in chosen)
        d = llm.complete_json(ORDER_SYSTEM, ORDER_PROMPT.format(topic=spec.summary, clips=clips), max_tokens=900)
        order = d.get("order") or d.get("items") or []
        items, seen = [], set()
        for o in order:
            cid = str(o.get("id", "")) if isinstance(o, dict) else str(o)
            if cid in by_id and cid not in seen:
                c = by_id[cid]
                seen.add(cid)
                items.append(StoryItem(cid=cid, role=str(o.get("role", "")) if isinstance(o, dict) else "",
                                       rationale=str(o.get("rationale", ""))[:240] if isinstance(o, dict) else "",
                                       start=c.start, end=c.end))
        if len(items) == len(chosen):
            return _fix_continuity(items, by_id), "llm"
    except ProviderUnavailable:
        pass
    return rule_order(chosen), "rules"


def countdown_order(chosen: list[Candidate]) -> list[StoryItem]:
    """The request asks for a ranking: the highest-scoring moment is #1 and comes last."""
    ranked = sorted(chosen, key=lambda c: (c.final_score, c.entertainment))
    n = len(ranked)
    return [StoryItem(cid=c.cid, role=f"#{n - i}",
                      rationale=f"Ranked #{n - i} of {n}: score {c.final_score:.0f}/100 (topic {c.topic_match:.0f}/10, "
                                f"entertainment {c.entertainment:.0f}/10).", start=c.start, end=c.end)
            for i, c in enumerate(ranked)]


def rank_of(story: list[StoryItem], i: int) -> int:
    """#k of story item i in a countdown (0 when the Short isn't a countdown)."""
    r = story[i].role if 0 <= i < len(story) else ""
    return int(r[1:]) if r.startswith("#") and r[1:].isdigit() else 0


def rule_order(chosen: list[Candidate]) -> list[StoryItem]:
    """Hook first, then rising entertainment, strongest payoff last; continuous events stay in order."""
    groups: list[list[Candidate]] = []
    for c in sorted(chosen, key=lambda c: c.start):
        if groups and c.start - groups[-1][-1].end < 10:
            groups[-1].append(c)
        else:
            groups.append([c])

    def g_score(g, attr):
        return max(getattr(c, attr) for c in g)

    # The most entertaining moment is the payoff and goes LAST (the edit opens with a short
    # flash-forward of it, so it still hooks the viewer); the best remaining opener goes first.
    payoff = max(groups, key=lambda g: (g_score(g, "entertainment"), g_score(g, "final_score")))
    rest = [g for g in groups if g is not payoff]
    if rest:
        hook = max(rest, key=lambda g: (g_score(g, "hook_potential"), g_score(g, "final_score")))
        middle = sorted([g for g in rest if g is not hook], key=lambda g: g_score(g, "entertainment"))
        seq = [hook] + middle + [payoff]
    else:
        hook, payoff, seq = payoff, None, [payoff]
    items: list[StoryItem] = []
    for gi, g in enumerate(seq):
        for k, c in enumerate(g):
            if gi == 0 and k == 0:
                role, why = "hook", f"Strongest opening (hook potential {c.hook_potential:.0f}/10)."
            elif payoff is not None and g is payoff and k == len(g) - 1:
                role, why = "payoff", f"Most entertaining moment ({c.entertainment:.0f}/10) saved for the end."
            elif k > 0:
                role, why = "escalation", "Continues the same event, kept in chronological order."
            else:
                role, why = "escalation", "Builds toward the payoff (ordered by rising entertainment)."
            items.append(StoryItem(cid=c.cid, role=role, rationale=why, start=c.start, end=c.end))
    return items


def _fix_continuity(items: list[StoryItem], by_id: dict) -> list[StoryItem]:
    """If the model split a continuous event out of order, restore chronological order inside it."""
    for i in range(len(items) - 1):
        a, b = by_id[items[i].cid], by_id[items[i + 1].cid]
        if 0 < a.start - b.end < 10:  # b happened just before a in the source: swap
            items[i], items[i + 1] = items[i + 1], items[i]
            items[i].rationale += " (moved: happens first in the source)"
    return items


# ----------------------------------------------------------------------------- hooks

HOOK_SYSTEM = """You write opening hooks for YouTube Shorts made from gameplay clips.
A hook = a headline shown on screen (max 7 words) + an opening narration line (max 14 words).
Hooks must be truthful to the clips: no claims the footage doesn't support, no fake stakes. Reply with JSON only."""

HOOK_PROMPT = """Short topic: {topic}
{request}Clips in order:
{clips}

Write {n} different hook options with different angles (curiosity, stakes, humour, disbelief).
Return JSON: {{"hooks": [{{"headline": "...", "opening_line": "...", "score": 0-10 how likely to stop a scrolling viewer, "rationale": "..."}}]}}"""


def make_hooks(story: list[StoryItem], by_id: dict, spec: TopicSpec, llm: LLM, n: int = 3) -> tuple[list[HookOption], str]:
    clips = "\n".join(f"{i + 1}. ({it.role}) {by_id[it.cid].description}" for i, it in enumerate(story))
    try:
        d = llm.complete_json(HOOK_SYSTEM, HOOK_PROMPT.format(topic=spec.summary, clips=clips, n=n,
                                                              request=_request_note(spec, len(story))), max_tokens=700)
        hooks = []
        for h in d.get("hooks") or d.get("items") or []:
            if not isinstance(h, dict):
                continue
            head = _clip_words(str(h.get("headline", "")), 7)
            line = _clip_words(str(h.get("opening_line", "")), 16)
            if head:
                hooks.append(HookOption(headline=head, opening_line=line, score=float(h.get("score") or 0),
                                        rationale=str(h.get("rationale", ""))[:200]))
        if hooks:
            hooks.sort(key=lambda h: -h.score)
            return hooks[:n], "llm"
    except ProviderUnavailable:
        pass
    return rule_hooks(spec, n, len(story)), "rules"


def rule_hooks(spec: TopicSpec, n: int, n_items: int = 0) -> list[HookOption]:
    """Fallback hooks (no language model). They promise nothing the clips don't show: the only
    claim made is the ranking ClipForge itself computed (the last clip is the strongest)."""
    if spec.format == "countdown" and n_items >= 2:
        what = countdown_phrase(spec, n_items)            # "4 coolest moments"
        return [HookOption(f"THE {what.upper()}", f"Here are the {_spell(n_items)} {what.split(' ', 1)[1]} "
                           f"from this stream, counted down.", score=6.5),
                HookOption(f"TOP {n_items}: {what.split(' ', 1)[1].upper()}",
                           f"Counting down the {what.split(' ', 1)[1]}. Stay for number one.", score=6),
                HookOption("WAIT FOR NUMBER ONE", f"{_spell(n_items).capitalize()} {what.split(' ', 1)[1]}, "
                           f"from number {_spell(n_items)} to number one.", score=5.5)][:n]
    topic = _short_topic(spec)
    opts = [
        HookOption(f"{topic.upper()}: BEST MOMENTS", f"The best {topic} from this stream.", score=6),
        HookOption("WAIT FOR THE LAST ONE", f"These {topic} build up. Wait for the last one.", score=5.5),
        HookOption(f"{topic.upper()} COMPILATION", f"Here are the top {topic} from the stream.", score=5),
    ]
    if getattr(spec, "open", False) or topic == "moments":
        # "find the craziest moments": no subject, so say how good they are, once
        sup = spec.superlative if spec.superlative not in ("", "top", "best") else "best"
        opts = [HookOption(f"THE {sup.upper()} MOMENTS", f"The {sup} moments from this stream.", score=6),
                HookOption("WAIT FOR THE LAST ONE", f"The {sup} moments from this stream. Wait for the last one.",
                           score=5.5),
                HookOption(f"{sup.upper()} MOMENTS OF THE STREAM", f"Here are the {sup} moments from the stream.",
                           score=5)]
    return opts[:n]


def _short_topic(spec: TopicSpec) -> str:
    t = (spec.sub_topics[0] if spec.sub_topics else spec.raw) or "moments"
    t = re.sub(r"^(please\s+)?(find|show|get|give|make)\s+(me\s+)?(some\s+|all\s+|the\s+)?", "", t.strip(), flags=re.I)
    parts = re.split(r"\b(where|that|when|which|who|with|involving|in which|from|during)\b", t, maxsplit=1, flags=re.I)
    head = re.sub(r"^(?:the|all|some)\s+", "", parts[0].strip(), flags=re.I)
    if (len(parts) > 2 and parts[1].lower() in ("with", "involving")
            and head.lower() in {"moments", "clips", "times", "parts", "bits", "scenes", "ones"}):
        t = parts[2]              # "the moments with the Christmas carolers" → "the Christmas carolers"
    else:
        t = parts[0]
    t = re.sub(r"\b(the\s+)?(most|best|funniest|craziest|wildest|top)\s+", "", t, flags=re.I)
    t = re.sub(r"^(some\s+|all\s+|the\s+)?(exciting|crazy|wild|insane|epic|cool|good|great|amazing|hilarious)\s+", "",
               t.strip(), flags=re.I)
    t = re.sub(r"^(?:an?\s+|the\s+)?(?:video|short|clip|compilation)\s+(?:about|of|on|with)\s+", "", t.strip(), flags=re.I)
    t = re.sub(r"^(?:the|a|an)\s+", "", t.strip(), flags=re.I)     # "The best the police chases"
    t = re.sub(r"\s+", " ", t).strip(" ,.")
    words = t.split()[:6]
    while words and words[-1].lower() in {"a", "an", "the", "of", "to", "in", "on", "his", "her", "their", "my",
                                          "and", "or", "with", "for", "at"}:
        words.pop()
    return " ".join(words) or "moments"


_WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]


def _spell(n: int) -> str:
    return _WORDS[n] if 0 <= n < len(_WORDS) else str(n)


def countdown_phrase(spec: TopicSpec, n: int = 0) -> str:
    """'4 coolest moments' / '5 funniest NPC moments' from the request."""
    n = n or spec.count
    sup = spec.superlative if spec.superlative not in ("", "top") else "best"
    sup = re.sub(r"^most\s+", "most ", sup)
    noun = (spec.search or _short_topic(spec)).strip()
    noun = re.sub(r"^(?:find|show|get|give|make)\s+(?:me\s+)?", "", noun, flags=re.I)
    noun = re.sub(r"\b(?:the|top|most|best|" + re.escape(sup.split()[-1]) + r")\b", " ", noun, flags=re.I)
    noun = re.sub(r"\b(things|ones|stuff)\b", "moments", noun, flags=re.I)
    noun = re.sub(r"\s+", " ", noun).strip(" ,.") or "moments"
    if not re.search(r"s\b", noun.split()[-1]):
        noun += " moments"
    return f"{n} {sup} {noun}"


def _request_note(spec: TopicSpec, n_items: int) -> str:
    """What the request asks of the Short beyond the topic (for the language model)."""
    parts = []
    if spec.raw and (spec.instructions or spec.format or spec.count):
        parts.append(f'The editor\'s request, in their words: "{spec.raw}"')
    if spec.format == "countdown":
        parts.append(f"The Short is a countdown of {n_items} moments: clip 1 is number {n_items}, the last clip is "
                     f"number 1.")
    elif spec.format == "story":
        parts.append("The clips tell one story, in the order it happened.")
    if spec.instructions:
        parts.append(f'For the narration they asked: "{spec.instructions}"')
    return ("\n".join(parts) + "\n") if parts else ""


def _clip_words(s: str, n: int) -> str:
    w = s.strip().strip('"').split()
    return " ".join(w[:n])


# ----------------------------------------------------------------------------- narration

SCRIPT_SYSTEM = """You write the voice-over for a YouTube Short made of gameplay livestream clips.
Style: natural, punchy, conversational, like a good gaming Shorts narrator. Short sentences.
Strict rules:
- Describe ONLY what the clip descriptions and transcripts show. Never invent events, names or dialogue.
- Never quote the streamer unless the exact words are in the transcript.
- The narration connects the clips and sets up each moment; it must not explain the joke after it lands.
- Narration plays while the original audio is quiet, so keep each line short.
Reply with JSON only."""

SCRIPT_PROMPT = """Short topic: {topic}
{request}Opening hook to start with (use or lightly adapt): "{hook}"
Total narration budget: at most {budget} words across ALL lines.

Clips in order:
{clips}

Return JSON:
{{"lines": [{{"item": clip number the line introduces (1 = first clip), "text": "..."}}],
  "context_texts": {{"<clip number>": "3-7 word on-screen context caption or empty"}},
  "title": "YouTube title, max 60 characters, truthful",
  "description": "1-2 sentence YouTube description"}}
{how}"""

HOW_LIGHT = ("Write one opening line for clip 1, then at most one short line before some later clips (skip clips that "
             "need no setup). Optionally end with a short closing line attached to the last clip number + 1.")
HOW_DETAILED = ("Write one line for EVERY clip, {words} words each, that says specifically what happens in that clip: "
                "who does what, what goes wrong or right, and why it fits the request. Name concrete things from the "
                "clip's description, frame descriptions and transcript (the car, the place, what is said). Set the "
                "moment up rather than giving away its last second. Clip 1's line also opens the Short with the hook.")
HOW_COUNTDOWN = (" Begin each clip's line with its number in the countdown, spelled out (\"Number four: …\"), and give "
                 "each clip a short on-screen context caption naming the moment.")


def write_script(story: list[StoryItem], by_id: dict, spec: TopicSpec, hook: Optional[HookOption], llm: LLM,
                 transcript: Transcript, target_seconds: float, narration_share: float = 0.18
                 ) -> tuple[list[NarrationLine], dict, str]:
    if spec.detail == "none":                       # "no narration": only the on-screen numbers / captions
        return [], {"context_texts": _rank_texts(story, {}), "title": _rule_title(spec, story), "description": ""}, "none"
    detailed = spec.detail == "detailed"
    if detailed:
        narration_share = max(narration_share, 0.4)
    elif spec.format == "countdown":
        narration_share = max(narration_share, 0.25)
    budget = max(14, int(target_seconds * narration_share * WORDS_PER_SECOND))
    if detailed:   # every clip gets its line, however short the Short is
        budget = max(budget, 12 * len(story) + 8)
    clips = []
    for i, it in enumerate(story):
        c = by_id[it.cid]
        said = " ".join(s.text for s in transcript.sentences_between(it.start, it.end))[:500]
        frames = "; ".join(x for x in (c.evidence.frame_captions or []) if x)[:400] if c.evidence else ""
        clips.append(f"{i + 1}. ({it.role}, {it.end - it.start:.0f}s) {c.description}"
                     + (f"\n   On screen: {frames}" if frames else "")
                     + f"\n   Streamer says: {said or '(nothing)'}")
    how = HOW_LIGHT
    if detailed or spec.format in ("countdown", "list"):
        how = HOW_DETAILED.format(words="10-20" if detailed else "5-10")
    if spec.format == "countdown":
        how += HOW_COUNTDOWN
    extras: dict = {}
    try:
        d = llm.complete_json(SCRIPT_SYSTEM, SCRIPT_PROMPT.format(topic=spec.summary, hook=hook.opening_line if hook else "",
                                                                  budget=budget, clips="\n".join(clips), how=how,
                                                                  request=_request_note(spec, len(story))),
                              max_tokens=1400 if detailed else 900)
        lines = []
        for ln in d.get("lines") or []:
            if not isinstance(ln, dict):
                continue
            try:
                item = int(ln.get("item", 1)) - 1
            except (TypeError, ValueError):
                item = 0
            text = _ground(str(ln.get("text", "")).strip(), transcript)
            if text:
                pos = "after" if item >= len(story) else "before"
                lines.append(NarrationLine(text=text, item_index=min(max(0, item), len(story) - 1), position=pos))
        extras = {"context_texts": _rank_texts(story, d.get("context_texts") or {}), "title": str(d.get("title", ""))[:100],
                  "description": str(d.get("description", ""))[:500]}
        if lines:
            if detailed or spec.format in ("countdown", "list"):
                # every clip must be introduced: fill any the model skipped from the clip's own evidence
                have = {ln.item_index for ln in lines if ln.position == "before"}
                for i in range(len(story)):
                    if i not in have:
                        lines.append(NarrationLine(text=_item_line(story, i, by_id, spec, transcript), item_index=i))
                lines.sort(key=lambda ln: (ln.item_index + (0.5 if ln.position == "after" else 0)))
                return lines, extras, "llm"
            return _budget(lines, budget), extras, "llm"
    except ProviderUnavailable:
        pass
    return (rule_script(story, by_id, spec, hook, transcript),
            {"context_texts": _rank_texts(story, {}), "title": _rule_title(spec, story), "description": ""}, "rules")


def _rank_texts(story: list[StoryItem], ctx: dict) -> dict:
    """On-screen caption per clip; in a countdown each starts with its number (#4 … #1)."""
    out = {}
    for i in range(len(story)):
        t = str(ctx.get(str(i + 1)) or ctx.get(i + 1) or "").strip()
        k = rank_of(story, i)
        if k:
            t = f"#{k}" + (f" {t}" if t and not t.startswith("#") else "")
        if t:
            out[str(i + 1)] = t[:60]
    return out


def _rule_title(spec: TopicSpec, story: list[StoryItem]) -> str:
    if spec.format == "countdown" and len(story) >= 2:
        return ("Top " + countdown_phrase(spec, len(story))).title()[:60]
    return ""


_PROFANE = re.compile(r"\b(fuck|shit|bitch|motherf|cunt|nigg|fag|retard|whore|slut|bastard|cock|dick|pussy|"
                      r"asshole|damn)\w*", re.I)
_REACT = re.compile(r"\b(no way|oh my god|oh my|what|wait|look|watch|go|run|get out|bro|dude|holy|insane|crazy|"
                    r"why|how|never|run|help|stop)\b", re.I)


def best_quote(c: Candidate, transcript: Transcript, start: float, end: float, avoid: Optional[set] = None) -> str:
    """The most telling thing actually said in a clip, word for word (3-14 words, no swearing),
    favouring a reaction near the clip's key moment. "" when nothing suitable was said. ``avoid``:
    quotes already used for other clips (a phrase said in several clips is quoted once)."""
    best, best_s = "", -1e9
    avoid = {a.lower().strip(" .!?,") for a in (avoid or set())}
    key = c.best_moment if c.best_moment and c.best_moment >= 0 else (start + end) / 2
    for sen in transcript.sentences_between(start, end):
        txt = re.sub(r"\s+", " ", sen.text).strip()
        words = txt.split()
        if not 3 <= len(words) <= 14 or _PROFANE.search(txt):
            continue
        if len({w.lower().strip(".,!?") for w in words}) <= 2:          # "go go go", "yeah yeah yeah"
            continue
        if txt.lower().strip(" .!?,") in avoid:
            continue
        sc = 2.0 * bool(_REACT.search(txt)) + 1.5 * txt.endswith(("!", "?")) - abs(sen.start - key) / 10.0 \
            - 0.15 * abs(len(words) - 7)
        if sc > best_s:
            best, best_s = txt, sc
    return best.rstrip(" ,") if best else ""


def _item_line(story: list[StoryItem], i: int, by_id: dict, spec: TopicSpec, transcript: Transcript,
               used: Optional[set] = None) -> str:
    """A specific line for one clip without a language model: its number (countdown) or place in
    the story, and the most telling thing actually said in it, quoted exactly. Nothing is made up:
    without the language model ClipForge can't see what happens, only hear what is said."""
    it, c = story[i], by_id[story[i].cid]
    k = rank_of(story, i)
    if k:
        lead = f"Number {_spell(k)}"
    elif spec.format == "story":
        lead = "First" if i == 0 else ("And finally" if i == len(story) - 1 else "Then")
    else:
        lead = "First up" if i == 0 else ("And last" if i == len(story) - 1 else "Next")
    q = best_quote(c, transcript, it.start, it.end, used) if spec.detail == "detailed" or k else ""
    if q and used is not None:
        used.add(q)
    if q:
        end = "" if q.endswith(("!", "?", ".")) else "."
        return f'{lead}: "{q}{end}"'
    return lead + "."


def rule_script(story: list[StoryItem], by_id: dict, spec: TopicSpec, hook: Optional[HookOption],
                transcript: Optional[Transcript] = None) -> list[NarrationLine]:
    if transcript is not None and (spec.format in ("countdown", "list", "story") or spec.detail == "detailed"):
        # a line for every clip: "Number four: …" with what was actually said
        opening = hook.opening_line if hook and hook.opening_line else ""
        lines, used = [], set()
        for i in range(len(story)):
            text = _item_line(story, i, by_id, spec, transcript, used)
            if i == 0 and opening:
                text = f"{opening} {text}"
            lines.append(NarrationLine(text=text, item_index=i))
        return lines
    lines = [NarrationLine(text=(hook.opening_line if hook and hook.opening_line else
                                 f"Here are the best {_short_topic(spec)} from this stream."), item_index=0)]
    # neutral bridges: they describe the edit, never invent what happens in the clip
    k = 0
    for i, it in enumerate(story[1:], start=1):
        if it.role == "payoff":
            lines.append(NarrationLine(text="And the biggest one of all.", item_index=i))
        elif k == 0 and len(story) > 2 and i == len(story) // 2:
            lines.append(NarrationLine(text="Here's another one.", item_index=i))
            k += 1
    return lines


_QUOTE = re.compile(r"[\"“”]([^\"“”]{3,})[\"“”]")


def _ground(text: str, transcript: Transcript) -> str:
    """Reject a narration line that quotes words the streamer never said (prevents invented
    dialogue). The whole line is dropped: removing just the quote leaves a sentence that still
    claims something was said."""
    norm = lambda s: re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s.lower())).strip()
    full_n = norm(" ".join(s.text for s in transcript.sentences))
    for q in _QUOTE.findall(text):
        if norm(q) not in full_n:
            return ""
    return re.sub(r"\s+", " ", text).strip(" ,")


def _budget(lines: list[NarrationLine], budget: int) -> list[NarrationLine]:
    total = sum(len(l.text.split()) for l in lines)
    if total <= budget:
        return lines
    # keep the opening line, drop later lines from the middle until within budget
    keep = lines[:1]
    used = len(lines[0].text.split())
    for l in lines[1:]:
        w = len(l.text.split())
        if used + w <= budget:
            keep.append(l)
            used += w
    return keep
