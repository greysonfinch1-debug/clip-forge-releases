"""Visual understanding backends.

* ``clip`` (VisionEncoder) – open_clip image/text embeddings. Every sampled frame is
  embedded once and cached; any future topic is matched against those cached embeddings
  without touching the video again.
* ``ollama`` (FrameCaptioner) – a local vision-language model (e.g. Qwen2.5-VL, LLaVA,
  Gemma 3) that describes the keyframes of the top candidates in words, so the language
  model can judge what actually happens on screen.
"""
from __future__ import annotations

import base64

import numpy as np

from .base import FrameCaptioner, ProviderUnavailable, VisionEncoder, register


@register("vision", "clip")
class ClipEncoder(VisionEncoder):
    def __init__(self, model: str = "ViT-B-32", pretrained: str = "laion2b_s34b_b79k", device: str = "auto",
                 models_dir: str = "", **_):
        try:
            import open_clip  # type: ignore
            import torch  # type: ignore
        except ImportError as e:
            raise ProviderUnavailable("open_clip_torch / torch are not installed") from e
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
            if device == "cuda":
                # don't fill a GPU that's nearly full (a game, Ollama…): CLIP needs ~1.5 GB
                try:
                    free, _total = torch.cuda.mem_get_info()
                    if free < 1500 * 2**20:
                        device = "cpu"
                except Exception:  # noqa: BLE001
                    pass
        if device == "cuda":
            try:
                torch.set_num_threads(max(1, torch.get_num_threads()))
            except Exception:  # noqa: BLE001
                pass
        else:
            from ..resources import ai_threads

            torch.set_num_threads(ai_threads())
        if pretrained in ("", "none"):  # untrained weights: only for speed benchmarks / tests
            pretrained = None
        self.device = device
        try:
            self.model, _, self.preprocess = open_clip.create_model_and_transforms(
                model, pretrained=pretrained, device=device,
                cache_dir=(models_dir + "/clip") if models_dir else None)
        except Exception as e:
            raise ProviderUnavailable(f"Could not load CLIP model {model}/{pretrained}: {e}") from e
        self.model.eval()
        self.tokenizer = open_clip.get_tokenizer(model)
        self._id = f"clip:{model}:{pretrained}"
        self.torch = torch

    @property
    def model_id(self) -> str:
        return self._id

    def encode_images(self, images: list[np.ndarray]) -> np.ndarray:
        from PIL import Image

        torch = self.torch
        if not images:
            return np.zeros((0, 512), np.float32)
        batch = torch.stack([self.preprocess(Image.fromarray(im)) for im in images]).to(self.device)
        with torch.no_grad():
            feats = self.model.encode_image(batch)
            feats = feats / feats.norm(dim=-1, keepdim=True)
        return feats.float().cpu().numpy()

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        torch = self.torch
        toks = self.tokenizer(texts).to(self.device)
        with torch.no_grad():
            feats = self.model.encode_text(toks)
            feats = feats / feats.norm(dim=-1, keepdim=True)
        return feats.float().cpu().numpy()


@register("captioner", "ollama")
class OllamaCaptioner(FrameCaptioner):
    def __init__(self, model: str = "qwen2.5vl:7b", base_url: str = "http://localhost:11434", timeout: int = 240, **_):
        import requests

        self.model, self.base, self.timeout = model, base_url.rstrip("/"), timeout
        self.s = requests.Session()
        try:
            r = self.s.get(self.base + "/api/tags", timeout=10)
            r.raise_for_status()
            names = {m.get("name", "") for m in r.json().get("models", [])}
            from .llm import ollama_has_model

            if not ollama_has_model(names, model):
                raise ProviderUnavailable(f"Vision model '{model}' is not pulled in Ollama. Run: ollama pull {model}")
        except ProviderUnavailable:
            raise
        except Exception as e:
            raise ProviderUnavailable(f"Ollama is not running at {self.base}: {e}") from e

    def describe(self, image_paths: list[str], instruction: str) -> str:
        imgs = []
        for p in image_paths:
            with open(p, "rb") as f:
                imgs.append(base64.b64encode(f.read()).decode())
        body = {"model": self.model, "stream": False, "options": {"temperature": 0.1},
                "messages": [{"role": "user", "content": instruction, "images": imgs}]}
        r = self.s.post(self.base + "/api/chat", json=body, timeout=self.timeout)
        if r.status_code >= 400:
            raise ProviderUnavailable(f"Vision model error {r.status_code}: {r.text[:200]}")
        return (r.json().get("message", {}).get("content") or "").strip()
