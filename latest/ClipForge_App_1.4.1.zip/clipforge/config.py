"""Application settings.

Settings live in a JSON file in the user's app-data folder (``%APPDATA%\\ClipForge`` on
Windows, ``~/.clipforge`` elsewhere). Every AI component is chosen here by name, so a
component can be swapped later (see ``clipforge/providers``) without touching the rest
of the application.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path


def app_dir() -> Path:
    """Folder for settings, projects, logs and backups (``%APPDATA%\\ClipForge`` on Windows)."""
    override = os.environ.get("CLIPFORGE_HOME")
    if override:
        base = Path(override)
    elif sys.platform == "win32" and os.environ.get("APPDATA"):
        base = Path(os.environ["APPDATA"]) / "ClipForge"
    else:
        base = Path.home() / ".clipforge"
    base.mkdir(parents=True, exist_ok=True)
    return base


def data_dir() -> Path:
    """Folder for large, machine-local data: AI models, analysis cache, downloaded updates and
    optional packages. ``%LOCALAPPDATA%\\ClipForge`` on Windows (not roamed, never touched by
    installing or updating the app)."""
    override = os.environ.get("CLIPFORGE_HOME")
    if override:
        base = Path(override)
    elif sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
        base = Path(os.environ["LOCALAPPDATA"]) / "ClipForge"
    else:
        base = Path.home() / ".clipforge"
    base.mkdir(parents=True, exist_ok=True)
    return base


PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
ASSETS_DIR = PROJECT_ROOT / "assets"


@dataclass
class TranscriptionSettings:
    # "parakeet" (sherpa-onnx, fast on CPU, English) or "faster-whisper" (multilingual, best with GPU)
    backend: str = "parakeet"
    whisper_model: str = "small"          # faster-whisper size: tiny/base/small/medium/large-v3
    whisper_device: str = "auto"          # auto / cpu / cuda
    language: str = "en"
    chunk_seconds: int = 300              # audio is processed in chunks so long streams never load fully
    threads: int = 0                      # 0 = automatic


@dataclass
class AudioAISettings:
    # Sound-event model (AudioSet): "ced" (CED-mini, ~45 MB, fast on CPU) or "none"
    sound_events: str = "ced"
    # Who-spoke-when: "pyannote" (pyannote-3.0 segmentation + TitaNet, ~45 MB) or "none"
    diarizer: str = "pyannote"
    diarize_threshold: float = 0.8        # higher = fewer, larger speaker groups (0.9 merged
                                          # different people in short windows; measured in 1.2.9)
    threads: int = 0                      # 0 = automatic


@dataclass
class VisionSettings:
    # "clip" (open_clip) or "none" (disables visual analysis; not recommended)
    backend: str = "clip"
    clip_model: str = "ViT-B-32"
    clip_pretrained: str = "laion2b_s34b_b79k"
    sample_every_seconds: float = 1.0     # frame sampling interval for analysis
    analysis_height: int = 360            # analysis proxy resolution (keeps long videos cheap)
    device: str = "auto"
    # Optional detailed frame descriptions for the top candidates, using a local vision LLM
    captioner: str = "ollama"             # "ollama" or "none"
    captioner_model: str = "qwen2.5vl:7b"
    keyframes_per_candidate: int = 3


@dataclass
class LLMSettings:
    # "ollama" (local, free), "openai" (any OpenAI-compatible API), or "rules" (no language model)
    backend: str = "ollama"
    model: str = "qwen2.5:7b-instruct"
    base_url: str = "http://localhost:11434"
    api_key: str = ""
    temperature: float = 0.3
    timeout_seconds: int = 240
    max_candidates_to_judge: int = 40


@dataclass
class EmbeddingSettings:
    # "ollama" (nomic-embed-text), "openai" (OpenAI-compatible embeddings), or "lexical" (built-in BM25 + topic expansion)
    backend: str = "ollama"
    model: str = "nomic-embed-text"


@dataclass
class VoiceSettings:
    backend: str = "kokoro"               # "kokoro" (local) ; more can be added in providers/tts.py
    voice: str = "am_michael"
    speed: float = 1.08
    volume_db: float = 0.0


@dataclass
class EditSettings:
    width: int = 1080
    height: int = 1920
    fps: int = 30
    crop_mode: str = "smart"              # smart / center / blur-fill / facecam-split
    transitions: str = "quick"            # none / quick (short cross-dissolve on context changes)
    transition_seconds: float = 0.18
    original_audio_db: float = -2.0
    narration_duck_db: float = -14.0      # how much original audio drops under narration
    music_path: str = ""                  # a licensed music file or folder (optional)
    music_db: float = -24.0
    sfx_enabled: bool = True
    caption_font: str = "Poppins"
    caption_size: int = 96               # (78 before 1.2.9: too small on a phone)
    caption_color: str = "#FFFFFF"
    caption_highlight: str = "#FFD400"
    caption_outline: str = "#000000"
    caption_position: float = 0.66        # vertical position (0 top, 1 bottom) for captions
    caption_words_per_line: int = 3
    show_original_dialogue_captions: bool = True
    headline_font: str = "Poppins"
    headline_size: int = 74
    headline_color: str = "#FFFFFF"
    headline_box: str = "#E0262680"        # RGBA box behind headline (last two hex = alpha)
    headline_position: float = 0.12
    end_message: str = "Follow for more"
    flash_forward_hook: bool = True       # open with a 2-4 s preview of the peak under the hook line
    tighten_pauses: bool = True           # jump-cut silent pauses (> 1.2 s, nothing moving) inside clips
    crf: int = 18
    preset: str = "veryfast"


@dataclass
class Settings:
    transcription: TranscriptionSettings = field(default_factory=TranscriptionSettings)
    vision: VisionSettings = field(default_factory=VisionSettings)
    audio_ai: AudioAISettings = field(default_factory=AudioAISettings)
    llm: LLMSettings = field(default_factory=LLMSettings)
    embedding: EmbeddingSettings = field(default_factory=EmbeddingSettings)
    voice: VoiceSettings = field(default_factory=VoiceSettings)
    edit: EditSettings = field(default_factory=EditSettings)
    output_dir: str = ""
    models_dir: str = ""
    hook_variants: int = 3
    check_updates: bool = True        # look for a new version at start-up (in the background)
    auto_install_updates: bool = True  # download + verify quietly; switch over at the next start
    first_run_done: bool = False      # the welcome / model overview has been shown
    settings_version: int = 2         # bumped when a default changes for everyone (see load)
    performance: str = ""            # balanced / performance / low ('' = pick for this PC)
    use_gpu: bool = True              # use a compatible GPU when one is available (falls back to CPU)

    # ---- persistence -------------------------------------------------
    @staticmethod
    def path() -> Path:
        return app_dir() / "settings.json"

    @classmethod
    def load(cls) -> "Settings":
        p = cls.path()
        s = cls()
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                s = cls.from_dict(data)
                if int(data.get("settings_version") or 1) < 2:
                    # 1.2.9: bigger default captions; only if the old default was never changed
                    if (data.get("edit") or {}).get("caption_size") in (None, 78):
                        s.edit.caption_size = 96
                    # 1.2.9: 0.9 put two different people under one label in short windows
                    if (data.get("audio_ai") or {}).get("diarize_threshold") in (None, 0.9):
                        s.audio_ai.diarize_threshold = 0.8
                    s.settings_version = 2
            except Exception:
                pass
        s._fill_defaults()
        return s

    def save(self) -> None:
        """Atomic write: an interrupted save can never leave a half-written settings file."""
        p = self.path()
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        os.replace(tmp, p)

    @classmethod
    def from_dict(cls, data: dict) -> "Settings":
        s = cls()
        for f in fields(cls):
            if f.name not in data:
                continue
            cur = getattr(s, f.name)
            if hasattr(cur, "__dataclass_fields__") and isinstance(data[f.name], dict):
                for k, v in data[f.name].items():
                    if k in cur.__dataclass_fields__:
                        setattr(cur, k, v)
            else:
                setattr(s, f.name, data[f.name])
        return s

    def _fill_defaults(self) -> None:
        if not self.output_dir:
            out = Path.home() / "Videos" / "ClipForge"
            self.output_dir = str(out)
        if not self.models_dir:
            legacy = app_dir() / "models"   # v1.0/v1.1 source builds kept models here: keep using them
            self.models_dir = str(legacy if legacy.exists() and any(legacy.iterdir()) else data_dir() / "models")
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        Path(self.models_dir).mkdir(parents=True, exist_ok=True)
