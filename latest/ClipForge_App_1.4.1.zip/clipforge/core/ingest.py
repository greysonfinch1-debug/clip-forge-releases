"""Video ingestion: URLs (YouTube, Twitch, Kick and other yt-dlp-supported sites) and local files.

Efficiency strategy for long streams:
  1. Read metadata only (no download) to validate the link and get the duration.
  2. Download the audio track alone for transcription/audio analysis (small).
  3. Download a low-resolution video stream for visual analysis (small).
  4. After clips are chosen, download only those sections in full quality.

Access rules: public / unlisted media only. No cookies, logins, DRM circumvention or
private-video access are implemented. Platforms that refuse access produce a clear error.
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlparse

from ..activity import YdlLogger
from ..activity import log as alog
from . import ffmpeg as ff
from .cache import SourceCache, file_fingerprint, stable_id
from .models import VideoSource

ProgressFn = Optional[Callable[[float, str], None]]

SUPPORTED_FILE_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".flv", ".ts", ".mts"}

PLATFORM_PATTERNS = [
    ("youtube", re.compile(r"(^|\.)youtube\.com$|(^|\.)youtu\.be$")),
    ("twitch", re.compile(r"(^|\.)twitch\.tv$")),
    ("kick", re.compile(r"(^|\.)kick\.com$")),
]


class IngestError(RuntimeError):
    pass


def detect_platform(url: str) -> str:
    host = (urlparse(url).hostname or "").lower()
    for name, pat in PLATFORM_PATTERNS:
        if pat.search(host):
            return name
    return "other"


def validate_url(url: str) -> str:
    url = url.strip()
    if not url:
        raise IngestError("Paste a video link first.")
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    parsed = urlparse(url)
    if not parsed.hostname or "." not in parsed.hostname:
        raise IngestError("That doesn't look like a valid web address.")
    return url


def _ensure_ffmpeg_on_path() -> str:
    """yt-dlp decides whether it can download *part* of a video by looking for FFmpeg on PATH only
    (it ignores ffmpeg_location for that check), so put ClipForge's FFmpeg folder on PATH."""
    d = os.path.dirname(ff.ffmpeg_bin())
    parts = os.environ.get("PATH", "").split(os.pathsep)
    if d and os.path.normcase(d) not in {os.path.normcase(x) for x in parts}:
        os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
    return d


def _ydl_base_opts() -> dict:
    _ensure_ffmpeg_on_path()
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 30,
        "retries": 5,
        "fragment_retries": 10,
        "concurrent_fragment_downloads": 4,
        # deliberately no cookiefile / username / password: public media only
        "ffmpeg_location": os.path.dirname(ff.ffmpeg_bin()),
        "logger": YdlLogger(),       # warnings/errors go to logs/activity.log
    }


TRANSIENT = ("timed out", "timeout", "connection reset", "connection aborted", "temporary failure",
             "remote end closed", "incompleteread", "incomplete read", "http error 500", "http error 502",
             "http error 503", "http error 504", "network is unreachable", "name resolution",
             "unable to download webpage", "downloaded file is empty", "did not get any data")


def is_transient(msg: str) -> bool:
    low = msg.lower()
    return any(k in low for k in TRANSIENT) and "403" not in low and "404" not in low


def _friendly_ydl_error(e: Exception) -> IngestError:
    msg = str(e)
    low = msg.lower()
    # order matters: specific causes before generic "sign in"
    if "drm" in low:
        return IngestError("This video is DRM-protected. ClipForge does not bypass DRM. Use a file you have rights to.")
    if ("confirm you" in low or "confirm that you" in low) and "bot" in low:
        return IngestError("The platform blocked the automated download (bot check). ClipForge does not use your "
                           "account to get around this. Download the video with the creator's permission and use "
                           "Upload File instead.")
    if "is live" in low or "live event" in low or "will begin in" in low or "premieres in" in low:
        return IngestError("This stream is still live or hasn't started. Process it once the recording (VOD) is "
                           "available.")
    if "age-restricted" in low or "confirm your age" in low or "inappropriate for some users" in low:
        return IngestError("This video is age-restricted and needs a signed-in account, which ClipForge does not use. "
                           "Use a file you have rights to instead.")
    if ("private" in low or "sign in" in low or "login" in low or "log in" in low or "members-only" in low
            or "subscriber" in low or "registered users" in low or "requires authentication" in low):
        return IngestError("This video is private, members-only or requires signing in. Only public videos can be "
                           "processed from a link; ask the creator for the file and use Upload File instead.")
    if ("not available from your location" in low or "available in your country" in low or "geo restrict" in low
            or "geo-restrict" in low):
        return IngestError("This video is blocked in your country. ClipForge does not bypass region locks.")
    if "unsupported url" in low:
        return IngestError("This website isn't supported for links. Download the video with the creator's "
                           "permission and use Upload File instead.")
    if "429" in low or "too many requests" in low:
        return IngestError("The platform is rate-limiting downloads right now. Wait a few minutes and try again.")
    if "removed" in low or "video unavailable" in low or "does not exist" in low or "404" in low:
        return IngestError("This video is unavailable (removed, deleted or the link is wrong).")
    from .storage import is_disk_full

    if is_disk_full(msg):
        return IngestError("The drive ran out of space while downloading. The unfinished download was kept so it can "
                           "resume. Free up some space (Settings → Storage can clean up ClipForge's temporary files) "
                           "and try again.")
    if is_transient(msg):
        return IngestError("The connection kept failing while downloading (tried several times). Check your "
                           "internet connection and try again.")
    return IngestError("Couldn't access this video: " + msg.splitlines()[-1][:300])


def _with_retries(fn, cancel=None, attempts: int = 3, waits=(3.0, 8.0)):
    """Retry a whole download on network hiccups (yt-dlp already retries individual requests)."""
    import time

    last = None
    for i in range(attempts):
        try:
            return fn()
        except IngestError:
            raise
        except Exception as e:  # noqa: BLE001
            last = e
            if not is_transient(str(e)) or i == attempts - 1:
                raise
            wait = waits[min(i, len(waits) - 1)]
            t0 = time.time()
            while time.time() - t0 < wait:
                if cancel and cancel():
                    raise IngestError("Cancelled") from e
                time.sleep(0.2)
    raise last  # pragma: no cover


def _in_thread_with_limit(fn, limit: float, cancel, timeout_msg: str, alive=None):
    """Run ``fn`` in a helper thread; give up after ``limit`` seconds or on Cancel.
    With ``alive`` (returns the time of the last sign of progress) the limit counts from that."""
    import threading
    import time

    box: dict = {}

    def run():
        try:
            box["ok"] = fn()
        except BaseException as e:  # noqa: BLE001
            box["err"] = e
    t = threading.Thread(target=run, daemon=True)
    t.start()
    t0 = time.time()
    while t.is_alive():
        t.join(0.25)
        if cancel and cancel():
            if alive is not None:
                # an active download stops at its next progress report (well under a second): wait
                # for that, so nothing keeps writing after Cancel and a retry can't collide with it.
                # A download that is stuck waiting on the network isn't writing: no wait.
                end = time.time() + 5.0
                while t.is_alive() and time.time() < end and time.time() - alive() < 1.5:
                    t.join(0.1)
            raise IngestError("Cancelled")
        if time.time() - max(t0, alive() if alive else 0.0) > limit:
            alog(f"Gave up: {timeout_msg}")
            raise IngestError(timeout_msg[0].upper() + timeout_msg[1:] + ".")
    if "err" in box:
        e = box["err"]
        if isinstance(e, IngestError):
            raise e
        raise _friendly_ydl_error(e) from e
    return box["ok"]


def _check_analysis_space(where, duration: float, downloads: bool) -> None:
    """Analysis copies: 16 kHz speech audio (32 KB/s) + small analysis video (~40 KB/s)
    (+ the downloaded originals they're made from, removed afterwards)."""
    from .storage import StorageError, check_space

    per_s = 32_000 + 40_000 + (60_000 if downloads else 0)
    try:
        check_space(where, max(60.0, duration or 3600) * per_s, "analysing this video")
    except StorageError as e:
        raise IngestError(str(e)) from e


def fetch_url_info(url: str) -> dict:
    """Metadata only, no download."""
    try:
        import yt_dlp  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise IngestError("yt-dlp is not installed (run the installer again).") from e
    url = validate_url(url)
    opts = _ydl_base_opts() | {"skip_download": True}
    def get():
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)

    try:
        info = _with_retries(get)
    except IngestError:
        raise
    except Exception as e:
        raise _friendly_ydl_error(e) from e
    if info is None:
        raise IngestError("No video information was returned for this link.")
    if info.get("_type") == "playlist":
        raise IngestError("This is a playlist/channel link. Paste the link to a single video.")
    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        raise IngestError("This stream is live or hasn't started. Process it once the recording (VOD) is available.")
    if info.get("availability") in ("private", "premium_only", "subscriber_only", "needs_auth"):
        raise IngestError("This video isn't publicly accessible, so it can't be processed from a link.")
    return info


def _verify_media(path: Path, label: str) -> None:
    """Reject empty, truncated or non-media downloads with a clear message (instead of a
    confusing failure later in the analysis)."""
    try:
        info = ff.media_info(str(path))
    except Exception as e:  # noqa: BLE001
        try:
            path.unlink()
        except OSError:
            pass
        raise IngestError(f"{label}: the downloaded file is damaged or incomplete. Try again; if it keeps "
                          f"happening, use Upload File with a copy you have rights to.") from e
    if info["duration"] <= 0.5 or not (info["has_audio"] or info["has_video"]):
        try:
            path.unlink()
        except OSError:
            pass
        raise IngestError(f"{label}: the downloaded file is empty or incomplete. Try again.")


class Ingestor:
    STREAM_STALL = 40.0    # s a stream read may go without moving forward before giving up on it
    STREAM_MIN_SPEED = 0.2 # a stream read slower than 1 s of video per 5 s is abandoned (after 45 s)
    LOOKUP_LIMIT = 90.0    # s allowed for looking up a link's video streams
    DOWNLOAD_STALL = 120.0 # s a download may go without any progress before giving up
    def __init__(self, progress: ProgressFn = None, cancel=None, analysis_height: int = 360, confirm=None):
        self.progress = progress or (lambda f, m: None)
        self.cancel = cancel
        self.analysis_height = analysis_height
        # confirm(question) -> bool: asked before something that needs a lot of disk space
        self.confirm = confirm

    # ------------------------------------------------------------------ files
    def from_file(self, path: str) -> VideoSource:
        p = Path(path).expanduser()
        p = p.resolve() if p.exists() else p
        if not p.exists():
            raise IngestError(f"File not found: {path}")
        if p.suffix.lower() not in SUPPORTED_FILE_EXT:
            raise IngestError(f"Unsupported file type {p.suffix}. Use MP4, MOV, MKV, WEBM, AVI or M4V.")
        info = ff.media_info(str(p))
        if not info["has_video"]:
            raise IngestError("This file has no video track.")
        if info["duration"] <= 0.5:
            raise IngestError("This file is empty or too short.")
        sid = "f_" + file_fingerprint(str(p))
        src = VideoSource(source_id=sid, kind="file", path=str(p), platform="file", title=p.stem,
                          duration=info["duration"], width=info["width"], height=info["height"], fps=info["fps"])
        c = SourceCache(sid)
        if not (c.has("analysis_audio.wav") and c.has("proxy.mp4")):
            _check_analysis_space(c.dir, src.duration, downloads=False)
        self._prepare_analysis_media(src, has_audio=info["has_audio"])
        return src

    # ------------------------------------------------------------------ URLs
    def from_url(self, url: str) -> VideoSource:
        url = validate_url(url)
        self.progress(0.02, "Reading video information")
        info = fetch_url_info(url)
        platform = detect_platform(url)
        vid = str(info.get("id") or url)
        sid = "u_" + stable_id(platform, info.get("extractor_key", ""), vid)
        src = VideoSource(source_id=sid, kind="url", url=info.get("webpage_url") or url, platform=platform,
                          title=info.get("title") or "", uploader=info.get("uploader") or info.get("channel") or "",
                          duration=float(info.get("duration") or 0.0), width=int(info.get("width") or 0),
                          height=int(info.get("height") or 0), fps=float(info.get("fps") or 0.0))
        cache = SourceCache(sid)
        if not (cache.has("analysis_audio.wav") and cache.has("proxy.mp4")):
            _check_analysis_space(cache.dir, src.duration, downloads=True)
        cache.save_json("source_info.json", {"title": src.title, "uploader": src.uploader,
                                             "duration": src.duration, "url": src.url})
        audio_raw: Optional[Path] = None
        proxy_raw: Optional[Path] = None
        if not cache.has("analysis_audio.wav"):
            audio_raw = Path(self._ydl_download(src.url, "bestaudio/best", str(cache.path("audio_source.m4a")),
                                                0.05, 0.35, "Downloading audio"))
        if not cache.has("proxy.mp4"):
            fmt = (f"bv*[height<={self.analysis_height}]/wv*[height>={min(240, self.analysis_height)}]/"
                   f"bv*[height<=480]/worst")
            proxy_raw = Path(self._ydl_download(src.url, fmt, str(cache.path("proxy_source.mp4")),
                                                0.35, 0.65, "Downloading analysis video"))
        if proxy_raw is not None and not src.duration:
            src.duration = ff.media_info(str(proxy_raw))["duration"]
        self._prepare_analysis_media(src, has_audio=True, audio_input=str(audio_raw) if audio_raw else None,
                                     video_input=str(proxy_raw) if proxy_raw else None)
        for p in (audio_raw, proxy_raw):
            if p is not None and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass
        return src

    def _ydl_download(self, url: str, fmt: str, out: str, p0: float, p1: float, label: str) -> str:
        import yt_dlp  # type: ignore

        import time as _t

        life = {"t": _t.time()}

        def hook(d):
            life["t"] = _t.time()
            if self.cancel and self.cancel():
                raise IngestError("Cancelled")
            if d.get("status") == "downloading":
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                done = d.get("downloaded_bytes") or 0
                frac = done / tot if tot else 0.0
                self.progress(p0 + (p1 - p0) * min(1.0, frac), label)

        base = os.path.splitext(out)[0]
        opts = _ydl_base_opts() | {
            "format": fmt,
            "outtmpl": base + ".%(ext)s",
            "progress_hooks": [hook],
            "postprocessor_hooks": [lambda d: life.update(t=_t.time())],
            "overwrites": True,
        }
        def get():
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                return ydl.prepare_filename(info)

        alog(f"{label}: starting ({fmt})")
        # gives up if the download shows no sign of life for 2 minutes (it can't hang forever)
        produced = _in_thread_with_limit(lambda: _with_retries(get, self.cancel), self.DOWNLOAD_STALL, self.cancel,
                                         f"{label.lower()}: the site stopped responding for "
                                         f"{self.DOWNLOAD_STALL:.0f} s", alive=lambda: life["t"])
        alog(f"{label}: finished")
        produced_path = Path(produced)
        if not produced_path.exists():
            # extension may differ after merge
            matches = sorted(Path(base).parent.glob(Path(base).name + ".*"))
            matches = [m for m in matches if not m.name.endswith((".part", ".ytdl"))]
            if not matches:
                raise IngestError(f"{label}: download finished but no file was produced.")
            produced_path = matches[0]
        # keep the real container extension (webm/mkv/mp4); FFmpeg reads any of them
        final = Path(base + produced_path.suffix)
        if produced_path != final:
            shutil.move(str(produced_path), str(final))
        _verify_media(final, label)
        return str(final)

    def _prepare_analysis_media(self, src: VideoSource, has_audio: bool, audio_input: Optional[str] = None,
                                video_input: Optional[str] = None) -> None:
        cache = SourceCache(src.source_id)
        wav = cache.path("analysis_audio.wav")
        proxy = cache.path("proxy.mp4")
        a_in = audio_input or src.path
        v_in = video_input or src.path
        if not wav.exists():
            if has_audio and a_in:
                ff.extract_analysis_audio(a_in, str(wav), src.duration,
                                          lambda f, m: self.progress(0.65 + 0.15 * f, m), self.cancel)
            else:
                ff.run(["-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono", "-t", f"{src.duration:.3f}",
                        "-c:a", "pcm_s16le", str(wav)], label="Silent audio")
        if not proxy.exists():
            ff.make_proxy(v_in, str(proxy), src.duration, self.analysis_height, 2.0,
                          lambda f, m: self.progress(0.80 + 0.19 * f, m), self.cancel)
        src.audio_path = str(wav)
        src.proxy_path = str(proxy)
        if not src.width:
            pi = ff.media_info(str(proxy))
            src.width, src.height = pi["width"], pi["height"]
        self.progress(1.0, "Video ready for analysis")

    # ---------------------------------------------------------- final-quality sections
    def fetch_sections(self, src: VideoSource, ranges: list[tuple[float, float]], max_height: int = 1080,
                       fps: int = 30) -> dict[tuple[float, float], str]:
        """Return local full-quality files for each (start, end) range on the source timeline.

        Each file starts exactly at its range start (frame-accurate), is H.264/AAC at up to
        ``max_height`` and ``fps``, so the edit's timing (captions, cuts) is exact.
        For links, ClipForge's own FFmpeg reads just those seconds from the stream (fast, with
        real progress); if that fails, the video is downloaded once in full and cut locally."""
        cache = SourceCache(src.source_id)
        out_dir = cache.subdir("sections")
        result: dict[tuple[float, float], str] = {}
        streams = None
        todo = [(a, b) for a, b in ranges
                if not (out_dir / f"sec_{int(a * 1000):010d}_{int(b * 1000):010d}_h{max_height}f{fps}.mp4").exists()]
        lo = 0.0
        if src.kind != "file" and todo and self._full_download_path(src) is None and self._prefer_full(src):
            # YouTube serves clips to FFmpeg very slowly or not at all; its normal download is fast.
            # So the video is downloaded once (kept and reused) and the clips are cut from it.
            self._download_full(src, max_height, 0.0, 0.8, "")
            lo = 0.8
        n = max(1, len(ranges))
        for i, (a, b) in enumerate(ranges):
            stem = f"sec_{int(a * 1000):010d}_{int(b * 1000):010d}_h{max_height}f{fps}"
            dst = out_dir / (stem + ".mp4")
            p0, p1 = lo + (1 - lo) * i / n, lo + (1 - lo) * (i + 1) / n
            label = f"Getting clip {i + 1} of {n}"
            if not dst.exists():
                want = max(0.5, min(b, src.duration or b) - a)
                if src.kind == "file":
                    self._cut(src.path, None, a, b, dst, p0, p1, label, max_height, fps, expect=want)
                else:
                    full = self._full_download_path(src)
                    if full is not None:                 # downloaded in full earlier: cut locally
                        self._cut(str(full), None, a, b, dst, p0, p1, label, max_height, fps, expect=want)
                    else:
                        try:
                            if streams is None:
                                self.progress(p0, f"{label}: finding the video stream…")
                                streams = self._resolve_streams(src.url, max_height)
                            self._cut_from_streams(streams, a, b, dst, p0, p1, label, max_height, fps, want)
                        except IngestError as e:
                            if "Cancelled" in str(e):
                                raise
                            full = self._download_full(src, max_height, p0, p1, str(e), streams=streams,
                                                       lookup=False)
                            self._cut(str(full), None, a, b, dst, p0, p1, label, max_height, fps, expect=want)
            result[(a, b)] = str(dst)
            self.progress(p1, f"Clip {i + 1} of {n} ready")
        return result

    @staticmethod
    def _prefer_full(src: VideoSource) -> bool:
        return src.platform == "youtube" or "youtu" in (src.url or "")

    # ---- section helpers
    def _cut(self, video: str, audio: str | None, a: float, b: float, dst: Path, p0: float, p1: float,
             label: str, max_height: int, fps: int, pre_inputs: list[list[str]] | None = None,
             expect: float | None = None) -> None:
        """Frame-accurate cut + H.264/AAC encode, reporting real progress."""
        tmp = ff._partial(str(dst))
        ins: list[str] = []
        sources = [video] + ([audio] if audio else [])
        for k, url in enumerate(sources):
            ins += (pre_inputs[k] if pre_inputs else []) + ["-ss", f"{a:.3f}", "-i", url]
        amap = ["-map", "1:a:0"] if audio else ["-map", "0:a:0?"]
        vf = f"scale=-2:'min({max_height},ih)':flags=bicubic,fps='min({fps},source_fps)'"
        args = ins + ["-t", f"{b - a:.3f}", "-map", "0:v:0", *amap,
                      "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p",
                      "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-max_error_rate", "1.0",
                      "-movflags", "+faststart", "-f", "mp4", tmp]
        prog = lambda f, m: self.progress(p0 + (p1 - p0) * f, label)
        remote = video.startswith("http")
        alog(f"{label}: cutting {a:.2f}-{b:.2f}s from {'the stream' if remote else Path(video).name}")
        try:
            # a network read that never moves forward (40 s) or crawls is stopped; the fallback takes over
            ff.run(args, prog, b - a, label, self.cancel, stall=self.STREAM_STALL if remote else None,
                   min_speed=self.STREAM_MIN_SPEED if remote else 0.0)
        except (ff.FFmpegError, ff.FFmpegStalled) as e:
            Path(tmp).unlink(missing_ok=True)
            if self.cancel and self.cancel():
                raise IngestError("Cancelled") from e
            alog(f"{label} failed: {str(e)[-600:]}")
            raise IngestError(f"{label} failed: {str(e)[-400:]}") from e
        # never accept a clip that isn't exactly what was asked for: picture and sound must both
        # start at the requested moment and run the full length (otherwise captions and cuts drift)
        want = (expect if expect is not None else b - a)
        times = ff.stream_times(tmp)
        bad = []
        for kind in ("video", "audio") if (audio or "audio" in times) else ("video",):
            st, du = times.get(kind, (0.0, 0.0))
            if kind not in times:
                bad.append(f"no {kind}")
            elif abs(st) > 0.12 or du < want - 0.3:
                bad.append(f"{kind} starts at {st:.2f}s and lasts {du:.2f}s (wanted 0.00s / {want:.2f}s)")
        if bad:
            Path(tmp).unlink(missing_ok=True)
            alog(f"{label}: incomplete clip refused: {'; '.join(bad)}")
            raise IngestError(f"{label}: the clip came back incomplete ({'; '.join(bad)})")
        os.replace(tmp, dst)
        alog(f"{label}: done")

    def _resolve_streams(self, url: str, max_height: int) -> dict:
        """Direct stream addresses for the best formats up to max_height (public access only)."""
        import yt_dlp  # type: ignore

        fmt = f"bv*[height<={max_height}]+ba/b[height<={max_height}]/bv*+ba/b"
        opts = _ydl_base_opts() | {"format": fmt}

        jar: dict = {}

        def get():
            with yt_dlp.YoutubeDL(opts) as ydl:
                inf = ydl.sanitize_info(ydl.extract_info(url, download=False))
                # the stream servers can expect the cookies the site set during the lookup
                # (yt-dlp hands them to FFmpeg the same way); public session cookies only
                for f in inf.get("requested_formats") or [inf]:
                    u = f.get("url") or ""
                    if u.startswith("http"):
                        jar[u] = "".join(f"{c.name}={c.value}; path={c.path}; domain={c.domain};\r\n"
                                         for c in ydl.cookiejar.get_cookies_for_url(u))
                return inf
        alog(f"Looking up the video streams for {url}")
        info = _in_thread_with_limit(lambda: _with_retries(get, self.cancel), self.LOOKUP_LIMIT, self.cancel,
                                     f"the site didn't answer within {self.LOOKUP_LIMIT:.0f} s while looking up "
                                     "the video stream")
        fmts = info.get("requested_formats") or [info]
        vid = next((f for f in fmts if (f.get("vcodec") or "none") != "none"), fmts[0])
        aud = next((f for f in fmts if f is not vid and (f.get("acodec") or "none") != "none"), None)
        for f in [vid] + ([aud] if aud else []):
            alog(f"  stream {f.get('format_id')}: {f.get('protocol')} {f.get('height') or ''}p "
                 f"{f.get('vcodec')}/{f.get('acodec')} {f.get('ext')}")

        def pre(f):
            u = f.get("url") or ""
            if not u.startswith("http"):
                return []
            hdr = "".join(f"{k}: {v}\r\n" for k, v in (f.get("http_headers") or info.get("http_headers") or {}).items())
            out = ["-reconnect", "1", "-reconnect_on_network_error", "1", "-reconnect_delay_max", "5",
                   "-rw_timeout", "30000000"]
            if jar.get(u):
                out += ["-cookies", jar[u]]
            return out + (["-headers", hdr] if hdr else [])
        dur = float(info.get("duration") or 0)
        size = 0
        for f in [vid] + ([aud] if aud else []):
            size += f.get("filesize") or f.get("filesize_approx") or (float(f.get("tbr") or 0) * 125 * dur)
        return {"video": vid["url"], "audio": aud["url"] if aud else None,
                "pre": [pre(vid)] + ([pre(aud)] if aud else []), "size": int(size)}

    def _cut_from_streams(self, st: dict, a: float, b: float, dst: Path, p0: float, p1: float, label: str,
                          max_height: int, fps: int, want: float) -> None:
        last = None
        for attempt in range(2):          # one retry for a dropped connection
            try:
                self._cut(st["video"], st["audio"], a, b, dst, p0, p1, label, max_height, fps, st["pre"], want)
                return
            except IngestError as e:
                if "Cancelled" in str(e) or "came back incomplete" in str(e):
                    raise             # an incomplete read repeats: go straight to the fallback
                last = e
                self.progress(p0, f"{label}: retrying…")
        raise last  # type: ignore[misc]

    def _full_download_path(self, src: VideoSource) -> Path | None:
        d = SourceCache(src.source_id).path("full")
        got = [p for p in Path(d).glob("full.*") if p.suffix in (".mp4", ".mkv", ".webm")] if Path(d).is_dir() else []
        return got[0] if got else None

    def _download_full(self, src: VideoSource, max_height: int, p0: float, p1: float, why: str,
                       streams: Optional[dict] = None, lookup: bool = True) -> Path:
        """Download the video once in edit quality (kept in the cache and reused for every clip and
        later edit) — first choice for YouTube, the fallback elsewhere. Checks disk space first
        and asks before a very large download."""
        from .storage import LARGE, StorageError, check_space, free_bytes, human

        if why:
            self.progress(p0, "Reading clips directly didn't work — downloading the video once instead…")
            alog(f"Falling back to one full download because: {why[:500]}")
        else:
            self.progress(p0, "Downloading the video once in full quality…")
        d = SourceCache(src.source_id).subdir("full")
        fmt = f"bv*[height<={max_height}]+ba/b[height<={max_height}]/bv*+ba/b"
        size = 0
        if streams is not None:                 # already looked up: reuse its size estimate
            size = streams.get("size") or 0
        elif lookup:                            # (skipped when the lookup just failed: it would fail again)
            try:
                size = self._resolve_streams(src.url, max_height).get("size") or 0
            except IngestError as e:
                if "Cancelled" in str(e):
                    raise
                size = 0
        if not size:   # unknown: assume about 8 Mbit/s for 1080p
            size = (src.duration or 1800) * 1_000_000
        alog(f"Full download estimated at {human(size)}; {human(free_bytes(d))} free")
        try:
            check_space(d, size * 1.1, "downloading this video")
        except StorageError as e:
            raise IngestError(str(e)) from e
        if size > LARGE and self.confirm is not None and not self.confirm(
                f"Making clips from this video needs one download of about {human(size)} "
                f"(kept so later edits don't download again). Continue?"):
            raise IngestError("Cancelled")
        try:
            got = self._ydl_download(src.url, fmt, str(d / "full.mp4"), p0, p1, "Downloading the video (once)")
        except IngestError as e:
            raise IngestError(f"Couldn't get the clips from this link.\nReading the clips: {why[:300]}\n"
                              f"Downloading the video: {e}") from e
        return Path(got)
