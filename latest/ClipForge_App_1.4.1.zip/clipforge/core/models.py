"""Plain data structures shared by every stage.

Everything here is JSON-serialisable through ``to_dict``/``from_dict`` so projects can be
saved, cached and resumed.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import get_args, get_origin, get_type_hints


class Serializable:
    def to_dict(self) -> dict:
        return asdict(self)  # type: ignore[arg-type]

    @classmethod
    def from_dict(cls, data: dict):
        hints = get_type_hints(cls)
        kwargs = {}
        for f in fields(cls):  # type: ignore[arg-type]
            if f.name not in data:
                continue
            kwargs[f.name] = _coerce(hints.get(f.name), data[f.name])
        return cls(**kwargs)


def _coerce(tp, value):
    if value is None or tp is None:
        return value
    origin = get_origin(tp)
    args = get_args(tp)
    if origin is list and args:
        return [_coerce(args[0], v) for v in value]
    if origin is dict:
        return value
    if origin is not None and type(None) in args:  # Optional[X]
        inner = [a for a in args if a is not type(None)][0]
        return _coerce(inner, value)
    if isinstance(tp, type) and is_dataclass(tp) and isinstance(value, dict):
        return tp.from_dict(value)  # type: ignore[attr-defined]
    return value


# ---------------------------------------------------------------------------
# Source and rights
# ---------------------------------------------------------------------------

RIGHTS_BASES = {
    "own": "I created this footage / it is my own stream",
    "written_permission": "I have written permission from the creator to edit and publish it",
    "licence": "I have a licence covering this use (including the game publisher where needed)",
    "non_commercial": "Non-commercial use only (no monetization)",
}


@dataclass
class RightsRecord(Serializable):
    basis: str = ""                 # key of RIGHTS_BASES
    creator: str = ""               # streamer / channel name
    commercial_use: bool = False    # does the permission cover monetized use?
    game_publisher_ok: bool = False # has the game publisher's policy been checked / licence obtained?
    notes: str = ""                 # e.g. where the written permission is stored
    confirmed: bool = False

    def problems(self, monetized: bool) -> list[str]:
        out = []
        if not self.confirmed or self.basis not in RIGHTS_BASES:
            out.append("Record how you have permission to use this footage (Page 1, Source rights).")
        if monetized and self.basis == "non_commercial":
            out.append("This source is marked non-commercial, but the export is marked as monetized.")
        if monetized and not self.commercial_use:
            out.append("The permission on record does not cover commercial (monetized) use.")
        if monetized and not self.game_publisher_ok:
            out.append("Game footage: the publisher's commercial-use policy has not been confirmed for monetized use.")
        return out


@dataclass
class VideoSource(Serializable):
    source_id: str = ""             # stable cache key
    kind: str = "file"              # "url" or "file"
    url: str = ""
    path: str = ""                  # local media path (full quality) if available
    platform: str = ""              # youtube / twitch / kick / file / other
    title: str = ""
    uploader: str = ""
    duration: float = 0.0
    width: int = 0
    height: int = 0
    fps: float = 0.0
    proxy_path: str = ""            # low-res analysis copy
    audio_path: str = ""            # 16 kHz mono wav used for analysis
    rights: RightsRecord = field(default_factory=RightsRecord)


# ---------------------------------------------------------------------------
# Transcript
# ---------------------------------------------------------------------------

@dataclass
class Word(Serializable):
    text: str
    start: float
    end: float
    prob: float = 1.0
    speaker: str = ""


@dataclass
class Sentence(Serializable):
    idx: int
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)
    speaker: str = ""


@dataclass
class Transcript(Serializable):
    language: str = "en"
    sentences: list[Sentence] = field(default_factory=list)
    backend: str = ""

    def text_between(self, start: float, end: float) -> str:
        return " ".join(s.text for s in self.sentences if s.end > start and s.start < end)

    def sentences_between(self, start: float, end: float) -> list[Sentence]:
        return [s for s in self.sentences if s.end > start and s.start < end]

    def words_between(self, start: float, end: float) -> list[Word]:
        out = []
        for s in self.sentences:
            if s.end < start or s.start > end:
                continue
            out.extend(w for w in s.words if w.end > start and w.start < end)
        return out


# ---------------------------------------------------------------------------
# Topic understanding
# ---------------------------------------------------------------------------

@dataclass
class TopicSpec(Serializable):
    """The model's structured understanding of what the user asked for."""
    raw: str = ""
    summary: str = ""
    visual_positive: list[str] = field(default_factory=list)   # things that should be on screen
    visual_negative: list[str] = field(default_factory=list)   # look-alikes that are NOT the topic
    speech_cues: list[str] = field(default_factory=list)       # things people might say
    keywords: list[str] = field(default_factory=list)
    entertainment_criteria: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    needs_visual: bool = True        # topic is mainly visual (chase, crash)
    needs_speech: bool = True        # topic is mainly about what is said (funny line)
    sub_topics: list[str] = field(default_factory=list)
    sounds: list[str] = field(default_factory=list)            # sound groups typical of the topic (siren, crash…)
    # how the Short should be told, read from the request ("describe the four coolest things")
    count: int = 0                   # number of moments asked for (0 = not said)
    format: str = ""                 # countdown (#N … #1) / list / story (chronological) / "" = ClipForge decides
    detail: str = ""                 # detailed (describe each moment) / light / none (no narration) / ""
    instructions: str = ""           # what the narration should say, in the user's words
    search: str = ""                 # the part of the request that says what to look for
    superlative: str = ""            # "coolest", "craziest"… (for titles: "THE 4 COOLEST MOMENTS")
    open: bool = False               # no subject ("the coolest things"): any entertaining moment qualifies


# ---------------------------------------------------------------------------
# Candidates
# ---------------------------------------------------------------------------

@dataclass
class Evidence(Serializable):
    transcript: str = ""
    transcript_before: str = ""
    transcript_after: str = ""
    visual_labels: list[str] = field(default_factory=list)   # top matching visual concepts over time
    frame_captions: list[str] = field(default_factory=list)  # from the optional vision LLM
    audio_summary: str = ""
    keyframe_times: list[float] = field(default_factory=list)


@dataclass
class Candidate(Serializable):
    cid: str
    start: float
    end: float
    # proposal-stage signals (0..1)
    visual_relevance: float = 0.0
    speech_relevance: float = 0.0
    sound_relevance: float = 0.0     # topic sounds heard (siren, crash…), from the sound-event model
    excitement: float = 0.0
    novelty: float = 0.0
    proposal_score: float = 0.0
    reasons: list[str] = field(default_factory=list)
    evidence: Evidence = field(default_factory=Evidence)
    # judge-stage (0..10 unless noted)
    topic_match: float = 0.0
    entertainment: float = 0.0
    context_completeness: float = 0.0
    audio_quality: float = 0.0
    visual_quality: float = 0.0
    hook_potential: float = 0.0
    confidence: float = 0.0
    final_score: float = 0.0
    description: str = ""
    why_matches: str = ""
    judged_by: str = ""
    best_moment: float = -1.0   # absolute source time of the most striking instant
    # user decisions
    included: bool = False
    locked: bool = False        # user forced it in
    excluded: bool = False      # user removed it (never auto-picked again)
    rank: int = 0

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


# ---------------------------------------------------------------------------
# Story, script, overlays
# ---------------------------------------------------------------------------

@dataclass
class StoryItem(Serializable):
    cid: str
    role: str = ""          # hook / context / escalation / peak / payoff
    rationale: str = ""
    start: float = 0.0      # final in/out on the source timeline
    end: float = 0.0
    context_text: str = ""  # optional on-screen context caption for this clip


@dataclass
class NarrationLine(Serializable):
    text: str
    position: str = "before"     # before / over-start / after  (relative to the story item)
    item_index: int = 0          # which story item it belongs to
    audio_path: str = ""
    duration: float = 0.0
    t_start: float = -1.0        # placement on the output timeline (filled by the timeline builder)


@dataclass
class HookOption(Serializable):
    headline: str
    opening_line: str
    first_item_index: int = 0
    score: float = 0.0
    rationale: str = ""


@dataclass
class Overlay(Serializable):
    text: str
    kind: str = "headline"   # headline / context / emphasis / end
    t_start: float = 0.0
    t_end: float = 0.0
    position: float = -1.0   # 0..1 vertical; -1 = style default


@dataclass
class CaptionChunk(Serializable):  # noqa: D101
    """One on-screen subtitle group (2-4 words). Times are on the OUTPUT timeline.
    ``kind``: narration (the voice-over) / dialogue (the streamer) / emphasis (the key line at a clip's peak)."""
    kind: str = "dialogue"
    start: float = 0.0
    end: float = 0.0
    words: list[Word] = field(default_factory=list)
    edited: bool = False
    speaker: str = ""

    @property
    def text(self) -> str:
        return " ".join(w.text for w in self.words)


# ---------------------------------------------------------------------------
# Narration-driven and hybrid videos (creative modes)
# ---------------------------------------------------------------------------

@dataclass
class CreativeBrief(Serializable):
    """What the user asked for, read from the prompt (and optional settings)."""
    mode: str = "clip"               # clip (footage tells the story) / narration / hybrid
    mode_reason: str = ""            # why this mode was chosen (shown to the user)
    subject: str = ""                # what the video is about
    style: str = ""                  # informative / documentary / educational / entertaining / dramatic /
                                     # conversational / storytelling / commentary / news
    tone: str = ""                   # free words from the prompt ("funny, fast-paced")
    pacing: str = "normal"           # slow / normal / fast (how often the picture changes)
    points: int = 0                  # "five interesting features" = 5
    visual_style: str = ""           # "visually satisfying", "cinematic"…
    dialogue: str = ""               # none / some / lots (original streamer moments, hybrid)
    music: str = ""                  # music preference words
    script_source: str = "ai"        # ai (the language model writes it) / user (pasted script)
    user_script: str = ""            # the user's own narration, if they pasted one
    notes: str = ""                  # facts / notes the user supplied (the only facts used when given)
    source_urls: list[str] = field(default_factory=list)
    footage: str = ""                # which footage the prompt asks for ("the cartoon footage" = "cartoon")


@dataclass
class Shot(Serializable):
    """One piece of footage on screen during a narration section."""
    source_id: str
    start: float
    end: float
    score: float = 0.0
    why: str = ""                    # what it matched and how well, in plain words
    locked: bool = False             # chosen by the user: kept when the section is re-matched

    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass
class Section(Serializable):
    """One part of a narration-driven video: what is said, what should be on screen, and the
    footage picked for it. ``kind`` 'moment' = an original clip with its own sound (hybrid)."""
    sid: str
    role: str = "point"              # hook / intro / point / conclusion / moment
    label: str = ""                  # short on-screen label ("1. Living city") — optional
    text: str = ""                   # narration (empty for a moment)
    visuals: list[str] = field(default_factory=list)   # what should be on screen (short descriptions)
    shots: list[Shot] = field(default_factory=list)
    kind: str = "narration"          # narration / moment
    cid: str = ""                    # candidate id of a moment
    claims: str = ""                 # verified / from your sources / general knowledge / speculation
    continue_visual: bool = False    # keep the previous section's footage running (one visual, two sections)
    edited: bool = False             # text edited by hand (kept when other sections are rewritten)
    audio_path: str = ""
    duration: float = 0.0


@dataclass
class LibraryItem(Serializable):
    """A video in the project's footage library."""
    source_id: str
    path: str = ""
    url: str = ""
    title: str = ""
    role: str = "broll"              # main / broll / reaction / atmosphere
    duration: float = 0.0


@dataclass
class Plan(Serializable):
    """Everything the renderer needs. Edited on pages 3-5."""
    topic: TopicSpec = field(default_factory=TopicSpec)
    target_seconds: float = 45.0
    desired_clips: int = 0      # 0 = automatic
    story: list[StoryItem] = field(default_factory=list)
    hooks: list[HookOption] = field(default_factory=list)
    chosen_hook: int = 0
    narration: list[NarrationLine] = field(default_factory=list)
    overlays: list[Overlay] = field(default_factory=list)
    captions: list[CaptionChunk] = field(default_factory=list)
    title: str = ""
    description: str = ""
    monetized: bool = False
    # creative modes (narration-driven / hybrid); the clip-driven mode leaves these empty
    brief: CreativeBrief = field(default_factory=CreativeBrief)
    sections: list[Section] = field(default_factory=list)
    sources_note: str = ""           # where the narration's facts came from (shown + in the description)


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def fmt_time(t: float) -> str:
    t = max(0.0, t)
    h, rem = divmod(int(t), 3600)
    m, s = divmod(rem, 60)
    frac = int((t - int(t)) * 10)
    return f"{h}:{m:02d}:{s:02d}.{frac}" if h else f"{m}:{s:02d}.{frac}"
