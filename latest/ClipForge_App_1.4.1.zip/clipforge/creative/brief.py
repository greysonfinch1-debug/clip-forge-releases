"""Understand the creative prompt: which kind of video, in which style.

Three modes:
  clip       the footage tells the story (find moments, narrate around them) — the original mode
  narration  the narration tells the story; footage is chosen to accompany each part of it
  hybrid     both: real moments (with their own sound) and narrated parts over supporting footage

The prompt is read with simple rules first (works without any AI model); when the language model
is available it reads the prompt too and its reading is used where the rules found nothing.
A mode or style chosen in the app's options always wins.
"""
from __future__ import annotations

import re

from ..core.models import CreativeBrief
from ..intelligence.topic import parse_request
from ..providers.base import LLM, ProviderUnavailable

STYLES = ["informative", "documentary", "educational", "entertaining", "dramatic", "conversational", "storytelling",
          "commentary", "news"]
STYLE_LABELS = {"": "Automatic (from the prompt)", "informative": "Informative", "documentary": "Documentary",
                "educational": "Educational", "entertaining": "Entertaining", "dramatic": "Dramatic",
                "conversational": "Conversational", "storytelling": "Storytelling", "commentary": "Commentary",
                "news": "News-style"}
MODES = {"auto": "Automatic (from the prompt)", "clip": "Clip-driven: the footage tells the story",
         "narration": "Narration-driven: the narration tells the story, footage supports it",
         "hybrid": "Hybrid: real moments and narration together"}

_EXPLAIN = re.compile(
    r"\b(explain\w*|explaining|why\s+(?:is|are|does|do|it|this|they|the)|how\s+(?:it|this|they|the)\s+\w+|"
    r"how\s+to\b|history\s+of|features?\b|facts?\b|documentary|news\b|upcoming|teach\w*|lesson|tutorial|guide\b|"
    r"review\b|analy[sz]\w*|essay|introduc\w*|top\s+\d+\s+(?:reasons|facts|features|changes|things\s+to\s+know)|"
    r"reasons?\b|mechanic\w*|lore|theor(?:y|ies)|trivia|did\s+you\s+know|breakdown|deep\s+dive|overview|"
    r"tell\s+(?:me|us|people|viewers)\s+about|talk\s+about|story\s+of\s+(?!the\s+stream)|educational|"
    r"tips?\b|rules?\s+(?:for|of|to)|ways?\s+to|steps?\s+to|poem|poetry|essay|monologue|speech|explainer|"
    r"report\b|story\s+about|mood\s+piece)", re.I)
_BACKGROUND = re.compile(
    r"\b(background\s+(?:footage|gameplay|video|visuals?)|as\s+(?:the\s+)?(?:visual\s+)?background|b-?roll|"
    r"supporting\s+(?:footage|visuals?|gameplay)|(?:relevant|matching|satisfying|interesting)\s+(?:gaming\s+)?"
    r"(?:footage|gameplay|visuals?)|while\s+(?:the\s+)?narrat\w*|while\s+(?:i|you|it)\s+explain|"
    r"show\s+(?:relevant|some|matching)\s+(?:gameplay|footage)|"
    r"(?:footage|gameplay|clips?|videos?|visuals?)\s+(?:in|as)\s+(?:the\s+)?background|"
    r"cover\s+(?:it|this|that|them)\s+with|over\s+(?:the\s+)?(?:footage|gameplay|clips|video)|"
    r"(?:footage|picture|visuals?)\s+(?:changes|follows|matches)\s+(?:with\s+)?(?:the\s+|every\s+)?"
    r"(?:narration|line|script|words?)|(?:store|cartoon|calm|stock)\s+footage\s+behind)\b", re.I)
_CLIPS = re.compile(
    r"\b(moments?|clips?|highlights?|compilation|montage|reactions?|funniest|craziest|best\s+plays?|fails?|"
    r"when\s+(?:he|she|they|the\s+streamer)|times?\s+(?:he|she|they)|chases?|crash(?:es)?|"
    r"find\s+(?:me\s+)?(?:the|all|some|every|clips?|moments?|parts?|times?|when|where))\b", re.I)
_HYBRID = re.compile(
    r"\b(hybrid|mix(?:ed|ing)?|combin\w*|open\s+with\s+(?:an?|the|his|her|a\s+real)\s+[\w\s]{0,30}?moment|"
    r"(?:insert|include|add|with|plus|and|keep)\s+(?:in\s+)?(?:the\s+)?(?:best\s+|funniest\s+|biggest\s+|some\s+)?"
    r"(?:his|her|their|the\s+streamer'?s?|streamer'?s?|real|actual|original)\s+"
    r"(?:streamer\s+)?(?:reactions?|moments?|clips?|gameplay\s+moments?)|actual\s+(?:gameplay\s+)?moments?|"
    r"real\s+moments?|then\s+explain|and\s+explain\s+(?:it|them|what|why))\b", re.I)
_NARRATED = re.compile(r"\b(narrat\w*|voice[- ]?over|voiced)\b", re.I)
_STYLE_WORDS = [
    ("documentary", r"documentar\w*"), ("news", r"\bnews\b|news-style|breaking|announcement|update\b"),
    ("educational", r"educational|teach\w*|lesson|tutorial|learn\w*"),
    ("dramatic", r"dramatic|epic|intense|suspense\w*|cinematic\s+narration"),
    ("storytelling", r"storytell\w*|tell\s+(?:the|a)\s+story|tale\b|narrative|poem|poetry|story\s+about"),
    ("commentary", r"commentary|opinion|hot\s+take|rant|react\s+to"),
    ("conversational", r"conversational|casual|chill\s+tone|like\s+a\s+friend|chatty"),
    ("entertaining", r"entertaining|funny|humou?r\w*|fun\b|hilarious|comedic|meme"),
    ("informative", r"informative|explain\w*|facts?\b|features?\b|interesting\s+things"),
]
_FAST = re.compile(r"\b(fast[- ]paced|fast\b|quick(?:\s+|-)(?:cuts?|edits?|pace|paced|cutting)|rapid|energetic|hype|"
                   r"snappy|punchy)\b", re.I)
_SLOW = re.compile(r"\b(slow\w*|calm\w*|relax\w*|chill\b|cinematic|peaceful|atmospheric|visually\s+satisfying)\b", re.I)
_VISUAL_STYLE = re.compile(r"\b(visually\s+(?:satisfying|interesting|stunning)|cinematic|scenic|beautiful|"
                           r"aesthetic|wide\s+shots?|smooth)\b", re.I)
_NO_DIALOGUE = re.compile(r"\b(no|without)\s+(?:the\s+)?(?:streamer|reactions?|original\s+(?:audio|dialogue)|"
                          r"talking|commentary\s+from)\b", re.I)
# a request for music ("with calm music", "add some upbeat background music"), not a topic ("why stores play music")
_MUSIC = re.compile(r"\b(?:with|use|using|add|over|plus|and|set\s+to)\s+(?:some\s+|a\s+bit\s+of\s+|the\s+|a\s+)?"
                    r"([a-z-]+\s+)?(?:background\s+)?music\b", re.I)
_NO_MUSIC = re.compile(r"\b(?:no|without)\s+(?:background\s+)?music\b", re.I)


def rule_brief(prompt: str) -> CreativeBrief:
    text = " ".join((prompt or "").split())
    b = CreativeBrief()
    explain = len(_EXPLAIN.findall(text))
    background = bool(_BACKGROUND.search(text))
    clips = len(_CLIPS.findall(text))
    hybrid = bool(_HYBRID.search(text))
    narrated = bool(_NARRATED.search(text))
    if hybrid and (explain or background or narrated):
        b.mode, b.mode_reason = "hybrid", "the prompt mixes real moments with narration"
    elif background or (explain and explain >= clips) or (narrated and not clips):
        b.mode = "narration"
        b.mode_reason = ("the prompt asks for footage that supports the narration" if background else
                         "the prompt asks to explain or inform, so the narration leads" if explain else
                         "the prompt asks for a narrated video and no particular moments")
    else:
        b.mode, b.mode_reason = "clip", "the prompt asks for moments from the footage"
    for style, pat in _STYLE_WORDS:
        if re.search(pat, text, re.I):
            b.style = style
            break
    if b.mode != "clip" and not b.style:
        b.style = "informative" if explain else "conversational"
    tones = re.findall(r"\b(funny|fast-paced|serious|calm|dramatic|epic|chill|hype|wholesome|dark|mysterious|"
                       r"informative|entertaining|engaging|satisfying|exciting|nostalgic)\b", text, re.I)
    b.tone = ", ".join(dict.fromkeys(t.lower() for t in tones))
    if re.search(r"\b(?:\w+|\d+)[- ]year[- ]olds?\b|\bkids?\b|\bchild(?:ren)?\b|\bbeginners?\b|\blike\s+i'?m\s+five\b",
                 text, re.I):
        b.tone = ", ".join(x for x in (b.tone, "simple words for the audience named in the request") if x)
    b.pacing = "fast" if _FAST.search(text) else ("slow" if _SLOW.search(text) else "normal")
    req = parse_request(text)
    b.points = req["count"]
    vs = _VISUAL_STYLE.findall(text)
    b.visual_style = ", ".join(dict.fromkeys(v.lower() for v in vs))
    b.footage = _footage_hint(text)
    b.dialogue = "none" if _NO_DIALOGUE.search(text) else ("some" if b.mode == "hybrid" else "")
    m = _MUSIC.search(text)
    if _NO_MUSIC.search(text):
        b.music = "none"
    elif m:
        w = (m.group(1) or "").strip().lower()
        b.music = "any" if w in ("", "background", "some", "the") else w
    b.subject = _subject(text)
    return b


_GENERIC_FOOTAGE = {"the", "my", "some", "this", "that", "relevant", "matching", "supporting", "background",
                    "any", "your", "our", "his", "her", "their", "other", "original", "real", "as", "of", "all"}


# how the footage should feel, not which footage ("calm footage" is pacing / style, not a kind of video)
_MOOD_WORDS = {"calm", "relaxing", "chill", "cinematic", "dramatic", "fast", "slow", "funny", "epic", "cool", "nice",
               "good", "great", "best", "random", "short", "long", "wide", "close", "satisfying", "aesthetic",
               "beautiful", "scenic", "smooth", "interesting", "exciting", "quiet", "loud", "moody", "dark", "bright",
               "high-quality", "hd", "4k", "fitting", "suitable", "appropriate", "different", "more", "less"}


def _footage_hint(text: str) -> str:
    """Which footage the prompt asks for: "use the cartoon footage" → "cartoon", "with store footage
    behind it" → "store" ("use the footage as background" names none)."""
    m = re.search(r"\b(?:use|using|with|over|from|cover\s+it\s+with)\s+((?:[\w-]+\s+){1,3}?)(?:footage|clips?|videos?|"
                  r"b-?roll|gameplay)\b", text, re.I)
    if not m:
        return ""
    words = [w for w in m.group(1).lower().split() if w not in _GENERIC_FOOTAGE and w not in _MOOD_WORDS]
    return " ".join(words)


_TRAIL = re.compile(
    r"[.;!?]|,\s*(?:with|use|using|footage|narrat\w*|keep|quick|slow|fast|calm|documentary|educational|informative|"
    r"storytelling|conversational|dramatic|news|entertaining|commentary|in\s+the\s+background)\b|"
    r"\b(?:use|using|while|show(?:ing)?|make\s+the|keep\s+it|as\s+(?:the\s+)?(?:b-?roll|background)|"
    r"in\s+the\s+background|with\s+(?:the\s+)?(?:store|cartoon|calm|clips?|footage|gameplay|real|actual|original|"
    r"his|her|their)|and\s+(?:cover|use|show|add|include|insert|keep|make|end)|then\s+(?:end|finish|close))\b", re.I)
_FORMAT_LABEL = re.compile(r"video|short|report|explainer|documentary|list|clip|story|narration|poem|piece|montage|"
                           r"did\s+you\s+know|news|style", re.I)


def _subject(text: str) -> str:
    """The subject in a few words ("five interesting features of GTA 6 that make its world feel realistic")."""
    m = re.search(r"\b(?:then\s+|and\s+)?explain(?:s|ing)?\s+(.+)", text, re.I)
    if m and re.match(r"^\s*(?:open|start|begin)\b", text, re.I):   # "Open with X, then explain Y": Y
        return _TRAIL.split(m.group(1), maxsplit=1)[0].strip(" ,")
    t = text
    lab = re.match(r"^\s*([^:?]{0,60})[:?]\s+(.+)$", t)          # "News-style report: X", "Did you know? X"
    if lab and _FORMAT_LABEL.search(lab.group(1)):
        t = lab.group(2)
    m = re.search(r"\b(?:about|explaining|that\s+explains|explains?|describing|on\s+the\s+topic\s+of)\s+"
                  r"(?:to\s+(?:a|an|my|the)\s+[\w'-]+(?:\s+[\w'-]+)?\s+(?=why|how|what|the|a\b))?(.+)", t, re.I)
    if m:
        t = m.group(1)
    else:
        t = re.sub(r"^(?:please\s+)?(?:(?:can|could)\s+you\s+)?(?:make|create|build|do|write|give\s+me)\s+(?:me\s+)?"
                   r"(?:an|a|the)?\b\s*(?:funny,?\s+|fast-paced,?\s+|short\s+|quick\s+)*(?:youtube\s+)?"
                   r"(?:video|short|documentary(?:-style\s+short)?|clip)?\s*", "", t, flags=re.I)
        t = re.sub(r"^(?:describe|show|tell\s+(?:me|us)\s+about)\s+", "", t, flags=re.I)
    t = _TRAIL.split(t, maxsplit=1)[0]
    return t.strip(" ,'\"") or text[:120]


LLM_SYSTEM = """You read a video creator's request for a YouTube Short and say what kind of video it is.
Modes:
- "clip": the video is built from moments found in the creator's footage (highlights, funniest/craziest moments, reactions, compilations). Narration, if any, describes those moments.
- "narration": the narration tells the story (explains, informs, reviews, tells a history, lists facts or features) and the footage is chosen to visually accompany it. The footage does not need to show the exact thing being said.
- "hybrid": both — real moments from the footage (with their original sound) AND narrated parts over supporting footage.
Reply with JSON only."""

LLM_PROMPT = """Request: "{prompt}"

Return JSON:
{{"mode": "clip|narration|hybrid", "why": "one short sentence",
  "subject": "what the video is about, in a few words",
  "style": one of {styles} or "",
  "tone": "a few words, or empty",
  "pacing": "slow|normal|fast",
  "points": number of items the request asks for (e.g. "five features" = 5), 0 if none,
  "visual_style": "what the footage should look like, or empty",
  "dialogue": "none|some|lots" (how much original streamer audio/reactions to keep; "" if not said),
  "music": "music the request asks for, 'none', or empty"}}"""


def understand_brief(prompt: str, llm: LLM, forced_mode: str = "auto", forced_style: str = "") -> CreativeBrief:
    b = rule_brief(prompt)
    try:
        d = llm.complete_json(LLM_SYSTEM, LLM_PROMPT.format(prompt=prompt, styles=STYLES), max_tokens=400)
        mode = str(d.get("mode") or "").lower()
        if mode in ("clip", "narration", "hybrid"):
            b.mode, b.mode_reason = mode, str(d.get("why") or b.mode_reason)[:200]
        b.subject = str(d.get("subject") or "").strip()[:200] or b.subject
        st = str(d.get("style") or "").lower()
        if st in STYLES:
            b.style = b.style or st
        b.tone = b.tone or str(d.get("tone") or "")[:80]
        if str(d.get("pacing") or "") in ("slow", "fast") and b.pacing == "normal":
            b.pacing = str(d["pacing"])
        try:
            n = int(d.get("points") or 0)
        except (TypeError, ValueError):
            n = 0
        b.points = b.points or (n if 1 <= n <= 10 else 0)
        b.visual_style = b.visual_style or str(d.get("visual_style") or "")[:80]
        if str(d.get("dialogue") or "") in ("none", "some", "lots") and not b.dialogue:
            b.dialogue = str(d["dialogue"])
        b.music = b.music or str(d.get("music") or "")[:40]
    except ProviderUnavailable:
        pass
    if forced_mode in ("clip", "narration", "hybrid"):
        b.mode, b.mode_reason = forced_mode, "chosen in the options"
    if forced_style:
        b.style = forced_style
    if b.mode != "clip" and not b.style:
        b.style = "informative" if _EXPLAIN.search(prompt or "") else "conversational"
    return b
