"""Creative quality check: does this Short give a viewer reasons to keep watching?

An extra layer AFTER the edit is prepared and BEFORE export. The technical QC (render/qc.py:
codec, loudness, black frames, duration) is untouched and still decides whether a file is valid.

It scores eleven areas from 0 to 10 with reasons, and lists problems with timestamps:

  hook, clarity, storytelling, retention, pacing, visual quality, visual variety, narration,
  captions, audio, ending

Every check is a measurement of the plan / timeline (times, words, shots, captions), tied to a
finding in the Shorts knowledge base (knowledge/shorts_kb.json). The thresholds come from that
research where it gives numbers, and are editorial judgement where it doesn't (marked in the
messages). A high score is NOT a prediction of views: the knowledge base is general research, and
only the user's own YouTube Studio numbers (performance.py) can show what works for their channel.

``improve`` makes one limited round of fixes (never more than ``MAX_ROUNDS``) and keeps the
original plan so the two versions can be compared or the original restored.
"""
from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from typing import Optional

from .knowledge import kb

VERSION = 1
MAX_ROUNDS = 1
AREAS = ["hook", "clarity", "storytelling", "retention", "pacing", "visual_quality", "visual_variety", "narration",
         "captions", "audio", "ending"]
LABEL = {"hook": "Hook", "clarity": "Clarity", "storytelling": "Storytelling", "retention": "Retention potential",
         "pacing": "Pacing", "visual_quality": "Visual quality", "visual_variety": "Visual variety",
         "narration": "Narration", "captions": "Captions", "audio": "Audio", "ending": "Ending"}
DISCLAIMER = ("Creative scores measure the edit against published research on attention and Shorts; they don't "
              "predict views. Your own YouTube Studio numbers are the real test.")


@dataclass
class Issue:
    area: str
    start: float
    end: float
    message: str
    fix: str = ""           # an automatic fix that can address it ("" = advice only)
    severity: int = 2       # 1 minor, 2 noticeable, 3 serious
    finding: str = ""       # knowledge-base finding / mistake id

    def to_dict(self) -> dict:
        return dict(self.__dict__)


@dataclass
class CreativeReport:
    category: str = ""
    mode: str = ""
    scores: dict = field(default_factory=dict)          # area -> 0..10
    reasons: dict = field(default_factory=dict)        # area -> [text]
    issues: list = field(default_factory=list)          # [Issue]
    stats: dict = field(default_factory=dict)
    version: int = VERSION

    @property
    def overall(self) -> float:
        w = {"hook": 2.0, "clarity": 1.5, "storytelling": 1.5, "retention": 1.5, "ending": 1.2}
        tot = sum(w.get(a, 1.0) for a in self.scores)
        return round(sum(self.scores[a] * w.get(a, 1.0) for a in self.scores) / tot, 1) if tot else 0.0

    def to_dict(self) -> dict:
        return {"category": self.category, "mode": self.mode, "scores": self.scores, "reasons": self.reasons,
                "issues": [i.to_dict() for i in self.issues], "stats": self.stats, "overall": self.overall,
                "version": self.version}

    @classmethod
    def from_dict(cls, d: dict) -> "CreativeReport":
        r = cls(category=d.get("category", ""), mode=d.get("mode", ""), scores=d.get("scores", {}),
                reasons=d.get("reasons", {}), stats=d.get("stats", {}), version=d.get("version", VERSION))
        r.issues = [Issue(**i) for i in d.get("issues", [])]
        return r

    def summary(self) -> str:
        out = [f"Creative check ({kb.profile(self.category)['name'] if self.category else 'general'}, "
               f"{self.mode or 'video'}): {self.overall}/10"]
        for a in AREAS:
            if a in self.scores:
                why = "; ".join(self.reasons.get(a, [])[:2])
                out.append(f"  {LABEL[a]:20s} {self.scores[a]:>4.1f}  {why}")
        if self.issues:
            out.append("Where to improve:")
            for i in sorted(self.issues, key=lambda x: (x.start, -x.severity)):
                out.append(f"  {_ts(i.start)}–{_ts(i.end)}  {LABEL.get(i.area, i.area)}: {i.message}")
        out.append(DISCLAIMER)
        return "\n".join(out)


def _ts(t: float) -> str:
    t = max(0.0, t)
    return f"{int(t // 60)}:{int(t % 60):02d}"


_WORD = re.compile(r"[A-Za-z0-9']+")
_STOP = set("a an the of in on at to for and or with about from by is are was be this that it its as into than then so "
            "very more most can could will would should do does did not no your you my his her their our they them we i "
            "he she just here there what when how why who which out up get got".split())


def _words(s: str) -> list[str]:
    return [w.lower() for w in _WORD.findall(s or "")]


def _content(s: str) -> set[str]:
    return {w for w in _words(s) if w not in _STOP and len(w) > 2}


def _jacc(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


# --------------------------------------------------------------------------------------- evaluate
def evaluate(plan, tl, captions, mode: str = "", category: str = "", tech_qc=None, es=None,
             skip: tuple = ()) -> CreativeReport:
    """Score the prepared edit. ``tl`` is the output timeline (segments, narration placements);
    ``tech_qc`` the technical QC report when the video has already been rendered."""
    mode = mode or getattr(plan.brief, "mode", "") or "clip"
    raw = getattr(plan, "original_prompt", "") or plan.topic.raw
    category = category or getattr(plan.brief, "category", "") or kb.detect_category(raw, mode)[0]
    prof = kb.edit_profile(category)
    r = CreativeReport(category=category, mode=mode)
    D = max(0.1, tl.duration)
    narr = sorted([(p.out_start, p.out_start + p.line.duration, p.line.text) for p in tl.narration], key=lambda x: x[0])
    segs = sorted(tl.segments, key=lambda s: s.out_start)
    dlg = [w for w, _ in tl.dialogue_words]
    first_speech = min([n[0] for n in narr] + [w.start for w in dlg] + [D])
    subject = getattr(plan.brief, "subject", "") or plan.topic.summary or raw
    subj_words = _content(subject) or _content(raw)
    r.stats.update(duration=round(D, 1), narration_lines=len(narr), shots=len(segs), first_speech=round(first_speech, 2))

    def add(area, a, b, msg, fix="", sev=2, fid=""):
        r.issues.append(Issue(area, round(a, 2), round(b, 2), msg, fix, sev, fid))

    # ---- hook (F01, F06, M01)
    s, why = 10.0, []
    if first_speech > 2.5:
        s -= 4
        add("hook", 0, first_speech, f"Nothing is said for the first {first_speech:.1f} s: a viewer has no reason to stay "
            "yet", "hook_first", 3, "F01/M01")
    elif first_speech > 1.2:
        s -= 1.5
        why.append(f"first words at {first_speech:.1f} s")
    else:
        why.append(f"speech starts at {first_speech:.1f} s")
    opening = (narr[0][2] if narr and narr[0][0] < 3.0 else " ".join(w.text for w in dlg if w.start < 3.0))
    low = opening.lower()
    stock = [p for p in kb.STOCK_PHRASES if p in low]
    if stock:
        s -= 3
        add("hook", 0, 3, f"Opening uses a stock phrase ('{stock[0]}') instead of the point", "rewrite_hook", 3, "M01/M11")
    if narr and narr[0][0] < 3.0:
        nw = len(_words(opening))
        signals = ("?" in opening or bool(re.search(r"\d|\b(one|two|three|five|ten|never|every|only|most|first|why|how|"
                                                   r"what|secret|nobody|biggest|worst|best)\b", low)))
        if nw > 22:
            s -= 1.5
            add("hook", narr[0][0], narr[0][1], f"The hook is {nw} words long; it takes too long to land", "rewrite_hook", 2,
                "F01")
        if not signals and not (_content(opening) & subj_words):
            s -= 2
            add("hook", narr[0][0], narr[0][1], "The first line neither names the subject nor opens a question or promise",
                "rewrite_hook", 2, "F02")
        else:
            why.append("first line names the subject or opens a question")
    changes_3s = sum(1 for g in segs if 0.05 < g.out_start < 3.0)
    if segs and changes_3s == 0 and D > 6 and (segs[0].out_end - segs[0].out_start) > 4.0:
        s -= 1
        why.append("one static picture for the first 3 s")
    r.scores["hook"], r.reasons["hook"] = _clip(s), why

    # ---- clarity (F14, M12)
    s, why = 10.0, []
    early = " ".join([n[2] for n in narr if n[0] < 4.0] + [o.text for o in getattr(plan, "overlays", [])
                                                          if o.kind == "headline" and o.t_start < 3.0])
    if subj_words and not (_content(early) & subj_words):
        s -= 3
        add("clarity", 0, 4, "The subject isn't named (spoken or on screen) in the first 4 s", "", 2, "F14/M12")
    else:
        why.append("subject named early")
    inside = [n for n in narr if re.search(r"\b(as i said|like i said|last time|as you know|you guys know)\b",
                                           n[2].lower())]
    for n in inside:
        s -= 2
        add("clarity", n[0], n[1], "Assumes the viewer has seen earlier videos", "rewrite", 2, "M12")
    r.scores["clarity"], r.reasons["clarity"] = _clip(s), why

    # ---- storytelling (F02, F03, M03, M04)
    s, why = 10.0, []
    lines = [n for n in narr]
    frag_pen = 0.0
    for i, n in enumerate(lines):
        nw = len(_words(n[2]))
        is_cta = bool(re.search(r"\b(follow|subscribe)\b", n[2].lower())) and nw <= 8
        if 0 < i and nw < 5 and not is_cta:
            frag_pen += 1.5
            s -= 1.5 if frag_pen <= 4.5 else 0
            add("storytelling", n[0], n[1], f"'{n[2].strip()}' is a fragment: say what and why", "rewrite", 2, "M03")
    for i in range(len(lines)):
        for j in range(i):
            if _jacc(_content(lines[i][2]), _content(lines[j][2])) >= 0.55 and len(_content(lines[i][2])) >= 3:
                s -= 2
                add("storytelling", lines[i][0], lines[i][1], f"Repeats what was said at {_ts(lines[j][0])}", "rewrite", 2,
                    "M04")
                break
    pts = getattr(plan.brief, "points", 0) or 0
    marks = 0
    if mode != "clip":
        marks = sum(1 for n in lines if re.search(r"\b(tip|step|number|reason|fact)\s+(\w+)|^(first|second|third|next|"
                                                  r"last|finally)\b", n[2].lower()))
    if pts and mode != "clip":
        if marks < min(pts, 3):
            s -= 1.5
            why.append(f"{pts} points asked for, {marks} signposted")
        else:
            why.append(f"{marks} points signposted")
    if narr and mode != "clip" and len(narr) >= 3 and marks < 2:      # a signposted list pays off its promise
        generic = {"want", "things", "thing", "these", "those", "know", "need", "here", "stop", "watch", "look"}
        hook_words = ((_content(narr[0][2]) - _content(raw)) | (_content(narr[0][2]) & subj_words)) - generic
        later = set().union(*[_content(n[2]) for n in narr[1:]])
        if hook_words and not (hook_words & later):
            s -= 1.5
            add("storytelling", narr[0][0], narr[0][1], "Nothing later picks up the hook's promise (pay it off)", "", 2,
                "F03/M02")
    r.scores["storytelling"], r.reasons["storytelling"] = _clip(s), why or ["progresses without repeats"]

    # ---- retention (F06, F16, M07)
    s, why = 10.0, []
    # new information: a new shot, a new narration line, or (clip-driven) the streamer starting to talk again
    phrases, last_end = set(), -9.0
    for w in sorted(dlg, key=lambda w: w.start):
        if w.start - last_end > 0.5:
            phrases.add(w.start)
        last_end = w.end
    events = sorted({0.0, D} | {g.out_start for g in segs} | {n[0] for n in narr} | phrases)
    worst = max(((b - a, a, b) for a, b in zip(events, events[1:])), default=(0, 0, 0))
    if worst[0] > 10.0:
        s -= 3
        add("retention", worst[1], worst[2], f"{worst[0]:.0f} s with no new picture and no new line", "split_shots", 2,
            "F16/M07")
    elif worst[0] > 7.0:
        s -= 1
        why.append(f"longest unchanged stretch {worst[0]:.0f} s")
    else:
        why.append(f"something new at least every {worst[0]:.0f} s")
    silent = _silences(narr, dlg, segs, D)
    for a, b in silent:
        s -= 1.5 if b - a > 2.5 else 0.5
        add("retention", a, b, f"{b - a:.1f} s with no voice (narration or dialogue)", "", 1 if b - a < 2.5 else 2,
            "M01")
    if D > 12 and narr and max(n[1] for n in narr) < D * 0.6 and mode != "clip":
        s -= 1
        why.append("narration ends early")
    r.scores["retention"], r.reasons["retention"] = _clip(s), why

    # ---- pacing (F04, M06)
    s, why = 10.0, []
    lens = [g.out_end - g.out_start for g in segs if g.out_end > g.out_start]
    avg = sum(lens) / len(lens) if lens else D
    lo, hi = prof["shot"]
    r.stats["avg_shot"] = round(avg, 2)
    if avg < 1.5:
        s -= 3
        add("pacing", 0, D, f"Average shot {avg:.1f} s: faster than the research's moderate optimum", "", 2, "F04/M06")
    elif avg > hi * 1.6:
        s -= 2
        why.append(f"average shot {avg:.1f} s (category typical {lo:.1f}-{hi:.1f} s)")
    else:
        why.append(f"average shot {avg:.1f} s (category typical {lo:.1f}-{hi:.1f} s)")
    nwords = sum(len(_words(n[2])) for n in narr)
    nsecs = sum(max(0.1, n[1] - n[0]) for n in narr)
    if nwords >= 12:
        wpm = 60 * nwords / nsecs
        r.stats["wpm"] = round(wpm)
        w0, w1 = prof["wpm"]
        if wpm > w1 + 25:
            s -= 2
            add("pacing", narr[0][0], narr[-1][1], f"Narration at {wpm:.0f} words/min is rushed for this kind of video "
                f"({w0}-{w1})", "", 2, "F04")
        elif wpm < w0 - 30:
            s -= 1
            why.append(f"narration slow ({wpm:.0f} wpm)")
        else:
            why.append(f"narration {wpm:.0f} wpm")
    r.scores["pacing"], r.reasons["pacing"] = _clip(s), why

    # ---- visual quality (F15)
    s, why = 10.0, []
    weak = []
    for i, sec in enumerate(getattr(plan, "sections", []) or []):
        for sh in sec.shots:
            if re.match(r"\s*(weak|loosely|no close match|unrelated)", (sh.why or "").lower()):
                weak.append((i, sh))
    if getattr(plan, "sections", None):
        shots = [sh for sec in plan.sections for sh in sec.shots]
        if shots:
            share = len(weak) / len(shots)
            s -= min(5, 8 * share)
            why.append(f"{len(shots) - len(weak)}/{len(shots)} shots clearly match their words")
            spans = getattr(tl, "item_spans", []) or []
            for i, sh in weak[:4]:
                a, b = spans[i] if i < len(spans) else (0, 0)
                add("visual_quality", a, b, "Footage only loosely matches what is said here", "rematch", 1, "F15/M05")
    else:
        why.append("clip-driven: the moments are the footage")
    r.scores["visual_quality"], r.reasons["visual_quality"] = _clip(s), why

    # ---- visual variety (M05, M07)
    s, why = 10.0, []
    seen: list[tuple[str, float, float, float, str]] = []
    reps = 0
    for g in segs:
        for f, a, b, t, kind in seen:
            if mode == "clip" and kind == "broll":
                continue            # the flash-forward teaser shows the peak again on purpose
            if f == g.src_file and min(b, g.src_out) - max(a, g.src_in) > 0.6:
                reps += 1
                add("visual_variety", g.out_start, g.out_end, f"Shows the same footage as {_ts(t)}", "rematch", 2, "M05")
                break
        seen.append((g.src_file, g.src_in, g.src_out, g.out_start, g.kind))
    s -= min(5, 2 * reps)
    longest = max(lens) if lens else 0
    if longest > prof["max_shot"] + 1.0 and mode != "clip":
        s -= 1.5
        g = max(segs, key=lambda x: x.out_end - x.out_start)
        add("visual_variety", g.out_start, g.out_end, f"One shot stays {longest:.1f} s (longest typical for this kind of "
            f"video: {prof['max_shot']:.0f} s)", "split_shots", 1, "M07")
    files = {g.src_file for g in segs}
    why.append(f"{len(segs)} shots from {len(files)} video file(s), {reps} repeat(s)")
    r.scores["visual_variety"], r.reasons["visual_variety"] = _clip(s), why

    # ---- narration (F09, F11, M11)
    s, why = 10.0, []
    if narr:
        for n in narr:
            hit = [p for p in kb.STOCK_PHRASES if p in n[2].lower()]
            if hit:
                s -= 1.5
                add("narration", n[0], n[1], f"Stock phrase '{hit[0]}' sounds generic", "rewrite", 2, "M11")
        starts = [(_words(n[2]) or [""])[0] for n in narr]
        same = max((starts.count(x) for x in set(starts)), default=0)
        if len(narr) >= 4 and same >= max(3, len(narr) * 0.6):
            s -= 1.5
            why.append("most lines start the same way")
        long_s = [n for n in narr if max((len(_words(x)) for x in re.split(r"[.!?]", n[2])), default=0) > 28]
        for n in long_s:
            s -= 1
            add("narration", n[0], n[1], "A sentence over 28 words is hard to follow by ear", "rewrite", 1, "F09")
        why.append(f"{len(narr)} lines, {nwords} words")
    else:
        why.append("no narration (the original sound carries it)")
    r.scores["narration"], r.reasons["narration"] = _clip(s), why

    # ---- captions (F07, F08, M08)
    s, why = 10.0, []
    caps = [c for c in captions or [] if c.words]
    if not caps:
        s -= 5
        add("captions", 0, D, "No captions: many viewers watch muted, and captions aid understanding", "", 2, "F07")
    else:
        dense = [c for c in caps if len(c.words) > max(prof["caption_words"] + 2, 5)]
        fast = [c for c in caps if len(" ".join(w.text for w in c.words)) / max(0.2, c.end - c.start) > 25]
        flash = [c for c in caps if c.end - c.start < 0.25]
        for c in dense[:3]:
            add("captions", c.start, c.end, f"{len(c.words)} words in one caption: hard to read at a glance",
                "caption_words", 1, "M08")
        s -= min(3, 0.5 * len(dense)) + min(2, 0.2 * len(fast)) + min(2, 0.3 * len(flash))
        if fast:
            why.append(f"{len(fast)} caption(s) faster than ~25 characters per second")
        # accuracy: narration captions must say what the voice says
        cw = [w.text for c in caps if c.kind == "narration" for w in c.words]
        nw_ = [w for n in narr for w in _words(n[2])]
        if nw_ and cw:
            def norm(ws):
                return [re.sub(r"[^a-z0-9]", "", w.lower()) for w in ws if re.sub(r"[^a-z0-9*]", "", w.lower())]
            a, b = norm(cw), norm(nw_)
            matched = sum(1 for x, y in zip(a, b) if x == y or "*" in x)
            acc = matched / max(len(a), len(b))
            r.stats["caption_match"] = round(acc, 2)
            if acc < 0.92:
                s -= 2
                add("captions", 0, D, f"Narration captions match the voice only {acc:.0%}", "", 2, "M08")
            else:
                why.append(f"captions match the narration ({acc:.0%})")
        why.append(f"{len(caps)} caption groups")
    r.scores["captions"], r.reasons["captions"] = _clip(s), why

    # ---- audio (F10, M09)
    s, why = 10.0, []
    if es is not None and getattr(es, "music_path", ""):
        if es.music_db > -18:
            s -= 2
            add("audio", 0, D, f"Music at {es.music_db:.0f} dB may compete with the narration", "", 2, "M09")
        else:
            why.append(f"music low ({es.music_db:.0f} dB) under the voice")
    if tech_qc is not None:
        for c in tech_qc.checks:
            if c.name in ("Loudness", "True peak", "Audio is not silent") and not c.ok:
                s -= 2
                add("audio", 0, D, f"{c.name}: {c.detail}", "", 2, "M09")
            if c.name == "No dead air" and not c.ok:
                s -= 1
                why.append(c.detail)
        why.append("technical audio checks included")
    else:
        why.append("audio levels are checked after rendering (technical QC)")
    r.scores["audio"], r.reasons["audio"] = _clip(s), why

    # ---- ending (F12, M10)
    s, why = 10.0, []
    last_voice = max([n[1] for n in narr] + [w.end for w in dlg] + [0.0])
    tail = D - last_voice
    if tail > 3.0:
        s -= 2
        add("ending", last_voice, D, f"The video runs {tail:.1f} s after the last words", "", 2, "M10")
    if narr and mode != "clip":
        last = narr[-1][2].lower()
        core = re.sub(r"\b(follow|subscribe)\b.*$", "", last).strip()
        if len(_words(core)) < 4 and len(narr) >= 2:
            prev = narr[-2][2]
            if len(_words(prev)) < 6:
                s -= 2
                add("ending", narr[-1][0], D, "No real conclusion: the last lines don't deliver a payoff or final "
                    "point", "add_ending", 2, "F12/M10")
        if re.search(r"\b(next time|part 2|in the next video)\b", last):
            s -= 1
            why.append("points away to another video")
    if not why:
        why.append("ends on the payoff")
    r.scores["ending"], r.reasons["ending"] = _clip(s), why
    for a in skip:                 # not measurable here (e.g. burned-in captions of a finished file)
        r.scores.pop(a, None)
        r.reasons[a] = ["not measurable from this input"]
        r.issues = [i for i in r.issues if i.area != a]
    return r


def timeline_from_file(path: str, sentences: list, duration: float, scene: float = 0.3, as_dialogue: bool = False):
    """A timeline rebuilt from a finished video: shot changes from the picture, speech from a
    transcript (``sentences`` with start/end/text). Narration and on-screen dialogue can't be told
    apart in a finished file, so all speech counts as narration."""
    import subprocess

    from .core.models import NarrationLine
    from .render.timeline import Placement, Segment, Timeline

    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vf",
                        f"select='gt(scene,{scene})',showinfo", "-an", "-f", "null", "-"],
                       capture_output=True, text=True)
    cuts = sorted(float(m) for m in re.findall(r"pts_time:([0-9.]+)", r.stderr))
    bounds = [0.0] + [c for c in cuts if 0.2 < c < duration - 0.2] + [duration]
    segs = [Segment(kind="clip", item_index=k, src_file=f"{path}#{k}", src_in=a, src_out=b, source_start=a,
                    out_start=a, out_end=b) for k, (a, b) in enumerate(zip(bounds, bounds[1:])) if b - a > 0.05]
    tl = Timeline(segments=segs, duration=duration)
    if as_dialogue:      # clip-driven: the speech is the streamer's own (no narration to judge as a script)
        for s_ in sentences:
            for w in (s_.words or []):
                tl.dialogue_words.append((w, 0))
    else:
        for s_ in sentences:
            ln = NarrationLine(text=s_.text, duration=max(0.1, s_.end - s_.start))
            tl.narration.append(Placement(line=ln, out_start=s_.start))
    tl.item_spans = [(g.out_start, g.out_end) for g in segs]
    return tl


def evaluate_file(path: str, prompt: str, transcriber) -> CreativeReport:
    """Creative check of a finished video file (any Short, e.g. one exported earlier). Captions
    and audio levels can't be read from the picture here, so those two areas are left out; the
    same picture repeated is detected only as a repeated shot change, not by content."""
    import json as _json
    import subprocess
    import tempfile

    from .core.models import Plan
    from .creative.brief import rule_brief

    dur = float(_json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json",
                                             path], capture_output=True, text=True).stdout)["format"]["duration"])
    with tempfile.TemporaryDirectory() as td:
        wav = f"{td}/a.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-ac", "1", "-ar", "16000", wav], check=True)
        tr = transcriber.transcribe(wav)
    plan = Plan(original_prompt=prompt)
    plan.topic.raw = prompt
    plan.brief = rule_brief(prompt)
    tl = timeline_from_file(path, tr.sentences, dur, as_dialogue=plan.brief.mode == "clip")
    skip = ("captions", "audio", "visual_quality") + (("clarity",) if plan.brief.mode == "clip" else ())
    rep = evaluate(plan, tl, [], plan.brief.mode, skip=skip)   # on-screen text can't be read from the file
    rep.stats["source"] = "finished file (shot changes from the picture; speech from a transcript)"
    return rep


def _clip(s: float) -> float:
    return round(max(0.0, min(10.0, s)), 1)


def _silences(narr, dlg, segs, D) -> list[tuple[float, float]]:
    """Stretches with no voice at all (narration or dialogue), ignoring the last 1.5 s."""
    spans = sorted([(a, b) for a, b, _ in narr] + [(w.start, w.end) for w in dlg])
    if not spans:
        return []
    out, t = [], 0.0
    for a, b in spans:
        if a - t > 1.8:
            out.append((round(t, 2), round(a, 2)))
        t = max(t, b)
    return [x for x in out if x[0] < D - 1.5][:4]


# --------------------------------------------------------------------------------------- improve
def improve(pipe, report: CreativeReport, progress=None) -> dict:
    """One round of automatic fixes for the weak parts (never more): returns what was changed.
    The plan before the fixes is kept by the caller (``Pipeline.creative_review``)."""
    plan = pipe.project.plan
    changed: list[str] = []
    fixes = {i.fix for i in report.issues if i.fix}
    creative = pipe.is_creative()
    user_script = getattr(plan.brief, "script_source", "") == "user"
    if creative and "hook_first" in fixes and plan.sections and plan.sections[0].kind != "narration":
        from .creative.narration import shape_for_shorts

        plan.sections = shape_for_shorts(plan.sections, outro=False)
        changed.append("moved the narrated hook to the start")
    if creative and not user_script and pipe.services.status["llm"].active != "rules":
        from .creative import workflow

        spans = list(getattr(pipe.edit_timeline, "item_spans", []) or [])
        todo = []
        for iss in report.issues:
            if iss.fix in ("rewrite", "rewrite_hook"):
                k = _section_at(spans, iss.start, plan.sections)
                if k is not None and k not in todo:
                    todo.append(k)
        for k in todo[:3]:
            instr = ("Rewrite this part: " + "; ".join(i.message for i in report.issues
                                                       if _section_at(spans, i.start, plan.sections) == k)
                     + ". Keep the same facts; no stock phrases; a complete thought with what and why.")
            try:
                workflow.rewrite_section(pipe, k, instr)
                changed.append(f"rewrote part {k + 1}")
            except Exception as e:  # noqa: BLE001
                changed.append(f"couldn't rewrite part {k + 1} ({str(e)[:80]})")
    if creative and ({"rematch", "split_shots"} & fixes):
        from .creative import workflow

        spans = list(getattr(pipe.edit_timeline, "item_spans", []) or [])
        done = set()
        for iss in report.issues:
            if iss.fix in ("rematch", "split_shots"):
                k = _section_at(spans, iss.start, plan.sections)
                if k is None or k in done or plan.sections[k].kind != "narration":
                    continue
                if plan.sections[k].shots and all(sh.locked for sh in plan.sections[k].shots):
                    continue                     # footage the user chose stays
                done.add(k)
                try:
                    workflow.find_different_footage(pipe, k)
                    changed.append(f"new footage for part {k + 1}")
                except Exception as e:  # noqa: BLE001
                    changed.append(f"couldn't change footage for part {k + 1} ({str(e)[:60]})")
                if len(done) >= 3:
                    break
    if creative and "add_ending" in fixes and not user_script:
        narrs = [s for s in plan.sections if s.kind == "narration"]
        if narrs and not re.search(r"\b(follow|subscribe)\b", narrs[-1].text.lower()) and \
                getattr(pipe.settings.edit, "spoken_outro", True):
            narrs[-1].text = narrs[-1].text.rstrip().rstrip(".") + ". Follow for more."
            changed.append("added a short spoken ending")
    if changed:
        pipe.edit_timeline = None
    return {"changed": changed}


def _section_at(spans, t: float, sections) -> Optional[int]:
    for k, (a, b) in enumerate(spans):
        if a - 0.05 <= t < b and k < len(sections):
            return k
    return None


def snapshot(plan) -> dict:
    return copy.deepcopy(plan.to_dict())
