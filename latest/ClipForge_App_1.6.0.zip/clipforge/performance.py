"""Your own Shorts performance vs the creative decisions behind each video.

Separate from the research knowledge base (knowledge/shorts_kb.json) on purpose: the research is
general and ships with the app; this is YOUR channel's data and stays in your data folder
(%APPDATA%\\ClipForge\\performance). Either can grow without the other.

  * Every export records its creative decisions (category, hook technique, structure, video type,
    length, pace, creative-check scores) in exports.jsonl.
  * ``clipforge-cli performance import <file.csv>`` reads a YouTube Studio export (Analytics →
    Advanced mode → Export current view → CSV) and matches its rows to your exports by title.
  * ``clipforge-cli performance report`` compares the numbers by decision (e.g. average percentage
    viewed for 'question' hooks vs 'payoff_promise' hooks) with the sample size beside every number.

Public view counts don't contain retention: only Studio data (stayed to watch, average view
duration, average percentage viewed) can. With fewer than 5 videos in a group the report says
there is too little data to conclude anything; even with more, these are correlations, not proof.
"""
from __future__ import annotations

import csv
import json
import re
import statistics
import time
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional

MIN_GROUP = 5
METRICS = {   # our name: words that identify the Studio column (lower-case)
    "views": ["views"],
    "engaged_views": ["engaged views"],
    "stayed_to_watch": ["stayed to watch", "viewed (vs. swiped", "chose to view"],
    "avg_view_duration": ["average view duration"],
    "avg_pct_viewed": ["average percentage viewed"],
    "likes": ["likes"],
    "comments": ["comments added", "comments"],
    "shares": ["shares"],
    "subscribers": ["subscribers gained", "subscribers"],
}
DECISIONS = ["category", "hook_type", "structure", "mode", "length_bucket", "pace_bucket"]


def folder() -> Path:
    from .config import app_dir

    d = app_dir() / "performance"
    d.mkdir(parents=True, exist_ok=True)
    return d


def record_export(path: Path, plan, tl, report=None) -> None:
    """Remember the creative decisions of an exported video (never fails an export)."""
    try:
        b = plan.brief
        lens = [g.out_end - g.out_start for g in getattr(tl, "segments", []) if g.out_end > g.out_start]
        rec = {"file": str(path), "exported": time.strftime("%Y-%m-%d %H:%M:%S"), "title": plan.title,
               "prompt": getattr(plan, "original_prompt", "") or plan.topic.raw,
               "category": getattr(b, "category", "") or (report.category if report else ""),
               "hook_type": getattr(b, "hook_type", ""), "structure": getattr(b, "structure", ""),
               "mode": b.mode if getattr(plan, "sections", None) else "clip",
               "length": round(getattr(tl, "duration", 0.0), 1),
               "avg_shot": round(sum(lens) / len(lens), 2) if lens else None,
               "first_line": (tl.narration[0].line.text if getattr(tl, "narration", None) else "")[:200],
               "creative_overall": report.overall if report else None,
               "creative_scores": report.scores if report else {}}
        with open(folder() / "exports.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001
        pass


def exports() -> list[dict]:
    p = folder() / "exports.jsonl"
    if not p.exists():
        return []
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(ln))
        except ValueError:
            pass
    return out


def _num(v: str) -> Optional[float]:
    v = (v or "").strip().replace(",", "").replace("%", "")
    if not v or v in ("—", "-"):
        return None
    m = re.match(r"^(\d+):(\d{2})(?::(\d{2}))?$", v)          # durations like 0:23 or 1:02:03
    if m:
        a, b, c = m.groups()
        return int(a) * 3600 + int(b) * 60 + int(c) if c else int(a) * 60 + int(b)
    try:
        return float(v)
    except ValueError:
        return None


def read_studio_csv(path: str) -> list[dict]:
    """Rows of a YouTube Studio CSV export as {title, <metric>: number}. Column names differ
    between Studio versions and languages, so they are matched by their words."""
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        return []
    cols = list(rows[0].keys())
    low = {c: c.lower() for c in cols}
    title_col = next((c for c in cols if low[c] in ("video title", "title", "content title")), None) or \
        next((c for c in cols if "title" in low[c]), None)
    mapping = {}
    for name, keys in METRICS.items():
        for k in keys:
            hit = next((c for c in cols if k in low[c] and c not in mapping.values()
                        and not (name == "views" and ("engaged" in low[c] or "%" in low[c]))), None)
            if hit:
                mapping[name] = hit
                break
    out = []
    for r in rows:
        t = (r.get(title_col) or "").strip() if title_col else ""
        if not t or t.lower() == "total":
            continue
        d = {"title": t}
        for name, col in mapping.items():
            d[name] = _num(r.get(col, ""))
        out.append(d)
    return out


def match(studio: list[dict], recs: list[dict], min_ratio: float = 0.72) -> list[dict]:
    """Studio rows joined to export records by title (best match above ``min_ratio``)."""
    joined = []
    for s in studio:
        best, score = None, 0.0
        for r in recs:
            q = SequenceMatcher(None, s["title"].lower(), (r.get("title") or "").lower()).ratio()
            if q > score:
                best, score = r, q
        if best is not None and score >= min_ratio:
            joined.append({**best, **{k: v for k, v in s.items() if k != "title"}, "studio_title": s["title"],
                           "match": round(score, 2)})
    return joined


def import_studio(path: str) -> dict:
    studio = read_studio_csv(path)
    joined = match(studio, exports())
    (folder() / "studio_latest.json").write_text(json.dumps({"imported": time.strftime("%Y-%m-%d %H:%M:%S"),
                                                             "file": str(path), "rows": studio, "joined": joined},
                                                            indent=1), encoding="utf-8")
    return {"rows": len(studio), "matched": len(joined)}


def _bucket(rec: dict) -> dict:
    L = rec.get("length") or 0
    sh = rec.get("avg_shot") or 0
    return {**rec, "length_bucket": "under 25 s" if L < 25 else ("25-40 s" if L <= 40 else "over 40 s"),
            "pace_bucket": "" if not sh else ("cuts under 2.5 s" if sh < 2.5 else
                                              ("2.5-4 s" if sh <= 4 else "over 4 s"))}


def report() -> str:
    p = folder() / "studio_latest.json"
    if not p.exists():
        return ("No YouTube Studio data yet. In YouTube Studio: Analytics → Advanced mode → choose your Shorts → "
                "Export current view → CSV, then run:  clipforge-cli performance import <that file>")
    data = json.loads(p.read_text(encoding="utf-8"))
    rows = [_bucket(r) for r in data.get("joined", [])]
    L = [f"Your Shorts: {len(rows)} matched to ClipForge exports (from {data.get('file')}, imported "
         f"{data.get('imported')})", ""]
    if not rows:
        return "\n".join(L + ["None of the Studio rows matched an exported title yet."])
    metric = next((m for m in ("stayed_to_watch", "avg_pct_viewed", "avg_view_duration", "engaged_views", "views")
                   if sum(1 for r in rows if r.get(m) is not None) >= 2), None)
    if metric is None:
        return "\n".join(L + ["The export has no retention or view columns ClipForge recognises."])
    L.append(f"Compared by: {metric.replace('_', ' ')} (higher is better). Groups under {MIN_GROUP} videos are "
             "marked as too small to conclude anything. These are correlations, not proof.")
    for dec in DECISIONS:
        groups: dict[str, list[float]] = {}
        for r in rows:
            k, v = r.get(dec), r.get(metric)
            if k and v is not None:
                groups.setdefault(str(k), []).append(float(v))
        if len(groups) < 2:
            continue
        L += ["", f"By {dec.replace('_', ' ')}:"]
        for k, vs in sorted(groups.items(), key=lambda kv: -statistics.mean(kv[1])):
            note = "" if len(vs) >= MIN_GROUP else "  (too few to conclude)"
            L.append(f"  {k:24s} {statistics.mean(vs):10.1f}   n={len(vs)}{note}")
    sc = [(r.get("creative_overall"), r.get(metric)) for r in rows if r.get("creative_overall") is not None
          and r.get(metric) is not None]
    if len(sc) >= MIN_GROUP:
        xs, ys = zip(*sc)
        try:
            corr = statistics.correlation(xs, ys)
            L += ["", f"Creative-check score vs {metric.replace('_', ' ')}: correlation {corr:+.2f} over {len(sc)} "
                  "videos (near 0 = the score doesn't track your results yet)."]
        except statistics.StatisticsError:
            pass
    return "\n".join(L)


def main(argv=None) -> int:
    import argparse

    ap = argparse.ArgumentParser(prog="clipforge-cli performance", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd")
    i = sub.add_parser("import", help="import a YouTube Studio CSV export")
    i.add_argument("csv")
    sub.add_parser("report", help="compare your results by creative decision")
    a = ap.parse_args(argv)
    if a.cmd == "import":
        r = import_studio(a.csv)
        print(f"Read {r['rows']} Studio rows; {r['matched']} matched an exported Short by title.")
        print(report())
        return 0
    print(report())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
