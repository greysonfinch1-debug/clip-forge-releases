"""Visual selection: which footage best accompanies each part of the narration.

For every narration section ClipForge has a few short descriptions of what should be on screen
("busy city streets with traffic", "a car driving at night") plus the narration itself. The CLIP
picture model turns those words and every second of every library video into points in the same
"meaning space"; footage whose pictures sit close to the words matches.

Scores are made comparable across queries and videos (each query is measured against the whole
library: "stands out as matching"), then combined with:
  quality     not too dark, not a menu / loading screen / webcam close-up (unless asked for)
  pacing      fast pacing prefers movement and short shots; slow pacing calmer, longer shots
  role        supporting footage is preferred for narration; the main story footage for hooks
  variety     a shot isn't reused, nor anything within a few seconds of it, nor a near-identical
              picture; repeats are only allowed when the library is too small (and said so)
  speech      seconds where someone talks are less attractive under narration (their lips move to
              other words, and many videos have their speech burned in as subtitles); when they
              are used, their sound is turned down further
Shots never cross a scene change. A section gets several shots when its narration is long
(``pacing``), and a section can continue the previous section's shot ("one visual, two sections").
Without a picture model only quality, movement and variety can be used: the result is labelled.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..core.models import Section, Shot
from .library import FootageIndex

SHOT_LENGTH = {"fast": 2.0, "normal": 3.2, "slow": 4.8}       # target seconds per shot
MIN_SHOT, MAX_SHOT = 1.4, 7.5
TEMPLATES = ["{}", "a video frame showing {}", "a screenshot of {}"]
NEGATIVE = ["a video game menu screen", "a loading screen", "a black screen", "a webcam of a person talking",
            "text on a plain background"]


# words CLIP knows better than the ones people type ("cartoon" footage is usually "animation" to it)
FOOTAGE_SYNONYMS = {
    "cartoon": ["animation", "an animated film", "a 3d animated scene"],
    "animated": ["animation", "an animated film"],
    "anime": ["animation", "anime"],
    "gameplay": ["a video game", "a video game screenshot"],
    "game": ["a video game", "a video game screenshot"],
    "minecraft": ["minecraft", "a blocky video game world"],
    "gta": ["a video game city", "a video game screenshot"],
    "drone": ["aerial footage", "an aerial view"],
    "nature": ["a forest", "a landscape", "nature"],
    "city": ["a city street", "buildings"],
    "store": ["a store", "a shop interior", "store shelves"],
    "irl": ["a real person", "a real place"],
    "stock": [],
}


@dataclass
class MatchReport:
    used_picture_model: bool
    repeats: int = 0
    notes: list[str] = None


class Matcher:
    def __init__(self, index: FootageIndex, vision=None, pacing: str = "normal", visual_style: str = "",
                 topic: str = "", footage: str = "", shot_profile: Optional[tuple] = None):
        self.ix, self.vision = index, vision
        self.pacing = pacing if pacing in SHOT_LENGTH else "normal"
        # (shortest, longest typical shot, longest allowed) for this category, from the Shorts knowledge base
        self.shot_profile = shot_profile
        self.style = visual_style
        self.used = np.zeros(len(index), np.float32)          # how often each second has been shown
        # pictures already shown anywhere in the video make near-identical pictures less attractive, even
        # from another library video (the same moment in a 360p copy and a 1080p copy, for example)
        self.seen_pen = np.zeros(len(index), np.float32)
        self.near_pen = np.zeros(len(index), np.float32)
        self._q: dict[str, np.ndarray] = {}
        self.semantic = index.emb is not None and vision is not None and len(index) > 0
        self.neg = self._zq(NEGATIVE, agg="max") if self.semantic else np.zeros(len(index), np.float32)
        # the whole video's subject: keeps every section's pictures in the same world, and a library
        # video that has nothing to do with the subject (a cartoon forest in a video about malls) is
        # only used when nothing else fits
        self.topic = topic.strip()
        self.topic_z = self._z(self.topic[:300]) if (self.semantic and self.topic) else np.zeros(len(index), np.float32)
        self.source_prior = np.zeros(len(index), np.float32)
        if self.semantic and self.topic and len(index.source_ids) > 1:
            fit = []
            for k in range(len(index.source_ids)):
                z = np.sort(self.topic_z[index.src_of == k])
                fit.append(float(z[int(0.75 * (len(z) - 1)):].mean()) if len(z) else -9.0)
            best = max(fit)
            pen = np.array([1.2 * max(0.0, best - f - 0.3) for f in fit], np.float32)
            self.source_prior = -pen[index.src_of]
        # the footage the prompt names ("use the cartoon footage"): the videos that clearly fit it are
        # used, the others only when nothing else fits. Measured in absolute terms (median similarity of
        # each video to the words and their usual synonyms), because relative scores follow whichever
        # video makes up most of the library.
        self.footage = footage.strip().lower()
        if self.semantic and self.footage and len(index.source_ids) > 1:
            words = [self.footage] + FOOTAGE_SYNONYMS.get(self.footage, [])
            per = []
            for k in range(len(index.source_ids)):
                e = index.emb[index.src_of == k]
                per.append(max(float(np.median(e @ self._enc(w))) for w in words) if len(e) else -1.0)
            top = max(per)
            # stronger than every variety penalty: with little of the named footage, repeating it beats
            # switching to footage the prompt didn't ask for (the plan then says the library is small)
            off = np.array([6.0 if f < top - 0.025 else 0.0 for f in per], np.float32)
            if off.any():
                self.source_prior = self.source_prior - off[index.src_of]

    # ---- query scores (z-scored over the whole library: "stands out as matching")
    def _enc(self, text: str) -> np.ndarray:
        if text not in self._q:
            e = self.vision.encode_texts([t.format(text) for t in TEMPLATES]).astype(np.float32)
            e = e / (np.linalg.norm(e, axis=1, keepdims=True) + 1e-9)
            v = e.mean(axis=0)
            self._q[text] = v / (np.linalg.norm(v) + 1e-9)
        return self._q[text]

    def _z(self, text: str) -> np.ndarray:
        s = self.ix.emb @ self._enc(text)
        return (s - s.mean()) / (s.std() + 1e-6)

    def _zq(self, texts: list[str], agg: str = "mean") -> np.ndarray:
        zs = np.stack([self._z(t) for t in texts if t.strip()]) if any(t.strip() for t in texts) else None
        if zs is None:
            return np.zeros(len(self.ix), np.float32)
        return zs.max(axis=0) if agg == "max" else zs.mean(axis=0)

    def relevance(self, sec: Section) -> np.ndarray:
        """Per-second match to what this section should show (z units, ~0 = average footage)."""
        if not self.semantic:
            return np.zeros(len(self.ix), np.float32)
        vis = [v for v in sec.visuals if v.strip()][:5]
        r = np.zeros(len(self.ix), np.float32)
        if vis:
            each = np.stack([self._z(v) for v in vis])
            # the best-matching requirement counts most, agreement with the others a little
            r = 0.75 * each.max(axis=0) + 0.25 * each.mean(axis=0)
        if sec.text.strip():
            r = (0.8 * r + 0.2 * self._z(sec.text[:300])) if vis else self._z(sec.text[:300])
        if self.style:
            r = r + 0.15 * self._z(self.style)
        if self.topic:
            # abstract lines ("everyone walks away with a story") match almost anything; the subject
            # of the whole video keeps them on topic
            r = 0.75 * r + 0.35 * self.topic_z
        return (r + self.source_prior).astype(np.float32)

    # ---- frame quality and fit
    def base_score(self, role_pref: tuple[str, ...]) -> np.ndarray:
        ix = self.ix
        q = np.zeros(len(ix), np.float32)
        q -= 2.0 * np.clip(0.16 - ix.bright, 0, None) / 0.16           # too dark
        if self.semantic:
            q -= 0.35 * np.clip(self.neg - 1.0, 0, None)                 # menus, loading screens, webcams
        if self.pacing == "fast":
            q += 0.35 * ix.motion
        elif self.pacing == "slow":
            q -= 0.25 * np.clip(ix.motion - 0.7, 0, None)
        else:
            q += 0.1 * ix.motion
        if role_pref:
            q += np.where(np.isin(ix.role, role_pref), 0.25, 0.0).astype(np.float32)
        q -= np.where(ix.role == "reaction", 0.4, 0.0).astype(np.float32)   # reactions only when asked for
        if len(ix.speech) == len(ix):
            q -= 0.5 * ix.speech                                             # someone talking on screen
        if ix.height is not None and len(ix.height) == len(ix):
            # sharper footage is preferred when it fits as well (360p looks soft in a 1080x1920 Short)
            h = ix.height
            q += np.where(h > 0, 0.25 * np.clip((h - 720.0) / 360.0, -1.0, 1.0), 0.0).astype(np.float32)
        return q

    # ---- choose shots for one section
    def choose(self, sec: Section, duration: float, prev: Optional[Shot] = None, exclude: list[Shot] = (),
               role_pref: tuple[str, ...] = ("broll", "atmosphere", "main")) -> list[Shot]:
        ix = self.ix
        if not len(ix):
            return []
        L, top = SHOT_LENGTH[self.pacing], MAX_SHOT
        if self.shot_profile:
            lo, hi, top = self.shot_profile
            L = {"fast": lo, "slow": hi}.get(self.pacing, (lo + hi) / 2)
        n = max(1, int(round(duration / L)))
        if duration / n < MIN_SHOT:
            n = max(1, int(duration // MIN_SHOT))
        if duration / n > top:
            n = int(math.ceil(duration / top))
        each = duration / n
        rel = self.relevance(sec)
        score = rel + self.base_score(role_pref) - 1.2 * self.used - self.seen_pen - np.minimum(self.near_pen, 1.5)
        for sh in exclude:
            score[self._frames(sh)] -= 3.0
        shots: list[Shot] = []
        if sec.continue_visual and prev is not None:
            cont = self._continue(prev, duration)
            if cont is not None:
                return [cont]
        taken = np.zeros(len(ix), bool)
        # several things to show: the shots follow them in narration order, so the picture changes
        # when the narration moves on ("Shoppers stop. Phones come out. A choir starts to sing.")
        vis = [v for v in sec.visuals if v.strip()][:5]
        focus = [self._z(v) for v in vis] if (self.semantic and len(vis) >= 2 and n >= 2) else []
        for k in range(n):
            w = max(2, int(math.ceil(each / max(1e-3, self._hop()))))
            j = _focus_index(sec.text, vis, (k + 0.5) / n) if focus else -1
            best = self._best_window(score + 0.5 * focus[j] if focus else score, taken, w)
            if best is None:
                break
            i0, val = best
            sid = ix.source_ids[ix.src_of[i0]]
            start = float(ix.t[i0])
            end = min(start + each, float(ix.t[i0 + w - 1]) + self._hop())
            sh = Shot(source_id=sid, start=round(start, 2), end=round(end, 2), score=round(float(val), 2),
                      why=self._why(sec, rel, i0, w, vis[j] if focus else ""))
            shots.append(sh)
            fr = np.arange(i0, i0 + w)
            taken[fr] = True
            self.used[fr] += 1.0
            # variety: nearby seconds and near-identical pictures are less attractive afterwards
            near = np.where((ix.src_of == ix.src_of[i0]) & (np.abs(ix.t - start) < 8.0))[0]
            score[near] -= 0.8
            self.near_pen[near] += 0.5          # and a little for the rest of the video
            self._seen(fr, score)
        if len(shots) < n and shots:      # too little footage: stretch what we have to cover the section
            per = duration / len(shots)
            for sh in shots:
                sh.end = round(sh.start + per, 2)
        return shots

    def _seen(self, fr: np.ndarray, score: Optional[np.ndarray] = None) -> None:
        """Footage ``fr`` is on screen. Within the part being chosen, similar pictures are less
        attractive; across the whole video, near-identical ones are (the same moment in another copy
        of the video, or the same shot a second later), and so are the seconds around such a copy.
        Capped, so a small one-location library still works. (Measured with CLIP ViT-B-32 on real
        footage: random pairs of seconds <= 0.78 for 99 %, neighbouring seconds of one video ~0.83,
        the same moment in a 360p and a 1080p copy ~0.93.)"""
        if not self.semantic or not len(fr):
            return
        ix = self.ix
        m = ix.emb[fr].mean(axis=0)
        sim = ix.emb @ (m / (np.linalg.norm(m) + 1e-9))
        before = self.seen_pen + np.minimum(self.near_pen, 1.5)
        self.seen_pen = np.minimum(self.seen_pen + 2.5 * np.clip(sim - 0.87, 0, None) / 0.06, 2.5).astype(np.float32)
        own_src = ix.src_of[fr[0]]
        for k in np.unique(ix.src_of[sim > 0.9]):
            if k == own_src:
                continue          # the video it came from: handled by "nothing within 8 s"
            ts = ix.t[(ix.src_of == k) & (sim > 0.9)]
            close = (ix.src_of == k) & (np.abs(ix.t[:, None] - ts[None, :]).min(axis=1) < 4.0)
            self.near_pen[close] += 0.5
        if score is not None:
            score -= (1.2 * np.clip(sim - 0.82, 0, None) / 0.1).astype(np.float32)
            score -= (self.seen_pen + np.minimum(self.near_pen, 1.5) - before).astype(np.float32)

    def _hop(self) -> float:
        t = self.ix.t
        return float(np.median(np.diff(t[:50]))) if len(t) > 2 else 1.0

    def _best_window(self, score: np.ndarray, taken: np.ndarray, w: int) -> Optional[tuple[int, float]]:
        """Best start index of w consecutive seconds of one source with no scene change inside."""
        ix = self.ix
        n = len(ix)
        if n < w:
            w = n
        csum = np.concatenate([[0.0], np.cumsum(score)])
        mean = (csum[w:] - csum[:-w]) / w                       # mean score of window starting at i
        starts = np.arange(len(mean))
        same_src = ix.src_of[starts] == ix.src_of[np.minimum(starts + w - 1, n - 1)]
        cuts = np.concatenate([[0.0], np.cumsum(ix.cut_after)])
        no_cut = (cuts[starts + w - 1] - cuts[starts]) == 0      # no scene change before the last second
        tk = np.concatenate([[0], np.cumsum(taken)])
        free = (tk[starts + w] - tk[starts]) == 0
        ok = same_src & no_cut & free
        if not ok.any():
            ok = same_src & free
        if not ok.any():
            return None
        m = np.where(ok, mean, -1e9)
        i = int(np.argmax(m))
        return i, float(m[i])

    def _continue(self, prev: Shot, duration: float) -> Optional[Shot]:
        """Keep the previous shot running into this section (same footage, carried on)."""
        f = self.ix.sources.get(prev.source_id)
        if f is None:
            return None
        end_t = float(f.visual.times[-1]) if len(f.visual.times) else 0.0
        if prev.end + duration > end_t:
            return None
        return Shot(source_id=prev.source_id, start=prev.end, end=round(prev.end + duration, 2), score=prev.score,
                    why="continues the previous shot")

    def _frames(self, sh: Shot) -> np.ndarray:
        ix = self.ix
        if sh.source_id not in ix.source_ids:
            return np.zeros(0, int)
        k = ix.source_ids.index(sh.source_id)
        return np.where((ix.src_of == k) & (ix.t >= sh.start - 0.5) & (ix.t <= sh.end + 0.5))[0]

    def _why(self, sec: Section, rel: np.ndarray, i0: int, w: int, focus: str = "") -> str:
        if not self.semantic:
            return "picked for picture quality and movement (no picture model to match meaning)"
        fr = slice(i0, i0 + w)
        if focus:
            return f"for \"{focus}\" ({_strength(float(self._z(focus)[fr].mean()), self._cos(focus, fr))})"
        if sec.visuals:
            zs = [(float(self._z(v)[fr].mean()), v) for v in sec.visuals if v.strip()]
            if zs:
                z, best = max(zs)
                return f"matches \"{best}\" ({_strength(z, self._cos(best, fr))})"
        return f"matches the narration ({_strength(float(rel[fr].mean()), self._cos(sec.text[:300], fr))})"

    def _cos(self, text: str, fr) -> float:
        """How close the pictures are to the words in absolute terms (not just the best in this library)."""
        return float((self.ix.emb[fr] @ self._enc(text)).mean())


def _focus_index(text: str, vis: list[str], at: float) -> int:
    """Which requirement the narration is on at fraction ``at`` of the section: by sentence length
    when the requirements are the narration's own sentences, otherwise evenly spread."""
    low = text.lower()
    if all(v.lower().rstrip(".!?") in low for v in vis):
        w = [max(1, len(v)) for v in vis]
    else:
        w = [1] * len(vis)
    acc, tot = 0.0, float(sum(w))
    for j, x in enumerate(w):
        acc += x / tot
        if at < acc:
            return j
    return len(vis) - 1


# Absolute picture-word similarity for CLIP ViT-B-32, measured on real footage: things that are on
# screen score 0.30-0.40 at best, things that aren't anywhere in the footage stay below ~0.24.
COS_SHOWS, COS_RELATED, COS_WEAK = 0.29, 0.26, 0.22


def _strength(z: float, cos: Optional[float] = None) -> str:
    """'Strong' must mean the pictures really show it, not only that they're the best this library has."""
    if cos is not None and cos < COS_WEAK:
        return "weak match: nothing in your footage really shows this"
    if cos is not None and cos < COS_RELATED:
        return "loose match: the mood or setting fits"
    if z >= 1.5 and (cos is None or cos >= COS_SHOWS):
        return "strong match"
    return "good match" if z >= 0.8 else "loose match"


def match_sections(sections: list[Section], index: FootageIndex, vision, durations: list[float], pacing: str = "normal",
                   visual_style: str = "", keep_locked: bool = True, topic: str = "",
                   reserved: list[Shot] = (), footage: str = "", shot_profile: Optional[tuple] = None) -> MatchReport:
    """Pick footage for every narration section (moments keep their own clip). ``reserved`` =
    footage that plays elsewhere in the video (a hybrid video's real moments): never reused."""
    m = Matcher(index, vision, pacing, visual_style, topic, footage, shot_profile)
    for r in reserved:
        m.used[m._frames(r)] += 3.0
        m._seen(m._frames(r))
    base = m.used.copy()                 # reserved footage isn't a repeat; only shots shown twice are
    prev: Optional[Shot] = None
    for sec, d in zip(sections, durations):
        if sec.kind == "moment":
            prev = None
            continue
        locked = [s for s in sec.shots if s.locked] if keep_locked else []
        if locked:
            for s in locked:
                m.used[m._frames(s)] += 1.0
                m._seen(m._frames(s))
            prev = locked[-1]
            continue
        role = ("main", "broll", "atmosphere") if sec.role == "hook" else ("broll", "atmosphere", "main")
        sec.shots = m.choose(sec, d, prev, role_pref=role)
        prev = sec.shots[-1] if sec.shots else prev
    reused = int(((m.used - base) > 1).sum())
    notes = []
    weak = [i + 1 for i, sec in enumerate(sections) if sec.kind != "moment" and sec.shots
            and all("weak match" in sh.why for sh in sec.shots if sh.why)]
    if weak and m.semantic:
        notes.append(f"Part{'s' if len(weak) > 1 else ''} {', '.join(map(str, weak))}: nothing in your footage really "
                     "shows what the narration is about, so the closest footage was used. Add footage, change "
                     "'what to show', or pick other shots.")
    if not m.semantic:
        notes.append("No picture model: footage was chosen for quality, movement and variety, not for meaning.")
    if reused:
        notes.append(f"The library is small for this video: {reused} second(s) of footage appear more than once.")
    return MatchReport(used_picture_model=m.semantic, repeats=reused, notes=notes)


def rematch_section(sections: list[Section], i: int, index: FootageIndex, vision, duration: float,
                    pacing: str = "normal", visual_style: str = "", only_shot: int = -1, topic: str = "",
                    reserved: list[Shot] = (), footage: str = "", shot_profile: Optional[tuple] = None) -> None:
    """'Find different footage' for one section (or one shot of it), keeping every other section."""
    m = Matcher(index, vision, pacing, visual_style, topic, footage, shot_profile)
    for r in reserved:
        m.used[m._frames(r)] += 3.0
        m._seen(m._frames(r))
    for j, s in enumerate(sections):
        if j != i:
            for sh in s.shots:
                m.used[m._frames(sh)] += 1.0
                m._seen(m._frames(sh))
    sec = sections[i]
    old = list(sec.shots)
    if only_shot >= 0 and only_shot < len(old):
        keep = [s for k, s in enumerate(old) if k != only_shot]
        for s in keep:
            m.used[m._frames(s)] += 1.0
            m._seen(m._frames(s))
        one = Section(sid=sec.sid, role=sec.role, text=sec.text, visuals=sec.visuals)
        new = m.choose(one, old[only_shot].duration, exclude=old)
        if new:
            sec.shots[only_shot] = new[0]
        return
    prev = sections[i - 1].shots[-1] if i > 0 and sections[i - 1].shots else None
    sec.shots = m.choose(sec, duration, prev if sec.continue_visual else None, exclude=old)
