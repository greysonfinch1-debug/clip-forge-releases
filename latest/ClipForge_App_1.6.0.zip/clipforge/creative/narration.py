"""Narration intelligence: what the video says, in sections, and what each section should show.

Two ways to get the narration:
  * the language model writes it from the prompt, in the requested style and length, using only
    the facts the user supplied when they supplied any (pasted notes or fetched links). Every
    section says where its claims come from; topics the model can't know reliably (unreleased
    games, recent news) are marked as speculation, never stated as fact;
  * the user's own script: ClipForge splits it into sections and works out what to show.

Each section also lists 2-4 concrete descriptions of what should be on screen. They describe
pictures (CLIP matches pictures, not ideas), and they don't have to show the exact thing being
said: "a busy city street" can accompany a sentence about believable worlds. The narration never
claims the footage proves anything ("as you can see…").
Without a language model and without a script there is no honest way to write narration about a
topic, so ClipForge says so and asks for one of the two.
"""
from __future__ import annotations

import re
from typing import Optional

from ..core.models import Candidate, CreativeBrief, Section, Transcript
from ..providers.base import LLM, ProviderUnavailable

WORDS_PER_SECOND = 2.6

STYLE_GUIDE = {
    "informative": "clear and engaging, like a good explainer channel; concrete details, no fluff",
    "documentary": "calm, authoritative documentary narrator; vivid but measured; a compelling opening line",
    "educational": "teach it step by step; simple words; one idea per sentence; end with what the viewer learned",
    "entertaining": "fun, punchy, playful; jokes allowed but every line still says something real",
    "dramatic": "dramatic and suspenseful; short sentences; build tension toward the ending",
    "conversational": "casual, like talking to a friend; contractions; direct 'you'",
    "storytelling": "tell it as a story with a beginning, a turn and an ending",
    "commentary": "opinionated commentary; make clear which parts are opinion",
    "news": "news anchor style: what, who, when, why it matters; neutral; verified facts first",
}

SYSTEM = """You are the scriptwriter and editor of a YouTube Short (vertical video, 9:16).
You write the narration first, then decide what should be on screen during each part of it.
Rules for the narration:
- Follow the creator's request: its topic, tone, structure, number of points and length.
- Natural, spoken English. No filler ("in this video", "let's dive in", "make sure to like and subscribe"). Don't repeat yourself.
- STRUCTURE (Shorts viewers decide in the first 2 seconds):
  1. HOOK first, before anything else: one short line that makes the viewer stay - a bold claim, a question, or the payoff promised ("Five stars and still alive? Here's how."). Never a title or a summary.
  2. Each point is a complete thought of 1-2 sentences: WHAT to do (or what happens) AND HOW or WHY. Never fragments like "Stay calm." alone. For tips, steps, reasons or lists, say the number out loud ("Tip one:", "Second,", "Last one:").
  3. ENDING: one last piece of advice or a payoff line, then a short call to action of at most 6 words that fits the topic ("Follow for more GTA tips.").
- FACTS: if source material is given, use only facts it contains. If none is given, use only well-established general knowledge, and NEVER present guesses, rumours or unannounced details as facts — say "reportedly", "is expected to" or "could" for anything unconfirmed. Topics after your knowledge (new or unreleased games, recent news) are speculation unless the sources say otherwise.
- The footage is illustration. Never say "as you can see", "here we see", "in this clip", and never claim the footage shows or proves something.
Rules for the visuals:
- For each section give 2-4 short, concrete descriptions of what could be on screen, as things VISIBLE in a single video frame (e.g. "a busy city street with traffic", "a car driving at sunset", "a crowd of people", "a character walking through a city").
- They don't need to show the exact thing being said; they must suit its meaning and fit what the footage library contains.
- List them in the order the narration gets to them: the picture changes as the narration moves on.
- Vary them between sections. When a section simply continues the previous one's thought, you may set "same_shot_as_previous": true to keep that picture running instead.
Reply with JSON only."""

PROMPT = """Creator's request: "{prompt}"
Style: {style} ({guide}). Tone: {tone}. Pacing: {pacing}.
Length: about {seconds:.0f} seconds of narration = about {words} words in total{points}.
{moments}{sources}What the footage library contains (most common things on screen):
{library}

Return JSON:
{{"title": "YouTube title, max 60 characters, truthful",
  "description": "1-2 sentence YouTube description",
  "sections": [{{"role": "hook|point|conclusion{moment_role}", "label": "2-5 word on-screen label or empty",
                "text": "the narration for this part", "visuals": ["...", "..."],
                "claims": "from_sources|general_knowledge|speculation|opinion|none",
                "same_shot_as_previous": false{moment_field}}}],
  "sources_used": ["which supplied sources were used, or empty"]}}
The first section is the hook (role hook, narration, never a moment). The last narrated section is the ending: final advice or payoff, then the short call to action. Keep each section 1-3 complete sentences."""


def word_budget(seconds: float, brief: CreativeBrief, moment_seconds: float = 0.0) -> int:
    pace = {"fast": 1.08, "slow": 0.9}.get(brief.pacing, 1.0)
    return max(25, int((seconds - moment_seconds) * WORDS_PER_SECOND * pace))


def write_sections(prompt: str, brief: CreativeBrief, llm: LLM, target_seconds: float,
                   library_summary: dict[str, list[str]], sources_text: str = "",
                   moments: Optional[list[Candidate]] = None, transcript: Optional[Transcript] = None,
                   direction: str = "", outro: bool = False, guidance: str = "") -> tuple[list[Section], dict, str]:
    """Return (sections, extras {title, description, sources_note}, how): how = llm / user / none."""
    if brief.user_script.strip():
        secs = split_script(brief.user_script, brief)
        if moments:
            secs = weave_moments(secs, moments, brief)
        return secs, {"title": "", "description": "", "sources_note": "Narration written by you."}, "user"
    moment_secs = sum(min(12.0, c.duration) for c in (moments or [])[:3])
    words = word_budget(target_seconds, brief, moment_secs)
    lib = "\n".join(f"- {', '.join(v)}" for v in library_summary.values() if v) or "- (unknown: describe generic gameplay)"
    mom = ""
    if moments:
        lines = []
        for c in moments[:6]:
            said = transcript.text_between(c.start, c.end)[:200] if transcript is not None else ""
            lines.append(f"- id={c.cid} ({c.duration:.0f}s): {c.description[:160]}" + (f' Said: "{said}"' if said else ""))
        mom = ("Real moments from the creator's footage you may place between narrated sections (they play with "
               "their original sound; use 1-3 of them, e.g. open or end with one):\n" + "\n".join(lines) + "\n")
    src = (f"Source material (use only these facts):\n{sources_text[:6000]}\n" if sources_text.strip() else
           "No source material was supplied.\n")
    pts = f", in {brief.points} clearly separate points" if brief.points else ""
    if guidance:
        # the Shorts knowledge base for this category (research findings; principles, not a template)
        src = f"Research guidance for this kind of Short:\n{guidance}\n\n" + src
    if direction:
        # the approved production brief (AI prompt expansion): its structure, hook, talking points,
        # visuals and ending lead the script; only its known facts (and the sources) may be stated
        src = (f"Production brief approved by the creator (follow its hook, parts, talking points, suggested "
               f"visuals and ending; 'facts to check' must NOT be stated as fact - hedge them or leave them out):\n"
               f"{direction[:4000]}\n\n") + src
    try:
        d = llm.complete_json(SYSTEM, PROMPT.format(
            prompt=prompt, style=brief.style or "informative", guide=STYLE_GUIDE.get(brief.style or "informative", ""),
            tone=brief.tone or "as the request suggests", pacing=brief.pacing, seconds=target_seconds - moment_secs,
            words=words, points=pts, moments=mom, sources=src, library=lib,
            moment_role="|moment" if moments else "",
            moment_field=', "moment_id": "id of a real moment (role moment only)"' if moments else ""),
            max_tokens=2200)
    except ProviderUnavailable:
        return [], {}, "none"
    if not isinstance(d, dict):
        return [], {}, "none"
    by_id = {c.cid: c for c in moments or []}
    secs: list[Section] = []
    for k, x in enumerate(d.get("sections") or []):
        if not isinstance(x, dict):
            continue
        role = str(x.get("role") or "point").lower()
        if role == "moment" and str(x.get("moment_id")) in by_id:
            c = by_id[str(x.get("moment_id"))]
            secs.append(Section(sid=f"s{k + 1}", role="moment", kind="moment", cid=c.cid, label=str(x.get("label") or "")[:40]))
            continue
        text = clean_line(str(x.get("text") or ""))
        if not text:
            continue
        vis = [str(v).strip()[:90] for v in _as_list(x.get("visuals")) if str(v).strip()][:4]
        secs.append(Section(sid=f"s{k + 1}", role=role if role in ("hook", "intro", "point", "conclusion") else "point",
                            text=text, visuals=vis or visuals_from_text(text), claims=_claims(x.get("claims")),
                            label=str(x.get("label") or "")[:40],
                            continue_visual=bool(secs) and secs[-1].kind == "narration"
                            and str(x.get("same_shot_as_previous")).lower() in ("true", "1", "yes")))
    if not any(s.kind == "narration" for s in secs):
        return [], {}, "none"
    if moments and not any(s.kind == "moment" for s in secs):
        secs = weave_moments(secs, moments, brief)
    secs = shape_for_shorts(secs, outro)
    extras = {"title": str(d.get("title") or "")[:100], "description": str(d.get("description") or "")[:500],
              "sources_note": _sources_note(d, sources_text)}
    return secs, extras, "llm"


_CTA = re.compile(r"\b(follow|subscribe)\b", re.I)


def has_cta(text: str) -> bool:
    return bool(_CTA.search(text or ""))


def shape_for_shorts(secs: list[Section], outro: bool = False) -> list[Section]:
    """What Shorts need, whatever the writer returned: the narrated hook is heard first (a real
    moment with no context in the first seconds loses viewers), and with ``outro`` the last
    narrated part ends with a short spoken call to action. Only for AI-written narration: the
    user's own script is never changed."""
    narr = [i for i, s in enumerate(secs) if s.kind == "narration"]
    if not narr:
        return secs
    if secs[0].kind != "narration":
        k = next((i for i in narr if secs[i].role == "hook"), narr[0])
        hook = secs.pop(k)
        hook.role, hook.continue_visual = "hook", False
        secs.insert(0, hook)
        if len(secs) > 1 and secs[1].kind == "narration":
            secs[1].continue_visual = False
    if outro:
        last = [s for s in secs if s.kind == "narration"][-1]
        if not has_cta(last.text):
            last.text = last.text.rstrip() + ("" if last.text.rstrip().endswith((".", "!", "?")) else ".") \
                + " Follow for more."
    return secs


def rewrite_section(sections: list[Section], i: int, prompt: str, brief: CreativeBrief, llm: LLM,
                    instruction: str = "", sources_text: str = "") -> bool:
    """Rewrite one section (keeping the others) — e.g. "make the introduction punchier"."""
    sec = sections[i]
    others = "\n".join(f"{j + 1}. {s.text}" for j, s in enumerate(sections) if s.kind == "narration")
    p = (f'Creator\'s request: "{prompt}"\nStyle: {brief.style}. Tone: {brief.tone or "as before"}.\n'
         + (f"Source material (use only these facts):\n{sources_text[:4000]}\n" if sources_text.strip() else "")
         + f"The whole script so far:\n{others}\n\nRewrite part {i + 1} ({sec.role}): \"{sec.text}\"\n"
         + (f"Change requested: {instruction}\n" if instruction else "Make it better, same length and meaning.\n")
         + 'Return JSON: {"text": "...", "visuals": ["2-4 concrete things that could be on screen"], '
           '"claims": "from_sources|general_knowledge|speculation|opinion|none"}')
    try:
        d = llm.complete_json(SYSTEM, p, max_tokens=500)
    except ProviderUnavailable:
        return False
    if not isinstance(d, dict):
        return False
    text = clean_line(str(d.get("text") or ""))
    if not text:
        return False
    sec.text = text
    sec.visuals = [str(v)[:90] for v in _as_list(d.get("visuals")) if str(v).strip()][:4] or sec.visuals
    sec.claims = _claims(d.get("claims")) or sec.claims
    sec.edited = False
    sec.audio_path, sec.duration = "", 0.0
    return True


# ------------------------------------------------------------------ the user's own script
_SAME = re.compile(r"^\s*\[(?:same shot|continue(?:d)?(?: shot)?|keep shot)\]\s*", re.I)


def split_script(text: str, brief: CreativeBrief) -> list[Section]:
    """Paragraphs become sections; a long paragraph is split at sentences (about 2 per section).
    A paragraph starting with "[same shot]" keeps the previous part's picture running."""
    paras = [p.strip() for p in re.split(r"\n\s*\n|\n(?=\s*(?:\d+[.)]|[-\u2022*])\s)", text) if p.strip()]
    if len(paras) == 1:
        sents = re.split(r"(?<=[.!?])\s+", paras[0])
        paras = [" ".join(sents[k:k + 2]) for k in range(0, len(sents), 2)]
    secs = []
    for k, p in enumerate(paras):
        same = bool(_SAME.match(p))
        p = _SAME.sub("", p)
        p = re.sub(r"^\s*(?:\d+[.)]|[-\u2022*])\s+", "", p)
        raw = p.strip(" ,;:")
        p = " ".join(p.split())
        if not p:
            continue
        role = "hook" if k == 0 else ("conclusion" if k == len(paras) - 1 and len(paras) > 2 else "point")
        secs.append(Section(sid=f"s{k + 1}", role=role, text=p, visuals=visuals_from_text(raw), claims="",
                            continue_visual=same and bool(secs)))
    return secs


_COUNTING = set("""one two three four five six seven eight nine ten first second third fourth fifth sixth
seventh eighth ninth tenth number next last finally okay""".split())
_STOP = set("""a an the and or but if then so to of in on at by for with from into onto about as is are was were be
been being it its this that these those there here which who whom whose what when where why how than too very can
could would should will just also more most much many some any every each other such only own same not no nor do does
did done have has had having you your yours we our they their them he his him she her i me my mine us one ones thing
things way ways really actually lot lots get gets got make makes made like feel feels even ever still because while
something anything everything nothing someone anyone people player players game games world""".split())


def visuals_from_text(text: str) -> list[str]:
    """What to show, without a language model: one requirement per sentence, in narration order,
    so the footage can change as the narration moves on (CLIP reads short sentences well).
    A sentence with no concrete words is skipped; the whole text is the fallback."""
    out = []
    pieces = []
    for s in re.split(r"(?<=[.!?])\s+|\s*\n+\s*", text):          # sentences, and the lines of a poem
        if len(s.split()) > 12:                                        # a long sentence: its clauses
            parts = []
            for c in re.split(r",\s+|;\s+|:\s+|\s+[-\u2014]\s+", s):
                if parts and (len(c.split()) < 3 or len(parts[-1].split()) < 3):
                    parts[-1] = parts[-1] + ", " + c
                else:
                    parts.append(c)
            pieces += parts
        else:
            pieces.append(s)
    for s in pieces:
        s = re.sub(r"^(?:and|but|so|then|or|because|now)\s+", "", s.strip(" ,;:-\u2014"), flags=re.I).rstrip(".!?")
        content = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]+", s) if w.lower() not in _STOP and len(w) > 2
                   and w.lower() not in _COUNTING]
        if not content:
            continue          # "Two." in a list, "Okay." — nothing to show
        s = " ".join(s.split()[:14])
        if s and s.lower() not in (o.lower() for o in out):
            out.append(s[:1].upper() + s[1:])
    if not out:
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]+", text) if w.lower() not in _STOP and len(w) > 2]
        key = " ".join(dict.fromkeys(w.lower() for w in words))[:80]
        out = [key or " ".join(text.split()[:14])]
    return out[:4]


def weave_moments(secs: list[Section], moments: list[Candidate], brief: CreativeBrief) -> list[Section]:
    """Hybrid without a language model: open with the strongest real moment, put one in the middle,
    and end on another when there's room."""
    ms = sorted(moments, key=lambda c: -c.final_score)
    if not ms:
        return secs
    out = list(secs)
    out.insert(0, Section(sid="m1", role="moment", kind="moment", cid=ms[0].cid))
    if len(ms) > 1 and len(secs) >= 2:
        out.insert(1 + (len(secs) + 1) // 2, Section(sid="m2", role="moment", kind="moment", cid=ms[1].cid))
    if len(ms) > 2 and len(secs) >= 4 and brief.dialogue == "lots":
        out.append(Section(sid="m3", role="moment", kind="moment", cid=ms[2].cid))
    return out


# ------------------------------------------------------------------ helpers
_BANNED = re.compile(r"\b(as you can see|here we see|in this clip|in this video,?|let'?s dive in|smash that like|"
                     r"like and subscribe|without further ado)\b[,.]?\s*", re.I)


def clean_line(text: str) -> str:
    t = _BANNED.sub("", " ".join(text.split())).strip()
    return t[:1].upper() + t[1:] if t else ""


def _as_list(v) -> list:
    """A model sometimes answers one string where a list was asked for."""
    if isinstance(v, str):
        return [x for x in re.split(r"\s*;\s*", v) if x]
    return list(v) if isinstance(v, (list, tuple)) else []


def _claims(v) -> str:
    v = str(v or "").lower().replace(" ", "_")
    return {"from_sources": "from your sources", "general_knowledge": "general knowledge — check before publishing",
            "speculation": "speculation — not confirmed", "opinion": "opinion", "none": ""}.get(v, "")


def _sources_note(d: dict, sources_text: str) -> str:
    used = [str(x) for x in d.get("sources_used") or [] if str(x).strip()]
    if sources_text.strip():
        return "Facts from the sources you supplied" + (": " + "; ".join(used)[:300] if used else ".")
    return ("No sources were supplied: facts come from the AI model's general knowledge and may be outdated or wrong. "
            "Check them before publishing.")
