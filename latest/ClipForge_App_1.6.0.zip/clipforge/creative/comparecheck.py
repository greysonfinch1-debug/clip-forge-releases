"""clipforge-cli creativecompare — the Shorts knowledge base ON vs OFF, scored by the creative check.

    clipforge-cli creativecompare --video "D:\\Videos\\my stream.mp4" --rights own
    clipforge-cli creativecompare --video ... --rights own --only 6 --export

For each of 20 prompts (several categories, all three video types) ClipForge makes the video
twice from the same footage:
  previous   knowledge base off, no automatic creative fixes (how 1.5.1 decided)
  new        knowledge base on (category guidance in the script, shot lengths, caption signalling)
             plus one round of automatic creative fixes
Both are scored by the same creative check, area by area, and the narration of both is listed so
you can judge for yourself.

Be careful reading the result: the creative check scores against the same research the knowledge
base is built from, so a better score shows the videos follow the research more closely — not that
they will get more views. Only your YouTube Studio numbers can show that (clipforge-cli performance).

Uses the language model set in Settings (Ollama) for the scripts: run it on the PC where Ollama runs.
Works in a temporary data folder: your projects and settings aren't touched.
Report: %APPDATA%\\ClipForge\\checks\\compare_<date>\\report.md (+ results.json).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import statistics
import tempfile
import time
from dataclasses import asdict
from pathlib import Path

from ..creative_qc import AREAS, DISCLAIMER, LABEL

SCRIPT = ("Most players panic at five stars. Here's how to survive.\n\nTip one: take out the helicopter first, "
          "because it tells every cop where you are.\n\nTip two: leave the highway, since tight streets slow the "
          "police cars down.\n\nLast one: find a quiet spot and stop moving, so the stars can fade.")

# (category, prompt, seconds, extra spec keys)
PROMPTS = [
    ("gaming", "5 things that make this game feel realistic, use the gameplay as background", 40, {}),
    ("gaming", "Show the best moments and explain why each one worked", 40, {}),
    ("gaming tips", "three tips to survive a five-star wanted level, use the gameplay", 35, {}),
    ("gaming news", "what has been announced about GTA 6 so far, news style", 35, {}),
    ("history", "the history of the printing press in 40 seconds, documentary style", 40, {}),
    ("history", "how the Roman Empire fell, told as a story", 45, {}),
    ("facts", "3 surprising facts about octopuses", 30, {}),
    ("science", "explain how black holes form, in simple words", 40, {}),
    ("technology", "is the new iPhone worth it?", 35, {}),
    ("education", "teach three tips to improve your aim in shooters", 35, {}),
    ("entertainment", "find the funniest moments", 35, {"mode": "clip"}),
    ("entertainment", "his best reactions, no narration", 30, {"mode": "clip"}),
    ("list", "countdown of the top 3 craziest moments", 40, {"mode": "clip"}),
    ("story", "Tell a short story about a lonely robot who finds a friend, calm narration over the footage", 45, {}),
    ("commentary", "why speedruns are so fun to watch, use the footage as background", 35, {}),
    ("documentary", "make it feel like a nature documentary about a gamer in his natural habitat", 40, {}),
    ("mystery", "the mystery of why some game glitches are never fixed", 40, {}),
    ("hybrid", "Open with the most exciting real moment, then explain why moments like this work so well", 45,
     {"mode": "hybrid"}),
    ("hybrid", "show the real reactions and explain what was happening in between", 40, {"mode": "hybrid"}),
    ("own script", "narrate my script over the gameplay", 30, {"script": SCRIPT, "use_my_script": True}),
]
VARIANTS = {"previous": {"shorts_kb": False, "creative_autofix": False},
            "new": {"shorts_kb": True, "creative_autofix": True}}


def main(argv=None) -> int:
    from ..config import Settings, app_dir

    ap = argparse.ArgumentParser(prog="clipforge-cli creativecompare", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", required=True, help="a video you own or have permission to use")
    ap.add_argument("--rights", required=True, choices=["own", "permission", "licence"])
    ap.add_argument("--creator", default="")
    ap.add_argument("--only", type=int, default=0, help="first N prompts only")
    ap.add_argument("--pick", default="", help="comma-separated prompt numbers (1-20)")
    ap.add_argument("--export", action="store_true", help="also render both versions (slower)")
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)
    video = Path(a.video).expanduser().resolve()
    if not video.is_file():
        print("--video must be an existing file")
        return 2
    real = Settings.load()
    out = Path(a.out) if a.out else app_dir() / "checks" / time.strftime("compare_%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    base = asdict(real)
    base.update(first_run_done=True, check_updates=False, auto_install_updates=False, expand_prompts=False)
    work = Path(tempfile.mkdtemp(prefix="cf_compare_"))
    base["output_dir"] = str(work / "exports")
    (work / "settings.json").write_text(json.dumps(base, indent=1), encoding="utf-8")
    old_home = os.environ.get("CLIPFORGE_HOME")
    os.environ["CLIPFORGE_HOME"] = str(work)
    todo = list(enumerate(PROMPTS, 1))
    if a.pick:
        want = {int(x) for x in a.pick.split(",") if x.strip().isdigit()}
        todo = [t for t in todo if t[0] in want]
    elif a.only:
        todo = todo[: a.only]
    res = {"llm": f"{real.llm.backend} / {real.llm.model}", "started": time.strftime("%Y-%m-%d %H:%M:%S"),
           "video": str(video), "rows": []}
    print(f"ClipForge creative comparison → {out}  (language model: {res['llm']})")
    try:
        from .cli import run_spec

        rights = {"basis": a.rights, "creator": a.creator or "(not given)", "commercial_use": False}
        for n, (cat, prompt, secs, extra) in todo:
            row = {"n": n, "category": cat, "prompt": prompt}
            for var, sets in VARIANTS.items():
                spec = {"name": f"compare {n} {var}", "main": {"path": str(video), "rights": rights},
                        "prompt": prompt, "seconds": secs, "export": a.export, "creative_check": True,
                        "out": str(work / "exports"), "settings": sets, **extra}
                t0 = time.time()
                try:
                    rep = run_spec(spec, quiet=True)
                    q = rep.get("creative_qc") or {}
                    row[var] = {"mode": rep.get("mode"), "script_by": rep.get("script_by") or
                                (rep.get("clip_driven") or {}).get("script_by"),
                                "scores": (q.get("final") or {}).get("scores", {}),
                                "overall": (q.get("final") or {}).get("overall"),
                                "first_overall": (q.get("first") or {}).get("overall"),
                                "issues": (q.get("final") or {}).get("issues", []),
                                "changes": q.get("changes"), "kept": q.get("kept"),
                                "narration": rep.get("final_narration") or [], "seconds": round(time.time() - t0, 1),
                                "category": (q.get("final") or {}).get("category")}
                    if rep.get("export"):
                        dst = out / f"{n:02d}_{var}.mp4"
                        shutil.copy2(rep["export"], dst)
                        row[var]["video"] = str(dst)
                except Exception as e:  # noqa: BLE001
                    row[var] = {"error": f"{type(e).__name__}: {str(e)[:300]}"}
                print(f"  {n:2d} {var:8s} " + (f"overall {row[var].get('overall')}" if "error" not in row[var]
                                                else row[var]["error"][:120]), flush=True)
            res["rows"].append(row)
            _report(out, res)
    finally:
        if old_home is None:
            os.environ.pop("CLIPFORGE_HOME", None)
        else:
            os.environ["CLIPFORGE_HOME"] = old_home
        res["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
        _report(out, res)
        shutil.rmtree(work, ignore_errors=True)
    print(f"Report: {out / 'report.md'}")
    return 0


def summarise(rows: list[dict]) -> dict:
    pairs = [r for r in rows if "scores" in r.get("previous", {}) and "scores" in r.get("new", {})]
    out = {"pairs": len(pairs), "areas": {}}
    for a in AREAS + ["overall"]:
        old = [r["previous"]["overall"] if a == "overall" else r["previous"]["scores"].get(a) for r in pairs]
        new = [r["new"]["overall"] if a == "overall" else r["new"]["scores"].get(a) for r in pairs]
        both = [(x, y) for x, y in zip(old, new) if x is not None and y is not None]
        if not both:
            continue
        d = [y - x for x, y in both]
        out["areas"][a] = {"previous": round(statistics.mean(x for x, _ in both), 2),
                           "new": round(statistics.mean(y for _, y in both), 2),
                           "better": sum(1 for x in d if x > 0.05), "worse": sum(1 for x in d if x < -0.05),
                           "same": sum(1 for x in d if abs(x) <= 0.05), "n": len(both)}
    return out


def _report(out: Path, res: dict) -> None:
    (out / "results.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    s = summarise(res["rows"])
    L = ["# ClipForge creative comparison: knowledge base off (previous) vs on (new)", "",
         f"Language model: {res['llm']}  ", f"Video: {res['video']}  ",
         f"Started {res['started']}" + (f", finished {res['finished']}" if res.get("finished") else " (running)"), "",
         "Both versions are made from the same footage and scored by the same creative check. The check is built "
         "from the same research as the knowledge base, so higher scores mean 'follows the research more "
         "closely', not 'more views'. Read the narration of both and judge for yourself.", "",
         f"Pairs compared: {s['pairs']}", "", "| Area | Previous | New | Better | Same | Worse |", "|---|---|---|---|---|---|"]
    for a, v in s["areas"].items():
        L.append(f"| {LABEL.get(a, 'Overall')} | {v['previous']} | {v['new']} | {v['better']} | {v['same']} | {v['worse']} |")
    for r in res["rows"]:
        L += ["", f"## {r['n']}. [{r['category']}] {r['prompt']}", ""]
        for var in ("previous", "new"):
            v = r.get(var) or {}
            if "error" in v:
                L.append(f"**{var}:** not made — {v['error']}")
                continue
            L.append(f"**{var}** — {v.get('mode')}, script by {v.get('script_by')}, category {v.get('category')}, "
                     f"overall {v.get('overall')}" + (f" (before fixes {v.get('first_overall')}; "
                                                      f"{'; '.join(v.get('changes') or []) or 'no changes'}; kept "
                                                      f"{v.get('kept')})" if var == "new" else ""))
            L += [f"- {t}" for t in v.get("narration", [])]
            iss = v.get("issues") or []
            if iss:
                L.append("  Remaining issues: " + "; ".join(f"{i['start']:.0f}s {i['message']}" for i in iss[:5]))
    L += ["", DISCLAIMER]
    (out / "report.md").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
