"""Turn a landscape (or vertical) source into a 1080x1920 frame.

Layouts
  smart          one picture, never two copies of the stream (1.5.1): a big webcam / face
                 (a reaction or talking stream) is followed with a full-height crop centred on
                 it; otherwise a zoomed gameplay window (about 60 % of the screen height)
                 centred on where the action is, over a blurred fill.
  center         full-height centre crop (fills the screen, loses the sides).
  blur-fill      the whole 16:9 frame, unzoomed, over a blurred copy of itself.
  facecam-split  webcam on top, gameplay (centred on the action) below.
"""
from __future__ import annotations

from typing import Optional

import numpy as np

SMART_ZOOM = 1.45          # facecam-split's gameplay zoom (unchanged)
FILL = 0.60                # zoom-fit: the gameplay fills this much of the height ...
MIN_WIDTH = 0.50           # ... while keeping at least this much of the frame's width
BIG_FACECAM = 0.08         # a webcam covering this much of the frame is what the video is about


def action_center(profile: Optional[np.ndarray], times: Optional[np.ndarray], start: float, end: float) -> float:
    """Horizontal centre of on-screen motion during [start, end], as a 0..1 fraction."""
    if profile is None or times is None or len(times) == 0:
        return 0.5
    idx = np.where((times >= start) & (times <= end))[0]
    if len(idx) == 0:
        return 0.5
    p = profile[idx].astype(float).mean(axis=0)
    if p.sum() <= 0 or p.max() < 1.3 * p.mean():  # flat: no dominant region
        return 0.5
    bins = (np.arange(len(p)) + 0.5) / len(p)
    w = np.clip(p - np.median(p), 0, None)
    if w.sum() <= 0:
        return 0.5
    c = float((bins * w).sum() / w.sum())
    return float(min(0.72, max(0.28, 0.5 + (c - 0.5) * 0.8)))  # damped: never swing to the edge


def _even(x: float) -> int:
    return max(2, int(round(x / 2)) * 2)


def layout_filter(inp: str, out: str, src_w: int, src_h: int, W: int, H: int, mode: str,
                  ax: float = 0.5, facecam: Optional[list] = None) -> str:
    """Return a filtergraph fragment taking [inp] to [out] (W x H, yuv420p, square pixels)."""
    if src_w <= 0 or src_h <= 0:
        src_w, src_h = 1920, 1080
    if mode == "smart":
        if facecam and facecam[2] * facecam[3] >= BIG_FACECAM:
            mode, ax = "center", facecam[0] + facecam[2] / 2      # follow the person, one picture
        else:
            mode = "zoom-fit"
    if src_h >= src_w * 1.2:  # already vertical: cover and centre
        return (f"[{inp}]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,"
                f"format=yuv420p[{out}]")
    if mode == "center":
        sw = _even(src_w * H / src_h)
        x = int(min(max(0, ax * sw - W / 2), sw - W))
        return f"[{inp}]scale={sw}:{H},crop={W}:{H}:{x}:0,setsar=1,format=yuv420p[{out}]"
    if mode == "facecam-split" and facecam:
        fx, fy, fw, fh = facecam
        top_h = _even(H * 0.36)
        bot_h = H - top_h
        # webcam: crop its box, cover-fit into W x top_h
        cw, ch = _even(fw * src_w), _even(fh * src_h)
        cx, cy = int(fx * src_w), int(fy * src_h)
        # gameplay: crop a W:bot_h aspect window, full height, centred on the action (avoid the webcam if possible)
        gw = _even(min(src_w, src_h * W / bot_h))
        gx = int(min(max(0, ax * src_w - gw / 2), src_w - gw))
        return (f"[{inp}]split=2[{out}_a][{out}_b];"
                f"[{out}_a]crop={cw}:{ch}:{cx}:{cy},scale={W}:{top_h}:force_original_aspect_ratio=increase,"
                f"crop={W}:{top_h}[{out}_top];"
                f"[{out}_b]crop={gw}:{src_h}:{gx}:0,scale={W}:{bot_h}[{out}_bot];"
                f"[{out}_top][{out}_bot]vstack=2,setsar=1,format=yuv420p[{out}]")
    if mode == "zoom-fit":
        cw = _even(min(src_w, max(src_w * MIN_WIDTH, W * src_h / (FILL * H))))
    else:
        cw = _even(src_w / (SMART_ZOOM if mode == "facecam-split" else 1.0))
    cx = int(min(max(0, ax * src_w - cw / 2), src_w - cw))
    fh = _even(W * src_h / cw)
    fy = int((H - fh) / 2 - H * 0.04)
    return (f"[{inp}]split=2[{out}_bg][{out}_fg];"
            f"[{out}_bg]scale={W // 4}:{H // 4}:force_original_aspect_ratio=increase,crop={W // 4}:{H // 4},"
            f"boxblur=12:2,eq=brightness=-0.10:saturation=1.15,scale={W}:{H}[{out}_bgb];"
            f"[{out}_fg]crop={cw}:{src_h}:{cx}:0,scale={W}:{fh}[{out}_fgs];"
            f"[{out}_bgb][{out}_fgs]overlay=0:{fy},setsar=1,format=yuv420p[{out}]")


def punch_filter(inp: str, out: str, W: int, H: int, fps: int, at: Optional[float], hold_push: bool,
                 duration: float) -> str:
    """Zoom accent: a quick punch-in at a clip's key moment, or a slow push-in on a hold frame."""
    if hold_push:
        z = f"1+{0.07 / max(0.5, duration):.5f}*it"
    elif at is not None and 0 < at < duration:
        a, b = max(0.0, at - 0.12), at + 0.9
        z = (f"if(between(it,{a:.3f},{b:.3f}),"
             f"1+0.09*if(lt(it,{at + 0.08:.3f}),(it-{a:.3f})/0.2,max(0,1-(it-{at + 0.08:.3f})/0.82)),1)")
    else:
        return f"[{inp}]null[{out}]"
    return (f"[{inp}]zoompan=z='{z}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={W}x{H}:fps={fps}[{out}]")
