"""The Shorts knowledge base: research findings turned into decisions ClipForge makes.

Loaded from ``shorts_kb.json`` (published sources, with evidence levels). Used by:
  * prompt expansion   — category, hook type, structure, retention plan, mistakes to avoid
  * script writing     — category guidance (narration-driven, hybrid and clip-driven)
  * footage / editing  — shot length, longest shot, transitions, caption group size
  * creative QC        — the thresholds and the stock phrases it checks for

Nothing here is a template: each category offers several hook types and structures, and the one
suggested depends on the prompt (the writer may pick another that fits better).
"""
from __future__ import annotations

import hashlib
import json
import re
from functools import lru_cache
from pathlib import Path

DEFAULT = "education"

# stock phrases that delay the point or sound generic (checked by creative QC; the writer is told to avoid them)
STOCK_PHRASES = [
    "in this video", "in today's video", "let's dive in", "dive into", "without further ado", "buckle up",
    "you won't believe", "stay tuned", "make sure to like", "smash that like", "hey guys", "what's up guys",
    "welcome back", "in conclusion", "game-changer", "game changer", "it's important to note", "delve",
    "a testament to", "in the world of", "unlock the secrets", "let's get started", "journey", "embark",
    "tapestry", "ever wondered", "the answer may surprise you", "and that's not all",
]


@lru_cache(maxsize=1)
def load() -> dict:
    return json.loads((Path(__file__).with_name("shorts_kb.json")).read_text(encoding="utf-8"))


def categories() -> dict:
    return load()["categories"]


def detect_category(text: str, mode: str = "") -> tuple[str, float]:
    """The content category from the prompt (and the brief's subject). Keyword evidence; the AI
    expansion can override it. Returns (category, confidence 0-1)."""
    t = " " + (text or "").lower() + " "
    scores: dict[str, float] = {}
    for cid, c in categories().items():
        s = 0.0
        for kw in c["keywords"]:
            if re.search(r"(?<![a-z])" + re.escape(kw) + r"(?:s|es)?(?![a-z])", t):
                s += 1.0 + 0.3 * (len(kw.split()) - 1)
        if s:
            scores[cid] = s
    if mode == "clip" and not scores:
        return "entertainment", 0.4
    if not scores:
        return DEFAULT, 0.2
    # "explain", "top 10" are framings on top of a subject: the subject's category wins a near tie
    framing = {"list", "education"}
    best = max(scores, key=lambda k: (scores[k], k not in framing))
    subject = {k: v for k, v in scores.items() if k not in framing}
    if best in framing and subject and max(subject.values()) >= scores[best] - 0.5:
        best = max(subject, key=subject.get)
    conf = min(1.0, 0.35 + 0.2 * scores[best])
    return best, round(conf, 2)


def profile(category: str) -> dict:
    c = categories().get(category) or categories()[DEFAULT]
    return dict(c, id=category if category in categories() else DEFAULT)


def _pick(options: list[str], seed: str) -> str:
    if not options:
        return ""
    h = int(hashlib.sha1(seed.encode("utf-8")).hexdigest(), 16)
    return options[h % len(options)]


def suggest(category: str, prompt: str) -> dict:
    """A hook type and structure suggestion for this prompt. Varies with the prompt so videos in
    the same category don't all share one template."""
    p = profile(category)
    hooks, structs = p["hooks"], p["structures"]
    low = (prompt or "").lower()
    # the request's own wording decides when it's explicit
    if re.search(r"\b(count ?down|top \d+|ranking)\b", low) and "countdown" in load()["structures"]:
        struct = "countdown"
    elif re.search(r"\b(\d+|three|four|five|six|seven|eight|nine|ten)\s+(tips|things|ways|steps|facts|reasons|"
                   r"features|changes|mistakes)\b", low):
        struct = next((s for s in structs if s.startswith("numbered")), "numbered_tips" if "tip" in low else
                      "numbered_facts")
    elif re.search(r"\bstory|poem|tale\b", low):
        struct = _pick([s for s in structs if "story" in s or "act" in s or "twist" in s] or structs, prompt)
    else:
        struct = _pick(structs, prompt + "|s")
    hook = _pick(hooks, prompt + "|h")
    if struct in ("numbered_tips", "step_by_step") and "payoff_promise" in load()["hook_types"]:
        hook = "payoff_promise" if "payoff_promise" in hooks or category in ("gaming", "education") else hook
    return {"category": p["id"], "hook_type": hook, "structure": struct,
            "hook_name": load()["hook_types"].get(hook, {}).get("name", hook),
            "structure_text": load()["structures"].get(struct, "")}


def guidance(category: str, prompt: str = "", purpose: str = "writer", mode: str = "narration") -> str:
    """Research-based guidance for this category, for a language-model prompt. Short on purpose:
    principles and options, not a script."""
    p = profile(category)
    s = suggest(category, prompt)
    kb = load()
    hooks = "; ".join(f"{h} ({kb['hook_types'][h]['name']})" for h in p["hooks"] if h in kb["hook_types"])
    structs = "; ".join(f"{x}: {kb['structures'][x]}" for x in p["structures"] if x in kb["structures"])
    lines = [f"Category: {p['name']}. {p['notes']}",
             f"Hook types that suit it: {hooks}. Suggested for this request: {s['hook_type']}.",
             f"Structures that suit it (choose the one that fits the request best, don't force it): {structs}.",
             f"Pace: about {p['wpm'][0]}-{p['wpm'][1]} words per minute; a new picture every "
             f"{p['shot'][0]:.0f}-{p['shot'][1]:.0f} s. Emotions that fit: {', '.join(p['emotions'])}.",
             "Research-based rules: the subject and a reason to keep watching in the first second (no greeting, no "
             "'in this video'); every point is new information with a how or why; something new at least every "
             "8-10 s; the hook's promise is paid off; end on the payoff, not on a new topic; conversational words, "
             "no stock phrases (" + ", ".join(STOCK_PHRASES[:8]) + "...); understandable to a stranger with no context."]
    if mode == "clip" or purpose == "clip":
        lines.append("Clip-driven: the real moments carry the video; narration gives context a stranger needs (who, "
                     "what's at stake) and never explains a joke after it lands.")
    if category in ("gaming_news", "news", "technology", "history", "science", "facts", "mystery"):
        lines.append("Facts: only state what the request, the notes or the sources say; say 'reportedly' / 'unconfirmed' "
                     "for anything else; never invent numbers or dates.")
    return "\n".join(lines)


def edit_profile(category: str) -> dict:
    """Numbers the editor uses: target shot length, longest shot, transitions, caption group size,
    narration words per minute."""
    p = profile(category)
    return {"shot": tuple(p["shot"]), "max_shot": p["max_shot"], "transitions": p["transitions"],
            "caption_words": int(p["caption_words"]), "wpm": tuple(p["wpm"]), "length": tuple(p["length"]),
            "music": p["music"]}


def finding(fid: str) -> dict:
    return next((f for f in load()["findings"] if f["id"] == fid), {})
