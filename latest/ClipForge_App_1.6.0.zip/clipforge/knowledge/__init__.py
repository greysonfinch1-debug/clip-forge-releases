"""ClipForge's Shorts knowledge base (research findings) and the user's own performance data.

Two independent parts, on purpose:
  shorts_kb.json / kb.py    research findings from published sources (shipped with the app)
  ../performance.py         the user's own YouTube Studio numbers (kept in the user's data folder)
"""
