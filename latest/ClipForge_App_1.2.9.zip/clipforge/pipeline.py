"""Orchestrates every stage. The GUI and tests drive the app only through this module.

Stages (each cached, each reports progress, each can be cancelled):
  ingest → transcribe → audio analysis → visual analysis → topic understanding →
  proposals → evidence → judging → selection → story → hooks → script → voice → render → QC
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from .analysis.audio import AudioFeatures, analyze_audio
from .analysis.transcript import get_transcript
from .analysis.visual import VisualFeatures, analyze_visual
from .config import Settings, app_dir
from .core import ffmpeg as ff
from .core.cache import SourceCache, stable_id
from .core.ingest import Ingestor
from .core.models import Candidate, NarrationLine, Plan, StoryItem, TopicSpec, Transcript, VideoSource
from .intelligence import judge as judge_mod
from .intelligence.proposals import build_timeline, propose
from .intelligence.selection import select_clips
from .intelligence.story import make_hooks, order_story, write_script
from .intelligence import topic as topic_mod
from .intelligence.topic import understand_topic
from .services import Services

Progress = Callable[[str, float, str], None]  # (stage, fraction, message)


@dataclass
class Project:
    source: Optional[VideoSource] = None
    plan: Plan = field(default_factory=Plan)
    candidates: list[Candidate] = field(default_factory=list)
    log: list[str] = field(default_factory=list)
    used: dict = field(default_factory=dict)       # which engine actually did each stage
    last_export: str = ""
    project_id: str = ""

    def to_dict(self) -> dict:
        return {"source": self.source.to_dict() if self.source else None, "plan": self.plan.to_dict(),
                "candidates": [c.to_dict() for c in self.candidates], "log": self.log[-300:], "used": self.used,
                "last_export": self.last_export, "project_id": self.project_id}

    @classmethod
    def from_dict(cls, d: dict) -> "Project":
        return cls(source=VideoSource.from_dict(d["source"]) if d.get("source") else None,
                   plan=Plan.from_dict(d.get("plan") or {}),
                   candidates=[Candidate.from_dict(c) for c in d.get("candidates") or []],
                   log=d.get("log") or [], used=d.get("used") or {}, last_export=d.get("last_export", ""),
                   project_id=d.get("project_id", ""))

    def save(self) -> Path:
        d = app_dir() / "projects"
        d.mkdir(exist_ok=True)
        if not self.project_id:
            self.project_id = time.strftime("%Y%m%d-%H%M%S")
        p = d / f"{self.project_id}.json"
        p.write_text(json.dumps(self.to_dict(), indent=1), encoding="utf-8")
        try:   # remembered so ClipForge reopens it next time (e.g. after an update restart)
            (app_dir() / "last_project.txt").write_text(str(p), encoding="utf-8")
        except OSError:
            pass
        return p

    def candidate(self, cid: str) -> Optional[Candidate]:
        return next((c for c in self.candidates if c.cid == cid), None)


class Pipeline:
    def __init__(self, settings: Optional[Settings] = None, services: Optional[Services] = None):
        self.settings = settings or Settings.load()
        self.services = services or Services(self.settings)
        self.project = Project()
        self._cancel = False
        # analysis results kept in memory for the current source
        self.transcript: Optional[Transcript] = None
        self.audio: Optional[AudioFeatures] = None
        self.visual: Optional[VisualFeatures] = None
        self.timeline = None
        self.sounds = None

    # -------------------------------------------------------------- utilities
    def cancel(self):
        self._cancel = True

    def _cancelled(self) -> bool:
        return self._cancel

    def log(self, msg: str):
        self.project.log.append(f"{time.strftime('%H:%M:%S')}  {msg}")

    @property
    def cache(self) -> SourceCache:
        assert self.project.source is not None
        return SourceCache(self.project.source.source_id)

    # -------------------------------------------------------------- 1. ingest
    def ingest(self, url: str = "", path: str = "", progress: Optional[Progress] = None) -> VideoSource:
        self._cancel = False
        p = (lambda f, m: progress("ingest", f, m)) if progress else None
        ing = Ingestor(progress=p, cancel=self._cancelled, analysis_height=self.settings.vision.analysis_height)
        src = ing.from_url(url) if url else ing.from_file(path)
        cached = SourceCache(src.source_id).load_json("rights.json")
        if cached:
            from .core.models import RightsRecord
            src.rights = RightsRecord.from_dict(cached)
        self.project = Project(source=src)
        self.transcript = self.audio = self.visual = self.timeline = self.sounds = None
        self.log(f"Loaded '{src.title}' ({src.duration / 60:.1f} min) from {src.platform}")
        return src

    def open_project(self, path: str, progress: Optional[Progress] = None) -> Project:
        """Resume a saved project; analysis comes back from the cache in seconds."""
        proj = Project.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
        if proj.source is None:
            raise ValueError("That project has no video")
        if proj.source.kind == "file" and not Path(proj.source.path).exists():
            raise FileNotFoundError(f"The video file has moved or was deleted: {proj.source.path}")
        self.project = proj
        self.transcript = self.audio = self.visual = self.timeline = self.edit_timeline = self.sounds = None
        self.analyze_signals(progress)
        return proj

    def save_rights(self):
        if self.project.source:
            self.cache.save_json("rights.json", self.project.source.rights.to_dict())

    # -------------------------------------------------------------- 2. analyse (whole-video signals)
    def analyze_signals(self, progress: Optional[Progress] = None):
        src = self.project.source
        assert src is not None
        self._cancel = False
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        t0 = time.time()
        self.transcript = get_transcript(src.audio_path, self.cache, lambda: self.services.transcriber(pr("models")),
                                         pr("transcript"), self._cancelled)
        self.used["transcription"] = self.transcript.backend
        self.services.release("transcriber")  # ~1 GB; reloaded only if needed for caption timing
        self.log(f"Transcript: {len(self.transcript.sentences)} sentences ({self.transcript.backend}) "
                 f"[{time.time() - t0:.0f}s]")
        t0 = time.time()
        self.audio = analyze_audio(src.audio_path, self.cache, pr("audio"), self._cancelled)
        self.log(f"Audio analysed [{time.time() - t0:.0f}s]")
        t0 = time.time()
        vision = self.services.vision()
        self.visual = analyze_visual(src.proxy_path, self.cache, self.settings.vision.sample_every_seconds, vision,
                                     self.settings.vision.analysis_height, pr("visual"), self._cancelled)
        self.used["vision"] = self.visual.emb_model or "none (no visual model)"
        self.log(f"Visuals analysed: {len(self.visual.times)} frames, model={self.used['vision']} "
                 f"[{time.time() - t0:.0f}s]")
        # real sound-event model (laughter, sirens, crashes…) and speaker identification
        t0 = time.time()
        from .analysis.sound_events import analyze_sound_events

        try:
            self.sounds = analyze_sound_events(src.audio_path, src.duration, self.cache,
                                               self.services.sound_tagger(pr("models")), pr("sounds"), self._cancelled)
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001  (a model failure must never stop the analysis)
            self.sounds = None
            self.log(f"Sound-event model failed ({e}); using loudness-based cues")
        self.used["sound_events"] = self.sounds.model_id if self.sounds is not None else "none"
        # speakers are identified later, only around candidate moments (much faster on long streams)
        dz = self.services.diarizer(pr("models"))
        self.used["speakers"] = dz.model_id if dz is not None else "none"
        self.log(f"Sounds analysed: {self.used['sound_events']}; speaker model: {self.used['speakers']} "
                 f"[{time.time() - t0:.0f}s]")

    @property
    def used(self) -> dict:
        return self.project.used

    # -------------------------------------------------------------- 3. find & judge moments for a topic
    def find_moments(self, topic: str, target_seconds: float, desired_clips: int = 0,
                     progress: Optional[Progress] = None) -> list[Candidate]:
        if self.transcript is None:
            self.analyze_signals(progress)
        self._cancel = False
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        llm = self.services.llm()
        self.used["llm"] = self.services.status["llm"].active
        spec_key = "topic_" + stable_id(topic.strip().lower(), self.used["llm"], self.settings.llm.model,
                                         str(topic_mod.VERSION))
        spec_d = self.cache.load_json(spec_key + ".json")
        spec = TopicSpec.from_dict(spec_d) if spec_d else understand_topic(topic, llm)
        self.cache.save_json(spec_key + ".json", spec.to_dict())
        self.log("Topic understood: " + spec.summary)
        embedder = self.services.embedder()
        self.used["embedder"] = self.services.status["embedder"].active
        vision = self.services.vision()
        self.timeline = build_timeline(spec, self.transcript, self.audio, self.visual, embedder, vision,
                                       getattr(self, "sounds", None))
        max_len = min(40.0, max(10.0, target_seconds * 0.8))
        cand_key = spec_key + "_" + stable_id(str(max_len), self.used["embedder"], self.used.get("vision", ""),
                                              self.settings.vision.captioner, str(judge_mod.VERSION),
                                              self.used.get("sound_events", ""), self.used.get("speakers", ""))
        cached = self.cache.load_json(f"cands_{cand_key}.json")
        if cached:
            cands = [Candidate.from_dict(c) for c in cached["candidates"]]
            self.used["judge"] = cached.get("judge", "?")
            self.log(f"Loaded {len(cands)} judged candidates from cache")
            self._label_speakers(cands, progress)
        else:
            n_judge = self.settings.llm.max_candidates_to_judge
            cands = propose(self.timeline, self.transcript, self.audio, max_candidates=n_judge, max_len=max_len)
            self.log(f"Proposed {len(cands)} candidate moments")
            self._label_speakers(cands, progress)
            captioner = self.services.captioner() if self.used["llm"] != "rules" else None
            kf_dir = str(self.cache.subdir("keyframes"))
            n_cap = 15  # vision-LLM descriptions only for the strongest proposals (speed)
            for i, c in enumerate(cands):
                c.evidence = judge_mod.build_evidence(c, spec, self.transcript, self.audio, self.visual, vision,
                                                      self.project.source.proxy_path, kf_dir, captioner, i < n_cap,
                                                      self.settings.vision.keyframes_per_candidate,
                                                      getattr(self, "sounds", None))
                if progress:
                    progress("evidence", (i + 1) / max(1, len(cands)), "Gathering evidence for each moment")
                if self._cancel:
                    raise RuntimeError("Cancelled")
            self.used["captioner"] = (self.services.status.get("captioner").active
                                      if self.services.status.get("captioner") else "none")
            self.used["judge"] = judge_mod.judge_candidates(cands, spec, llm, self.transcript, self.visual, self.audio,
                                                            self.timeline, batch_size=4, progress=pr("judge"),
                                                            cancel=self._cancelled)
            self.cache.save_json(f"cands_{cand_key}.json", {"candidates": [c.to_dict() for c in cands],
                                                            "judge": self.used["judge"]})
        self.project.plan = Plan(topic=spec, target_seconds=target_seconds, desired_clips=desired_clips)
        self.project.candidates = cands
        self.select(progress)
        self.project.save()
        return cands

    def _label_speakers(self, cands, progress=None):
        """Who-spoke-when around the candidate moments (cached; only new windows are processed)."""
        from .analysis.speakers import get_speakers

        src = self.project.source
        pr = (lambda f, m: progress("speakers", f, m)) if progress else None
        t0 = time.time()
        try:
            n = get_speakers(src.audio_path, src.duration, self.cache, self.transcript, self.services.diarizer(),
                             [(c.start, c.end) for c in cands], pr, self._cancelled)
            if self.services.diarizer() is not None:
                self.log(f"Speakers identified around {len(cands)} moments: {n} voice(s) [{time.time() - t0:.0f}s]")
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001  (never stops the analysis)
            self.log(f"Speaker identification failed ({e})")

    # -------------------------------------------------------------- 4. select + story + script
    def select(self, progress: Optional[Progress] = None):
        plan = self.project.plan
        chosen = select_clips(self.project.candidates, self.transcript, plan.target_seconds, plan.desired_clips,
                              self.services.embedder())
        self.log(f"Selected {len(chosen)} clips: " + ", ".join(f"{c.cid} ({c.duration:.0f}s)" for c in chosen))
        self.build_story(progress)

    def build_story(self, progress: Optional[Progress] = None):
        plan = self.project.plan
        chosen = [c for c in self.project.candidates if c.included]
        llm = self.services.llm()
        story, how = order_story(chosen, plan.topic, llm)
        plan.story = story
        self.used["story"] = how
        by_id = {c.cid: c for c in self.project.candidates}
        hooks, how_h = make_hooks(story, by_id, plan.topic, llm, self.settings.hook_variants)
        plan.hooks, plan.chosen_hook = hooks, 0
        self.used["hooks"] = how_h
        self.write_script()
        if progress:
            progress("story", 1.0, "Story, hooks and script ready")

    def write_script(self):
        plan = self.project.plan
        by_id = {c.cid: c for c in self.project.candidates}
        hook = plan.hooks[plan.chosen_hook] if plan.hooks else None
        lines, extras, how = write_script(plan.story, by_id, plan.topic, hook, self.services.llm(), self.transcript,
                                          plan.target_seconds)
        plan.narration = lines
        self.edit_timeline = None
        self.used["script"] = how
        ctx = extras.get("context_texts") or {}
        for i, it in enumerate(plan.story):
            t = ctx.get(str(i + 1)) or ctx.get(i + 1)
            c = by_id[it.cid]
            if not t:
                t = next((r.split(":", 1)[1] for r in c.reasons if r.startswith("context:")), "")
            it.context_text = str(t or "")[:60]
        plan.title = extras.get("title") or (hook.headline.title() if hook else plan.topic.summary[:60])
        if extras.get("description"):
            plan.description = extras["description"]
        else:  # fallback: a clean sentence, not the raw search request
            from .intelligence.story import _short_topic

            plan.description = f"The best {_short_topic(plan.topic)} from the stream."
        self.log(f"Script: {len(lines)} narration lines ({how})")

    # -------------------------------------------------------------- re-selection after user edits
    def set_choices(self, include: set[str]):
        """Apply the user's ticks on the candidates page: ticked = locked in, unticked = excluded."""
        for c in self.project.candidates:
            was = c.included
            c.included = c.cid in include
            c.locked = c.included
            c.excluded = (not c.included) and (was or c.excluded)
        self.edit_timeline = None
        self.build_story()

    def replace_clip(self, cid: str):
        """Remove one clip and let the selector pick the best remaining alternative."""
        c = self.project.candidate(cid)
        if c is None:
            return
        c.excluded, c.locked, c.included = True, False, False
        for x in self.project.candidates:
            x.locked = x.included
        self.select()

    def auto_select(self):
        for x in self.project.candidates:
            x.locked = False
        self.select()

    def render_preview(self, progress: Optional[Progress] = None) -> Path:
        """Fast low-resolution preview of the current edit (not checked for rights: stays on this PC)."""
        import dataclasses

        from .render.render import RenderJob, render

        if self.edit_timeline is None:
            self.prepare_edit(progress)
        es = dataclasses.replace(self.settings.edit, width=540, height=960, crf=30, preset="ultrafast")
        work = self.cache.subdir("render") / "preview"
        out = self.cache.subdir("render") / "preview.mp4"
        job = RenderJob(self.edit_timeline, self.project.plan.captions, self.project.plan.overlays, es, work, out,
                        getattr(self, "_best_src", {}), self.visual,
                        self.visual.facecam if self.visual is not None else None, self.project.source.source_id)
        path = render(job, (lambda f, m: progress("preview", f, m)) if progress else None, self._cancelled)
        shutil.rmtree(work, ignore_errors=True)
        return path

    def story_candidates(self) -> list[tuple[StoryItem, Candidate]]:
        by_id = {c.cid: c for c in self.project.candidates}
        return [(it, by_id[it.cid]) for it in self.project.plan.story if it.cid in by_id]

    def move_story_item(self, index: int, delta: int):
        st = self.project.plan.story
        j = index + delta
        if 0 <= index < len(st) and 0 <= j < len(st):
            st[index], st[j] = st[j], st[index]
            for ln in self.project.plan.narration:  # narration follows its clip
                if ln.item_index == index:
                    ln.item_index = j
                elif ln.item_index == j:
                    ln.item_index = index
            self.edit_timeline = None

    def choose_hook(self, index: int):
        """Switch the hook: headline overlay + opening narration line (rest of the script kept)."""
        plan = self.project.plan
        if not (0 <= index < len(plan.hooks)):
            return
        plan.chosen_hook = index
        h = plan.hooks[index]
        first = next((ln for ln in plan.narration if ln.item_index == 0 and ln.position != "after"), None)
        if first is not None and h.opening_line:
            first.text, first.audio_path, first.duration = h.opening_line, "", 0.0
        elif h.opening_line:
            plan.narration.insert(0, NarrationLine(text=h.opening_line, item_index=0))
        for o in plan.overlays:
            if o.kind == "headline":
                o.text = h.headline
        self.edit_timeline = None

    # -------------------------------------------------------------- "Any changes?" (typed revisions)
    def revise(self, request: str, progress: Optional[Progress] = None, render: bool = True) -> dict:
        """Apply a typed change request ("drop clip 3, make the hook funnier") and re-render the preview.
        Returns {done, skipped, reply, how, undo, preview}."""
        from .intelligence.revise import apply_changes, plan_changes, snapshot

        if progress:
            progress("revise", 0.05, "Understanding your request…")
        undo = snapshot(self)
        ops, how, reply = plan_changes(request, self)
        done, skipped = apply_changes(self, ops)
        self.log(f"Revision ({how}): {request!r} -> {len(done)} changes, {len(skipped)} skipped")
        preview = None
        if done:
            self.project.save()
            if render:
                sub = (lambda st, f, m: progress(st, 0.1 + 0.9 * f, m)) if progress else None
                preview = self.render_preview(sub)
        return {"done": done, "skipped": skipped, "reply": reply, "how": how, "undo": undo,
                "preview": str(preview) if preview else ""}

    def undo_revision(self, snap: dict, progress: Optional[Progress] = None) -> str:
        from .intelligence.revise import restore

        restore(self, snap)
        self.project.save()
        return str(self.render_preview(progress))

    # -------------------------------------------------------------- 5. voice + edit plan (captions, overlays)
    edit_timeline = None

    def prepare_edit(self, progress: Optional[Progress] = None, keep_overlays: bool = True):
        """Fetch full-quality clip sections, voice the script, lay out the timeline, and build
        captions + overlays (stored in the plan so they can be corrected before export)."""
        from .render.captions import build_captions, default_overlays
        from .render.timeline import build_timeline as build_out_timeline
        from .render.timeline import find_dead_air, refine_cut_points
        from .render.voice import narration_word_times, synthesize_lines

        src, plan = self.project.source, self.project.plan
        assert src is not None and plan.story, "Nothing to edit yet"
        self._cancel = False
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        es = self.settings.edit
        # full-quality footage for the chosen clips only
        if src.kind == "file" and src.path and Path(src.path).exists():
            sections = {i: (src.path, 0.0) for i in range(len(plan.story))}
        else:
            ranges = [(max(0.0, it.start - 6.0), it.end + 1.5) for it in plan.story]  # lead-in room
            ing = Ingestor(progress=pr("download"), cancel=self._cancelled)
            got = ing.fetch_sections(src, ranges)
            sections = {i: (got[r], r[0]) for i, r in enumerate(ranges)}
        # analysis models aren't needed for editing: free their memory before loading the voice
        self.services.release("vision", "captioner", "sound_events", "diarizer")
        # voice
        v = self.settings.voice
        tts = self.services.tts(pr("models"))
        synthesize_lines(plan.narration, tts, v.voice, v.speed, v.volume_db, self.cache, pr("voice"))
        self.used["voice"] = f"{tts.name}:{v.voice}"
        # exact narration word timings for captions (speech model), estimated if it can't load
        try:
            trans = self.services.transcriber() if plan.narration else None
        except Exception:  # noqa: BLE001
            trans = None
        word_times = [narration_word_times(ln, trans) for ln in plan.narration]
        self.services.release("transcriber")
        # timeline
        T = es.transition_seconds if es.transitions != "none" else 0.0
        by_id = {c.cid: c for c in self.project.candidates}
        self._best_src = {}
        for i, it in enumerate(plan.story):
            c = by_id.get(it.cid)
            if c is not None and it.start <= c.best_moment <= it.end:
                self._best_src[i] = c.best_moment
        # cut points: never open or end a clip on a few frames of a different scene, and know
        # where the scene changes are so lead-in / flash-forward footage never crosses one
        cuts = self._scene_cuts(sections)
        notes = refine_cut_points(plan.story, cuts, self.transcript)
        if notes:
            self.log("Cut points moved to scene changes: " + "; ".join(notes))
        self._best_src = {i: bm for i, bm in self._best_src.items() if plan.story[i].start <= bm <= plan.story[i].end}
        trims = find_dead_air(plan.story, self.transcript, self.audio, self.visual, self._best_src) \
            if getattr(es, "tighten_pauses", True) else {}
        tl = build_out_timeline(plan.story, sections, plan.narration, self.transcript, T, self._best_src,
                                teaser=es.flash_forward_hook, cuts=cuts, trims=trims)
        if trims:
            self.log("Tightened pauses: " + ", ".join(f"clip {i + 1}: {sum(b - a for a, b in v):.1f}s"
                                                     for i, v in trims.items()))
        by_line = {id(ln): wt for ln, wt in zip(plan.narration, word_times)}
        best_out = [o for o in (tl.to_output(i, bm) for i, bm in self._best_src.items() if i < len(tl.item_spans))
                    if o is not None]
        old_edits = {(c.kind, round(c.start, 1)): c for c in plan.captions if c.edited}
        chunks = build_captions(tl, [by_line[id(p.line)] for p in tl.narration], es, best_out)
        for c in chunks:
            e = old_edits.get((c.kind, round(c.start, 1)))
            if e is not None:
                c.words, c.edited = e.words, True
        plan.captions = chunks
        defaults = default_overlays(plan, tl, es)
        if keep_overlays and plan.overlays:
            # keep the user's text edits, re-time to the new edit
            kinds: dict = {}
            for o in defaults:
                k = kinds[o.kind] = kinds.get(o.kind, -1) + 1
                prev = [x for x in plan.overlays if x.kind == o.kind]
                if k < len(prev) and prev[k].text.strip():
                    o.text = prev[k].text
            defaults += [o for o in plan.overlays if o.kind == "emphasis"]
        plan.overlays = defaults
        self.edit_timeline = tl
        self.log(f"Edit ready: {tl.duration:.1f}s, {len(tl.narration)} narration lines, {len(chunks)} caption groups")
        return tl

    def _scene_cuts(self, sections: dict) -> dict[int, list[float]]:
        """Scene changes near each clip's start, end and best moment (source time), cached."""
        plan = self.project.plan
        store = self.cache.load_json("scene_cuts.json") or {}
        out: dict[int, list[float]] = {}
        changed = False
        for i, it in enumerate(plan.story):
            f, f0 = sections[i]
            spans = [(it.start - 6.5, it.start + 3.6), (it.end - 3.6, it.end + 1.5)]
            bm = getattr(self, "_best_src", {}).get(i)
            if bm is not None:
                spans.append((bm - 3.0, bm + 3.0))
            found: set[float] = set()
            for a, b in spans:
                a, b = max(f0, a), b
                key = f"{Path(f).name}|{a - f0:.2f}|{b - f0:.2f}"
                if key not in store:
                    try:
                        store[key] = [round(c + f0, 3) for c in ff.detect_cuts(f, a - f0, b - f0)]
                    except Exception:  # noqa: BLE001  (cut detection is a refinement, never a failure)
                        store[key] = []
                    changed = True
                found.update(store[key])
            out[i] = sorted(found)
        if changed:
            self.cache.save_json("scene_cuts.json", store)
        return out

    # -------------------------------------------------------------- 6. export
    def export(self, hook_indices: Optional[list[int]] = None, progress: Optional[Progress] = None,
               out_dir: str = "") -> list[tuple[Path, "object"]]:
        from .render.qc import run_qc
        from .render.render import RenderJob, render

        src, plan = self.project.source, self.project.plan
        assert src is not None
        problems = src.rights.problems(plan.monetized)
        if problems:
            raise PermissionError("Export blocked until footage rights are recorded:\n- " + "\n- ".join(problems))
        hook_indices = hook_indices if hook_indices else [plan.chosen_hook]
        original_hook = plan.chosen_hook
        out_root = Path(out_dir or self.settings.output_dir)
        out_root.mkdir(parents=True, exist_ok=True)
        results = []
        base = _safe_name(plan.title or plan.topic.summary or "short")
        stamp = time.strftime("%Y%m%d-%H%M")
        for n, h in enumerate(hook_indices):
            if h != plan.chosen_hook or self.edit_timeline is None:
                if h != plan.chosen_hook:
                    self.choose_hook(h)
                self.prepare_edit(progress)
            tl = self.edit_timeline
            suffix = f"_hook{h + 1}" if len(hook_indices) > 1 else ""
            out = out_root / f"{base}_{stamp}{suffix}.mp4"
            job = RenderJob(timeline=tl, chunks=plan.captions, overlays=plan.overlays, edit=self.settings.edit,
                            workdir=self.cache.subdir("render") / f"{stamp}_{h}", out_path=out,
                            best_moments=getattr(self, "_best_src", {}), visual_profile=self.visual,
                            facecam=self.visual.facecam if self.visual is not None else None,
                            seed=src.source_id + str(h))
            sub = (lambda f, m, n=n: progress("render", (n + f) / len(hook_indices), m)) if progress else None
            path = render(job, sub, self._cancelled)
            rep = run_qc(str(path), self.settings.edit, tl.duration, plan.captions, plan.target_seconds, tl)
            try:
                from .story_eval import evaluate_plan

                self.story_quality = evaluate_plan(plan, self.project.candidates, self.transcript, self.timeline, tl)
            except Exception:  # noqa: BLE001  (informational only)
                self.story_quality = None
            _write_sidecar(path, plan, src, rep, self.used)
            self.log(f"Exported {path.name}: QC {'passed' if rep.passed else 'FAILED'}")
            results.append((path, rep))
            shutil.rmtree(job.workdir, ignore_errors=True)
        if plan.chosen_hook != original_hook:
            self.choose_hook(original_hook)
            self.edit_timeline = None
        self.project.last_export = str(results[-1][0]) if results else ""
        self.project.save()
        return results


def _safe_name(s: str) -> str:
    import re as _re

    s = _re.sub(r"[^\w\- ]+", "", s).strip().replace(" ", "_")
    return (s or "short")[:60]


def _write_sidecar(path: Path, plan: Plan, src: VideoSource, rep, used: dict) -> None:
    """Upload helper text: title, description with source credit, rights record, QC result."""
    r = src.rights
    lines = [f"TITLE: {plan.title}", "", "DESCRIPTION:", plan.description, "",
             f"Footage: {src.uploader or r.creator or 'source creator'}" + (f" - {src.url}" if src.url else ""),
             "", "---- for your records (not for upload) ----",
             f"Rights basis: {r.basis} | creator: {r.creator} | commercial use: {r.commercial_use} | "
             f"publisher policy checked: {r.game_publisher_ok} | monetized: {plan.monetized}",
             f"Notes: {r.notes}", f"Engines used: {used}", "", "QC:", rep.summary()]
    path.with_suffix(".txt").write_text("\n".join(lines), encoding="utf-8")
