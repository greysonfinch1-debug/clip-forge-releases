"""Measurable quality checks for a finished edit plan (before or after rendering).

Used by the test runner and shown in the export report. Each metric maps to a question a
human editor asks about a Short:

  opening_on_action      do the first 3 seconds show the topic (or a flash-forward of the peak)?
  strongest_first_or_last is the most entertaining clip used as the hook or the payoff?
  payoff_last            does the Short end on its strongest/peak moment, not a weak one?
  key_moments_kept       does every clip keep its key moment with setup before and reaction after?
  filler_share           how much of the Short shows footage that isn't about the topic?
  pacing                 clip lengths (none too short to follow, none dragging), narration share
  fabricated_quotes      narration quoting words never said (must be 0)
  narration_over_dialogue streamer words covered by the voice-over (must be 0)
"""
from __future__ import annotations

import re

import numpy as np

QUOTE = re.compile(r"[\"“]([^\"”]{3,})[\"”]")


def evaluate_plan(plan, candidates, transcript, topic_timeline, edit_timeline) -> dict:
    by_id = {c.cid: c for c in candidates}
    items = [(it, by_id.get(it.cid)) for it in plan.story]
    items = [(it, c) for it, c in items if c is not None]
    m: dict = {}
    if not items:
        return {"error": "empty story"}
    hop = 0.5
    rel = topic_timeline.relevance if topic_timeline is not None else None

    def rel_at(t0, t1):
        if rel is None:
            return 1.0
        a, b = int(t0 / hop), max(int(t0 / hop) + 1, int(t1 / hop))
        seg = rel[a:b]
        return float(seg.mean()) if len(seg) else 0.0

    # ---- opening: what is on screen in the first 3 s of the output
    tl = edit_timeline
    first = [s for s in tl.segments if s.out_start < 3.0]
    open_rel = []
    for s in first:
        span = min(3.0, s.out_end) - max(0.0, s.out_start)
        src0 = s.source_start + max(0.0, -s.out_start) if s.kind != "hold" else s.source_start
        open_rel.append((rel_at(src0, src0 + max(0.5, span)), span))
    w = sum(sp for _, sp in open_rel) or 1.0
    m["opening_relevance"] = round(sum(r * sp for r, sp in open_rel) / w, 2)
    m["opening_is_flash_forward"] = bool(first and first[0].kind == "broll" and first[0].item_index != 0)
    m["opening_on_action"] = m["opening_relevance"] >= 0.35 or m["opening_is_flash_forward"]
    # ---- strongest moment placement
    ent = [c.entertainment for _, c in items]
    best = int(np.argmax(ent))
    m["strongest_first_or_last"] = best in (0, len(items) - 1)
    m["payoff_last"] = len(items) == 1 or ent[-1] >= np.median(ent)
    # ---- key moments kept with setup + reaction
    kept = []
    for it, c in items:
        bm = c.best_moment if c.best_moment >= 0 else (c.start + c.end) / 2
        kept.append(it.start <= bm - 1.5 and it.end >= bm + 1.5)
    m["key_moments_kept"] = f"{sum(kept)}/{len(kept)}"
    m["key_moments_ok"] = all(kept)
    # ---- filler: output seconds of clip footage whose source isn't on topic
    clip_secs = [(s.source_start, s.source_start + (s.src_out - s.src_in)) for s in tl.segments if s.kind == "clip"]
    total = sum(b - a for a, b in clip_secs) or 1.0
    if rel is not None:
        off = 0.0
        for a, b in clip_secs:
            seg = rel[int(a / hop):int(b / hop)]
            # a second counts as filler only if nothing on-topic happens within 4 s of it
            if len(seg):
                near = np.convolve((seg >= 0.25).astype(float), np.ones(17), mode="same") > 0
                off += float((~near).sum()) * hop
        m["filler_share"] = round(off / total, 2)
    else:
        m["filler_share"] = None
    # ---- pacing
    lens = [it.end - it.start for it, _ in items]
    narr = sum(p.line.duration for p in tl.narration)
    holds = sum(s.out_end - s.out_start for s in tl.segments if s.kind == "hold")
    m["clip_lengths"] = [round(x, 1) for x in lens]
    m["narration_share"] = round(narr / max(1.0, tl.duration), 2)
    m["freeze_share"] = round(holds / max(1.0, tl.duration), 2)
    m["pacing_ok"] = all(4.0 <= x <= 30.0 for x in lens) and m["narration_share"] <= 0.3 and m["freeze_share"] <= 0.12
    # ---- honesty
    said = " ".join(s.text for s in transcript.sentences).lower()
    norm = lambda x: re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", x.lower())).strip()
    fab = [q for ln in plan.narration for q in QUOTE.findall(ln.text) if norm(q) not in norm(said)]
    m["fabricated_quotes"] = len(fab)
    spans = [(p.out_start, p.out_start + p.line.duration) for p in tl.narration]
    m["narration_over_dialogue"] = sum(1 for wd, _ in tl.dialogue_words
                                       if any(a + 0.05 < (wd.start + wd.end) / 2 < b - 0.05 for a, b in spans))
    m["passed"] = bool(m["opening_on_action"] and m["key_moments_ok"] and m["pacing_ok"] and m["fabricated_quotes"] == 0
                       and m["narration_over_dialogue"] == 0 and (m["filler_share"] is None or m["filler_share"] <= 0.2)
                       and m["payoff_last"])
    return m
