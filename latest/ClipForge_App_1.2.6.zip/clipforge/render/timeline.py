"""Output timeline: where every clip, narration line, caption and overlay lands.

Narration is placed where the original audio has no speech, so it never talks over what
the streamer says. If a clip starts with dialogue immediately and the line doesn't fit,
a short "hold" (the clip's first frame with a slow push-in) is inserted for the line,
which is how human editors add context without cutting the moment.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..core.models import NarrationLine, StoryItem, Transcript, Word


@dataclass
class Segment:
    kind: str                  # "clip", "broll" (moving lead-in/teaser footage under narration) or "hold"
    item_index: int
    src_file: str
    src_in: float              # seconds inside src_file
    src_out: float
    source_start: float        # absolute source-timeline time of src_in (for transcript lookups)
    out_start: float = 0.0
    out_end: float = 0.0
    unit: int = 0              # segments of the same unit are joined with hard cuts; units get transitions

    @property
    def duration(self) -> float:
        return self.src_out if self.kind == "hold" else self.src_out - self.src_in


@dataclass
class Placement:
    line: NarrationLine
    out_start: float


@dataclass
class Timeline:
    segments: list[Segment] = field(default_factory=list)
    narration: list[Placement] = field(default_factory=list)
    transition: float = 0.0
    duration: float = 0.0
    dialogue_words: list[tuple[Word, int]] = field(default_factory=list)  # (word on output time, item index)
    narration_words: list[Word] = field(default_factory=list)
    item_spans: list[tuple[float, float]] = field(default_factory=list)   # output span of each story item's clip


def first_speech_offset(transcript: Transcript, start: float, end: float) -> float:
    ws = transcript.words_between(start, end)
    return (ws[0].start - start) if ws else (end - start)


def build_timeline(story: list[StoryItem], sections: dict[int, tuple[str, float]], narration: list[NarrationLine],
                   transcript: Transcript, transition: float = 0.18, best_moments: dict[int, float] | None = None,
                   teaser: bool = True) -> Timeline:
    """``sections[i] = (file, file_offset)`` where file_offset is the source time at file t=0.

    When a narration line needs more quiet time than the clip offers, the extra time is filled,
    in order of preference, with:
      1. (first clip only) a muted-ish flash-forward of the strongest moment - a classic Shorts hook;
      2. the few seconds of footage just before the clip, if nobody is talking there;
      3. a freeze frame with a slow push-in.
    """
    best_moments = best_moments or {}
    tl = Timeline(transition=transition)
    t = 0.0
    lines_before: dict[int, list[NarrationLine]] = {}
    lines_after: list[NarrationLine] = []
    for ln in narration:
        if ln.position == "after":
            lines_after.append(ln)
        else:
            lines_before.setdefault(ln.item_index, []).append(ln)
    for i, it in enumerate(story):
        f, f0 = sections[i]
        clip_in, clip_out = it.start - f0, it.end - f0
        lines = lines_before.get(i, [])
        need = sum(l.duration for l in lines) + 0.15 * max(0, len(lines) - 1)
        quiet = first_speech_offset(transcript, it.start, it.end) - 0.15
        if i > 0 and transition:
            t -= transition  # units overlap by the transition length
        unit_start = t
        if lines and need > max(0.0, quiet):
            hold = round(need - max(0.0, quiet) + 0.25, 2)
            seg = None
            if i == 0 and teaser and best_moments:
                # flash-forward: the peak of the most exciting later clip (falls back to this clip)
                j = max(best_moments, key=lambda k: (k != 0, k))  # prefer the payoff (last) item
                bm = best_moments[j]
                fj, fj0 = sections[j]
                a = max(story[j].start, min(bm - hold * 0.5, story[j].end - hold))
                if story[j].end - a >= hold - 0.05:
                    seg = Segment("broll", j, fj, a - fj0, a - fj0 + hold, a, t, t + hold, unit=i)
            if seg is None:
                lead = transcript.words_between(it.start - hold, it.start - 0.05)
                if clip_in - hold >= 0 and len(lead) <= 1:
                    seg = Segment("broll", i, f, clip_in - hold, clip_in, it.start - hold, t, t + hold, unit=i)
            if seg is None:
                seg = Segment("hold", i, f, clip_in, hold, it.start, t, t + hold, unit=i)
            tl.segments.append(seg)
            t += hold
        seg = Segment("clip", i, f, clip_in, clip_out, it.start, t, t + (clip_out - clip_in), unit=i)
        tl.segments.append(seg)
        tl.item_spans.append((seg.out_start, seg.out_end))
        # narration starts at the unit start (after the incoming transition)
        nt = unit_start + (transition if i > 0 and transition else 0.0)
        for ln in lines:
            tl.narration.append(Placement(ln, nt))
            ln.t_start = nt
            nt += ln.duration + 0.15
        # original dialogue words on the output timeline
        for w in transcript.words_between(it.start, it.end):
            ws, we = seg.out_start + (w.start - it.start), seg.out_start + (w.end - it.start)
            if ws >= seg.out_start - 0.05 and we <= seg.out_end + 0.3:
                tl.dialogue_words.append((Word(w.text, ws, min(we, seg.out_end), speaker=w.speaker), i))
        t = seg.out_end
    if lines_after and tl.segments:
        last = tl.segments[-1]
        need = sum(l.duration for l in lines_after) + 0.3
        seg = Segment("hold", last.item_index, last.src_file, max(last.src_in, last.src_out - 0.04), need,
                      last.source_start, t, t + need, unit=last.unit)
        tl.segments.append(seg)
        nt = t + 0.1
        for ln in lines_after:
            tl.narration.append(Placement(ln, nt))
            ln.t_start = nt
            nt += ln.duration + 0.15
        t += need
    tl.duration = t
    return tl
