"""Audio for the final mix: generated sound effects and the mix filtergraph.

Mix = original audio (lowered smoothly only while narration plays) + narration
+ optional licensed music (lower still, and ducked under narration) + sparing SFX,
then two-pass EBU R128 loudness normalisation to -14 LUFS (YouTube's reference).
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import numpy as np

from ..core import ffmpeg as ff

SR = 48000


def make_sfx(dirpath: Path) -> dict[str, str]:
    """Programmatically generated SFX (no third-party samples, so no licensing questions)."""
    import soundfile as sf

    dirpath.mkdir(parents=True, exist_ok=True)
    out = {}
    rng = np.random.default_rng(7)
    p = dirpath / "whoosh.wav"
    if not p.exists():
        n = int(0.42 * SR)
        t = np.arange(n) / SR
        noise = rng.standard_normal(n)
        # band-pass sweep: moving one-pole low-pass over noise
        fc = 300 + 5200 * np.sin(np.pi * t / t[-1]) ** 2
        y = np.zeros(n)
        acc = 0.0
        for i in range(n):
            a = 1 - np.exp(-2 * np.pi * fc[i] / SR)
            acc += a * (noise[i] - acc)
            y[i] = acc
        y -= np.convolve(y, np.ones(64) / 64, mode="same")
        env = np.sin(np.pi * t / t[-1]) ** 1.6
        y = y * env
        y = y / (np.abs(y).max() + 1e-9) * 0.5
        sf.write(p, np.stack([y, y], 1).astype(np.float32), SR)
    out["whoosh"] = str(p)
    p = dirpath / "pop.wav"
    if not p.exists():
        n = int(0.16 * SR)
        t = np.arange(n) / SR
        f = 900 * np.exp(-t * 18) + 220
        y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 28)
        y = y / np.abs(y).max() * 0.45
        sf.write(p, np.stack([y, y], 1).astype(np.float32), SR)
    out["pop"] = str(p)
    return out


def duck_expr(spans: list[tuple[float, float]], depth_db: float, ramp: float = 0.18) -> str:
    """volume expression: 1 outside narration, depth inside, with smooth linear ramps."""
    if not spans:
        return "1"
    g = 10 ** (depth_db / 20)
    terms = []
    for a, b in spans:
        # r = 1 inside [a,b], ramps to 0 over `ramp` seconds on either side
        r = f"clip(min((t-{a - ramp:.3f})/{ramp:.3f},({b + ramp:.3f}-t)/{ramp:.3f}),0,1)"
        terms.append(f"(1-{1 - g:.4f}*{r})")
    return "*".join(terms)


def build_mix_graph(n_narr: int, narr_delays: list[float], duck_spans: list[tuple[float, float]],
                    duration: float, orig_db: float, duck_db: float, music_idx: int | None, music_db: float,
                    sfx: list[tuple[int, float, float]], first_extra_idx: int) -> str:
    """Inputs: 0 = joined video (with original audio); 1..n_narr = narration wavs;
    music_idx = music input index or None; sfx = [(input index, time, gain_db)].
    Produces [amix] (not yet loudness normalised)."""
    parts = []
    dexp = duck_expr(duck_spans, duck_db)
    parts.append(f"[0:a]aresample={SR},aformat=channel_layouts=stereo,volume={orig_db}dB,"
                 f"volume='{dexp}':eval=frame[orig]")
    labels = ["[orig]"]
    for k in range(n_narr):
        ms = int(round(narr_delays[k] * 1000))
        parts.append(f"[{k + 1}:a]aresample={SR},aformat=channel_layouts=stereo,adelay={ms}|{ms}[n{k}]")
        labels.append(f"[n{k}]")
    if music_idx is not None:
        mexp = duck_expr(duck_spans, -8.0, 0.3)
        parts.append(f"[{music_idx}:a]aresample={SR},aformat=channel_layouts=stereo,atrim=0:{duration:.3f},"
                     f"volume={music_db}dB,volume='{mexp}':eval=frame,afade=t=in:d=0.6,"
                     f"afade=t=out:st={max(0.0, duration - 1.5):.3f}:d=1.5[mus]")
        labels.append("[mus]")
    for j, (idx, t, gdb) in enumerate(sfx):
        ms = int(round(max(0.0, t) * 1000))
        parts.append(f"[{idx}:a]aresample={SR},aformat=channel_layouts=stereo,volume={gdb}dB,adelay={ms}|{ms}[s{j}]")
        labels.append(f"[s{j}]")
    parts.append(f"{''.join(labels)}amix=inputs={len(labels)}:normalize=0:duration=first:dropout_transition=0,"
                 f"atrim=0:{duration:.3f}[amix]")
    return ";".join(parts)


def measure_loudness(args_inputs: list[str], graph: str) -> dict:
    """First loudnorm pass (audio only, fast). Returns the measured values."""
    cmd = [ff.ffmpeg_bin(), "-hide_banner", "-nostdin", "-y"] + args_inputs + [
        "-filter_complex", graph + ";[amix]loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json[out]",
        "-map", "[out]", "-f", "null", "-"]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=ff._NO_WINDOW)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if r.returncode != 0 or not m:
        return {}
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return {}


def loudnorm_filter(meas: dict) -> str:
    if meas and all(k in meas for k in ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")):
        try:
            if float(meas["input_i"]) > -70:
                return (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={meas['input_i']}:measured_TP={meas['input_tp']}:"
                        f"measured_LRA={meas['input_lra']}:measured_thresh={meas['input_thresh']}:"
                        f"offset={meas['target_offset']}:linear=true")
        except ValueError:
            pass
    return "loudnorm=I=-14:TP=-1.5:LRA=11"
