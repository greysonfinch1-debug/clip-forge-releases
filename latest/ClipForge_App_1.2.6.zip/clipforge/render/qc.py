"""Automatic quality control of an exported Short. Every check is measured on the file."""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field

from ..config import EditSettings
from ..core import ffmpeg as ff
from ..core.models import CaptionChunk


@dataclass
class Check:
    name: str
    ok: bool
    detail: str
    severity: str = "error"   # error / warning


@dataclass
class QCReport:
    checks: list[Check] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(c.ok for c in self.checks if c.severity == "error")

    def summary(self) -> str:
        return "\n".join(f"{'PASS' if c.ok else ('FAIL' if c.severity == 'error' else 'WARN')}  {c.name}: {c.detail}"
                         for c in self.checks)


def _ffmpeg_stderr(args: list[str]) -> str:
    r = subprocess.run([ff.ffmpeg_bin(), "-hide_banner", "-nostdin"] + args, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", creationflags=ff._NO_WINDOW)
    return r.stderr


def run_qc(path: str, es: EditSettings, expected_duration: float, chunks: list[CaptionChunk] | None = None,
           target_seconds: float = 0.0, timeline=None) -> QCReport:
    rep = QCReport()
    add = rep.checks.append
    try:
        d = ff.probe(path)
    except Exception as e:  # noqa: BLE001  (unreadable file = corrupted export)
        add(Check("File readable", False, f"cannot be opened: {e}"[:200]))
        return rep
    # decode every frame and audio sample: catches truncated / corrupted exports
    err = _ffmpeg_stderr(["-v", "error", "-i", path, "-f", "null", "-"])
    errs = [l for l in err.splitlines() if l.strip()]
    add(Check("File decodes cleanly", not errs, f"{len(errs)} decode error(s): {errs[0][:120]}" if errs else
              "every frame and sample decoded"))
    v = next((s for s in d["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in d["streams"] if s.get("codec_type") == "audio"), None)
    dur = float(d["format"].get("duration") or 0)
    if v is None:
        add(Check("Video stream", False, "missing"))
        return rep
    add(Check("Resolution", (v["width"], v["height"]) == (es.width, es.height), f"{v['width']}x{v['height']}"))
    add(Check("Codec", v.get("codec_name") == "h264" and v.get("pix_fmt") == "yuv420p",
              f"{v.get('codec_name')} {v.get('profile', '')} {v.get('pix_fmt')}"))
    num, den = (v.get("avg_frame_rate") or "0/1").split("/")
    fps = float(num) / float(den) if float(den) else 0
    add(Check("Frame rate", abs(fps - es.fps) < 0.5, f"{fps:.2f} fps"))
    add(Check("Duration matches edit", abs(dur - expected_duration) < 0.6,
              f"{dur:.2f}s (planned {expected_duration:.2f}s)"))
    if target_seconds:
        add(Check("Target length", abs(dur - target_seconds) <= max(6.0, 0.2 * target_seconds),
                  f"{dur:.1f}s for a {target_seconds:.0f}s target", "warning"))
    add(Check("Shorts length limit", dur <= 180.0, f"{dur:.1f}s (Shorts max 3 min)"))
    add(Check("Audio stream", a is not None and a.get("codec_name") == "aac" and int(a.get("channels", 0)) == 2,
              f"{a.get('codec_name')} {a.get('channels')}ch {a.get('sample_rate')}Hz" if a else "missing"))
    if a is not None:
        vd = float(v.get("duration") or dur)
        ad = float(a.get("duration") or dur)
        vs, as_ = float(v.get("start_time") or 0), float(a.get("start_time") or 0)
        add(Check("Audio/video aligned", abs(vd - ad) < 0.1 and abs(vs - as_) < 0.05,
                  f"video {vd:.3f}s from {vs:.3f}, audio {ad:.3f}s from {as_:.3f}"))
    if a is not None:
        err = _ffmpeg_stderr(["-i", path, "-map", "0:a", "-filter:a", "ebur128=peak=true", "-f", "null", "-"])
        mi = re.findall(r"I:\s+(-?[\d.]+) LUFS", err)
        tp = re.findall(r"Peak:\s+(-?[\d.]+|-inf) dBFS", err)
        if mi:
            li = float(mi[-1])
            add(Check("Loudness", -16.0 <= li <= -12.0, f"{li:.1f} LUFS (target -14)"))
        if tp:
            p = float(tp[-1]) if tp[-1] != "-inf" else -99
            add(Check("True peak", p <= -0.5, f"{p:.1f} dBTP"))
        err = _ffmpeg_stderr(["-i", path, "-map", "0:a", "-af", "volumedetect", "-f", "null", "-"])
        mv = re.findall(r"mean_volume: (-?[\d.]+|-inf) dB", err)
        mean_db = float(mv[-1]) if mv and mv[-1] != "-inf" else -99.0
        add(Check("Audio is not silent", mean_db > -45, f"mean volume {mean_db:.1f} dB"))
        err = _ffmpeg_stderr(["-i", path, "-map", "0:a", "-af", "silencedetect=n=-45dB:d=1.5", "-f", "null", "-"])
        sil = re.findall(r"silence_duration: ([\d.]+)", err)
        add(Check("No dead air", not sil, f"{len(sil)} silent gap(s) over 1.5 s" if sil else "none", "warning"))
    err = _ffmpeg_stderr(["-i", path, "-map", "0:v", "-vf", "blackdetect=d=0.4:pix_th=0.08", "-an", "-f", "null", "-"])
    blk = re.findall(r"black_duration:([\d.]+)", err)
    add(Check("No black frames", not blk, f"{len(blk)} black section(s)" if blk else "none"))
    # frozen picture longer than any planned freeze-frame = a stuck/duplicated video stream
    err = _ffmpeg_stderr(["-i", path, "-map", "0:v", "-vf", "freezedetect=n=0.002:d=2", "-an", "-f", "null", "-"])
    frz = [float(x) for x in re.findall(r"freeze_duration: ([\d.]+)", err)]
    planned = max([s.out_end - s.out_start for s in timeline.segments if s.kind == "hold"], default=0.0) \
        if timeline is not None else 0.0
    long_frz = [f for f in frz if f > planned + 1.0]
    add(Check("No stuck video", not long_frz, f"{len(long_frz)} frozen section(s) longer than planned "
              f"({max(long_frz):.1f}s)" if long_frz else "none beyond planned freeze-frames", "warning"))
    if chunks is not None:
        ordered = sorted((c for c in chunks if c.words), key=lambda c: c.start)
        overlaps = sum(1 for x, y in zip(ordered, ordered[1:]) if y.start < x.end - 0.01)
        add(Check("Captions don't overlap", overlaps == 0, f"{overlaps} overlap(s) in {len(ordered)} caption groups"))
        long = [c for c in ordered if len(c.text) > 26]
        add(Check("Caption line length", not long, f"{len(long)} group(s) longer than 26 characters", "warning"))
        late = [c for c in ordered if c.end > dur + 0.3]
        add(Check("Captions inside video", not late, f"{len(late)} after the end" if late else "all inside"))
        short = [c for c in ordered if c.end - c.start < 0.25]
        add(Check("Captions readable long enough", len(short) <= max(1, len(ordered) // 20),
                  f"{len(short)} group(s) shown < 0.25 s", "warning"))
        fast = [c for c in ordered if len(c.text) / max(0.05, c.end - c.start) > 30]
        add(Check("Caption reading speed", len(fast) <= max(1, len(ordered) // 20),
                  f"{len(fast)} group(s) faster than 30 characters/s", "warning"))
        if timeline is not None:
            # every caption word must be on screen while it is spoken (timing within 0.15 s)
            spoken = [(w.start, w.end) for w, _ in timeline.dialogue_words]
            dlg = [w for c in ordered if c.kind != "narration" for w in c.words if not c.edited]
            off = sum(1 for w in dlg if not any(abs(w.start - a) < 0.15 for a, _ in spoken))
            add(Check("Caption timing matches speech", off <= max(1, len(dlg) // 50),
                      f"{off}/{len(dlg)} dialogue words off by more than 0.15 s"))
    if timeline is not None:
        # narration must never play over the streamer's words
        spans = [(p.out_start, p.out_start + p.line.duration) for p in timeline.narration]
        clash = [w.text for w, _ in timeline.dialogue_words
                 if any(a + 0.05 < (w.start + w.end) / 2 < b - 0.05 for a, b in spans)]
        add(Check("Narration never covers dialogue", not clash,
                  f"{len(clash)} spoken word(s) under narration: {' '.join(clash[:6])}" if clash else "no overlap"))
    return rep
