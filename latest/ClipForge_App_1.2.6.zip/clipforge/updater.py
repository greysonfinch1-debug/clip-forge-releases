"""Built-in updates from GitHub Releases (no server of your own).

A release contains:
  clipforge-update.json        manifest: version, notes, packages with SHA-256 + size
  clipforge-update.json.sig    Ed25519 signature of the manifest (the public key is built in)
  ClipForge_App_<ver>.zip      the program files only (small; used when the runtime is unchanged)
  ClipForge_Setup_<ver>.exe    the full installer (used when Python/Qt/FFmpeg changed)

Update flow (one click):
  1. check()   – fetch the latest release, verify the manifest's signature, compare versions
  2. prepare() – download the package (resumable), verify SHA-256, then
                  * app package: unpack into a NEW folder app/<version> next to the running one,
                    verify every file, back up settings/projects, mark it "pending"
                  * full installer: kept ready to run silently
  3. finish()  – restart: the launcher switches to the new version; if it fails to start, it
                  automatically rolls back to the previous version (see installer/boot)
User data (settings, projects, models, cache) lives outside the install folder and is never
touched by an update.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from . import __version__
from .config import app_dir, data_dir

Progress = Optional[Callable[[float, str], None]]
MANIFEST = "clipforge-update.json"
SIGNATURE = MANIFEST + ".sig"
# Ed25519 public key for release manifests (the private key stays with the developer).
PUBLIC_KEY_B64 = "JGTjKWK4LUc5PmOXrcs+lzcOoIDb70iHKE5/dsIKja0="
CONFIG_FILE = Path(__file__).resolve().parent / "update_config.json"


class UpdateError(RuntimeError):
    pass


def parse_version(v: str) -> tuple:
    parts = []
    for p in v.strip().lstrip("vV").split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(num) if num else 0)
    return tuple(parts + [0] * (3 - len(parts)))


SOURCE_FILE = "update_source.json"     # in the settings folder: the user's choice, kept across updates
REPO_RE = r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"


def update_config() -> dict:
    try:
        cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    try:   # set in About & Updates (or `clipforge-cli update --repo owner/name`)
        user = json.loads((app_dir() / SOURCE_FILE).read_text(encoding="utf-8"))
        if user.get("github_repo"):
            cfg["github_repo"] = user["github_repo"]
    except (OSError, ValueError, AttributeError):
        pass
    if os.environ.get("CLIPFORGE_UPDATE_URL"):       # testing / mirrors: a folder URL with the release files
        cfg["base_url"] = os.environ["CLIPFORGE_UPDATE_URL"].rstrip("/") + "/"
    return cfg


def set_github_repo(repo: str) -> None:
    """Where to look for releases (owner/name on GitHub). Only releases signed with ClipForge's key
    are ever installed, whatever the source."""
    import re

    repo = repo.strip().removeprefix("https://github.com/").strip("/")
    if repo and not re.match(REPO_RE, repo):
        raise UpdateError("Use the form owner/name, e.g. yourname/clipforge")
    p = app_dir() / SOURCE_FILE
    p.write_text(json.dumps({"github_repo": repo}), encoding="utf-8")
    try:
        (app_dir() / "update_state.json").unlink()      # check again right away
    except OSError:
        pass


def install_dir() -> Optional[Path]:
    d = os.environ.get("CLIPFORGE_INSTALL_DIR")
    return Path(d) if d else None


def runtime_version() -> str:
    d = install_dir()
    if d and (d / "runtime" / "RUNTIME_VERSION").exists():
        return (d / "runtime" / "RUNTIME_VERSION").read_text(encoding="utf-8").strip()
    return ""


@dataclass
class UpdateInfo:
    version: str
    notes: str
    manifest: dict
    needs_full_installer: bool

    @property
    def download_mb(self) -> float:
        pkg = self.manifest["installer"] if self.needs_full_installer else self.manifest["app_package"]
        return pkg.get("size", 0) / 2**20


def _http_get(url: str, timeout=20, stream=False, accept: str = "application/octet-stream"):
    import requests

    try:
        r = requests.get(url, timeout=timeout, stream=stream,
                         headers={"User-Agent": f"ClipForge/{__version__}", "Accept": accept})
    except requests.RequestException as e:
        raise UpdateError(f"Couldn't reach the update server (check your internet connection): {e}") from e
    if r.status_code != 200:
        raise UpdateError(f"HTTP {r.status_code} from {url}")
    return r


def bad_versions() -> list[str]:
    """Versions that failed to start on this PC and were rolled back (written by the launcher)."""
    try:
        return list(json.loads((app_dir() / "bad_versions.json").read_text(encoding="utf-8")))
    except (OSError, ValueError, TypeError):
        return []


def _release_files(cfg: dict) -> dict[str, str]:
    """name -> download URL of the latest stable release's files."""
    if cfg.get("base_url"):
        base = cfg["base_url"]
        return {n: base + n for n in (MANIFEST, SIGNATURE)} | {"__base__": base}
    repo = cfg.get("github_repo", "").strip()
    if not repo or "/" not in repo:
        raise UpdateError("No update source is set yet. In About & Updates, enter the GitHub repository "
                          "that ClipForge releases are published to (owner/name).")
    import requests

    # 1. the update channel: files in the repository's "updates" branch (published by ClipForge's build tools).
    # GitHub's file servers cache a branch's files for minutes and ignore cache-busting, so first ask the API for
    # the branch's latest commit and read the files at that exact commit (never stale).
    branch = cfg.get("channel_branch", "updates")
    ref = branch
    try:
        r = requests.get(f"https://api.github.com/repos/{repo}/commits/{branch}", timeout=15,
                         headers={"User-Agent": f"ClipForge/{__version__}", "Accept": "application/vnd.github.sha"})
        if r.status_code == 200 and len(r.text.strip()) == 40:
            ref = r.text.strip()
    except Exception:  # noqa: BLE001  (API unavailable or rate-limited: use the branch name)
        pass
    channel = f"https://raw.githubusercontent.com/{repo}/{ref}/latest/"
    try:
        r = requests.get(channel + MANIFEST, timeout=20, headers={"User-Agent": f"ClipForge/{__version__}"})
        if r.status_code == 200:
            return {n: channel + n for n in (MANIFEST, SIGNATURE)} | {"__base__": channel}
    except Exception:  # noqa: BLE001  (no channel: fall back to Releases)
        pass
    # 2. GitHub Releases (also used for full installers too big for the branch)
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    try:   # the API answers JSON only: asking for octet-stream here gets "HTTP 415"
        r = requests.get(url, timeout=20, headers={"User-Agent": f"ClipForge/{__version__}",
                                                   "Accept": "application/vnd.github+json",
                                                   "X-GitHub-Api-Version": "2022-11-28"})
    except requests.RequestException as e:
        raise UpdateError(f"Couldn't reach GitHub (check your internet connection): {e}") from e
    if r.status_code == 404:
        raise UpdateError(f"No ClipForge release has been published to {repo} yet (or the repository name is "
                          "wrong, or it is private).")
    if r.status_code == 403 and "rate limit" in r.text.lower():
        raise UpdateError("GitHub's limit for update checks was reached; it resets within an hour.")
    if r.status_code != 200:
        raise UpdateError(f"GitHub answered HTTP {r.status_code} for {repo}.")
    rel = r.json()
    return {a["name"]: a["browser_download_url"] for a in rel.get("assets", [])}


def verify_signature(data: bytes, sig_b64: str, public_key_b64: str = "") -> bool:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    key = public_key_b64 or PUBLIC_KEY_B64
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(key)).verify(base64.b64decode(sig_b64.strip()), data)
        return True
    except (InvalidSignature, ValueError):
        return False


def check(force: bool = False) -> Optional[UpdateInfo]:
    """Return info about a newer version, or None if up to date. Raises UpdateError on problems."""
    cfg = update_config()
    state_file = app_dir() / "update_state.json"
    try:
        state = json.loads(state_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    if not force and time.time() - state.get("last_check", 0) < 60 and not cfg.get("base_url"):
        cached = state.get("available")
        if cached and parse_version(cached["version"]) > parse_version(__version__) \
                and cached["version"] not in bad_versions():
            return UpdateInfo(cached["version"], cached["notes"], cached["manifest"], cached["full"])
        return None
    files = _release_files(cfg)
    if MANIFEST not in files or SIGNATURE not in files:
        raise UpdateError("The latest release has no signed update manifest.")
    data = _http_get(files[MANIFEST]).content
    sig = _http_get(files[SIGNATURE]).text
    # (release assets are downloaded as files: Accept application/octet-stream)
    if not verify_signature(data, sig):
        raise UpdateError("The update manifest's signature is invalid. The update was NOT installed.")
    man = json.loads(data.decode("utf-8"))
    for key in ("app_package", "installer"):
        pkg = man.get(key)
        if pkg and pkg.get("url"):          # explicit location (e.g. a big installer kept on a Release)
            continue
        if pkg and "__base__" in files:
            pkg["url"] = files["__base__"] + pkg["name"]
        elif pkg and pkg["name"] in files:
            pkg["url"] = files[pkg["name"]]
    info = None
    if parse_version(man["version"]) > parse_version(__version__) and man["version"] not in bad_versions():
        full = (man.get("runtime_version") != runtime_version()) or not man.get("app_package") \
            or install_dir() is None
        if full and not man.get("installer"):
            raise UpdateError(f"ClipForge {man['version']} is available but needs the full installer, which this "
                              "release doesn't include. Download ClipForge_Setup.exe from the releases page.")
        info = UpdateInfo(man["version"], man.get("notes", ""), man, full)
    state = {"last_check": time.time(),
             "available": ({"version": info.version, "notes": info.notes, "manifest": man,
                            "full": info.needs_full_installer} if info else None)}
    try:
        state_file.write_text(json.dumps(state), encoding="utf-8")
    except OSError:
        pass
    return info


def _download(pkg: dict, progress: Progress, cancel=None) -> Path:
    from .model_manager import ModelError, download_resumable

    dst = data_dir() / "updates" / pkg["name"]
    if dst.exists() and dst.stat().st_size == pkg["size"] and _sha256(dst) == pkg["sha256"]:
        return dst
    try:
        download_resumable(pkg["url"], dst, progress, "Downloading update", cancel, expected_size=pkg["size"])
    except ModelError as e:
        raise UpdateError(str(e)) from e
    if _sha256(dst) != pkg["sha256"]:
        dst.unlink(missing_ok=True)
        raise UpdateError("The downloaded update failed verification (corrupted or tampered). Nothing was "
                          "installed; try again.")
    return dst


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 22), b""):
            h.update(b)
    return h.hexdigest()


def _replace_retry(src: Path, dst: Path, seconds: int = 120) -> None:
    """Rename a freshly unpacked folder. Antivirus programs briefly lock new files while scanning
    them, which makes the rename fail on Windows; wait and retry instead of giving up."""
    t = time.time()
    while True:
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if time.time() - t > seconds:
                raise UpdateError("The update files are still locked (often by an antivirus scan). Nothing was "
                                  "changed; try again in a minute.")
            time.sleep(1)


def backup_user_config(tag: str) -> Path:
    """Copy settings and project files before an update (they are never modified by updates,
    but a backup makes any recovery trivial). Keeps the 5 most recent backups."""
    root = app_dir() / "backups"
    dst = root / f"{time.strftime('%Y%m%d-%H%M%S')}-before-{tag}"
    dst.mkdir(parents=True, exist_ok=True)
    src = app_dir()
    for name in ("settings.json", "update_state.json"):
        if (src / name).exists():
            shutil.copy2(src / name, dst / name)
    if (src / "projects").exists():
        shutil.copytree(src / "projects", dst / "projects", dirs_exist_ok=True)
    for old in sorted(root.iterdir())[:-5]:
        shutil.rmtree(old, ignore_errors=True)
    return dst


def _note_updated(info: UpdateInfo) -> None:
    """Tell the next start which version it was updated to (shown once, with the notes)."""
    p = app_dir() / "boot_notes.json"
    try:
        notes = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        notes = {}
    notes["updated"] = {"from": __version__, "to": info.version, "notes": info.notes[:3000]}
    try:
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(notes), encoding="utf-8")
        os.replace(tmp, p)
    except OSError:
        pass


def prepare(info: UpdateInfo, progress: Progress = None, cancel=None) -> dict:
    """Download + verify + stage. Returns {'mode': 'app'|'installer', ...} for finish()."""
    staged = _prepare(info, progress, cancel)
    _note_updated(info)
    return staged


def _prepare(info: UpdateInfo, progress: Progress = None, cancel=None) -> dict:
    if info.needs_full_installer:
        exe = _download(info.manifest["installer"], progress, cancel)
        backup_user_config(info.version)
        return {"mode": "installer", "path": str(exe), "version": info.version}
    inst = install_dir()
    zpath = _download(info.manifest["app_package"], progress, cancel)
    apps = inst / "app"
    stage = apps / f"{info.version}.staging"
    final = apps / info.version
    shutil.rmtree(stage, ignore_errors=True)
    try:
        with zipfile.ZipFile(zpath) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise UpdateError("Unsafe path in update package")
            z.extractall(stage)
        files = json.loads((stage / "FILES.json").read_text(encoding="utf-8"))
        for rel, digest in files.items():
            if _sha256(stage / rel) != digest:
                raise UpdateError(f"Update file failed verification: {rel}")
        if (stage / "VERSION").read_text(encoding="utf-8").strip() != info.version:
            raise UpdateError("Update package version mismatch")
        (stage / ".complete").write_text(info.version, encoding="utf-8")
        if final.exists():
            shutil.rmtree(final)
        _replace_retry(stage, final)
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    backup_user_config(info.version)
    tmp = apps / "pending.tmp"
    tmp.write_text(info.version, encoding="utf-8")
    os.replace(tmp, apps / "pending")
    return {"mode": "app", "version": info.version}


def finish(staged: dict) -> None:
    """Restart into the new version. The caller must quit the application right after."""
    inst = install_dir()
    launcher = os.environ.get("CLIPFORGE_LAUNCHER") or (str(inst / "ClipForge.exe") if inst else sys.executable)
    flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0   # DETACHED_PROCESS | NEW_PROCESS_GROUP
    if staged["mode"] == "installer":
        # NSIS needs /D= last and unquoted (even with spaces), so the command line is built by hand
        cmd = f'"{staged["path"]}" /S /UPDATE' + (f" /D={inst}" if inst else "")
        subprocess.Popen(cmd if sys.platform == "win32" else [staged["path"], "/S", "/UPDATE"] +
                         ([f"/D={inst}"] if inst else []), creationflags=flags, close_fds=True)
    else:
        subprocess.Popen([launcher, "--after-update"], creationflags=flags, close_fds=True)


def mark_started_ok() -> None:
    """Called by the GUI once the main window is up: the new version is confirmed good."""
    inst = install_dir()
    if not inst:
        return
    v = inst / "app" / "verify"
    try:
        v.unlink()
    except OSError:
        pass
