"""Per-source cache.

Each video source gets its own folder keyed by ``source_id``. Expensive results
(transcript, audio features, frame embeddings, judged candidates, narration audio) are
stored there, so re-analysing the same stream with a different topic only redoes the
cheap, topic-specific steps.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Optional

import numpy as np

from ..config import app_dir


def cache_root() -> Path:
    from ..config import data_dir

    legacy = app_dir() / "cache"   # older builds: keep using an existing cache
    p = legacy if legacy.exists() and any(legacy.iterdir()) else data_dir() / "cache"
    p.mkdir(parents=True, exist_ok=True)
    return p


def stable_id(*parts: str) -> str:
    h = hashlib.sha1("||".join(parts).encode("utf-8")).hexdigest()
    return h[:16]


def file_fingerprint(path: str) -> str:
    """Cheap, stable fingerprint for a local file (size + head/tail bytes)."""
    p = Path(path)
    size = p.stat().st_size
    h = hashlib.sha1(str(size).encode())
    with open(p, "rb") as f:
        h.update(f.read(1 << 20))
        if size > (2 << 20):
            f.seek(-(1 << 20), os.SEEK_END)
            h.update(f.read(1 << 20))
    return h.hexdigest()[:16]


class SourceCache:
    def __init__(self, source_id: str):
        self.source_id = source_id
        self.dir = cache_root() / source_id
        self.dir.mkdir(parents=True, exist_ok=True)

    def path(self, name: str) -> Path:
        return self.dir / name

    def has(self, name: str) -> bool:
        return self.path(name).exists()

    # JSON -----------------------------------------------------------------
    def save_json(self, name: str, data: Any) -> None:
        _atomic_write_text(self.path(name), json.dumps(data, ensure_ascii=False))

    def load_json(self, name: str) -> Optional[Any]:
        p = self.path(name)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return None

    # Arrays ---------------------------------------------------------------
    def save_npz(self, name: str, **arrays: np.ndarray) -> None:
        tmp = self.path(name + ".tmp.npz")
        np.savez_compressed(tmp, **arrays)
        os.replace(tmp, self.path(name))

    def load_npz(self, name: str) -> Optional[dict]:
        p = self.path(name)
        if not p.exists():
            return None
        try:
            with np.load(p, allow_pickle=False) as d:
                return {k: d[k] for k in d.files}
        except Exception:
            return None

    def subdir(self, name: str) -> Path:
        d = self.dir / name
        d.mkdir(parents=True, exist_ok=True)
        return d

    def clear(self) -> None:
        shutil.rmtree(self.dir, ignore_errors=True)
        self.dir.mkdir(parents=True, exist_ok=True)


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def cache_size_bytes() -> int:
    total = 0
    for root, _, files in os.walk(cache_root()):
        for fn in files:
            try:
                total += os.path.getsize(os.path.join(root, fn))
            except OSError:
                pass
    return total
