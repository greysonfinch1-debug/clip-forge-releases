"""Video ingestion: URLs (YouTube, Twitch, Kick and other yt-dlp-supported sites) and local files.

Efficiency strategy for long streams:
  1. Read metadata only (no download) to validate the link and get the duration.
  2. Download the audio track alone for transcription/audio analysis (small).
  3. Download a low-resolution video stream for visual analysis (small).
  4. After clips are chosen, download only those sections in full quality.

Access rules: public / unlisted media only. No cookies, logins, DRM circumvention or
private-video access are implemented. Platforms that refuse access produce a clear error.
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlparse

from . import ffmpeg as ff
from .cache import SourceCache, file_fingerprint, stable_id
from .models import VideoSource

ProgressFn = Optional[Callable[[float, str], None]]

SUPPORTED_FILE_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".flv", ".ts", ".mts"}

PLATFORM_PATTERNS = [
    ("youtube", re.compile(r"(^|\.)youtube\.com$|(^|\.)youtu\.be$")),
    ("twitch", re.compile(r"(^|\.)twitch\.tv$")),
    ("kick", re.compile(r"(^|\.)kick\.com$")),
]


class IngestError(RuntimeError):
    pass


def detect_platform(url: str) -> str:
    host = (urlparse(url).hostname or "").lower()
    for name, pat in PLATFORM_PATTERNS:
        if pat.search(host):
            return name
    return "other"


def validate_url(url: str) -> str:
    url = url.strip()
    if not url:
        raise IngestError("Paste a video link first.")
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    parsed = urlparse(url)
    if not parsed.hostname or "." not in parsed.hostname:
        raise IngestError("That doesn't look like a valid web address.")
    return url


def _ensure_ffmpeg_on_path() -> str:
    """yt-dlp decides whether it can download *part* of a video by looking for FFmpeg on PATH only
    (it ignores ffmpeg_location for that check), so put ClipForge's FFmpeg folder on PATH."""
    d = os.path.dirname(ff.ffmpeg_bin())
    parts = os.environ.get("PATH", "").split(os.pathsep)
    if d and os.path.normcase(d) not in {os.path.normcase(x) for x in parts}:
        os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
    return d


def _ydl_base_opts() -> dict:
    _ensure_ffmpeg_on_path()
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 30,
        "retries": 5,
        "fragment_retries": 10,
        "concurrent_fragment_downloads": 4,
        # deliberately no cookiefile / username / password: public media only
        "ffmpeg_location": os.path.dirname(ff.ffmpeg_bin()),
    }


TRANSIENT = ("timed out", "timeout", "connection reset", "connection aborted", "temporary failure",
             "remote end closed", "incompleteread", "incomplete read", "http error 500", "http error 502",
             "http error 503", "http error 504", "network is unreachable", "name resolution",
             "unable to download webpage", "downloaded file is empty", "did not get any data")


def is_transient(msg: str) -> bool:
    low = msg.lower()
    return any(k in low for k in TRANSIENT) and "403" not in low and "404" not in low


def _friendly_ydl_error(e: Exception) -> IngestError:
    msg = str(e)
    low = msg.lower()
    # order matters: specific causes before generic "sign in"
    if "drm" in low:
        return IngestError("This video is DRM-protected. ClipForge does not bypass DRM. Use a file you have rights to.")
    if ("confirm you" in low or "confirm that you" in low) and "bot" in low:
        return IngestError("The platform blocked the automated download (bot check). ClipForge does not use your "
                           "account to get around this. Download the video with the creator's permission and use "
                           "Upload File instead.")
    if "is live" in low or "live event" in low or "will begin in" in low or "premieres in" in low:
        return IngestError("This stream is still live or hasn't started. Process it once the recording (VOD) is "
                           "available.")
    if "age-restricted" in low or "confirm your age" in low or "inappropriate for some users" in low:
        return IngestError("This video is age-restricted and needs a signed-in account, which ClipForge does not use. "
                           "Use a file you have rights to instead.")
    if ("private" in low or "sign in" in low or "login" in low or "log in" in low or "members-only" in low
            or "subscriber" in low or "registered users" in low or "requires authentication" in low):
        return IngestError("This video is private, members-only or requires signing in. Only public videos can be "
                           "processed from a link; ask the creator for the file and use Upload File instead.")
    if ("not available from your location" in low or "available in your country" in low or "geo restrict" in low
            or "geo-restrict" in low):
        return IngestError("This video is blocked in your country. ClipForge does not bypass region locks.")
    if "unsupported url" in low:
        return IngestError("This website isn't supported for links. Download the video with the creator's "
                           "permission and use Upload File instead.")
    if "429" in low or "too many requests" in low:
        return IngestError("The platform is rate-limiting downloads right now. Wait a few minutes and try again.")
    if "removed" in low or "video unavailable" in low or "does not exist" in low or "404" in low:
        return IngestError("This video is unavailable (removed, deleted or the link is wrong).")
    if is_transient(msg):
        return IngestError("The connection kept failing while downloading (tried several times). Check your "
                           "internet connection and try again.")
    return IngestError("Couldn't access this video: " + msg.splitlines()[-1][:300])


def _with_retries(fn, cancel=None, attempts: int = 3, waits=(3.0, 8.0)):
    """Retry a whole download on network hiccups (yt-dlp already retries individual requests)."""
    import time

    last = None
    for i in range(attempts):
        try:
            return fn()
        except IngestError:
            raise
        except Exception as e:  # noqa: BLE001
            last = e
            if not is_transient(str(e)) or i == attempts - 1:
                raise
            wait = waits[min(i, len(waits) - 1)]
            t0 = time.time()
            while time.time() - t0 < wait:
                if cancel and cancel():
                    raise IngestError("Cancelled") from e
                time.sleep(0.2)
    raise last  # pragma: no cover


def fetch_url_info(url: str) -> dict:
    """Metadata only, no download."""
    try:
        import yt_dlp  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise IngestError("yt-dlp is not installed (run the installer again).") from e
    url = validate_url(url)
    opts = _ydl_base_opts() | {"skip_download": True}
    def get():
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)

    try:
        info = _with_retries(get)
    except IngestError:
        raise
    except Exception as e:
        raise _friendly_ydl_error(e) from e
    if info is None:
        raise IngestError("No video information was returned for this link.")
    if info.get("_type") == "playlist":
        raise IngestError("This is a playlist/channel link. Paste the link to a single video.")
    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        raise IngestError("This stream is live or hasn't started. Process it once the recording (VOD) is available.")
    if info.get("availability") in ("private", "premium_only", "subscriber_only", "needs_auth"):
        raise IngestError("This video isn't publicly accessible, so it can't be processed from a link.")
    return info


def _verify_media(path: Path, label: str) -> None:
    """Reject empty, truncated or non-media downloads with a clear message (instead of a
    confusing failure later in the analysis)."""
    try:
        info = ff.media_info(str(path))
    except Exception as e:  # noqa: BLE001
        try:
            path.unlink()
        except OSError:
            pass
        raise IngestError(f"{label}: the downloaded file is damaged or incomplete. Try again; if it keeps "
                          f"happening, use Upload File with a copy you have rights to.") from e
    if info["duration"] <= 0.5 or not (info["has_audio"] or info["has_video"]):
        try:
            path.unlink()
        except OSError:
            pass
        raise IngestError(f"{label}: the downloaded file is empty or incomplete. Try again.")


class Ingestor:
    def __init__(self, progress: ProgressFn = None, cancel=None, analysis_height: int = 360):
        self.progress = progress or (lambda f, m: None)
        self.cancel = cancel
        self.analysis_height = analysis_height

    # ------------------------------------------------------------------ files
    def from_file(self, path: str) -> VideoSource:
        p = Path(path)
        if not p.exists():
            raise IngestError(f"File not found: {path}")
        if p.suffix.lower() not in SUPPORTED_FILE_EXT:
            raise IngestError(f"Unsupported file type {p.suffix}. Use MP4, MOV, MKV, WEBM, AVI or M4V.")
        info = ff.media_info(str(p))
        if not info["has_video"]:
            raise IngestError("This file has no video track.")
        if info["duration"] <= 0.5:
            raise IngestError("This file is empty or too short.")
        sid = "f_" + file_fingerprint(str(p))
        src = VideoSource(source_id=sid, kind="file", path=str(p), platform="file", title=p.stem,
                          duration=info["duration"], width=info["width"], height=info["height"], fps=info["fps"])
        self._prepare_analysis_media(src, has_audio=info["has_audio"])
        return src

    # ------------------------------------------------------------------ URLs
    def from_url(self, url: str) -> VideoSource:
        url = validate_url(url)
        self.progress(0.02, "Reading video information")
        info = fetch_url_info(url)
        platform = detect_platform(url)
        vid = str(info.get("id") or url)
        sid = "u_" + stable_id(platform, info.get("extractor_key", ""), vid)
        src = VideoSource(source_id=sid, kind="url", url=info.get("webpage_url") or url, platform=platform,
                          title=info.get("title") or "", uploader=info.get("uploader") or info.get("channel") or "",
                          duration=float(info.get("duration") or 0.0), width=int(info.get("width") or 0),
                          height=int(info.get("height") or 0), fps=float(info.get("fps") or 0.0))
        cache = SourceCache(sid)
        cache.save_json("source_info.json", {"title": src.title, "uploader": src.uploader,
                                             "duration": src.duration, "url": src.url})
        audio_raw: Optional[Path] = None
        proxy_raw: Optional[Path] = None
        if not cache.has("analysis_audio.wav"):
            audio_raw = Path(self._ydl_download(src.url, "bestaudio/best", str(cache.path("audio_source.m4a")),
                                                0.05, 0.35, "Downloading audio"))
        if not cache.has("proxy.mp4"):
            fmt = (f"bv*[height<={self.analysis_height}]/wv*[height>={min(240, self.analysis_height)}]/"
                   f"bv*[height<=480]/worst")
            proxy_raw = Path(self._ydl_download(src.url, fmt, str(cache.path("proxy_source.mp4")),
                                                0.35, 0.65, "Downloading analysis video"))
        if proxy_raw is not None and not src.duration:
            src.duration = ff.media_info(str(proxy_raw))["duration"]
        self._prepare_analysis_media(src, has_audio=True, audio_input=str(audio_raw) if audio_raw else None,
                                     video_input=str(proxy_raw) if proxy_raw else None)
        for p in (audio_raw, proxy_raw):
            if p is not None and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass
        return src

    def _ydl_download(self, url: str, fmt: str, out: str, p0: float, p1: float, label: str,
                      download_ranges=None) -> str:
        import yt_dlp  # type: ignore

        def hook(d):
            if self.cancel and self.cancel():
                raise IngestError("Cancelled")
            if d.get("status") == "downloading":
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                done = d.get("downloaded_bytes") or 0
                frac = done / tot if tot else 0.0
                self.progress(p0 + (p1 - p0) * min(1.0, frac), label)

        base = os.path.splitext(out)[0]
        opts = _ydl_base_opts() | {
            "format": fmt,
            "outtmpl": base + ".%(ext)s",
            "progress_hooks": [hook],
            "overwrites": True,
        }
        if download_ranges is not None:
            opts["download_ranges"] = download_ranges
            opts["force_keyframes_at_cuts"] = True
        def get():
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                return ydl.prepare_filename(info)

        try:
            produced = _with_retries(get, self.cancel)
        except IngestError:
            raise
        except Exception as e:
            raise _friendly_ydl_error(e) from e
        produced_path = Path(produced)
        if not produced_path.exists():
            # extension may differ after merge
            matches = sorted(Path(base).parent.glob(Path(base).name + ".*"))
            matches = [m for m in matches if not m.name.endswith((".part", ".ytdl"))]
            if not matches:
                raise IngestError(f"{label}: download finished but no file was produced.")
            produced_path = matches[0]
        # keep the real container extension (webm/mkv/mp4); FFmpeg reads any of them
        final = Path(base + produced_path.suffix)
        if produced_path != final:
            shutil.move(str(produced_path), str(final))
        _verify_media(final, label)
        return str(final)

    def _prepare_analysis_media(self, src: VideoSource, has_audio: bool, audio_input: Optional[str] = None,
                                video_input: Optional[str] = None) -> None:
        cache = SourceCache(src.source_id)
        wav = cache.path("analysis_audio.wav")
        proxy = cache.path("proxy.mp4")
        a_in = audio_input or src.path
        v_in = video_input or src.path
        if not wav.exists():
            if has_audio and a_in:
                ff.extract_analysis_audio(a_in, str(wav), src.duration,
                                          lambda f, m: self.progress(0.65 + 0.15 * f, m), self.cancel)
            else:
                ff.run(["-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono", "-t", f"{src.duration:.3f}",
                        "-c:a", "pcm_s16le", str(wav)], label="Silent audio")
        if not proxy.exists():
            ff.make_proxy(v_in, str(proxy), src.duration, self.analysis_height, 2.0,
                          lambda f, m: self.progress(0.80 + 0.19 * f, m), self.cancel)
        src.audio_path = str(wav)
        src.proxy_path = str(proxy)
        if not src.width:
            pi = ff.media_info(str(proxy))
            src.width, src.height = pi["width"], pi["height"]
        self.progress(1.0, "Video ready for analysis")

    # ---------------------------------------------------------- final-quality sections
    def fetch_sections(self, src: VideoSource, ranges: list[tuple[float, float]], max_height: int = 1080
                       ) -> dict[tuple[float, float], str]:
        """Return local full-quality files for each (start, end) range on the source timeline."""
        cache = SourceCache(src.source_id)
        out_dir = cache.subdir("sections")
        result: dict[tuple[float, float], str] = {}
        for i, (a, b) in enumerate(ranges):
            stem = f"sec_{int(a * 1000):010d}_{int(b * 1000):010d}"
            existing = [p for p in out_dir.glob(stem + ".*") if p.suffix in (".mp4", ".mkv", ".webm")
                        and ".partial" not in p.name]
            dst = existing[0] if existing else out_dir / (stem + ".mp4")
            if not existing:
                if src.kind == "file":
                    tmp = ff._partial(str(dst))
                    ff.run(["-ss", f"{a:.3f}", "-i", src.path, "-t", f"{b - a:.3f}", "-map", "0:v:0", "-map", "0:a:0?",
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-c:a", "aac", "-b:a", "192k",
                            "-f", "mp4", tmp], label="Cutting clip")
                    os.replace(tmp, dst)
                else:
                    try:
                        from yt_dlp.utils import download_range_func  # type: ignore
                    except ImportError as e:
                        raise IngestError("yt-dlp is too old for section downloads; update it.") from e
                    fmt = f"bv*[height<={max_height}]+ba/b[height<={max_height}]/bv*+ba/b"
                    dst = Path(self._ydl_download(src.url, fmt, str(dst), i / len(ranges), (i + 1) / len(ranges),
                                                  f"Downloading clip {i + 1}/{len(ranges)}",
                                                  download_ranges=download_range_func(None, [(a, b)])))
            result[(a, b)] = str(dst)
            self.progress((i + 1) / max(1, len(ranges)), f"Clip {i + 1}/{len(ranges)} ready")
        return result
