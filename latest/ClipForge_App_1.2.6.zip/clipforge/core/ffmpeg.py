"""FFmpeg / FFprobe helpers.

All heavy media work goes through FFmpeg subprocesses, so multi-hour videos are streamed
from disk and never loaded into memory.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from ..config import PROJECT_ROOT

ProgressFn = Optional[Callable[[float, str], None]]  # (fraction 0..1, message)


class FFmpegError(RuntimeError):
    pass


_BIN_CACHE: dict[str, str] = {}


def _find(name: str) -> str:
    if name in _BIN_CACHE:
        return _BIN_CACHE[name]
    exe = name + (".exe" if sys.platform == "win32" else "")
    candidates = []
    if os.environ.get("CLIPFORGE_FFMPEG_DIR"):  # set by the installed app: its bundled FFmpeg
        candidates.append(Path(os.environ["CLIPFORGE_FFMPEG_DIR"]) / exe)
    candidates.append(PROJECT_ROOT / "bin" / exe)
    for c in candidates:
        if c.exists():
            _BIN_CACHE[name] = str(c)
            return str(c)
    found = shutil.which(name)
    if found:
        _BIN_CACHE[name] = found
        return found
    try:  # optional pip package that ships FFmpeg binaries
        import static_ffmpeg  # type: ignore

        static_ffmpeg.add_paths()
        found = shutil.which(name)
        if found:
            _BIN_CACHE[name] = found
            return found
    except Exception:
        pass
    raise FFmpegError(
        f"{name} was not found. Install FFmpeg (Windows: `winget install Gyan.FFmpeg`) "
        f"or place {exe} in the ClipForge 'bin' folder."
    )


def ffmpeg_bin() -> str:
    return _find("ffmpeg")


def ffprobe_bin() -> str:
    return _find("ffprobe")


_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0  # hide console windows on Windows


def run(args: list[str], progress: ProgressFn = None, total_seconds: float = 0.0,
        label: str = "", cancel: Optional[Callable[[], bool]] = None) -> None:
    """Run ffmpeg with progress parsing. ``args`` excludes the binary name."""
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-y", "-progress", "pipe:1", "-nostats"] + args
    if os.environ.get("CLIPFORGE_LOG_FFMPEG"):     # troubleshooting: record every FFmpeg command
        try:
            with open(os.environ["CLIPFORGE_LOG_FFMPEG"], "a", encoding="utf-8") as f:
                f.write(json.dumps(cmd) + "\n")
        except OSError:
            pass
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                            encoding="utf-8", errors="replace", creationflags=_NO_WINDOW)
    err_tail: list[str] = []

    import threading

    def _drain_err():
        assert proc.stderr is not None
        for line in proc.stderr:
            err_tail.append(line.rstrip())
            if len(err_tail) > 40:
                del err_tail[:-40]

    t = threading.Thread(target=_drain_err, daemon=True)
    t.start()
    assert proc.stdout is not None
    for line in proc.stdout:
        if cancel and cancel():
            proc.kill()
            raise FFmpegError("Cancelled")
        if progress and total_seconds > 0 and line.startswith("out_time_us="):
            try:
                us = int(line.split("=", 1)[1])
                progress(min(1.0, us / 1e6 / total_seconds), label)
            except ValueError:
                pass
    proc.wait()
    t.join(timeout=2)
    if proc.returncode != 0:
        raise FFmpegError(f"FFmpeg failed ({label}):\n" + "\n".join(err_tail[-15:]))


def probe(path: str) -> dict:
    cmd = [ffprobe_bin(), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=_NO_WINDOW)
    if r.returncode != 0:
        raise FFmpegError(f"Could not read media file: {path}\n{r.stderr.strip()[:400]}")
    return json.loads(r.stdout)


def media_info(path: str) -> dict:
    """Duration, resolution, fps and whether audio/video exist."""
    d = probe(path)
    info = {"duration": 0.0, "width": 0, "height": 0, "fps": 0.0, "has_audio": False, "has_video": False}
    try:
        info["duration"] = float(d.get("format", {}).get("duration") or 0.0)
    except ValueError:
        pass
    for s in d.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            if s.get("disposition", {}).get("attached_pic"):
                continue
            info["has_video"] = True
            info["width"] = int(s.get("width") or 0)
            info["height"] = int(s.get("height") or 0)
            rate = s.get("avg_frame_rate") or s.get("r_frame_rate") or "0/1"
            try:
                num, den = rate.split("/")
                info["fps"] = float(num) / float(den) if float(den) else 0.0
            except Exception:
                info["fps"] = 0.0
            if not info["duration"]:
                try:
                    info["duration"] = float(s.get("duration") or 0.0)
                except ValueError:
                    pass
        elif s.get("codec_type") == "audio":
            info["has_audio"] = True
    return info


def extract_analysis_audio(src: str, dst: str, duration: float, progress: ProgressFn = None,
                           cancel=None) -> None:
    """16 kHz mono 16-bit WAV for transcription and audio analysis."""
    tmp = _partial(dst)
    run(["-i", src, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", "-f", "wav", tmp],
        progress, duration, "Extracting audio", cancel)
    os.replace(tmp, dst)  # only a complete file ever appears under the final name


def make_proxy(src: str, dst: str, duration: float, height: int = 360, fps: float = 2.0,
               progress: ProgressFn = None, cancel=None) -> None:
    """Low-resolution, low-frame-rate, video-only copy used for visual analysis."""
    tmp = _partial(dst)
    run(["-i", src, "-an", "-vf", f"fps={fps},scale=-2:{height}", "-c:v", "libx264", "-preset", "ultrafast",
         "-crf", "30", "-g", str(int(fps * 10)), "-f", "mp4", tmp], progress, duration, "Building analysis copy", cancel)
    os.replace(tmp, dst)


def _partial(dst: str) -> str:
    """Temporary name for an output being written; a cancelled or killed job leaves only this
    behind, which is never mistaken for a finished file (and is overwritten next time)."""
    p = Path(dst)
    return str(p.with_name(p.stem + ".partial" + p.suffix))


def iter_wav_chunks(wav_path: str, chunk_seconds: float, overlap_seconds: float = 0.0
                    ) -> Iterator[tuple[float, np.ndarray]]:
    """Yield (start_time, float32 samples) chunks of a 16 kHz mono PCM WAV without loading it all."""
    import soundfile as sf

    with sf.SoundFile(wav_path) as f:
        sr = f.samplerate
        step = int(chunk_seconds * sr)
        ov = int(overlap_seconds * sr)
        pos = 0
        total = f.frames
        while pos < total:
            f.seek(max(0, pos - ov))
            start = max(0, pos - ov)
            data = f.read(step + (pos - start), dtype="float32", always_2d=False)
            if data.ndim > 1:
                data = data.mean(axis=1)
            yield start / sr, data
            pos += step


def read_wav_segment(wav_path: str, start: float, end: float) -> tuple[np.ndarray, int]:
    import soundfile as sf

    with sf.SoundFile(wav_path) as f:
        sr = f.samplerate
        f.seek(int(max(0, start) * sr))
        data = f.read(int(max(0.0, end - start) * sr), dtype="float32", always_2d=False)
    if data.ndim > 1:
        data = data.mean(axis=1)
    return data, sr


def extract_frames_at(src: str, times: list[float], out_dir: str, height: int = 480) -> list[str]:
    """Grab single frames at exact timestamps (fast seek per frame)."""
    os.makedirs(out_dir, exist_ok=True)
    out = []
    for i, t in enumerate(times):
        p = os.path.join(out_dir, f"kf_{int(t * 1000):010d}.jpg")
        if not os.path.exists(p):
            subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t:.3f}",
                            "-i", src, "-frames:v", "1", "-vf", f"scale=-2:{height}", "-q:v", "3", p],
                           capture_output=True, creationflags=_NO_WINDOW)
        if os.path.exists(p):
            out.append(p)
    return out


def iter_frames(src: str, every_seconds: float, height: int, cancel=None
                ) -> Iterator[tuple[float, np.ndarray]]:
    """Stream RGB frames sampled every N seconds as numpy arrays (no temp files)."""
    info = media_info(src)
    w0, h0 = info["width"], info["height"]
    if not w0 or not h0:
        return
    h = height
    w = int(round(w0 * h / h0 / 2)) * 2
    cmd = [ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-nostdin", "-i", src, "-an",
           "-vf", f"fps=1/{every_seconds},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    frame_bytes = w * h * 3
    idx = 0
    assert proc.stdout is not None
    try:
        while True:
            if cancel and cancel():
                break
            buf = proc.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                break
            arr = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 3)
            # fps filter emits the frame nearest to each tick; tick k is at (k + 0.5) * every
            yield (idx + 0.5) * every_seconds, arr
            idx += 1
    finally:
        proc.kill()
        proc.wait()


def has_filter(name: str) -> bool:
    r = subprocess.run([ffmpeg_bin(), "-hide_banner", "-filters"], capture_output=True, text=True,
                       creationflags=_NO_WINDOW)
    return re.search(rf"\s{re.escape(name)}\s", r.stdout) is not None


def ffmpeg_escape_path(p: str) -> str:
    """Escape a path for use inside an FFmpeg filter argument (e.g. subtitles=...)."""
    p = p.replace("\\", "/")
    p = p.replace(":", r"\:").replace("'", r"\'")
    return p
