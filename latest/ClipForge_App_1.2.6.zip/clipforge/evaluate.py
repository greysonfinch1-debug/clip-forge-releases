"""Measure ClipForge on YOUR real streams against your own judgement.

1. Watch (or skim) a stream and write down the moments that would make a good Short for a
   topic, in a CSV file (one line per moment):

       start,end,key,rating,note
       12:40,13:05,12:58,3,cops chase him onto the highway
       1:02:10,1:02:30,1:02:21,2,crashes into the ocean

   start/end = where the moment begins and ends, key = its single best instant,
   rating = 1 (ok) .. 3 (must have). Times as seconds, M:SS or H:MM:SS.

2. Run:
       .venv\\Scripts\\python -m clipforge.evaluate --file "D:\\streams\\ep12.mp4" \\
            --topic "police chases" --marks ep12_marks.csv [--seconds 45]

It analyses the video (or reuses the cache), then reports — and saves next to the CSV —
  precision@10        of the 10 best-ranked candidates, how many are moments you marked
  recall@10 / @20     of your marked moments, how many ClipForge found in its top 10 / 20
  must-have recall    the same for rating-3 moments only
  selected precision  of the clips put in the Short, how many you marked
  setup/payoff kept   selected clips that contain your key instant with ≥2 s before and after
  loudest-not-marked  of the 5 loudest moments of the stream, how many ClipForge (correctly)
                      left out because you didn't mark them
  duplicates          selected clips showing the same moment twice
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np


def parse_time(s: str) -> float:
    s = s.strip()
    if not s:
        return -1.0
    parts = [float(p) for p in s.split(":")]
    t = 0.0
    for p in parts:
        t = t * 60 + p
    return t


def load_marks(path: str) -> list[dict]:
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            row = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
            a, b = parse_time(row.get("start", "")), parse_time(row.get("end", ""))
            if a < 0 or b <= a:
                continue
            key = parse_time(row.get("key", "")) if row.get("key") else (a + b) / 2
            out.append({"start": a, "end": b, "key": key, "rating": int(row.get("rating") or 2),
                        "note": row.get("note", "")})
    return out


def _ov(a0, a1, b0, b1):
    return max(0.0, min(a1, b1) - max(a0, b0))


def hit(c0, c1, marks, need=0.5) -> dict | None:
    """The marked moment this clip covers (≥50% of the clip or of the moment overlaps)."""
    best = None
    for m in marks:
        ov = _ov(c0, c1, m["start"], m["end"])
        if ov >= need * min(c1 - c0, m["end"] - m["start"]):
            if best is None or ov > _ov(c0, c1, best["start"], best["end"]):
                best = m
    return best


def score(candidates, story, marks, audio=None) -> dict:
    ranked = sorted(candidates, key=lambda c: -c.final_score)
    r: dict = {}
    top10 = ranked[:10]
    r["precision@10"] = round(sum(hit(c.start, c.end, marks) is not None for c in top10) / max(1, len(top10)), 2)
    for k in (10, 20):
        found = {id(m) for c in ranked[:k] for m in [hit(c.start, c.end, marks)] if m is not None}
        r[f"recall@{k}"] = round(len(found) / max(1, len(marks)), 2)
    must = [m for m in marks if m["rating"] >= 3]
    found = {id(m) for c in ranked[:10] for m in [hit(c.start, c.end, must)] if m is not None}
    r["must_have_recall@10"] = round(len(found) / len(must), 2) if must else None
    sel = [(it.start, it.end) for it in story]
    hits = [hit(a, b, marks) for a, b in sel]
    r["selected_precision"] = round(sum(h is not None for h in hits) / max(1, len(sel)), 2)
    kept = [h is not None and a <= h["key"] - 2 and b >= h["key"] + 2 for (a, b), h in zip(sel, hits)]
    r["setup_payoff_kept"] = f"{sum(kept)}/{sum(h is not None for h in hits)}"
    r["duplicates"] = sum(1 for i in range(len(hits)) for j in range(i + 1, len(hits))
                          if hits[i] is not None and hits[i] is hits[j])
    if audio is not None and len(audio.times):
        loud = np.argsort(-audio.loud_z)
        picks, taken = [], []
        for i in loud:
            t = float(audio.times[i])
            if all(abs(t - x) > 30 for x in taken):
                taken.append(t)
                picks.append(t)
            if len(picks) == 5:
                break
        unmarked = [t for t in picks if not any(m["start"] - 2 <= t <= m["end"] + 2 for m in marks)]
        avoided = [t for t in unmarked if not any(a <= t <= b for a, b in sel)]
        r["loudest_not_marked_avoided"] = f"{len(avoided)}/{len(unmarked)}"
    return r


def main(argv=None) -> int:
    from .config import Settings
    from .pipeline import Pipeline

    ap = argparse.ArgumentParser(prog="clipforge.evaluate")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--file")
    src.add_argument("--url")
    ap.add_argument("--topic", required=True)
    ap.add_argument("--marks", required=True)
    ap.add_argument("--seconds", type=float, default=45)
    a = ap.parse_args(argv)
    marks = load_marks(a.marks)
    if not marks:
        print("No valid moments in the marks file.")
        return 2
    p = Pipeline(Settings.load())
    p.ingest(url=a.url or "", path=a.file or "")
    p.find_moments(a.topic, a.seconds)
    res = score(p.project.candidates, p.project.plan.story, marks, p.audio)
    res["engines"] = dict(p.used)
    res["marked_moments"] = len(marks)
    print(json.dumps(res, indent=1))
    out = Path(a.marks).with_suffix(".clipforge_eval.json")
    out.write_text(json.dumps(res, indent=1), encoding="utf-8")
    print(f"\nSaved: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
