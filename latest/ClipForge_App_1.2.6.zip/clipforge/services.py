"""Builds the configured AI providers from Settings, with explicit, reported fallbacks.

Nothing silently degrades: every fallback is recorded in ``status`` and shown in the app
(Analysis page and System Check), so you always know which components did the work.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from . import providers  # noqa: F401  (registers backends)
from .config import Settings
from .providers.base import (LLM, TTS, FrameCaptioner, ProviderUnavailable, TextEmbedder, Transcriber,
                             VisionEncoder, create)


@dataclass
class ComponentStatus:
    kind: str
    wanted: str
    active: str
    ok: bool
    message: str = ""


@dataclass
class Services:
    settings: Settings
    status: dict[str, ComponentStatus] = field(default_factory=dict)
    _transcriber: Optional[Transcriber] = None
    _embedder: Optional[TextEmbedder] = None
    _vision: Optional[VisionEncoder] = None
    _vision_loaded: bool = False
    _captioner: Optional[FrameCaptioner] = None
    _captioner_loaded: bool = False
    _llm: Optional[LLM] = None
    _tts: Optional[TTS] = None
    _tagger: object = None
    _tagger_loaded: bool = False
    _diarizer: object = None
    _diarizer_loaded: bool = False

    # Each getter is lazy: models load only when a stage needs them.
    def transcriber(self, progress=None) -> Transcriber:
        if self._transcriber is None:
            t = self.settings.transcription
            kw = dict(models_dir=self.settings.models_dir, threads=t.threads, progress=progress,
                      model=t.whisper_model, device=t.whisper_device, language=t.language, chunk_seconds=t.chunk_seconds)
            try:
                self._transcriber = create("transcriber", t.backend, **kw)
                self._set("transcriber", t.backend, t.backend, True)
            except ProviderUnavailable as e:
                alt = "parakeet" if t.backend != "parakeet" else "faster-whisper"
                try:
                    self._transcriber = create("transcriber", alt, **kw)
                    self._set("transcriber", t.backend, alt, True, f"{t.backend} unavailable ({e}); using {alt}")
                except ProviderUnavailable as e2:
                    self._set("transcriber", t.backend, "none", False, f"{e}; {e2}")
                    raise ProviderUnavailable(f"No speech-to-text engine available: {e}") from e2
        return self._transcriber

    def embedder(self) -> TextEmbedder:
        if self._embedder is None:
            e = self.settings.embedding
            llm = self.settings.llm
            kw = dict(model=e.model, base_url=llm.base_url if e.backend == "ollama" else llm.base_url,
                      api_key=llm.api_key)
            if e.backend == "openai":
                kw["model"] = e.model if e.model != "nomic-embed-text" else "text-embedding-3-small"
            try:
                self._embedder = create("embedder", e.backend, **kw)
                self._set("embedder", e.backend, e.backend, True)
            except ProviderUnavailable as ex:
                self._embedder = create("embedder", "lexical")
                ok = e.backend == "lexical"
                self._set("embedder", e.backend, "lexical", ok,
                          "" if ok else f"{ex} - using built-in word matching (paraphrases may be missed)")
        return self._embedder

    def vision(self) -> Optional[VisionEncoder]:
        if not self._vision_loaded:
            self._vision_loaded = True
            v = self.settings.vision
            if v.backend == "none":
                self._set("vision", "none", "none", False, "Visual analysis disabled in Settings")
            else:
                try:
                    self._vision = create("vision", v.backend, model=v.clip_model, pretrained=v.clip_pretrained,
                                          device=v.device, models_dir=self.settings.models_dir)
                    self._set("vision", v.backend, v.backend, True)
                except ProviderUnavailable as e:
                    self._set("vision", v.backend, "none", False, f"{e} - visual analysis skipped")
        return self._vision

    def sound_tagger(self, progress=None):
        """AudioSet sound-event model, or None (ClipForge then relies on loudness-based cues)."""
        if not self._tagger_loaded:
            self._tagger_loaded = True
            a = self.settings.audio_ai
            if a.sound_events == "none":
                self._set("sound_events", "none", "none", False, "Sound-event model disabled in Settings")
            else:
                try:
                    self._tagger = create("audio_tagger", a.sound_events, models_dir=self.settings.models_dir,
                                          threads=a.threads, progress=progress)
                    self._set("sound_events", a.sound_events, a.sound_events, True)
                except Exception as e:  # noqa: BLE001  (any model failure must not stop the analysis)
                    self._set("sound_events", a.sound_events, "none", False,
                              f"{e} - using loudness-based reaction cues instead")
        return self._tagger

    def diarizer(self, progress=None):
        if not self._diarizer_loaded:
            self._diarizer_loaded = True
            a = self.settings.audio_ai
            if a.diarizer == "none":
                self._set("diarizer", "none", "none", False, "Speaker identification disabled in Settings")
            else:
                try:
                    self._diarizer = create("diarizer", a.diarizer, models_dir=self.settings.models_dir,
                                            threads=a.threads, threshold=a.diarize_threshold, progress=progress)
                    self._set("diarizer", a.diarizer, a.diarizer, True)
                except Exception as e:  # noqa: BLE001
                    self._set("diarizer", a.diarizer, "none", False, f"{e} - speakers will not be told apart")
        return self._diarizer

    def captioner(self) -> Optional[FrameCaptioner]:
        if not self._captioner_loaded:
            self._captioner_loaded = True
            v = self.settings.vision
            if v.captioner == "none":
                self._set("captioner", "none", "none", True, "Frame descriptions disabled")
            else:
                try:
                    self._captioner = create("captioner", v.captioner, model=v.captioner_model,
                                             base_url=self.settings.llm.base_url)
                    self._set("captioner", v.captioner, v.captioner, True)
                except ProviderUnavailable as e:
                    self._set("captioner", v.captioner, "none", False,
                              f"{e} - the judge will rely on CLIP labels instead of frame descriptions")
        return self._captioner

    def llm(self) -> LLM:
        if self._llm is None:
            l = self.settings.llm
            try:
                self._llm = create("llm", l.backend, model=l.model, base_url=l.base_url, api_key=l.api_key,
                                   temperature=l.temperature, timeout_seconds=l.timeout_seconds)
                self._set("llm", l.backend, l.backend, l.backend != "rules",
                          "Rule-based mode: less intelligent selection and script" if l.backend == "rules" else "")
            except ProviderUnavailable as e:
                self._llm = create("llm", "rules")
                self._set("llm", l.backend, "rules", False, f"{e} - using rule-based fallback")
        return self._llm

    def llm_available(self) -> bool:
        self.llm()
        return self.status["llm"].active != "rules"

    def tts(self, progress=None) -> TTS:
        if self._tts is None:
            v = self.settings.voice
            try:
                self._tts = create("tts", v.backend, models_dir=self.settings.models_dir, progress=progress)
                self._set("tts", v.backend, v.backend, True)
            except ProviderUnavailable as e:
                self._set("tts", v.backend, "none", False, str(e))
                raise
        return self._tts

    def release(self, *kinds: str) -> None:
        """Free models that the next stages don't need (each reloads on demand). Keeps peak memory
        low: e.g. the speech model (~1 GB) isn't needed once the transcript is cached."""
        import gc

        for k in kinds:
            if k == "transcriber":
                self._transcriber = None
            elif k == "vision":
                self._vision, self._vision_loaded = None, False
            elif k == "captioner":
                self._captioner, self._captioner_loaded = None, False
            elif k == "sound_events":
                self._tagger, self._tagger_loaded = None, False
            elif k == "diarizer":
                self._diarizer, self._diarizer_loaded = None, False
            elif k == "tts":
                self._tts = None
        gc.collect()

    def _set(self, kind, wanted, active, ok, msg=""):
        self.status[kind] = ComponentStatus(kind, wanted, active, ok, msg)

    def report(self) -> list[str]:
        return [f"{s.kind}: {s.active}" + (f" ({s.message})" if s.message else "") for s in self.status.values()]
