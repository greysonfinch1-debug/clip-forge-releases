"""AI model manager: which models exist, which are installed, and safe downloading.

* Every model file has a known SHA-256: a download is only installed if it matches.
* Downloads resume after an interruption (HTTP Range) instead of starting over.
* Installs are atomic (staging folder → rename), so a half-finished download can never be
  mistaken for an installed model.
* Already-installed models are never downloaded again.
* Models live in the models folder (``%LOCALAPPDATA%\\ClipForge\\models`` by default), which
  installing, updating or uninstalling the app never touches unless you ask it to.

Ollama models (language model, embeddings, frame descriptions) are managed by Ollama itself;
``ollama_status`` / ``ollama_pull`` show and download them through Ollama's local API.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tarfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

Progress = Optional[Callable[[float, str], None]]
SHERPA = "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
KOKORO = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"


@dataclass
class ModelFile:
    path: str            # relative to the models folder
    sha256: str
    size: int = 0        # bytes (for display / quick checks)


@dataclass
class ModelSpec:
    key: str
    name: str
    purpose: str
    url: str
    files: list[ModelFile]
    archive: bool = False          # url is a .tar.bz2; ``files`` are taken from it
    archive_root: str = ""         # folder name inside the archive
    download_mb: int = 0
    required: bool = True          # needed for the default pipeline
    extra: dict = field(default_factory=dict)


MODELS: list[ModelSpec] = [
    ModelSpec("parakeet", "Speech-to-text (Parakeet TDT 0.6B)", "Transcribes what the streamer says",
              SHERPA + "asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2",
              [ModelFile("sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/encoder.int8.onnx",
                         "92a10bd9c23936ea0566c29f963bc57c2a5df4261b6a8921c39abea66557ca8b", 652282309),
               ModelFile("sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/decoder.int8.onnx",
                         "4d097bae3bac5c96018d5293ba39f1b657296102b142affda40378f38b020f41", 7257753),
               ModelFile("sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/joiner.int8.onnx",
                         "77a29f3e5ac7d37074e0af465391b80f314015d5b97f0f90c6c7767f1d56f428", 1739080),
               ModelFile("sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/tokens.txt",
                         "ec182b70dd42113aff6c5372c75cac58c952443eb22322f57bbd7f53977d497d", 9384)],
              archive=True, archive_root="sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8", download_mb=480),
    ModelSpec("vad", "Voice activity detector (Silero VAD)", "Finds where speech starts and stops",
              SHERPA + "asr-models/silero_vad.onnx",
              [ModelFile("silero_vad.onnx", "9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6",
                         643854)], download_mb=1),
    ModelSpec("kokoro_model", "Voice-over (Kokoro-82M)", "Reads the narration aloud",
              KOKORO + "kokoro-v1.0.int8.onnx",
              [ModelFile("kokoro/kokoro-v1.0.int8.onnx",
                         "6e742170d309016e5891a994e1ce1559c702a2ccd0075e67ef7157974f6406cb", 92361271)],
              download_mb=88),
    ModelSpec("kokoro_voices", "Voice-over voices (Kokoro)", "The 21 pre-made narrator voices",
              KOKORO + "voices-v1.0.bin",
              [ModelFile("kokoro/voices-v1.0.bin", "bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d",
                         28214398)], download_mb=27),
    ModelSpec("ced", "Sound events (CED-mini, AudioSet)", "Hears laughter, sirens, crashes, engines…",
              SHERPA + "audio-tagging-models/sherpa-onnx-ced-mini-audio-tagging-2024-04-19.tar.bz2",
              [ModelFile("sherpa-onnx-ced-mini-audio-tagging-2024-04-19/model.int8.onnx",
                         "ff29f39f9fbe637f72535160e9d006d61d872fdab0fce838672265b9b38cf946", 10451715),
               ModelFile("sherpa-onnx-ced-mini-audio-tagging-2024-04-19/class_labels_indices.csv",
                         "cdd1049833c4b86127c2773ac0d14a2754b6a6d0d1798002ed5c66e699708429", 14675)],
              archive=True, archive_root="sherpa-onnx-ced-mini-audio-tagging-2024-04-19", download_mb=45),
    ModelSpec("speaker_seg", "Speaker segmentation (pyannote 3.0)", "Splits audio by who is speaking",
              SHERPA + "speaker-segmentation-models/sherpa-onnx-pyannote-segmentation-3-0.tar.bz2",
              [ModelFile("sherpa-onnx-pyannote-segmentation-3-0/model.int8.onnx",
                         "d582f4b4c6b48205de7e0643c57df0df5615a3c176189be3fc461e9d18827b5d", 1540506)],
              archive=True, archive_root="sherpa-onnx-pyannote-segmentation-3-0", download_mb=7),
    ModelSpec("speaker_emb", "Speaker voices (TitaNet-small)", "Recognises the same voice across the stream",
              SHERPA + "speaker-recongition-models/nemo_en_titanet_small.onnx",
              [ModelFile("nemo_en_titanet_small.onnx", "ad4a1802485d8b34c722d2a9d04249662f2ece5d28a7a039063ca22f515a789e",
                         40257283)], download_mb=38),
]
BY_KEY = {m.key: m for m in MODELS}
MARKER = ".clipforge_verified.json"


class ModelError(RuntimeError):
    pass


def _sha256(path: Path, progress: Progress = None, label: str = "") -> str:
    h = hashlib.sha256()
    total = path.stat().st_size or 1
    done = 0
    with open(path, "rb") as f:
        while True:
            b = f.read(1 << 22)
            if not b:
                break
            h.update(b)
            done += len(b)
            if progress:
                progress(done / total, label or f"Verifying {path.name}")
    return h.hexdigest()


def _verified(models_dir: Path) -> dict:
    try:
        return json.loads((models_dir / MARKER).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _mark(models_dir: Path, spec: ModelSpec) -> None:
    data = _verified(models_dir)
    data[spec.key] = {f.path: f.sha256 for f in spec.files}
    tmp = models_dir / (MARKER + ".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    os.replace(tmp, models_dir / MARKER)


def status(models_dir: str | Path) -> list[dict]:
    """Fast status (file presence + sizes + the verified marker; no re-hashing)."""
    md = Path(models_dir)
    ver = _verified(md)
    out = []
    for m in MODELS:
        present = all((md / f.path).exists() and (not f.size or (md / f.path).stat().st_size == f.size)
                      for f in m.files)
        out.append({"key": m.key, "name": m.name, "purpose": m.purpose, "download_mb": m.download_mb,
                    "installed": present, "verified": present and m.key in ver})
    return out


def missing(models_dir: str | Path) -> list[str]:
    return [s["key"] for s in status(models_dir) if not s["installed"]]


def download_resumable(url: str, dst: Path, progress: Progress = None, label: str = "Downloading",
                       cancel: Optional[Callable[[], bool]] = None, attempts: int = 4,
                       expected_size: int = 0) -> Path:
    """Download to ``dst`` (via ``dst.part``), resuming a previous partial download."""
    import requests

    dst.parent.mkdir(parents=True, exist_ok=True)
    part = dst.with_name(dst.name + ".part")
    last_err: Exception | None = None
    for attempt in range(attempts):
        have = part.stat().st_size if part.exists() else 0
        if expected_size and have == expected_size:
            break
        headers = {"User-Agent": "ClipForge-ModelManager"}
        if have:
            headers["Range"] = f"bytes={have}-"
        try:
            with requests.get(url, headers=headers, stream=True, timeout=(15, 60)) as r:
                if r.status_code == 416:          # already complete
                    break
                if r.status_code not in (200, 206):
                    raise ModelError(f"HTTP {r.status_code} for {url}")
                if have and r.status_code == 200:  # server ignored Range: start over
                    have = 0
                total = have + int(r.headers.get("Content-Length") or 0)
                with open(part, "ab" if have else "wb") as f:
                    done = have
                    for chunk in r.iter_content(1 << 18):
                        if cancel and cancel():
                            raise ModelError("Cancelled")
                        f.write(chunk)
                        done += len(chunk)
                        if progress and total:
                            progress(done / total, f"{label}: {done >> 20} / {total >> 20} MB")
            last_err = None
            break
        except ModelError:
            raise
        except Exception as e:  # noqa: BLE001  (network hiccup: retry, resuming)
            last_err = e
            time.sleep(min(10, 2 * (attempt + 1)))
    if last_err is not None:
        raise ModelError(f"Download failed after {attempts} attempts ({last_err}). Run it again to resume.")
    os.replace(part, dst)
    return dst


def ensure(key: str, models_dir: str | Path, progress: Progress = None,
           cancel: Optional[Callable[[], bool]] = None, reverify: bool = False) -> Path:
    """Make sure a model is installed and verified; download it if needed. Returns models_dir.
    ``reverify`` re-hashes an already-verified model (and repairs it if it was damaged)."""
    md = Path(models_dir)
    md.mkdir(parents=True, exist_ok=True)
    spec = BY_KEY[key]
    st = next(s for s in status(md) if s["key"] == key)
    if st["installed"] and st["verified"] and not reverify:
        return md
    if st["installed"]:
        # present but never verified (e.g. copied from an older version): verify once, no download
        if all(_sha256(md / f.path, progress, f"Checking {spec.name}") == f.sha256 for f in spec.files):
            _mark(md, spec)
            return md
    dl_dir = md / ".downloads"
    stage = md / f".staging_{key}"
    shutil.rmtree(stage, ignore_errors=True)
    name = spec.url.rsplit("/", 1)[-1]
    got = download_resumable(spec.url, dl_dir / name, progress, f"Downloading {spec.name}", cancel)
    stage.mkdir(parents=True)
    try:
        if spec.archive:
            wanted = {f.path for f in spec.files}
            with tarfile.open(got) as t:
                for mem in t:
                    if mem.name in wanted and mem.isfile():
                        if os.path.isabs(mem.name) or ".." in Path(mem.name).parts:
                            raise ModelError("Unsafe path in model archive")
                        t.extract(mem, stage)
        else:
            target = stage / spec.files[0].path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(got, target)
        for f in spec.files:
            p = stage / f.path
            if not p.exists():
                raise ModelError(f"{spec.name}: {f.path} missing from the download")
            if _sha256(p, progress, f"Verifying {spec.name}") != f.sha256:
                raise ModelError(f"{spec.name}: {f.path} failed verification (corrupted or tampered download)")
        for f in spec.files:  # move verified files into place
            dst = md / f.path
            dst.parent.mkdir(parents=True, exist_ok=True)
            os.replace(stage / f.path, dst)
        _mark(md, spec)
    except Exception:
        try:
            got.unlink()   # a bad archive must be downloaded fresh next time
        except OSError:
            pass
        raise
    finally:
        shutil.rmtree(stage, ignore_errors=True)
    try:
        got.unlink()
    except OSError:
        pass
    return md


def ensure_all(models_dir: str | Path, keys: list[str] | None = None, progress: Progress = None,
               cancel: Optional[Callable[[], bool]] = None) -> list[str]:
    todo = keys or missing(models_dir) or []
    done = []
    for i, k in enumerate(todo):
        sub = (lambda f, m, i=i: progress((i + f) / len(todo), m)) if progress else None
        ensure(k, models_dir, sub, cancel)
        done.append(k)
    return done


# ----------------------------------------------------------------------------- Ollama
def ollama_status(base_url: str, wanted: list[str]) -> dict:
    import requests

    try:
        r = requests.get(base_url.rstrip("/") + "/api/tags", timeout=4)
        names = [m.get("name", "") for m in r.json().get("models", [])]
    except Exception as e:  # noqa: BLE001
        return {"running": False, "error": str(e), "models": {w: False for w in wanted}}
    from .providers.llm import ollama_has_model

    return {"running": True, "models": {w: ollama_has_model(names, w) for w in wanted if w}}


def ollama_pull(base_url: str, model: str, progress: Progress = None,
                cancel: Optional[Callable[[], bool]] = None) -> None:
    """Download an Ollama model through the local Ollama app, with progress."""
    import requests

    with requests.post(base_url.rstrip("/") + "/api/pull", json={"model": model, "stream": True},
                       stream=True, timeout=(10, 600)) as r:
        if r.status_code != 200:
            raise ModelError(f"Ollama refused the download: HTTP {r.status_code} {r.text[:200]}")
        for line in r.iter_lines():
            if cancel and cancel():
                raise ModelError("Cancelled")
            if not line:
                continue
            d = json.loads(line)
            if d.get("error"):
                raise ModelError(f"Ollama: {d['error']}")
            if progress:
                tot, done = d.get("total") or 0, d.get("completed") or 0
                progress(done / tot if tot else 0.0, f"{model}: {d.get('status', '')}"
                         + (f" {done >> 20} / {tot >> 20} MB" if tot else ""))
