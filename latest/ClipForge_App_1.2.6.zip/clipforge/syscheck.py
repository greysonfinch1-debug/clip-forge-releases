"""System Check: verifies every component on THIS computer and says how to fix what's missing.

Nothing here is assumed: each line is the result of actually importing, running or
contacting the component.
"""
from __future__ import annotations

import importlib
import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from .config import ASSETS_DIR, Settings


INSTALLED = bool(os.environ.get("CLIPFORGE_INSTALL_DIR"))   # running from the Windows installer build
FIX_REINSTALL = ("Run ClipForge_Setup.exe again to repair (projects, settings and models are kept)." if INSTALLED
                 else "Re-run install.bat")
FIX_MODELS = "Click 'AI Models' in the sidebar → Download missing models."
FIX_VISION = ("Click 'AI Models' in the sidebar → Install visual understanding (about 2 GB)." if INSTALLED
              else "Run install.bat and choose the 'vision' option (about 2 GB download).")


@dataclass
class Item:
    name: str
    status: str        # ok / warn / fail
    detail: str
    fix: str = ""
    required: bool = True


def _try_import(mod: str):
    try:
        m = importlib.import_module(mod)
        return m, getattr(m, "__version__", "") or "installed"
    except Exception as e:  # noqa: BLE001
        return None, str(e).split("\n")[0][:120]


def run_checks(settings: Settings) -> list[Item]:
    out: list[Item] = []
    add = out.append
    v = sys.version_info
    add(Item("Python", "ok" if (3, 10) <= v[:2] <= (3, 12) or INSTALLED else "warn",
             platform.python_version() + (" (built in)" if INSTALLED else ""),
             "Python 3.11 is recommended (some AI packages lag behind the newest Python)."))
    # FFmpeg
    try:
        from .core import ffmpeg as ff

        exe = ff.ffmpeg_bin()
        ver = subprocess.run([exe, "-version"], capture_output=True, text=True, creationflags=ff._NO_WINDOW
                             ).stdout.split("\n")[0]
        missing = [f for f in ("ass", "xfade", "loudnorm", "zoompan", "ebur128") if not ff.has_filter(f)]
        add(Item("FFmpeg", "ok" if not missing else "fail", ver[:70] + (f" | missing filters: {missing}" if missing else ""),
                 (FIX_REINSTALL if INSTALLED else "Install a full build: winget install Gyan.FFmpeg")))
    except Exception as e:  # noqa: BLE001
        add(Item("FFmpeg", "fail", str(e)[:150], (FIX_REINSTALL if INSTALLED else "Run: winget install Gyan.FFmpeg  then restart ClipForge")))
    # Core Python packages
    for mod, why in [("numpy", "maths"), ("cv2", "visual analysis"), ("soundfile", "audio files"),
                     ("yt_dlp", "public URL downloads"), ("sherpa_onnx", "Parakeet speech-to-text"),
                     ("kokoro_onnx", "local voice-over"), ("PySide6", "the interface"), ("requests", "networking")]:
        m, info = _try_import(mod)
        add(Item(f"Package: {mod}", "ok" if m else "fail", f"{info} ({why})", FIX_REINSTALL))
    # Optional AI packages
    torch, tinfo = _try_import("torch")
    oc, ocinfo = _try_import("open_clip")
    gpu = ""
    if torch is not None:
        try:
            gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "no CUDA GPU (CPU mode)"
        except Exception:  # noqa: BLE001
            gpu = "unknown"
    add(Item("Visual understanding (CLIP)", "ok" if torch and oc else "warn",
             f"torch {tinfo}, open_clip {ocinfo}; {gpu}" if torch and oc else "not installed",
             FIX_VISION + " Without it, clips are found from speech and audio only.", required=False))
    fw, fwinfo = _try_import("faster_whisper")
    add(Item("faster-whisper (alternative speech-to-text)", "ok" if fw else "warn", fwinfo if fw else "not installed",
             ("Optional and not part of the Windows app: Parakeet (included) is used for English." if INSTALLED
              else "Optional. pip install faster-whisper"), required=False))
    # Models on disk (registry-driven; each file has a known SHA-256)
    from . import model_manager as mm

    for st in mm.status(settings.models_dir):
        state = "ok" if st["installed"] else "warn"
        detail = ("installed and verified" if st["verified"] else "installed") if st["installed"] else \
            f"not downloaded yet (about {st['download_mb']} MB)"
        add(Item(st["name"], state, detail,
                 f"{FIX_MODELS} It also downloads automatically the first time it is needed.", required=False))
    # LLM
    l = settings.llm
    if l.backend == "ollama":
        try:
            import requests

            r = requests.get(l.base_url.rstrip("/") + "/api/tags", timeout=4)
            names = [m.get("name", "") for m in r.json().get("models", [])]
            from .providers.llm import ollama_has_model

            for model, role in [(l.model, "reasoning (judge, story, script)"),
                                (settings.embedding.model if settings.embedding.backend == "ollama" else "", "meaning search"),
                                (settings.vision.captioner_model if settings.vision.captioner == "ollama" else "",
                                 "frame descriptions")]:
                if not model:
                    continue
                ok = ollama_has_model(names, model)
                add(Item(f"Ollama model {model}", "ok" if ok else "warn", role + ("" if ok else " - not pulled"),
                         f"Run in a terminal: ollama pull {model}", required=False))
        except Exception as e:  # noqa: BLE001
            add(Item("Ollama", "warn", f"not reachable at {l.base_url} ({type(e).__name__})",
                     "Install from ollama.com, then: ollama pull " + l.model + " ; ollama pull nomic-embed-text ; "
                     "ollama pull " + settings.vision.captioner_model + ".  Without it ClipForge uses rule-based "
                     "selection, which is noticeably less accurate.", required=False))
    elif l.backend == "openai":
        add(Item("Language model", "ok" if l.api_key else "warn", f"OpenAI-compatible API at {l.base_url}",
                 "Enter an API key in Settings (paid per use).", required=False))
    else:
        add(Item("Language model", "warn", "Rule-based mode (no AI reasoning)",
                 "Install Ollama for much better topic matching and scripts.", required=False))
    # Fonts, disk
    fonts = list((ASSETS_DIR / "fonts").glob("*.ttf"))
    add(Item("Caption fonts", "ok" if fonts else "fail", ", ".join(f.stem for f in fonts) or "none",
             FIX_REINSTALL))
    try:
        free = shutil.disk_usage(Path(settings.output_dir)).free / 1e9
        add(Item("Free disk space", "ok" if free > 10 else "warn", f"{free:.0f} GB",
                 "Keep 10 GB+ free for long streams (cache can be cleared in Settings).", required=False))
    except Exception:  # noqa: BLE001
        pass
    return out


def run_render_selftest(settings: Settings) -> tuple[bool, str]:
    """Renders a 6-second test Short through the real renderer (captions, mix, QC)."""
    import tempfile

    from .core import ffmpeg as ff
    from .core.models import Overlay, Sentence, StoryItem, Transcript, Word
    from .render.captions import build_captions
    from .render.qc import run_qc
    from .render.render import RenderJob, render
    from .render.timeline import build_timeline

    tmp = Path(tempfile.mkdtemp(prefix="clipforge_selftest_"))
    try:
        src = tmp / "src.mp4"
        ff.run(["-f", "lavfi", "-i", "testsrc2=s=1280x720:r=30:d=8", "-f", "lavfi", "-i", "sine=f=440:d=8",
                "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", "-shortest", str(src)], label="test media")
        story = [StoryItem("a", "hook", "", 0.5, 4.0), StoryItem("b", "payoff", "", 4.5, 7.5)]
        words = [Word("Self", 0.9, 1.3), Word("test", 1.3, 1.8), Word("passed", 5.0, 5.6)]
        tr = Transcript(sentences=[Sentence(0, 0.9, 1.8, "Self test", words[:2]),
                                   Sentence(1, 5.0, 5.6, "passed", words[2:])])
        tl = build_timeline(story, {0: (str(src), 0.0), 1: (str(src), 0.0)}, [], tr, 0.18)
        chunks = build_captions(tl, [], settings.edit, [])
        job = RenderJob(tl, chunks, [Overlay("ClipForge test", "headline", 0, 2)], settings.edit, tmp / "work",
                        tmp / "out.mp4", {})
        out = render(job)
        rep = run_qc(str(out), settings.edit, tl.duration, chunks, timeline=tl)
        return rep.passed, rep.summary()
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
