"""Storytelling: clip order, hook options and grounded narration.

The language model sees every selected clip's verified description and transcript and
arranges them into hook → context → escalation → peak → payoff, explaining each
placement. It then writes hooks and narration that may only describe what the evidence
shows. Narration is checked afterwards: quotes that don't appear in the transcript are
removed, and the total length is kept inside the word budget for the Short.
"""
from __future__ import annotations

import re
from typing import Optional

from ..core.models import Candidate, HookOption, NarrationLine, StoryItem, TopicSpec, Transcript
from ..providers.base import LLM, ProviderUnavailable

WORDS_PER_SECOND = 2.6

# ----------------------------------------------------------------------------- ordering

ORDER_SYSTEM = """You are the editor of a YouTube Short built from gameplay livestream clips.
Arrange the clips into the most engaging, coherent sequence:
- Open with the clip whose first seconds grab attention best (hook). The editor automatically opens the Short with a 2-3 second flash-forward of the LAST clip's peak, so save the single strongest moment for the end.
- Then build: context, escalation, and finish on the strongest moment (payoff).
- If clips are parts of the SAME continuous event (close in source time and the evidence shows it continues), keep them in chronological order.
- Never put two near-identical moments back to back.
- Base every decision only on the descriptions given. Reply with JSON only."""

ORDER_PROMPT = """Short topic: {topic}

Clips (source_time = where it happens in the original video):
{clips}

Return JSON: {{"order": [{{"id": clip id, "role": "hook|context|escalation|peak|payoff", "rationale": one sentence why it goes here}}, ...]}}
Use every clip id exactly once."""


def order_story(chosen: list[Candidate], spec: TopicSpec, llm: LLM) -> tuple[list[StoryItem], str]:
    if not chosen:
        return [], "none"
    if len(chosen) == 1:
        c = chosen[0]
        return [StoryItem(cid=c.cid, role="peak", rationale="Only clip selected.", start=c.start, end=c.end)], "rules"
    by_id = {c.cid: c for c in chosen}
    try:
        clips = "\n".join(
            f"- id={c.cid} source_time={c.start:.0f}s duration={c.duration:.0f}s entertainment={c.entertainment:.0f}/10 "
            f"hook_potential={c.hook_potential:.0f}/10: {c.description}" for c in chosen)
        d = llm.complete_json(ORDER_SYSTEM, ORDER_PROMPT.format(topic=spec.summary, clips=clips), max_tokens=900)
        order = d.get("order") or d.get("items") or []
        items, seen = [], set()
        for o in order:
            cid = str(o.get("id", "")) if isinstance(o, dict) else str(o)
            if cid in by_id and cid not in seen:
                c = by_id[cid]
                seen.add(cid)
                items.append(StoryItem(cid=cid, role=str(o.get("role", "")) if isinstance(o, dict) else "",
                                       rationale=str(o.get("rationale", ""))[:240] if isinstance(o, dict) else "",
                                       start=c.start, end=c.end))
        if len(items) == len(chosen):
            return _fix_continuity(items, by_id), "llm"
    except ProviderUnavailable:
        pass
    return rule_order(chosen), "rules"


def rule_order(chosen: list[Candidate]) -> list[StoryItem]:
    """Hook first, then rising entertainment, strongest payoff last; continuous events stay in order."""
    groups: list[list[Candidate]] = []
    for c in sorted(chosen, key=lambda c: c.start):
        if groups and c.start - groups[-1][-1].end < 10:
            groups[-1].append(c)
        else:
            groups.append([c])

    def g_score(g, attr):
        return max(getattr(c, attr) for c in g)

    # The most entertaining moment is the payoff and goes LAST (the edit opens with a short
    # flash-forward of it, so it still hooks the viewer); the best remaining opener goes first.
    payoff = max(groups, key=lambda g: (g_score(g, "entertainment"), g_score(g, "final_score")))
    rest = [g for g in groups if g is not payoff]
    if rest:
        hook = max(rest, key=lambda g: (g_score(g, "hook_potential"), g_score(g, "final_score")))
        middle = sorted([g for g in rest if g is not hook], key=lambda g: g_score(g, "entertainment"))
        seq = [hook] + middle + [payoff]
    else:
        hook, payoff, seq = payoff, None, [payoff]
    items: list[StoryItem] = []
    for gi, g in enumerate(seq):
        for k, c in enumerate(g):
            if gi == 0 and k == 0:
                role, why = "hook", f"Strongest opening (hook potential {c.hook_potential:.0f}/10)."
            elif payoff is not None and g is payoff and k == len(g) - 1:
                role, why = "payoff", f"Most entertaining moment ({c.entertainment:.0f}/10) saved for the end."
            elif k > 0:
                role, why = "escalation", "Continues the same event, kept in chronological order."
            else:
                role, why = "escalation", "Builds toward the payoff (ordered by rising entertainment)."
            items.append(StoryItem(cid=c.cid, role=role, rationale=why, start=c.start, end=c.end))
    return items


def _fix_continuity(items: list[StoryItem], by_id: dict) -> list[StoryItem]:
    """If the model split a continuous event out of order, restore chronological order inside it."""
    for i in range(len(items) - 1):
        a, b = by_id[items[i].cid], by_id[items[i + 1].cid]
        if 0 < a.start - b.end < 10:  # b happened just before a in the source: swap
            items[i], items[i + 1] = items[i + 1], items[i]
            items[i].rationale += " (moved: happens first in the source)"
    return items


# ----------------------------------------------------------------------------- hooks

HOOK_SYSTEM = """You write opening hooks for YouTube Shorts made from gameplay clips.
A hook = a headline shown on screen (max 7 words) + an opening narration line (max 14 words).
Hooks must be truthful to the clips: no claims the footage doesn't support, no fake stakes. Reply with JSON only."""

HOOK_PROMPT = """Short topic: {topic}
Clips in order:
{clips}

Write {n} different hook options with different angles (curiosity, stakes, humour, disbelief).
Return JSON: {{"hooks": [{{"headline": "...", "opening_line": "...", "score": 0-10 how likely to stop a scrolling viewer, "rationale": "..."}}]}}"""


def make_hooks(story: list[StoryItem], by_id: dict, spec: TopicSpec, llm: LLM, n: int = 3) -> tuple[list[HookOption], str]:
    clips = "\n".join(f"{i + 1}. ({it.role}) {by_id[it.cid].description}" for i, it in enumerate(story))
    try:
        d = llm.complete_json(HOOK_SYSTEM, HOOK_PROMPT.format(topic=spec.summary, clips=clips, n=n), max_tokens=700)
        hooks = []
        for h in d.get("hooks") or d.get("items") or []:
            if not isinstance(h, dict):
                continue
            head = _clip_words(str(h.get("headline", "")), 7)
            line = _clip_words(str(h.get("opening_line", "")), 16)
            if head:
                hooks.append(HookOption(headline=head, opening_line=line, score=float(h.get("score") or 0),
                                        rationale=str(h.get("rationale", ""))[:200]))
        if hooks:
            hooks.sort(key=lambda h: -h.score)
            return hooks[:n], "llm"
    except ProviderUnavailable:
        pass
    return rule_hooks(spec, n), "rules"


def rule_hooks(spec: TopicSpec, n: int) -> list[HookOption]:
    """Fallback hooks (no language model). They promise nothing the clips don't show: the only
    claim made is the ranking ClipForge itself computed (the last clip is the strongest)."""
    topic = _short_topic(spec)
    opts = [
        HookOption(f"{topic.upper()}: BEST MOMENTS", f"The best {topic} from this stream.", score=6),
        HookOption("WAIT FOR THE LAST ONE", f"These {topic} build up. Wait for the last one.", score=5.5),
        HookOption(f"{topic.upper()} COMPILATION", f"Here are the top {topic} from the stream.", score=5),
    ]
    return opts[:n]


def _short_topic(spec: TopicSpec) -> str:
    t = (spec.sub_topics[0] if spec.sub_topics else spec.raw) or "moments"
    t = re.sub(r"^(please\s+)?(find|show|get|give|make)\s+(me\s+)?(some\s+|all\s+|the\s+)?", "", t.strip(), flags=re.I)
    t = re.split(r"\b(where|that|when|which|who|with|involving|in which|from|during)\b", t, maxsplit=1, flags=re.I)[0]
    t = re.sub(r"\b(the\s+)?(most|best|funniest|craziest|wildest|top)\s+", "", t, flags=re.I)
    t = re.sub(r"^(some\s+|all\s+|the\s+)?(exciting|crazy|wild|insane|epic|cool|good|great|amazing|hilarious)\s+", "",
               t.strip(), flags=re.I)
    t = re.sub(r"\s+", " ", t).strip(" ,.")
    words = t.split()[:6]
    while words and words[-1].lower() in {"a", "an", "the", "of", "to", "in", "on", "his", "her", "their", "my",
                                          "and", "or", "with", "for", "at"}:
        words.pop()
    return " ".join(words) or "moments"


def _clip_words(s: str, n: int) -> str:
    w = s.strip().strip('"').split()
    return " ".join(w[:n])


# ----------------------------------------------------------------------------- narration

SCRIPT_SYSTEM = """You write the voice-over for a YouTube Short made of gameplay livestream clips.
Style: natural, punchy, conversational, like a good gaming Shorts narrator. Short sentences.
Strict rules:
- Describe ONLY what the clip descriptions and transcripts show. Never invent events, names or dialogue.
- Never quote the streamer unless the exact words are in the transcript.
- The narration connects the clips and sets up each moment; it must not explain the joke after it lands.
- Narration plays while the original audio is quiet, so keep each line short.
Reply with JSON only."""

SCRIPT_PROMPT = """Short topic: {topic}
Opening hook to start with (use or lightly adapt): "{hook}"
Total narration budget: at most {budget} words across ALL lines.

Clips in order:
{clips}

Return JSON:
{{"lines": [{{"item": clip number the line introduces (1 = first clip), "text": "..."}}],
  "context_texts": {{"<clip number>": "3-7 word on-screen context caption or empty"}},
  "title": "YouTube title, max 60 characters, truthful",
  "description": "1-2 sentence YouTube description"}}
Write one opening line for clip 1, then at most one short line before some later clips (skip clips that need no setup). Optionally end with a short closing line attached to the last clip number + 1."""


def write_script(story: list[StoryItem], by_id: dict, spec: TopicSpec, hook: Optional[HookOption], llm: LLM,
                 transcript: Transcript, target_seconds: float, narration_share: float = 0.18
                 ) -> tuple[list[NarrationLine], dict, str]:
    budget = max(14, int(target_seconds * narration_share * WORDS_PER_SECOND))
    clips = []
    for i, it in enumerate(story):
        c = by_id[it.cid]
        said = " ".join(s.text for s in transcript.sentences_between(it.start, it.end))[:400]
        clips.append(f"{i + 1}. ({it.role}, {it.end - it.start:.0f}s) {c.description}\n   Streamer says: {said or '(nothing)'}")
    extras: dict = {}
    try:
        d = llm.complete_json(SCRIPT_SYSTEM, SCRIPT_PROMPT.format(topic=spec.summary, hook=hook.opening_line if hook else "",
                                                                  budget=budget, clips="\n".join(clips)), max_tokens=900)
        lines = []
        for ln in d.get("lines") or []:
            if not isinstance(ln, dict):
                continue
            try:
                item = int(ln.get("item", 1)) - 1
            except (TypeError, ValueError):
                item = 0
            text = _ground(str(ln.get("text", "")).strip(), transcript)
            if text:
                pos = "after" if item >= len(story) else "before"
                lines.append(NarrationLine(text=text, item_index=min(max(0, item), len(story) - 1), position=pos))
        extras = {"context_texts": d.get("context_texts") or {}, "title": str(d.get("title", ""))[:100],
                  "description": str(d.get("description", ""))[:500]}
        if lines:
            return _budget(lines, budget), extras, "llm"
    except ProviderUnavailable:
        pass
    return rule_script(story, by_id, spec, hook), {"context_texts": {}, "title": "", "description": ""}, "rules"


def rule_script(story: list[StoryItem], by_id: dict, spec: TopicSpec, hook: Optional[HookOption]) -> list[NarrationLine]:
    lines = [NarrationLine(text=(hook.opening_line if hook and hook.opening_line else
                                 f"Here are the best {_short_topic(spec)} from this stream."), item_index=0)]
    # neutral bridges: they describe the edit, never invent what happens in the clip
    k = 0
    for i, it in enumerate(story[1:], start=1):
        if it.role == "payoff":
            lines.append(NarrationLine(text="And the biggest one of all.", item_index=i))
        elif k == 0 and len(story) > 2 and i == len(story) // 2:
            lines.append(NarrationLine(text="Here's another one.", item_index=i))
            k += 1
    return lines


_QUOTE = re.compile(r"[\"“”]([^\"“”]{3,})[\"“”]")


def _ground(text: str, transcript: Transcript) -> str:
    """Reject a narration line that quotes words the streamer never said (prevents invented
    dialogue). The whole line is dropped: removing just the quote leaves a sentence that still
    claims something was said."""
    norm = lambda s: re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s.lower())).strip()
    full_n = norm(" ".join(s.text for s in transcript.sentences))
    for q in _QUOTE.findall(text):
        if norm(q) not in full_n:
            return ""
    return re.sub(r"\s+", " ", text).strip(" ,")


def _budget(lines: list[NarrationLine], budget: int) -> list[NarrationLine]:
    total = sum(len(l.text.split()) for l in lines)
    if total <= budget:
        return lines
    # keep the opening line, drop later lines from the middle until within budget
    keep = lines[:1]
    used = len(lines[0].text.split())
    for l in lines[1:]:
        w = len(l.text.split())
        if used + w <= budget:
            keep.append(l)
            used += w
    return keep
