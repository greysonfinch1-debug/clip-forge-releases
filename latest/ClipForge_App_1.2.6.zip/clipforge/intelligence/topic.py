"""Topic understanding: turn the user's request into a structured search specification.

With a language model, the request is decomposed into visual concepts (what should be on
screen), look-alikes to reject, things people would say, entertainment criteria and
exclusions. Without one, a built-in gaming vocabulary does a simpler expansion.
"""
from __future__ import annotations

import re

from ..core.models import TopicSpec
from ..providers.base import LLM, ProviderUnavailable

VERSION = 3  # bump when topic expansion changes (invalidates cached topic specs)

SYSTEM = """You turn a video editor's request into a precise search specification for finding moments in a long gameplay livestream.
The search uses four signals: (1) a CLIP image model that compares video frames to short visual descriptions, (2) the transcript of what the streamer says, (3) a sound-event model (sirens, crashes, laughter, engines...), (4) audio energy.
Be concrete and literal. Visual concepts must describe what is VISIBLE in a single frame (CLIP cannot see motion or story).
Reply with JSON only."""

PROMPT = """Request: "{raw}"

Return JSON with these keys:
- "summary": one sentence restating exactly what moments are wanted.
- "sub_topics": list of 1-5 distinct kinds of moments contained in the request.
- "visual_positive": 4-10 short concrete visual descriptions of frames that would appear in these moments (e.g. "police cars with flashing red and blue lights chasing a car", "a car crashing into a wall").
- "visual_negative": 3-6 visually similar frames that are NOT what is wanted (e.g. "a parked police car with no action", "a menu screen").
- "speech_cues": 6-15 short phrases a streamer might actually say during these moments (e.g. "the cops are behind me", "oh my god", "no way").
- "keywords": 5-15 single words or short terms strongly tied to the topic.
- "entertainment_criteria": 3-6 things that make such a moment entertaining for a stranger (e.g. "an unexpected outcome", "a big reaction").
- "exclude": things that must not be selected (e.g. "reading donations", "menu screens", "talking about unrelated topics").
- "sounds": 0-4 sound types typical of these moments, chosen ONLY from: {sound_groups}. Use [] if sound says nothing about the topic.
- "needs_visual": true if the topic is mainly about what happens on screen.
- "needs_speech": true if the topic is mainly about what is said."""

# ---------------------------------------------------------------- built-in vocabulary (fallback)

LEXICON: list[tuple[tuple[str, ...], dict]] = [
    (("police", "cop", "cops", "chase", "pursuit", "wanted", "stars"), {
        "visual": ["police cars with flashing red and blue lights", "a car being chased by police cars",
                   "a high speed car chase on a city street", "a police helicopter overhead"],
        "neg": ["a parked police car with no action", "a calm empty street"],
        "speech": ["the cops are behind me", "police", "lose them", "they're chasing me", "go go go", "wanted level",
                   "they're still on me", "get away"]}),
    (("crash", "crashes", "wreck", "accident", "collision"), {
        "visual": ["a car crashing into another car", "a wrecked car with smoke", "a car flipping over"],
        "neg": ["a clean parked car"], "speech": ["I crashed", "oh no", "my car", "wrecked", "no no no"]}),
    (("explosion", "explode", "blow", "boom", "bomb"), {
        "visual": ["a large fiery explosion", "a car on fire", "smoke and flames"],
        "neg": ["a sunset sky"], "speech": ["it exploded", "boom", "blew up", "oh my god"]}),
    (("npc", "npcs", "pedestrian", "civilian", "people"), {
        "visual": ["a pedestrian standing close to the player character", "people on a sidewalk reacting",
                   "a character talking to another character"],
        "neg": ["an empty road"], "speech": ["this guy", "this lady", "what is he doing", "bro", "the people in this game"]}),
    (("drive", "driving", "car", "cars", "vehicle", "drift", "stunt", "jump"), {
        "visual": ["a sports car driving fast", "a car in mid-air after a jump", "a car drifting around a corner"],
        "neg": ["a car garage menu"], "speech": ["watch this", "full send", "look at this jump", "drifting"]}),
    (("funny", "hilarious", "laugh", "comedy", "lol"), {
        "visual": ["a character falling over", "an absurd situation in a video game"],
        "neg": [], "speech": ["I'm dying", "ha ha", "that's hilarious", "what", "bro", "no way"]}),
    (("surprise", "surprised", "unexpected", "shock", "wtf", "insane", "crazy"), {
        "visual": ["a sudden dramatic event in a video game"], "neg": [],
        "speech": ["no way", "what", "wait wait", "oh my god", "that is insane", "did you see that"]}),
    (("boat", "water", "ocean", "beach", "swim"), {
        "visual": ["a car sinking in the ocean", "a speedboat on the water", "a beach with palm trees"],
        "neg": [], "speech": ["into the water", "the ocean", "swimming", "boat"]}),
    (("plane", "helicopter", "fly", "flying", "airport"), {
        "visual": ["an airplane flying low over a city", "a helicopter in the air", "an aircraft crash"],
        "neg": [], "speech": ["flying", "the plane", "helicopter", "landing"]}),
    (("discover", "discovery", "secret", "hidden", "easter", "found"), {
        "visual": ["a hidden room in a video game", "a strange object in a video game world"],
        "neg": [], "speech": ["look at this", "I found", "what is this", "secret", "did you know", "hidden"]}),
    (("fight", "shootout", "gun", "shooting", "heist", "robbery", "rob"), {
        "visual": ["a shootout between characters", "a bank robbery in a video game", "characters with weapons"],
        "neg": [], "speech": ["heist", "rob", "shoot", "get the money", "the vault"]}),
]

# sound groups that can describe a topic (reaction sounds like laughter are entertainment, not topic)
TOPIC_SOUNDS = ["siren", "explosion", "gunfire", "crash", "skidding", "vehicle", "aircraft", "water", "alarm",
                "music", "animal", "cheering"]
LEXICON_SOUNDS = {"police": ["siren", "skidding"], "crash": ["crash", "skidding"], "explosion": ["explosion"],
                  "drive": ["skidding"], "boat": ["water"], "plane": ["aircraft"], "fight": ["gunfire", "explosion"]}

GENERIC_EXCLUDE = ["reading donations or thanking chat", "menu or loading screens", "talking about unrelated real-life topics"]
GENERIC_ENTERTAINMENT = ["an unexpected outcome", "a big genuine reaction", "a clear setup and payoff", "something absurd"]


def understand_topic(raw: str, llm: LLM) -> TopicSpec:
    raw = (raw or "").strip()
    if not raw:
        raw = "the most entertaining moments"
    try:
        d = llm.complete_json(SYSTEM, PROMPT.format(raw=raw, sound_groups=", ".join(TOPIC_SOUNDS)), max_tokens=900)
        spec = TopicSpec(
            raw=raw,
            summary=str(d.get("summary") or raw),
            sub_topics=_strs(d.get("sub_topics"))[:5] or [raw],
            visual_positive=_strs(d.get("visual_positive"))[:10],
            visual_negative=_strs(d.get("visual_negative"))[:6],
            speech_cues=_strs(d.get("speech_cues"))[:15],
            keywords=_strs(d.get("keywords"))[:15],
            entertainment_criteria=_strs(d.get("entertainment_criteria"))[:6] or GENERIC_ENTERTAINMENT,
            exclude=_strs(d.get("exclude"))[:8] or GENERIC_EXCLUDE,
            needs_visual=bool(d.get("needs_visual", True)),
            needs_speech=bool(d.get("needs_speech", True)),
            sounds=[x for x in _strs(d.get("sounds")) if x in TOPIC_SOUNDS][:4],
        )
        if spec.visual_positive or spec.speech_cues:
            _merge_lexicon(spec)  # adds proven phrasings the model may have missed
            return spec
    except ProviderUnavailable:
        pass
    return rule_topic(raw)


def rule_topic(raw: str) -> TopicSpec:
    spec = TopicSpec(raw=raw, summary=raw)
    parts = [p.strip() for p in re.split(r",|;| and | or |\n", raw) if len(p.strip()) > 3]
    spec.sub_topics = parts[:5] or [raw]
    spec.keywords = [w for w in re.findall(r"[a-zA-Z']+", raw.lower()) if len(w) > 3][:15]
    spec.entertainment_criteria = GENERIC_ENTERTAINMENT
    spec.exclude = GENERIC_EXCLUDE
    _merge_lexicon(spec)
    if not spec.visual_positive:
        spec.visual_positive = [f"a video game scene showing {p}" for p in spec.sub_topics]
    if not spec.speech_cues:
        spec.speech_cues = spec.sub_topics
    words = set(re.findall(r"[a-z]+", raw.lower()))
    speech_only = {"say", "says", "said", "quote", "quotes", "rant", "story", "talks", "conversation"}
    spec.needs_speech = True
    spec.needs_visual = not (words & speech_only and not any(words & set(k) for k, _ in LEXICON))
    return spec


# Groups that describe a QUALITY of a moment (funny, surprising) rather than its subject.
# When the topic also names a subject ("funny NPC interactions"), their reaction phrases are
# evidence of entertainment, not of the topic, so they must not make an off-subject clip look on-topic.
QUALITY_GROUPS = {"funny", "surprise"}


def _merge_lexicon(spec: TopicSpec) -> None:
    words = set(re.findall(r"[a-z]+", (spec.raw + " " + " ".join(spec.keywords)).lower()))
    matched = [(keys, entry) for keys, entry in LEXICON if words & set(keys)]
    has_subject = any(keys[0] not in QUALITY_GROUPS for keys, _ in matched)
    for keys, entry in matched:
        if has_subject and keys[0] in QUALITY_GROUPS:
            spec.entertainment_criteria = list(dict.fromkeys(
                spec.entertainment_criteria + [f'reactions like "{c}"' for c in entry["speech"][:4]]))[:10]
            spec.visual_positive += [v for v in entry["visual"] if v not in spec.visual_positive]
            continue
        if True:
            spec.visual_positive += [v for v in entry["visual"] if v not in spec.visual_positive]
            spec.visual_negative += [v for v in entry["neg"] if v not in spec.visual_negative]
            spec.speech_cues += [v for v in entry["speech"] if v not in spec.speech_cues]
            spec.keywords += [k for k in keys if k not in spec.keywords]
            spec.sounds += [x for x in LEXICON_SOUNDS.get(keys[0], []) if x not in spec.sounds]
    spec.sounds = spec.sounds[:5]
    spec.visual_positive = spec.visual_positive[:14]
    spec.visual_negative = spec.visual_negative[:8]
    spec.speech_cues = spec.speech_cues[:24]
    spec.keywords = spec.keywords[:24]


def _strs(v) -> list[str]:
    if isinstance(v, str):
        return [v]
    if not isinstance(v, list):
        return []
    return [str(x).strip() for x in v if str(x).strip()]
