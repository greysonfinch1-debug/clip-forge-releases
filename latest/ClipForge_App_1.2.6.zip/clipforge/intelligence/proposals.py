"""Pass 1 – recall: propose candidate moments across the whole video.

A 0.5 s timeline is scored for *topic relevance* (what is on screen via CLIP, and what is
said via semantic text similarity) and *entertainment signals* (audio energy, laughter,
reactions). Relevance gates everything: a loud moment that is off-topic scores ~0, which
is how "the streamer is shouting" is prevented from passing as "a police chase".

Each peak becomes a window that is expanded to complete sentences, with the setup before
and the reaction after, so clips don't start too late or end too early. Pass 2 (judge.py)
then verifies every candidate with the language model.
"""
from __future__ import annotations

import re
from typing import Optional

import numpy as np

from ..analysis.audio import HOP, AudioFeatures
from ..analysis.visual import VisualFeatures, topic_similarity
from ..core.models import Candidate, TopicSpec, Transcript, clamp
from ..providers.base import TextEmbedder

EXCLAIM = re.compile(r"\b(no way|oh my god|what the|wait|holy|bro|dude|insane|crazy|i'm dying|ha ?ha|lol|lmao|"
                     r"oh no|let's go|yes+|no+|what)\b|!", re.I)


GOOD_MIN_LEN = 8.0  # seconds; shorter moments are grown with connected context
HOUSEKEEPING = re.compile(r"\b(donat\w*|subscri\w*|resub\w*|gift(ed)? subs?|bits|cheer(ed)?|raid\w*|prime|"
                          r"follow(ed|ing)? the (stream|channel)|thank(s| you)( so much)? (for|chat)|sponsor\w*|"
                          r"promo code|discount code|merch|be right back|brb)\b", re.I)


class TopicTimeline:
    """Per-hop arrays for the whole video, for one topic."""

    def __init__(self, n: int):
        self.n = n
        self.t = (np.arange(n) + 0.5) * HOP
        self.visual = np.zeros(n, np.float32)
        self.speech = np.zeros(n, np.float32)
        self.relevance = np.zeros(n, np.float32)
        self.entertain = np.zeros(n, np.float32)
        self.score = np.zeros(n, np.float32)
        self.sound = np.zeros(n, np.float32)
        self.sentence_rel: dict[int, float] = {}
        self.vision_used = False
        self.sound_used = False


def build_timeline(spec: TopicSpec, transcript: Transcript, audio: AudioFeatures, visual: Optional[VisualFeatures],
                   embedder: TextEmbedder, vision=None, sounds=None) -> TopicTimeline:
    n = len(audio.times)
    tl = TopicTimeline(n)
    # ---- topic sounds (real sound-event model): sirens for a chase, crashes, engines…
    if sounds is not None and spec.sounds and len(sounds.times):
        snd = np.zeros(n, np.float32)
        for g in spec.sounds:
            snd = np.maximum(snd, np.clip((sounds.on_grid(g, tl.t) - 0.12) / 0.45, 0, 1))
        tl.sound = _smooth(snd, 3).astype(np.float32)
        tl.sound_used = True
    # ---- visual relevance (cached CLIP embeddings vs topic concepts)
    if visual is not None and vision is not None and visual.emb is not None and len(visual.times):
        vs = topic_similarity(visual, vision, spec.visual_positive, spec.visual_negative)
        tl.visual = np.interp(tl.t, visual.times, vs).astype(np.float32)
        tl.vision_used = True
    # ---- speech relevance (semantic similarity of sentence windows to the topic)
    sents = transcript.sentences
    if sents:
        windows = []
        for i, s in enumerate(sents):
            nxt = sents[i + 1].text if i + 1 < len(sents) and sents[i + 1].start - s.end < 3 else ""
            windows.append((s.text + " " + nxt).strip())
        queries = [spec.summary] + spec.sub_topics + spec.speech_cues
        queries = [q for q in queries if q]
        E = embedder.embed(windows)
        Q = embedder.embed(queries)
        sims = E @ Q.T
        # best match per sentence, plus a little credit for matching several cues
        top = np.sort(sims, axis=1)[:, ::-1]
        raw = top[:, 0] + 0.15 * top[:, 1:3].mean(axis=1) if top.shape[1] > 1 else top[:, 0]
        kw = [k.lower() for k in spec.keywords if len(k) > 2]
        kw_hits = np.array([sum(1 for k in kw if re.search(r"\b" + re.escape(k), w.lower())) for w in windows], np.float32)
        mu, sd = float(np.median(raw)), float(np.std(raw) + 1e-4)
        rel = 1 / (1 + np.exp(-((raw - mu) / sd - 1.0) * 1.5))
        rel = np.clip(rel + 0.12 * np.minimum(kw_hits, 3), 0, 1)
        # stream housekeeping (donations, subs, sponsor reads) is never the topic
        house = np.array([bool(HOUSEKEEPING.search(w)) for w in windows])
        rel = np.where(house, rel * 0.2, rel)
        rel = _bridge_events(sents, rel)
        rel = np.where(house, np.minimum(rel, 0.15), rel)
        for i, s in enumerate(sents):
            tl.sentence_rel[i] = float(rel[i])
            a, b = int(max(0, s.start - 1.0) / HOP), int((s.end + 1.0) / HOP) + 1
            tl.speech[a:b] = np.maximum(tl.speech[a:b], rel[i])
    # ---- combine: relevance is the gate
    v, s = tl.visual, tl.speech
    if tl.vision_used and spec.needs_visual and spec.needs_speech:
        rel = np.maximum(v, s) + 0.3 * np.minimum(v, s)
    elif tl.vision_used and spec.needs_visual:
        rel = np.maximum(v, 0.7 * s) + 0.2 * np.minimum(v, s)
    else:
        rel = s
    if tl.sound_used:
        # a topic sound supports relevance but never proves it alone (a siren can play anywhere)
        snd = tl.sound
        rel = np.maximum(rel, 0.62 * snd) + 0.18 * np.minimum(rel, snd)
    tl.relevance = np.clip(_smooth(rel, 5), 0, 1)
    # ---- entertainment proxy from audio + verbal reactions
    reaction = np.zeros(n, np.float32)
    for s_ in sents:
        k = len(EXCLAIM.findall(s_.text))
        if k:
            a, b = int(s_.start / HOP), int(s_.end / HOP) + 1
            reaction[a:b] = np.maximum(reaction[a:b], min(1.0, 0.35 * k))
    if sounds is not None and len(sounds.times):
        # real laughter / screams / cheering and impacts (explosions, crashes) from the sound model
        # beat raw loudness: a big laugh at normal volume counts, a loud ad does not
        ev_react, ev_impact = sounds.reaction(tl.t), sounds.impact(tl.t)
        tl.entertain = np.clip(0.4 * audio.excitement[:n] + 0.2 * reaction + 0.3 * ev_react + 0.15 * ev_impact, 0, 1)
    else:
        tl.entertain = np.clip(0.55 * audio.excitement[:n] + 0.25 * reaction + 0.2 * audio.laugh[:n], 0, 1)
    tl.score = _smooth(tl.relevance * (0.55 + 0.45 * _smooth(tl.entertain, 9)), 5)
    tl.score *= (1 - 0.9 * audio.silence[:n] * (tl.speech < 0.2))
    return tl


def _bridge_events(sents, rel: np.ndarray, gap: float = 18.0, hi: float = 0.45) -> np.ndarray:
    """Sentences sandwiched between two on-topic sentences a few seconds apart belong to the
    same continuous event (e.g. the crash in the middle of a chase), so they inherit part of
    the relevance even if their own words don't mention the topic."""
    out = rel.copy()
    on = [i for i in range(len(sents)) if rel[i] >= hi]
    for a, b in zip(on, on[1:]):
        if b - a > 1 and sents[b].start - sents[a].end <= gap:
            fill = 0.75 * min(rel[a], rel[b])
            for k in range(a + 1, b):
                out[k] = max(out[k], fill)
    # the sentence right after an on-topic sentence is often the reaction
    for a in on:
        if a + 1 < len(sents) and sents[a + 1].start - sents[a].end < 2.0:
            out[a + 1] = max(out[a + 1], 0.6 * rel[a])
    return out


def _smooth(x: np.ndarray, k: int) -> np.ndarray:
    if len(x) < k or k <= 1:
        return x.astype(np.float32)
    return np.convolve(x, np.ones(k) / k, mode="same").astype(np.float32)


def _peaks(x: np.ndarray, min_dist: int, max_n: int, floor: float) -> list[int]:
    order = np.argsort(-x)
    chosen: list[int] = []
    for i in order:
        if x[i] < floor or len(chosen) >= max_n:
            break
        if all(abs(i - j) >= min_dist for j in chosen):
            chosen.append(int(i))
    return chosen


def propose(tl: TopicTimeline, transcript: Transcript, audio: AudioFeatures, max_candidates: int = 40,
            max_len: float = 35.0, min_len: float = 4.0) -> list[Candidate]:
    if tl.n == 0:
        return []
    floor = max(0.12, float(np.percentile(tl.score, 70)))
    # look at enough peaks for long streams (≈2 per minute), so that after repeats are removed
    # the judging budget still covers every distinct kind of moment
    n_peaks = int(min(400, max(max_candidates * 2, tl.n * HOP / 30)))
    peaks = _peaks(tl.score, int(10 / HOP), n_peaks, floor)
    cands: list[Candidate] = []
    for p in peaks:
        a, b = _event_region(tl, p)
        start, end = _expand_to_context(a * HOP, (b + 1) * HOP, transcript, audio, tl, max_len)
        if end - start < min_len:
            mid = (start + end) / 2
            start, end = max(0.0, mid - min_len / 2), mid + min_len / 2
        sl = slice(int(start / HOP), int(end / HOP) + 1)
        c = Candidate(cid="", start=round(start, 2), end=round(end, 2),
                      visual_relevance=float(np.max(tl.visual[sl])) if tl.vision_used else 0.0,
                      speech_relevance=float(np.max(tl.speech[sl])),
                      sound_relevance=float(np.max(tl.sound[sl])) if tl.sound_used else 0.0,
                      excitement=float(np.max(tl.entertain[sl])),
                      proposal_score=float(tl.score[p]))
        c.reasons = _reasons(c, tl)
        cands.append(c)
    cands = merge_overlaps(cands, max_len, tl)
    for c in cands:
        _trim_offtopic(c, tl, transcript)
    cands = [c for c in cands if not _is_spillover(c, tl)]
    cands.sort(key=lambda c: -c.proposal_score)
    # don't spend the judging budget on repeats of the same moment (same lines said again)
    from .selection import _same_words

    kept: list[Candidate] = []
    for c in cands:
        if not any(_same_words(c, k, transcript) for k in kept):
            kept.append(c)
        if len(kept) >= max_candidates:
            break
    cands = kept
    for i, c in enumerate(cands):
        c.cid = f"c{i + 1:02d}"
    return cands


def _event_region(tl: TopicTimeline, p: int) -> tuple[int, int]:
    """Extent of the on-topic event around a peak (where relevance stays high)."""
    thr = 0.5 * tl.relevance[p]
    lim = int(22 / HOP)
    a = p
    while a > 0 and p - a < lim and tl.relevance[a - 1] >= thr:
        a -= 1
    b = p
    while b < tl.n - 1 and b - p < lim and tl.relevance[b + 1] >= thr:
        b += 1
    return a, b


def _expand_to_context(start: float, end: float, transcript: Transcript, audio: AudioFeatures, tl: TopicTimeline,
                       max_len: float) -> tuple[float, float]:
    sents = transcript.sentences
    # setup: begin at the sentence that is running at the event start, plus one connected lead-in sentence
    inside = [i for i, s in enumerate(sents) if s.end > start - 0.5 and s.start < end + 0.5]
    if inside:
        first = inside[0]
        if first > 0:
            prev = sents[first - 1]
            if sents[first].start - prev.end < 2.5 and (tl.sentence_rel.get(first - 1, 0) > 0.25 or
                                                          len(prev.text.split()) <= 8):
                first -= 1
        start = min(start, sents[first].start - 0.35)
        last = inside[-1]
        # reaction: keep the next sentence if it follows immediately (the reaction usually comes right after)
        if last + 1 < len(sents) and sents[last + 1].start - sents[last].end < 1.5:
            last += 1
        end = max(end, sents[last].end + 0.6)
    # include an audio reaction peak right after the event (up to 4 s)
    a, b = int(end / HOP), int(min(end + 4.0, (len(audio.times) - 1) * HOP) / HOP)
    if b > a and audio.excitement[a:b].size and audio.excitement[a:b].max() > 0.5:
        end = max(end, (a + int(np.argmax(audio.excitement[a:b])) + 3) * HOP)
    start = max(0.0, start)
    # a moment shorter than ~8 s rarely makes sense to a stranger: grow it with what is
    # connected to it (next/previous sentence when close, otherwise the surrounding non-silent action)
    grow_to = min(GOOD_MIN_LEN, max_len)
    guard = 0
    while end - start < grow_to and guard < 6:
        guard += 1
        nxt = next((s for s in sents if s.start >= end - 0.3), None)
        prv = next((s for s in reversed(sents) if s.end <= start + 0.3), None)
        if nxt is not None and nxt.start - end < 4.0 and not HOUSEKEEPING.search(nxt.text) \
                and nxt.end - start <= max_len:
            end = nxt.end + 0.6
            continue
        if prv is not None and start - prv.end < 3.0 and not HOUSEKEEPING.search(prv.text) \
                and end - prv.start <= max_len:
            start = max(0.0, prv.start - 0.35)
            continue
        # no connected speech: extend into surrounding audible action (not silence)
        need = grow_to - (end - start)
        a, b = int(end / HOP), int(min(end + need, (len(audio.times) - 1) * HOP) / HOP)
        if b > a and audio.silence[a:b].mean() < 0.5:
            end = b * HOP
        a0 = int(max(0.0, start - need) / HOP)
        if a0 < int(start / HOP) and audio.silence[a0:int(start / HOP)].mean() < 0.5:
            start = a0 * HOP
        break
    if end - start > max_len:  # keep the most relevant part
        best_s, best_v = start, -1.0
        step = 1.0
        s0 = start
        while s0 + max_len <= end + 1e-6:
            sl = slice(int(s0 / HOP), int((s0 + max_len) / HOP))
            v = float(tl.score[sl].sum())
            if v > best_v:
                best_v, best_s = v, s0
            s0 += step
        start, end = best_s, best_s + max_len
        start, end = snap_to_words(start, end, transcript)
    return start, end


def _is_spillover(c: Candidate, tl: "TopicTimeline", edge: float = 5.0) -> bool:
    """A 'moment' whose only on-topic seconds are the tail/start of a neighbouring event
    (e.g. a siren fading out as unrelated talk begins) is not a moment of its own."""
    a, b = int(c.start / HOP), min(tl.n, int(c.end / HOP) + 1)
    on = np.where(tl.relevance[a:b] >= 0.3)[0]
    n = max(1, b - a)
    if len(on) == 0 or len(on) / n >= 0.4:
        return False
    k = int(edge / HOP)
    return bool(np.all((on < k) | (on >= n - k)))


def _trim_offtopic(c: Candidate, tl: "TopicTimeline", transcript: Transcript, lead_keep: float = 3.0,
                   tail_keep: float = 5.0) -> None:
    """Context expansion and merging can pull in long stretches of unrelated footage before or
    after the event (e.g. the end of a different scene). Keep a few seconds of setup/reaction,
    drop the rest."""
    a, b = int(c.start / HOP), min(tl.n, int(c.end / HOP) + 1)
    rel = tl.relevance[a:b]
    on = np.where(rel >= 0.3)[0]
    if len(on) == 0:
        return
    t_first, t_last = (a + on[0]) * HOP, (a + on[-1] + 1) * HOP
    start, end = c.start, c.end
    if t_first - start > lead_keep + 3.0:
        start = t_first - lead_keep
        # begin on a sentence boundary so the setup isn't cut mid-thought
        prev = [s_.start for s_ in transcript.sentences if start - 2.0 <= s_.start <= t_first]
        if prev:
            start = min(prev) - 0.3
    if end - t_last > tail_keep + 3.0:
        end = t_last + tail_keep
    # the streamer moving on to an unrelated subject ends the moment ("Anyway, yesterday I…")
    for s_ in transcript.sentences:
        if max(t_last - 1.0, start + 3.0) <= s_.start < end and tl.sentence_rel.get(s_.idx, 1.0) < 0.2:
            end = max(t_last + 1.0, s_.start - 0.2)
            break
    # …and unrelated talk right before the event isn't its setup. The event's start is the
    # first clearly on-topic sentence (or the first on-topic second if nothing is said).
    inside = [s_ for s_ in transcript.sentences if start <= s_.start < end]
    strong = [s_.start for s_ in inside if tl.sentence_rel.get(s_.idx, 0.0) >= 0.45]
    anchor = min(strong[0], t_first) if strong and strong[0] - t_first < 6.0 else (strong[0] if strong else t_first)
    for s_ in reversed(inside):
        if s_.end <= min(anchor + 0.5, end - 3.0) and tl.sentence_rel.get(s_.idx, 1.0) < 0.2:
            start = max(start, min(anchor - 1.0, s_.end + 0.2))
            break
    if (start, end) != (c.start, c.end) and end - start >= 3.0:
        c.start, c.end = snap_to_words(max(0.0, start), end, transcript)


def snap_to_words(start: float, end: float, transcript: Transcript) -> tuple[float, float]:
    """Move cut points out of the middle of words (each point moves once, to the nearest
    boundary of the word it falls in, never cascading into the following words)."""
    words = [w for s in transcript.sentences for w in s.words]
    new_start, new_end = start, end
    for i, w in enumerate(words):
        if w.start < start < w.end:
            prev_end = words[i - 1].end if i > 0 else 0.0
            new_start = max(prev_end, w.start - 0.1)
        if w.start < end < w.end:
            nxt = words[i + 1].start if i + 1 < len(words) else w.end + 1.0
            new_end = min(nxt, w.end + 0.15)
    return max(0.0, new_start), new_end


def merge_overlaps(cands: list[Candidate], max_len: float, tl: Optional["TopicTimeline"] = None) -> list[Candidate]:
    cands = sorted(cands, key=lambda c: c.start)
    out: list[Candidate] = []
    for c in cands:
        if out:
            p = out[-1]
            inter = min(p.end, c.end) - max(p.start, c.start)
            union_len = max(p.end, c.end) - min(p.start, c.start)
            # same continuous event: the gap between them is still on-topic (e.g. the crash mid-chase)
            gap_on_topic = False
            if tl is not None and -inter < 16 and union_len <= max_len:
                # judge the gap's interior: relevance always ramps up near the next event's edge
                g0, g1 = p.end, c.start
                if g1 - g0 > 4.0:
                    g0, g1 = g0 + 1.5, g1 - 1.5
                sl = slice(int(g0 / HOP), int(g1 / HOP) + 1)
                gap = tl.relevance[sl]
                gap_on_topic = gap.size > 0 and float(gap.max()) >= 0.3 and float((gap >= 0.2).mean()) >= 0.5
                # two clearly on-topic moments a few seconds apart are one event (a pause mid-chase)
                rel_p = max(p.visual_relevance, p.speech_relevance, p.sound_relevance)
                rel_c = max(c.visual_relevance, c.speech_relevance, c.sound_relevance)
                gap_on_topic = gap_on_topic or (-inter <= 5.0 and min(rel_p, rel_c) >= 0.45)
            # overlapping, separated by a tiny gap, or one event: merge into one clip with full context
            # (two moments that merely sit next to each other are NOT merged: that glued the end of
            # an unrelated scene onto the start of a chase)
            if (inter > 0.5 * min(p.duration, c.duration) or (inter > 0.0 and union_len <= max_len * 0.9)
                    or gap_on_topic):
                if union_len <= max_len:
                    p.start, p.end = min(p.start, c.start), max(p.end, c.end)
                    p.proposal_score = max(p.proposal_score, c.proposal_score)
                    p.visual_relevance = max(p.visual_relevance, c.visual_relevance)
                    p.speech_relevance = max(p.speech_relevance, c.speech_relevance)
                    p.sound_relevance = max(p.sound_relevance, c.sound_relevance)
                    p.excitement = max(p.excitement, c.excitement)
                    p.reasons = list(dict.fromkeys(p.reasons + c.reasons))
                    continue
                if c.proposal_score > p.proposal_score:
                    out[-1] = c
                continue
        out.append(c)
    return out


def _reasons(c: Candidate, tl: TopicTimeline) -> list[str]:
    r = []
    if c.visual_relevance > 0.6:
        r.append("on-screen action matches the topic")
    if c.speech_relevance > 0.6:
        r.append("what is said matches the topic")
    if c.sound_relevance > 0.5:
        r.append("topic sounds heard (e.g. sirens, crashes)")
    if c.excitement > 0.55:
        r.append("strong audio reaction")
    return r or ["weak match"]


def relevance_profile(tl: TopicTimeline, start: float, end: float) -> dict:
    sl = slice(int(start / HOP), int(end / HOP) + 1)
    return {"visual": float(clamp(tl.visual[sl].max() if tl.visual[sl].size else 0)),
            "speech": float(clamp(tl.speech[sl].max() if tl.speech[sl].size else 0)),
            "entertain": float(clamp(tl.entertain[sl].max() if tl.entertain[sl].size else 0))}
