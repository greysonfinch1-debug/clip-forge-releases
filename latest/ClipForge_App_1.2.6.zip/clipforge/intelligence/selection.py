"""Choose the strongest combination of judged candidates for the requested length.

Filters (off-topic, low quality, missing context, rejected), removes repeats (overlapping
time ranges and near-identical moments by meaning), then picks a diverse set by score and
fits it to the target duration, trimming toward each clip's strongest moment rather than
dropping its setup or reaction.
"""
from __future__ import annotations

import re
from typing import Optional

import numpy as np

from ..core.models import Candidate, Transcript
from ..providers.base import TextEmbedder
from .proposals import snap_to_words

MIN_TOPIC = 5.0


def filter_reasons(c: Candidate, min_topic: float = MIN_TOPIC) -> list[str]:
    r = []
    if c.why_matches.startswith("Rejected"):
        r.append(c.why_matches)
    if c.topic_match < min_topic:
        r.append(f"topic match {c.topic_match:.0f}/10 is below {min_topic:.0f}")
    if c.context_completeness < 4:
        r.append("not enough context to understand")
    if c.visual_quality < 3:
        r.append("low visual quality (dark or blurry)")
    if c.audio_quality < 2:
        r.append("almost no usable audio")
    return r


def select_clips(cands: list[Candidate], transcript: Transcript, target_seconds: float, desired_clips: int = 0,
                 embedder: Optional[TextEmbedder] = None, narration_share: float = 0.15,
                 min_topic: float = MIN_TOPIC) -> list[Candidate]:
    for c in cands:
        if not c.locked:
            c.included = False
    pool = [c for c in cands if not c.excluded and (c.locked or not filter_reasons(c, min_topic))]
    pool.sort(key=lambda c: -c.final_score)
    pool = _dedupe(pool, embedder, transcript)
    budget = max(8.0, target_seconds * (1 - narration_share))
    chosen: list[Candidate] = [c for c in pool if c.locked]
    rest = [c for c in pool if not c.locked]
    if desired_clips > 0:
        for c in rest:
            if len(chosen) >= desired_clips:
                break
            chosen.append(c)
    else:
        best = rest[0].final_score if rest else 0
        total = sum(c.duration for c in chosen)
        for c in rest:
            if chosen and c.final_score < 0.55 * best:
                break
            # plan with the gently-trimmed length, so the Short is filled with fewer, fuller clips
            est = 0.5 * (_min_len(c, 0) + _min_len(c, 1))  # between a gentle and a firm trim
            if chosen and total + est > budget * 1.05:
                continue  # too long even when trimmed; a shorter, slightly weaker clip may still fit
            chosen.append(c)
            total += est
    # pacing: no single clip may take over the Short (keeps cuts coming; long events are
    # trimmed around their key moment, keeping setup and reaction)
    # (with a single usable moment there is nothing else to cut to, so it may fill the Short)
    cap = max(12.0, 0.45 * target_seconds) if len(chosen) > 1 else budget
    for c in chosen:
        if c.duration > cap and not c.locked:
            _trim_to(c, cap, transcript)
    _fit(chosen, budget, transcript)
    for i, c in enumerate(sorted(cands, key=lambda c: -c.final_score)):
        c.rank = i + 1
    for c in chosen:
        c.included = True
    return chosen


def _shingles(c: Candidate, transcript: Optional[Transcript], n: int = 4) -> set[tuple[str, ...]]:
    if transcript is None:
        return set()
    words = [re.sub(r"[^a-z0-9]", "", w.text.lower()) for w in transcript.words_between(c.start, c.end)]
    words = [w for w in words if w]
    return {tuple(words[i:i + n]) for i in range(len(words) - n + 1)}


def _same_words(a: Candidate, b: Candidate, transcript: Optional[Transcript]) -> bool:
    """The same lines are said in both clips (robust to different sentence splitting)."""
    sa, sb = _shingles(a, transcript), _shingles(b, transcript)
    if len(sa) < 3 or len(sb) < 3:
        return False
    return len(sa & sb) / min(len(sa), len(sb)) >= 0.5


def _dedupe(pool: list[Candidate], embedder: Optional[TextEmbedder],
            transcript: Optional[Transcript] = None) -> list[Candidate]:
    kept: list[Candidate] = []
    vecs = None
    if embedder is not None and len(pool) > 1:
        try:
            vecs = embedder.embed([re.sub(r"\[[+-]?[\d.]+s\]", " ", f"{c.description} {c.evidence.transcript}").strip()
                                  for c in pool])
        except Exception:
            vecs = None
    kept_idx: list[int] = []
    for i, c in enumerate(pool):
        dup = False
        for j in kept_idx:
            k = pool[j]
            inter = min(k.end, c.end) - max(k.start, c.start)
            if inter > 0.3 * min(k.duration, c.duration):
                dup = True
                break
            if _same_words(c, k, transcript):
                dup = True  # the same lines are said in both: a repeated moment
                break
            sim = float(vecs[i] @ vecs[j]) if vecs is not None else 0.0
            if sim > 0.97 or (sim > 0.93 and abs(c.start - k.start) < 600):
                dup = True  # (near-)identical moment anywhere, or the same kind of moment close in time
                break
        if not dup or c.locked:
            kept.append(c)
            kept_idx.append(i)
    return kept


# How much of a clip may be trimmed around its key moment. Tier 0 keeps generous setup and
# reaction; tier 1 is used only when the alternative is dropping a good clip entirely.
_TIERS = [(3.0, 4.0, 0.4), (2.0, 3.0, 0.75)]   # (setup kept before focus, reaction kept after, share of rest cuttable)


def _cuttable(c: Candidate, tier: int = 0) -> tuple[float, float, float]:
    """(focus, max cut before focus, max cut after focus) that still keeps setup and reaction."""
    keep_before, keep_after, share = _TIERS[tier]
    focus = c.best_moment if c.best_moment >= 0 else (c.start + c.end) / 2
    focus = min(max(focus, c.start), c.end)
    before = max(0.0, focus - c.start - keep_before)
    after = max(0.0, (c.end - focus - keep_after) * share)
    return focus, before, after


MIN_CLIP = 6.0   # never trim a clip below this; drop the weakest clip instead


def _min_len(c: Candidate, tier: int = 0) -> float:
    _, b, a = _cuttable(c, tier)
    return max(min(c.duration, MIN_CLIP), c.duration - b - a)


def _trim_to(c: Candidate, length: float, transcript: Transcript) -> None:
    """Shorten a clip to about ``length`` seconds around its key moment (60 % of the cut taken
    from before it, as setups run longer than reactions), never below the protected margins."""
    focus, rb, ra = _cuttable(c, len(_TIERS) - 1)
    need = c.duration - length
    if need <= 0.2:
        return
    cut_b = min(rb, need * 0.6)
    cut_a = min(ra, need - cut_b)
    cut_b = min(rb, need - cut_a)
    c.start, c.end = snap_to_words(c.start + cut_b, c.end - cut_a, transcript)


def _fit(chosen: list[Candidate], budget: float, transcript: Transcript) -> None:
    """Trim toward each clip's key moment; if even the stronger trim can't fit without losing
    setup or payoff, drop the weakest unlocked clip instead of butchering the good ones."""
    while chosen:
        total = sum(c.duration for c in chosen)
        if total <= budget:
            return
        excess = total - budget
        def room(t):
            return sum(min(b + a, max(0.0, c.duration - MIN_CLIP)) for c, (_, b, a) in
                       ((c, _cuttable(c, t)) for c in chosen))
        tier = next((t for t in range(len(_TIERS)) if room(t) >= excess), None)
        if tier is None:
            if len(chosen) > 1:
                weakest = min((c for c in chosen if not c.locked), key=lambda c: c.final_score, default=None)
                if weakest is not None:
                    chosen.remove(weakest)
                    continue
            tier = len(_TIERS) - 1
        # distribute cuts, weaker clips cut more
        weights = np.array([max(0.05, 1.0 - c.final_score / 100.0) for c in chosen])
        rooms = []
        for c in chosen:
            f, b, a = _cuttable(c, tier)
            cap = max(0.0, c.duration - MIN_CLIP)
            if b + a > cap:  # keep at least MIN_CLIP seconds
                k = cap / (b + a)
                b, a = b * k, a * k
            rooms.append((f, b, a))
        want = [excess * w / weights.sum() for w in weights]
        # redistribute what a clip can't absorb to the others
        for _ in range(3):
            spill = sum(max(0.0, w - (rb + ra)) for w, (_, rb, ra) in zip(want, rooms))
            if spill <= 1e-3:
                break
            free = [max(0.0, (rb + ra) - w) for w, (_, rb, ra) in zip(want, rooms)]
            tot_free = sum(free) or 1.0
            want = [min(w, rb + ra) + spill * f / tot_free for w, (_, rb, ra), f in zip(want, rooms, free)]
        for c, (focus, rb, ra), cut in zip(chosen, rooms, want):
            cut = min(cut * 1.03, rb + ra)
            cut_after = min(ra, cut * 0.5)            # take from both sides, setup a bit more
            cut_before = min(rb, cut - cut_after)
            cut_after = min(ra, cut - cut_before)
            if cut_before + cut_after > 0.2:
                c.start, c.end = snap_to_words(c.start + cut_before, c.end - cut_after, transcript)
        return
