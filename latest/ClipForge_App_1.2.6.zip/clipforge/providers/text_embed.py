"""Text embedding backends, used to match transcript passages to the topic by meaning.

* ``ollama``  – local embedding model through Ollama (default ``nomic-embed-text``).
* ``openai``  – any OpenAI-compatible ``/v1/embeddings`` endpoint.
* ``lexical`` – built-in, no model: hashed word + character n-gram TF vectors. Catches
  wording overlap only (paraphrases are missed), so the topic is expanded with synonyms
  first. Used automatically when no embedding model is reachable.
"""
from __future__ import annotations

import hashlib
import re

import numpy as np

from .base import ProviderUnavailable, TextEmbedder, register


def _norm(m: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(m, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return (m / n).astype(np.float32)


@register("embedder", "ollama")
class OllamaEmbedder(TextEmbedder):
    def __init__(self, model: str = "nomic-embed-text", base_url: str = "http://localhost:11434", **_):
        import requests

        self.model, self.base = model, base_url.rstrip("/")
        self.s = requests.Session()
        try:
            r = self.s.post(self.base + "/api/embed", json={"model": self.model, "input": ["test"]}, timeout=60)
            if r.status_code == 404 and "not found" in r.text.lower():
                raise ProviderUnavailable(f"Ollama model '{model}' is not pulled. Run: ollama pull {model}")
            r.raise_for_status()
        except ProviderUnavailable:
            raise
        except Exception as e:
            raise ProviderUnavailable(f"Ollama embeddings unavailable at {self.base}: {e}") from e

    def embed(self, texts: list[str]) -> np.ndarray:
        out = []
        prefix = "search_document: " if "nomic" in self.model else ""
        for i in range(0, len(texts), 64):
            batch = [prefix + (t or " ") for t in texts[i:i + 64]]
            r = self.s.post(self.base + "/api/embed", json={"model": self.model, "input": batch}, timeout=300)
            r.raise_for_status()
            out.extend(r.json()["embeddings"])
        return _norm(np.asarray(out, dtype=np.float32)) if out else np.zeros((0, 1), np.float32)


@register("embedder", "openai")
class OpenAIEmbedder(TextEmbedder):
    def __init__(self, model: str = "text-embedding-3-small", base_url: str = "https://api.openai.com/v1",
                 api_key: str = "", **_):
        import requests

        if not api_key:
            raise ProviderUnavailable("No API key set for the OpenAI-compatible embedding provider")
        self.model, self.base, self.key = model, base_url.rstrip("/"), api_key
        self.s = requests.Session()

    def embed(self, texts: list[str]) -> np.ndarray:
        out = []
        for i in range(0, len(texts), 128):
            r = self.s.post(self.base + "/embeddings", headers={"Authorization": f"Bearer {self.key}"},
                            json={"model": self.model, "input": [t or " " for t in texts[i:i + 128]]}, timeout=120)
            if r.status_code >= 400:
                raise ProviderUnavailable(f"Embedding API error {r.status_code}: {r.text[:200]}")
            out.extend(d["embedding"] for d in r.json()["data"])
        return _norm(np.asarray(out, dtype=np.float32))


_TOKEN = re.compile(r"[a-z0-9']+")
_STOP = set("""a an the and or but if then so of to in on at for with from by is are was were be been being it
this that these those i you he she we they me him her us them my your his our their its im i'm you're it's
just like really very oh uh um yeah yes no not do does did doing have has had having what who where when
why how all any some can could would should will shall may might must there here up down out over""".split())


@register("embedder", "lexical")
class LexicalEmbedder(TextEmbedder):
    """Hashing-trick TF vectors over word stems and character trigrams. Deterministic, no model."""
    DIM = 4096

    def __init__(self, **_):
        pass

    @staticmethod
    def _stem(w: str) -> str:
        for suf in ("ing", "ers", "er", "ed", "es", "s", "ly"):
            if len(w) > len(suf) + 2 and w.endswith(suf):
                return w[: -len(suf)]
        return w

    def _vec(self, text: str) -> np.ndarray:
        v = np.zeros(self.DIM, np.float32)
        toks = [self._stem(t) for t in _TOKEN.findall((text or "").lower()) if t not in _STOP]
        for t in toks:
            v[int(hashlib.md5(("w:" + t).encode()).hexdigest(), 16) % self.DIM] += 1.0
            padded = f"#{t}#"
            for i in range(len(padded) - 2):
                v[int(hashlib.md5(("c:" + padded[i:i + 3]).encode()).hexdigest(), 16) % self.DIM] += 0.25
        for a, b in zip(toks, toks[1:]):
            v[int(hashlib.md5(("b:" + a + "_" + b).encode()).hexdigest(), 16) % self.DIM] += 0.7
        return np.log1p(v)

    def embed(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.DIM), np.float32)
        return _norm(np.stack([self._vec(t) for t in texts]))
