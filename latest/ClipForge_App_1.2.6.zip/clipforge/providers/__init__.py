"""Provider registry. Importing this package registers every built-in backend."""
from . import audio_ai, base, llm, text_embed, transcribe, tts, vision  # noqa: F401
from .base import ProviderUnavailable, available, create  # noqa: F401
