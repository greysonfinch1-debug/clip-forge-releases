"""Audio AI models (run locally with sherpa-onnx, downloaded once from the sherpa-onnx
GitHub releases):

* ``ced`` (AudioTagger) – CED-mini, an AudioSet sound-event classifier (527 classes):
  real laughter, screaming, sirens, explosions, gunfire, crashes, skidding, engines,
  aircraft, music, cheering… This replaces guesswork from loudness alone, so ClipForge
  can find an exciting chase with no talking, and tell a big laugh from a loud ad.
* ``pyannote`` (Diarizer) – pyannote segmentation-3.0 + NVIDIA TitaNet-small speaker
  embeddings: who spoke when, so the judge and the captions can tell speakers apart.
"""
from __future__ import annotations

import csv
import os
from pathlib import Path

import numpy as np

from .base import AudioTagger, Diarizer, ProviderUnavailable, download_file, extract_tar, register

SHERPA = "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
CED_DIR = "sherpa-onnx-ced-mini-audio-tagging-2024-04-19"
SEG_DIR = "sherpa-onnx-pyannote-segmentation-3-0"
EMB_FILE = "nemo_en_titanet_small.onnx"

# Sound groups ClipForge reasons about, each a set of AudioSet class names.
SOUND_GROUPS: dict[str, list[str]] = {
    "laughter": ["Laughter", "Baby laughter", "Giggle", "Snicker", "Belly laugh", "Chuckle, chortle"],
    "screaming": ["Screaming", "Shout", "Yell", "Bellow", "Whoop", "Battle cry", "Children shouting"],
    "cheering": ["Cheering", "Applause", "Crowd", "Clapping"],
    "siren": ["Siren", "Police car (siren)", "Ambulance (siren)", "Fire engine, fire truck (siren)",
              "Emergency vehicle", "Civil defense siren"],
    "explosion": ["Explosion", "Boom", "Burst, pop", "Eruption", "Fireworks", "Firecracker"],
    "gunfire": ["Gunshot, gunfire", "Machine gun", "Fusillade", "Artillery fire", "Cap gun"],
    "crash": ["Smash, crash", "Breaking", "Glass", "Shatter", "Crushing", "Thump, thud", "Bang", "Slam"],
    "skidding": ["Skidding", "Tire squeal"],
    "vehicle": ["Vehicle", "Car", "Engine", "Accelerating, revving, vroom", "Race car, auto racing",
                "Motorcycle", "Car passing by", "Traffic noise, roadway noise", "Truck"],
    "aircraft": ["Aircraft", "Helicopter", "Fixed-wing aircraft, airplane", "Jet engine", "Propeller, airscrew",
                 "Aircraft engine"],
    "water": ["Water", "Splash, splatter", "Boat, Water vehicle", "Ocean", "Waves, surf", "Motorboat, speedboat"],
    "alarm": ["Alarm", "Car alarm", "Smoke detector, smoke alarm", "Fire alarm", "Buzzer"],
    "music": ["Music"],
    "speech": ["Speech", "Conversation", "Narration, monologue"],
    "animal": ["Animal", "Dog", "Cat", "Domestic animals, pets"],
}
# groups that signal an entertaining reaction or event
REACTION_GROUPS = {"laughter": 1.0, "screaming": 0.85, "cheering": 0.7}
IMPACT_GROUPS = {"explosion": 0.6, "crash": 0.6, "gunfire": 0.5, "skidding": 0.45}


def _ensure_tar(models_dir: Path, name: str, url: str, progress, label: str) -> Path:
    d = models_dir / name
    if not d.exists() or not any(d.glob("*.onnx")):
        arc = models_dir / (name + ".tar.bz2")
        download_file(url, arc, progress, label)
        extract_tar(arc, models_dir)
        try:
            arc.unlink()
        except OSError:
            pass
    return d


@register("audio_tagger", "ced")
class CedTagger(AudioTagger):
    def __init__(self, models_dir: str, threads: int = 0, progress=None, **_):
        try:
            import sherpa_onnx
        except ImportError as e:
            raise ProviderUnavailable("sherpa-onnx is not installed") from e
        try:
            from ..model_manager import ensure

            d = ensure("ced", models_dir, progress) / CED_DIR
        except Exception as e:  # noqa: BLE001
            raise ProviderUnavailable(f"Could not download the sound-event model: {e}") from e
        threads = threads or max(1, min(4, os.cpu_count() or 2))
        labels_csv = d / "class_labels_indices.csv"
        with open(labels_csv, newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))[1:]
        self._labels = [r[2] for r in rows]
        cfg = sherpa_onnx.AudioTaggingConfig(
            model=sherpa_onnx.AudioTaggingModelConfig(ced=str(d / "model.int8.onnx"), num_threads=threads),
            labels=str(labels_csv), top_k=len(self._labels))
        if not cfg.validate():
            raise ProviderUnavailable("Sound-event model files are incomplete; delete the folder to re-download")
        self.at = sherpa_onnx.AudioTagging(cfg)
        self._id = "ced-mini-2024-04-19"

    @property
    def model_id(self) -> str:
        return self._id

    def labels(self) -> list[str]:
        return self._labels

    def tag(self, samples: np.ndarray, sr: int) -> np.ndarray:
        s = self.at.create_stream()
        s.accept_waveform(sr, samples.astype(np.float32))
        out = np.zeros(len(self._labels), np.float32)
        for e in self.at.compute(s):
            out[e.index] = e.prob
        return out


@register("diarizer", "pyannote")
class PyannoteDiarizer(Diarizer):
    def __init__(self, models_dir: str, threads: int = 0, threshold: float = 0.9, progress=None, **_):
        try:
            import sherpa_onnx
        except ImportError as e:
            raise ProviderUnavailable("sherpa-onnx is not installed") from e
        md = Path(models_dir)
        try:
            from ..model_manager import ensure

            seg = ensure("speaker_seg", md, progress) / SEG_DIR
            emb = ensure("speaker_emb", md, progress) / EMB_FILE
        except Exception as e:  # noqa: BLE001
            raise ProviderUnavailable(f"Could not download the speaker models: {e}") from e
        threads = threads or max(1, min(4, os.cpu_count() or 2))
        cfg = sherpa_onnx.OfflineSpeakerDiarizationConfig(
            segmentation=sherpa_onnx.OfflineSpeakerSegmentationModelConfig(
                pyannote=sherpa_onnx.OfflineSpeakerSegmentationPyannoteModelConfig(model=str(seg / "model.int8.onnx")),
                num_threads=threads),
            embedding=sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=str(emb), num_threads=threads),
            clustering=sherpa_onnx.FastClusteringConfig(num_clusters=-1, threshold=threshold),
            min_duration_on=0.3, min_duration_off=0.5)
        if not cfg.validate():
            raise ProviderUnavailable("Speaker model files are incomplete; delete them to re-download")
        self.sd = sherpa_onnx.OfflineSpeakerDiarization(cfg)
        self.ext = sherpa_onnx.SpeakerEmbeddingExtractor(
            sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=str(emb), num_threads=threads))
        self._id = f"pyannote3+titanet-s@{threshold}"

    @property
    def model_id(self) -> str:
        return self._id

    def diarize(self, samples: np.ndarray, sr: int, progress=None) -> list[tuple[float, float, int]]:
        if sr != self.sd.sample_rate:
            raise ValueError(f"diarizer expects {self.sd.sample_rate} Hz")
        cb = None
        if progress:
            def cb(done, total):  # noqa: ANN001
                progress(done / max(1, total), "Identifying speakers")
                return 0
        res = self.sd.process(samples.astype(np.float32), callback=cb).sort_by_start_time()
        return [(float(r.start), float(r.end), int(r.speaker)) for r in res]

    def embed(self, samples: np.ndarray, sr: int) -> np.ndarray:
        """Unit-length voice embedding (used to link speakers across chunks of a long stream)."""
        st = self.ext.create_stream()
        st.accept_waveform(sr, samples.astype(np.float32))
        st.input_finished()
        v = np.array(self.ext.compute(st), np.float32)
        return v / (np.linalg.norm(v) + 1e-9)
