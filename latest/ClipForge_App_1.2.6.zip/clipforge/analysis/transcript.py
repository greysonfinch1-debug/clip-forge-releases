"""Cached transcription of a source's analysis audio."""
from __future__ import annotations

from ..core.cache import SourceCache
from ..core.models import Transcript


def get_transcript(audio_path: str, cache: SourceCache, transcriber_factory, progress=None, cancel=None) -> Transcript:
    """``transcriber_factory`` is only called when no cached transcript exists (avoids loading models)."""
    data = cache.load_json("transcript.json")
    if data:
        return Transcript.from_dict(data)
    tr = transcriber_factory()
    transcript = tr.transcribe(audio_path, progress=progress, cancel=cancel)
    cache.save_json("transcript.json", transcript.to_dict())
    if progress:
        progress(1.0, f"Transcribed {len(transcript.sentences)} sentences")
    return transcript


def speech_density(transcript: Transcript, n_hops: int, hop: float) -> list[float]:
    """Words per second for each hop (used to tell talk from gameplay-only stretches)."""
    dens = [0.0] * n_hops
    for s in transcript.sentences:
        for w in s.words:
            i = int(w.start / hop)
            if 0 <= i < n_hops:
                dens[i] += 1.0 / hop
    return dens
