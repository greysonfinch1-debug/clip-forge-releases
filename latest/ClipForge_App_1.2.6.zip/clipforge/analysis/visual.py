"""Visual analysis of the low-resolution analysis copy.

One pass over sampled frames produces, per frame:
  * a CLIP embedding (if a vision model is available) – cached, reused for every topic;
  * scene-change strength, motion energy, sharpness and brightness (quality/editing signals);
  * a horizontal motion profile (where the action is, for smart vertical cropping);
  * face boxes (to find a streamer's facecam overlay for the facecam-split layout).

Topic matching against the cached embeddings happens in ``topic_similarity`` and costs
milliseconds, so a new topic never re-reads the video.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..core.cache import SourceCache
from ..core.ffmpeg import iter_frames, media_info

VERSION = 3
PROFILE_BINS = 24


@dataclass
class VisualFeatures:
    times: np.ndarray
    scene: np.ndarray        # 0..1 scene-change strength vs previous frame
    motion: np.ndarray       # 0..1 normalised motion energy
    sharp: np.ndarray        # 0..1 sharpness
    bright: np.ndarray       # 0..1 mean brightness
    profile: np.ndarray      # (n, PROFILE_BINS) horizontal motion distribution
    emb: Optional[np.ndarray] = None   # (n, d) CLIP embeddings or None
    emb_model: str = ""
    facecam: Optional[list] = None     # [x, y, w, h] as fractions of the frame, or None
    every: float = 1.0

    def idx(self, start: float, end: float) -> np.ndarray:
        return np.where((self.times >= start) & (self.times <= end))[0]


def analyze_visual(proxy_path: str, cache: SourceCache, every: float, vision=None, height: int = 360,
                   progress=None, cancel=None) -> VisualFeatures:
    model_id = vision.model_id if vision is not None else ""
    cached = cache.load_npz("visual_features.npz")
    if cached is not None and int(cached["version"][0]) == VERSION and abs(float(cached["every"][0]) - every) < 1e-6:
        have_emb = "emb" in cached and str(cached["emb_model"][0]) == model_id
        if have_emb or vision is None:
            return _from_cache(cached, every, model_id if have_emb else "")
    import cv2

    info = media_info(proxy_path)
    total = max(1.0, info["duration"])
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    times, scene, motion, sharp, bright, profile, faces = [], [], [], [], [], [], []
    embs: list[np.ndarray] = []
    batch_imgs: list[np.ndarray] = []
    prev_gray, prev_hist = None, None

    def flush_batch():
        if vision is not None and batch_imgs:
            embs.append(vision.encode_images(batch_imgs))
            batch_imgs.clear()

    for t, frame in iter_frames(proxy_path, every, height, cancel):
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        small = cv2.resize(gray, (160, 90))
        hsv = cv2.cvtColor(cv2.resize(frame, (160, 90)), cv2.COLOR_RGB2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [16, 8], [0, 180, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        if prev_gray is None:
            sc, mo, prof = 0.0, 0.0, np.zeros(PROFILE_BINS, np.float32)
        else:
            sc = float(cv2.compareHist(prev_hist, hist, cv2.HISTCMP_BHATTACHARYYA))
            diff = cv2.absdiff(small, prev_gray).astype(np.float32)
            mo = float(diff.mean())
            col = diff.mean(axis=0)
            prof = np.array([c.mean() for c in np.array_split(col, PROFILE_BINS)], np.float32)
        sh = float(cv2.Laplacian(small, cv2.CV_64F).var())
        times.append(t)
        scene.append(sc)
        motion.append(mo)
        sharp.append(sh)
        bright.append(float(small.mean()) / 255.0)
        profile.append(prof)
        if len(times) % 10 == 1:  # face detection on every 10th sample is plenty for a fixed overlay
            fs = cascade.detectMultiScale(gray, scaleFactor=1.15, minNeighbors=6, minSize=(24, 24))
            h, w = gray.shape
            faces.extend([(x / w, y / h, fw / w, fh / h) for (x, y, fw, fh) in fs])
        prev_gray, prev_hist = small, hist
        if vision is not None:
            batch_imgs.append(frame)
            if len(batch_imgs) >= 32:
                flush_batch()
        if progress and len(times) % 20 == 0:
            progress(min(0.99, t / total), "Analysing visuals")
    flush_batch()
    n = len(times)
    mo = np.asarray(motion, np.float32)
    feats = VisualFeatures(
        times=np.asarray(times, np.float32),
        scene=np.clip(np.asarray(scene, np.float32) / 0.6, 0, 1),
        motion=np.clip(mo / (np.percentile(mo, 95) + 1e-3), 0, 1) if n else mo,
        sharp=np.clip(np.log1p(np.asarray(sharp, np.float32)) / 7.0, 0, 1),
        bright=np.asarray(bright, np.float32),
        profile=np.asarray(profile, np.float32).reshape(n, PROFILE_BINS) if n else np.zeros((0, PROFILE_BINS), np.float32),
        emb=np.concatenate(embs).astype(np.float16) if embs else None,
        emb_model=model_id if embs else "",
        facecam=_facecam_box(faces, n),
        every=every,
    )
    arrays = dict(version=np.array([VERSION]), every=np.array([every]), times=feats.times, scene=feats.scene,
                  motion=feats.motion, sharp=feats.sharp, bright=feats.bright, profile=feats.profile,
                  facecam=np.array(feats.facecam if feats.facecam else [-1, -1, -1, -1], np.float32),
                  emb_model=np.array([feats.emb_model]))
    if feats.emb is not None:
        arrays["emb"] = feats.emb
    cache.save_npz("visual_features.npz", **arrays)
    if progress:
        progress(1.0, "Visuals analysed")
    return feats


def _from_cache(c: dict, every: float, model_id: str) -> VisualFeatures:
    fc = c["facecam"].tolist()
    return VisualFeatures(times=c["times"], scene=c["scene"], motion=c["motion"], sharp=c["sharp"], bright=c["bright"],
                          profile=c["profile"], emb=c.get("emb") if model_id else None, emb_model=model_id,
                          facecam=None if fc[0] < 0 else fc, every=every)


def _facecam_box(faces: list, n_frames: int) -> Optional[list]:
    """A facecam is a face that stays in roughly the same place in many sampled frames."""
    if not faces or n_frames < 5:
        return None
    arr = np.asarray(faces)
    cx, cy = arr[:, 0] + arr[:, 2] / 2, arr[:, 1] + arr[:, 3] / 2
    best, best_n = None, 0
    for i in range(len(arr)):
        close = (np.abs(cx - cx[i]) < 0.06) & (np.abs(cy - cy[i]) < 0.06)
        if close.sum() > best_n:
            best_n, best = close.sum(), close
    checked = max(1, n_frames // 10)
    if best is None or best_n < max(3, 0.4 * checked):
        return None
    sel = arr[best]
    fx, fy, fw, fh = np.median(sel, axis=0)
    # expand the face box to the typical webcam overlay around it
    w, h = min(0.45, fw * 3.2), min(0.5, fh * 3.0)
    x = float(np.clip(fx + fw / 2 - w / 2, 0, 1 - w))
    y = float(np.clip(fy + fh / 2 - h / 2.2, 0, 1 - h))
    return [x, y, float(w), float(h)]


def topic_similarity(feats: VisualFeatures, vision, positive: list[str], negative: list[str]) -> np.ndarray:
    """Per-frame visual topic score (0..1) from cached CLIP embeddings.

    For every frame: best similarity to any positive concept, minus a penalty when a
    negative look-alike concept matches better. Calibrated against the clip's own
    distribution so the score means 'stands out as on-topic in this video'.
    """
    if feats.emb is None or vision is None or not positive or len(feats.times) == 0:
        return np.zeros(len(feats.times), np.float32)
    templates = ["a screenshot of a video game showing {}", "gameplay footage of {}", "a video frame of {}"]
    def enc(concepts):
        vecs = []
        for c in concepts:
            e = vision.encode_texts([t.format(c) for t in templates]).mean(axis=0)
            vecs.append(e / (np.linalg.norm(e) + 1e-9))
        return np.stack(vecs)
    img = feats.emb.astype(np.float32)
    pos = img @ enc(positive).T
    best_pos = pos.max(axis=1)
    if negative:
        neg = (img @ enc(negative).T).max(axis=1)
        margin = best_pos - neg
    else:
        margin = np.zeros_like(best_pos)
    # neutral baseline: generic prompts describe 'any frame'
    base = (img @ enc(["a person playing a video game", "a video game menu", "a blank screen"]).T).max(axis=1)
    raw = 0.6 * (best_pos - base) + 0.4 * margin
    mu, sd = np.median(raw), np.std(raw) + 1e-4
    z = (raw - mu) / sd
    score = 1 / (1 + np.exp(-(z - 1.0) * 1.6))
    score = np.convolve(score, np.ones(3) / 3, mode="same")
    return score.astype(np.float32)


def concept_labels(feats: VisualFeatures, vision, concepts: list[str], start: float, end: float, k: int = 3
                   ) -> list[str]:
    """Which concepts best describe frames in [start, end], as human-readable labels with times."""
    if feats.emb is None or vision is None or not concepts:
        return []
    idx = feats.idx(start, end)
    if len(idx) == 0:
        return []
    txt = vision.encode_texts([f"a video game screenshot of {c}" for c in concepts])
    sims = feats.emb[idx].astype(np.float32) @ txt.T
    labels = []
    step = max(1, len(idx) // 4)
    for j in range(0, len(idx), step):
        row = sims[j]
        top = np.argsort(-row)[:k]
        t = float(feats.times[idx[j]])
        labels.append(f"{t - start:+.0f}s: " + ", ".join(concepts[i] for i in top))
    return labels
