"""Audio analysis on the 16 kHz analysis track, streamed in chunks.

Per 0.5 s hop we compute loudness, spectral flux (sudden sound events: crashes, shouts,
explosions), brightness, voice pitch movement and a laughter-like rhythm measure. Each
signal is normalised against its *local* baseline (the surrounding ~2 minutes), so a quiet
streamer's surprise counts as much as a loud streamer's, and constant loud music does not
look exciting.

These are supporting signals only. Excitement never selects a clip by itself: the topic
match and the language-model judge decide (see intelligence/).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.cache import SourceCache
from ..core.ffmpeg import iter_wav_chunks

HOP = 0.5
SR = 16000
VERSION = 3


@dataclass
class AudioFeatures:
    times: np.ndarray          # hop centre times (s)
    rms_db: np.ndarray
    loud_z: np.ndarray         # loudness vs local baseline (z)
    flux_z: np.ndarray         # sudden onsets vs local baseline (z)
    pitch_var: np.ndarray      # voice pitch movement (0..1)
    laugh: np.ndarray          # laughter-like rhythmic bursts (0..1, heuristic)
    silence: np.ndarray        # 1 if near-silent
    excitement: np.ndarray     # combined 0..1

    def window(self, start: float, end: float) -> slice:
        a = int(max(0, start) / HOP)
        b = int(max(0, end) / HOP) + 1
        return slice(a, max(a + 1, b))

    def summary(self, start: float, end: float) -> dict:
        s = self.window(start, end)
        if s.start >= len(self.times):
            return {"peak_excitement": 0.0, "mean_excitement": 0.0, "laughter": 0.0, "silence_fraction": 1.0,
                    "loudness_db": -60.0}
        return {
            "peak_excitement": float(np.max(self.excitement[s])) if self.excitement[s].size else 0.0,
            "mean_excitement": float(np.mean(self.excitement[s])) if self.excitement[s].size else 0.0,
            "laughter": float(np.max(self.laugh[s])) if self.laugh[s].size else 0.0,
            "silence_fraction": float(np.mean(self.silence[s])) if self.silence[s].size else 1.0,
            "loudness_db": float(np.median(self.rms_db[s])) if self.rms_db[s].size else -60.0,
            "peak_time": float(self.times[s][int(np.argmax(self.excitement[s]))]) if self.excitement[s].size else start,
        }


def _local_z(x: np.ndarray, active: np.ndarray, win_hops: int = 240) -> np.ndarray:
    """Robust z-score against a centred rolling median / MAD (default ~2 minutes).

    Only non-silent hops form the baseline, so speech right after a quiet loading screen
    is not mistaken for excitement.
    """
    n = len(x)
    if n == 0:
        return x
    step = max(1, win_hops // 8)
    med = np.zeros(n, np.float32)
    mad = np.zeros(n, np.float32)
    for c in range(0, n, step):
        a, b = max(0, c - win_hops // 2), min(n, c + win_hops // 2)
        seg = x[a:b][active[a:b]]
        if len(seg) < 10:
            seg = x[a:b]
        m = np.median(seg)
        d = np.median(np.abs(seg - m)) * 1.4826 + 1e-3
        med[c:c + step] = m
        mad[c:c + step] = d
    out = (x - med) / mad
    return np.clip(out, -6, 8).astype(np.float32)


def _frame_features(chunk: np.ndarray):
    hop = int(HOP * SR)
    n = len(chunk) // hop
    if n == 0:
        return [np.zeros(0, np.float32)] * 5
    frames = chunk[: n * hop].reshape(n, hop)
    rms = np.sqrt(np.mean(frames ** 2, axis=1) + 1e-10)
    rms_db = 20 * np.log10(rms + 1e-9)
    win = np.hanning(hop).astype(np.float32)
    spec = np.abs(np.fft.rfft(frames * win, axis=1))
    freqs = np.fft.rfftfreq(hop, 1 / SR)
    centroid = (spec * freqs).sum(axis=1) / (spec.sum(axis=1) + 1e-9)
    # sub-frame flux: split each hop into 8 slices and measure the largest energy jump
    sub = frames.reshape(n, 8, hop // 8)
    sub_e = np.log(np.mean(sub ** 2, axis=2) + 1e-9)
    flux = np.max(np.maximum(0, np.diff(sub_e, axis=1)), axis=1)
    # pitch via autocorrelation on the voiced band (80-400 Hz)
    lo, hi = SR // 400, SR // 80
    ac = np.fft.irfft(np.abs(np.fft.rfft(frames, n=2 * hop, axis=1)) ** 2, axis=1)[:, :hop]
    ac_norm = ac / (ac[:, :1] + 1e-9)
    lag = np.argmax(ac_norm[:, lo:hi], axis=1) + lo
    voiced = ac_norm[np.arange(n), lag] > 0.35
    pitch = np.where(voiced, SR / lag, 0.0)
    # laughter-like: energy envelope modulated at 3.5-7 Hz (ha-ha-ha rhythm)
    env = np.abs(frames).reshape(n, 40, hop // 40).mean(axis=2)  # 80 Hz envelope rate
    env = env - env.mean(axis=1, keepdims=True)
    mspec = np.abs(np.fft.rfft(env, axis=1))
    mfreq = np.fft.rfftfreq(40, 1 / 80.0)
    band = (mfreq >= 3.5) & (mfreq <= 7.0)
    laugh_ratio = mspec[:, band].sum(axis=1) / (mspec[:, 1:].sum(axis=1) + 1e-9)
    return [rms_db.astype(np.float32), flux.astype(np.float32), centroid.astype(np.float32),
            pitch.astype(np.float32), laugh_ratio.astype(np.float32)]


def analyze_audio(wav_path: str, cache: SourceCache, progress=None, cancel=None) -> AudioFeatures:
    cached = cache.load_npz("audio_features.npz")
    if cached is not None and int(cached.get("version", np.array([0]))[0]) == VERSION:
        return AudioFeatures(**{k: cached[k] for k in AudioFeatures.__dataclass_fields__})
    import soundfile as sf

    total = sf.info(wav_path).duration or 1.0
    parts = [[] for _ in range(5)]
    for t0, chunk in iter_wav_chunks(wav_path, 120.0):
        if cancel and cancel():
            raise RuntimeError("Cancelled")
        feats = _frame_features(chunk)
        for i, f in enumerate(feats):
            parts[i].append(f)
        if progress:
            progress(min(0.99, (t0 + 120.0) / total), "Analysing audio")
    rms_db, flux, centroid, pitch, laugh_ratio = [np.concatenate(p) if p else np.zeros(0, np.float32) for p in parts]
    n = len(rms_db)
    times = (np.arange(n) + 0.5) * HOP
    silence = (rms_db < -48).astype(np.float32)
    active = silence < 0.5
    loud_z = _local_z(rms_db, active)
    flux_z = _local_z(flux, active)
    # pitch movement over ~2 s windows (voice getting animated)
    pv = np.zeros(n, np.float32)
    for i in range(n):
        seg = pitch[max(0, i - 2): i + 3]
        seg = seg[seg > 0]
        pv[i] = np.std(seg) / 60.0 if len(seg) >= 3 else 0.0
    pitch_var = np.clip(pv, 0, 1)
    laugh = np.clip((laugh_ratio - 0.35) / 0.35, 0, 1) * (loud_z > 0.5) * (1 - silence)
    laugh = np.convolve(laugh, np.ones(3) / 3, mode="same").astype(np.float32)
    exc = (0.45 * _sig(loud_z - 1.0) + 0.30 * _sig(flux_z - 1.5) + 0.15 * pitch_var + 0.10 * laugh)
    exc = exc * (1 - 0.8 * silence)
    exc = np.convolve(exc, np.ones(3) / 3, mode="same").astype(np.float32)
    feats = AudioFeatures(times=times.astype(np.float32), rms_db=rms_db, loud_z=loud_z, flux_z=flux_z,
                          pitch_var=pitch_var.astype(np.float32), laugh=laugh, silence=silence, excitement=exc)
    cache.save_npz("audio_features.npz", version=np.array([VERSION]),
                   **{k: getattr(feats, k) for k in AudioFeatures.__dataclass_fields__})
    if progress:
        progress(1.0, "Audio analysed")
    return feats


def _sig(x):
    return 1.0 / (1.0 + np.exp(-x))
