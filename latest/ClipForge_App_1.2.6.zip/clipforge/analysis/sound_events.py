"""Sound events over the whole stream with a real AudioSet model (see providers/audio_ai).

The analysis audio is tagged in 2-second windows every second; for each window we keep the
probability of each ClipForge sound group (the max over its AudioSet classes). Cached per
source and model, so every topic reuses it.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.cache import SourceCache
from ..core.ffmpeg import iter_wav_chunks
from ..providers.audio_ai import IMPACT_GROUPS, REACTION_GROUPS, SOUND_GROUPS

VERSION = 1
WIN, STEP = 2.0, 1.0


@dataclass
class SoundEvents:
    times: np.ndarray          # window centres (s)
    groups: list[str]
    probs: np.ndarray          # (n, len(groups)) float16
    model_id: str

    def group(self, name: str) -> np.ndarray:
        return self.probs[:, self.groups.index(name)].astype(np.float32) if name in self.groups \
            else np.zeros(len(self.times), np.float32)

    def on_grid(self, name: str, grid: np.ndarray) -> np.ndarray:
        if len(self.times) == 0:
            return np.zeros(len(grid), np.float32)
        return np.interp(grid, self.times, self.group(name)).astype(np.float32)

    def reaction(self, grid: np.ndarray) -> np.ndarray:
        """0..1: real laughter / screaming / cheering (entertaining reactions)."""
        out = np.zeros(len(grid), np.float32)
        for g, w in REACTION_GROUPS.items():
            out = np.maximum(out, w * np.clip((self.on_grid(g, grid) - 0.08) / 0.5, 0, 1))
        return out

    def impact(self, grid: np.ndarray) -> np.ndarray:
        out = np.zeros(len(grid), np.float32)
        for g, w in IMPACT_GROUPS.items():
            out = np.maximum(out, w * np.clip((self.on_grid(g, grid) - 0.1) / 0.5, 0, 1))
        return out

    def summary(self, start: float, end: float, min_p: float = 0.2, top: int = 5) -> list[tuple[str, float]]:
        idx = np.where((self.times >= start - 0.5) & (self.times <= end + 0.5))[0]
        if len(idx) == 0:
            return []
        peak = self.probs[idx].astype(np.float32).max(axis=0)
        found = [(g, float(peak[i])) for i, g in enumerate(self.groups) if peak[i] >= min_p and g != "speech"]
        return sorted(found, key=lambda x: -x[1])[:top]


def analyze_sound_events(wav: str, duration: float, cache: SourceCache, tagger, progress=None, cancel=None
                         ) -> SoundEvents | None:
    if tagger is None:
        return None
    key = "sound_events.npz"
    cached = cache.load_npz(key)
    if cached is not None and int(cached["version"][0]) == VERSION and str(cached["model"][0]) == tagger.model_id:
        return SoundEvents(cached["times"], [str(g) for g in cached["groups"]], cached["probs"], tagger.model_id)
    labels = tagger.labels()
    lab_idx = {l: i for i, l in enumerate(labels)}
    groups = list(SOUND_GROUPS)
    gidx = [[lab_idx[c] for c in SOUND_GROUPS[g] if c in lab_idx] for g in groups]
    times, rows = [], []
    sr = 16000
    win, step = int(WIN * sr), int(STEP * sr)
    for off, chunk in iter_wav_chunks(wav, 120.0, overlap_seconds=WIN):
        if cancel and cancel():
            raise RuntimeError("Cancelled")
        first = 0 if off == 0 else int(round((np.ceil((off + WIN / 2) / STEP) * STEP - WIN / 2 - off) * sr))
        for a in range(max(0, first), max(1, len(chunk) - win + 1), step):
            t = off + (a + win / 2) / sr
            if times and t <= times[-1] + 1e-3:
                continue
            seg = chunk[a:a + win]
            if len(seg) < sr // 2:
                continue
            p = tagger.tag(seg, sr)
            rows.append([float(p[ix].max()) if ix else 0.0 for ix in gidx])
            times.append(t)
        if progress and duration:
            progress(min(1.0, (off + len(chunk) / sr) / duration), "Detecting sounds (laughter, sirens, crashes…)")
    ev = SoundEvents(np.array(times, np.float32), groups, np.array(rows, np.float16).reshape(-1, len(groups)),
                     tagger.model_id)
    cache.save_npz(key, version=np.array([VERSION]), model=np.array([tagger.model_id]), times=ev.times,
                   groups=np.array(groups), probs=ev.probs)
    return ev
