"""Output timeline: where every clip, narration line, caption and overlay lands.

Narration is placed where the original audio has no speech, so it never talks over what
the streamer says. If a clip starts with dialogue immediately and the line doesn't fit,
a short "hold" (the clip's first frame with a slow push-in) is inserted for the line,
which is how human editors add context without cutting the moment.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..core.models import NarrationLine, StoryItem, Transcript, Word


@dataclass
class Segment:
    kind: str                  # "clip", "broll" (moving lead-in/teaser footage under narration) or "hold"
    item_index: int
    src_file: str
    src_in: float              # seconds inside src_file
    src_out: float
    source_start: float        # absolute source-timeline time of src_in (for transcript lookups)
    out_start: float = 0.0
    out_end: float = 0.0
    unit: int = 0              # segments of the same unit are joined with hard cuts; units get transitions

    @property
    def duration(self) -> float:
        return self.src_out if self.kind == "hold" else self.src_out - self.src_in


@dataclass
class Placement:
    line: NarrationLine
    out_start: float


@dataclass
class Timeline:
    segments: list[Segment] = field(default_factory=list)
    narration: list[Placement] = field(default_factory=list)
    transition: float = 0.0
    duration: float = 0.0
    dialogue_words: list[tuple[Word, int]] = field(default_factory=list)  # (word on output time, item index)
    narration_words: list[Word] = field(default_factory=list)
    item_spans: list[tuple[float, float]] = field(default_factory=list)   # output span of each story item's clip

    def to_output(self, item: int, t_src: float) -> float | None:
        """Output time of source time ``t_src`` inside story item ``item``'s clip (None if cut out)."""
        segs = [g for g in self.segments if g.kind == "clip" and g.item_index == item]
        for g in segs:
            if g.source_start - 0.02 <= t_src <= g.source_start + (g.src_out - g.src_in) + 0.02:
                return g.out_start + (t_src - g.source_start)
        # just inside a removed pause: snap to the nearest kept edge
        best = None
        for g in segs:
            for src, out in ((g.source_start, g.out_start), (g.source_start + g.src_out - g.src_in, g.out_end)):
                if abs(src - t_src) <= 0.35 and (best is None or abs(src - t_src) < best[0]):
                    best = (abs(src - t_src), out)
        return best[1] if best else None


def first_speech_offset(transcript: Transcript, start: float, end: float) -> float:
    ws = transcript.words_between(start, end)
    return (ws[0].start - start) if ws else (end - start)


def refine_cut_points(story: list[StoryItem], cuts: dict[int, list[float]], transcript: Transcript,
                      reach: float = 2.5) -> list[str]:
    """Move a clip's in/out point onto a nearby scene change when the clip would otherwise open
    (or end) on a second or two of a different scene. Never moves past speech: if someone is
    talking across the cut, the setup matters more than the picture, so the point stays."""
    notes = []
    for i, it in enumerate(story):
        cs = cuts.get(i) or []
        words = transcript.words_between(it.start - 1.0, it.end + 1.0)
        # opening: a cut shortly after the in-point, nobody speaking before it
        early = [c for c in cs if it.start + 0.08 < c <= it.start + reach and it.end - c >= 3.0]
        if early:
            c = max(early)
            if not any(w.end > it.start + 0.05 and w.start < c - 0.05 for w in words):
                notes.append(f"clip {i + 1}: start {it.start:.2f} -> {c:.2f} (scene change)")
                it.start = c
        # ending: a cut shortly before the out-point, nothing said after it
        late = [c for c in cs if it.end - reach <= c < it.end - 0.08 and c - it.start >= 3.0]
        if late:
            c = min(late)
            if not any(w.start >= c - 0.15 and w.start < it.end for w in words):
                notes.append(f"clip {i + 1}: end {it.end:.2f} -> {c - 0.12:.2f} (scene change)")
                it.end = c - 0.12
    return notes


def _keep_ranges(start: float, end: float, trims: list[tuple[float, float]]) -> list[tuple[float, float]]:
    out, t = [], start
    for a, b in sorted(trims):
        a, b = max(a, start), min(b, end)
        if b - a < 0.2 or a < t:
            continue
        out.append((t, a))
        t = b
    out.append((t, end))
    return [(a, b) for a, b in out if b - a > 0.05]


def find_dead_air(story: list[StoryItem], transcript: Transcript, audio, visual=None, best: dict | None = None,
                  min_gap: float = 1.2, keep: float = 0.2, protect: dict | None = None
                  ) -> dict[int, list[tuple[float, float]]]:
    """Pauses inside clips where nothing happens (no words, near-silent audio, little movement):
    returns the middle part of each to remove, leaving ``keep`` seconds either side, the way an
    editor tightens a clip with a jump cut. Never touches the key moment, nor the first
    ``protect[i]`` seconds of clip i (the quiet opening a narration line is placed in: cutting it
    would put the narration on top of the streamer's words)."""
    out: dict[int, list[tuple[float, float]]] = {}
    if audio is None or not len(getattr(audio, "times", [])):
        return out
    hop = float(audio.times[1] - audio.times[0]) if len(audio.times) > 1 else 0.5
    for i, it in enumerate(story):
        words = transcript.words_between(it.start, it.end)
        bm = (best or {}).get(i)
        sl = audio.window(it.start, it.end)
        lv = audio.rms_db[sl]
        # near-silent, or far quieter than the clip's normal level (a pause with faint background)
        floor = max(-48.0, float(np.percentile(lv, 75)) - 20.0) if lv.size else -48.0
        quiet_from = None
        spans = []
        t = it.start + 0.3
        while t <= it.end - 0.3:
            k = min(len(audio.silence) - 1, max(0, int(round((t - audio.times[0]) / hop))))
            talking = any(w.start - 0.1 <= t <= w.end + 0.1 for w in words)
            silent = (bool(audio.silence[k]) or float(audio.rms_db[k]) < floor) and not talking
            if silent and quiet_from is None:
                quiet_from = t
            if (not silent or t + 0.1 > it.end - 0.3) and quiet_from is not None:
                spans.append((quiet_from, t))
                quiet_from = None
            t += 0.1
        cuts = []
        guard = it.start + float((protect or {}).get(i, 0.0))
        for a, b in spans:
            if guard > it.start and a < guard:
                a = guard                     # keep the narration's quiet opening intact
            if b - a < min_gap:
                continue
            if bm is not None and a + keep - 0.5 <= bm <= b - keep + 0.5:
                continue      # the key moment is in (or right at the edge of) the pause
            if visual is not None and len(getattr(visual, "times", [])):
                idx, whole = visual.idx(a, b), visual.idx(it.start, it.end)
                base = float(np.median(visual.motion[whole])) if len(whole) else 0.0
                if len(idx) and float(np.max(visual.motion[idx])) > max(0.5, 1.5 * base):
                    continue      # quiet, but something happens on screen (more movement than usual)
            cuts.append((a + keep, b - keep))
        if cuts:
            out[i] = cuts
    return out


def _crosses_cut(cuts: list[float], a: float, b: float) -> bool:
    return any(a - 0.02 < c <= b + 0.05 for c in cuts)


def build_timeline(story: list[StoryItem], sections: dict[int, tuple[str, float]], narration: list[NarrationLine],
                   transcript: Transcript, transition: float = 0.18, best_moments: dict[int, float] | None = None,
                   teaser: bool = True, cuts: dict[int, list[float]] | None = None,
                   trims: dict[int, list[tuple[float, float]]] | None = None) -> Timeline:
    """``sections[i] = (file, file_offset)`` where file_offset is the source time at file t=0.

    When a narration line needs more quiet time than the clip offers, the extra time is filled,
    in order of preference, with:
      1. (first clip only) a muted-ish flash-forward of the strongest moment - a classic Shorts hook;
      2. the few seconds of footage just before the clip, if nobody is talking there;
      3. a freeze frame with a slow push-in.
    """
    best_moments = best_moments or {}
    cuts = cuts or {}
    tl = Timeline(transition=transition)
    t = 0.0
    lines_before: dict[int, list[NarrationLine]] = {}
    lines_after: list[NarrationLine] = []
    last = len(story) - 1
    # an "after" line on clip i plays between clip i and clip i+1 (before the next clip's own
    # lines); only lines after the LAST clip become the outro over its final frame.
    between: dict[int, list[NarrationLine]] = {}
    for ln in narration:
        if ln.position == "after" and ln.item_index < last:
            between.setdefault(ln.item_index + 1, []).append(ln)
        elif ln.position == "after":
            lines_after.append(ln)
        else:
            lines_before.setdefault(ln.item_index, []).append(ln)
    for i, lns in between.items():
        lines_before[i] = lns + lines_before.get(i, [])
    for i, it in enumerate(story):
        f, f0 = sections[i]
        clip_in, clip_out = it.start - f0, it.end - f0
        lines = lines_before.get(i, [])
        need = sum(l.duration for l in lines) + 0.15 * max(0, len(lines) - 1)
        quiet = first_speech_offset(transcript, it.start, it.end) - 0.15
        if i > 0 and transition:
            t -= transition  # units overlap by the transition length
        unit_start = t
        if lines and need > max(0.0, quiet):
            hold = round(need - max(0.0, quiet) + 0.25, 2)
            seg = None
            if i == 0 and teaser and best_moments:
                # flash-forward: the peak of the most exciting later clip (falls back to this clip)
                j = max(best_moments, key=lambda k: (k != 0, k))  # prefer the payoff (last) item
                bm = best_moments[j]
                fj, fj0 = sections[j]
                a = max(story[j].start, min(bm - hold * 0.5, story[j].end - hold))
                cj = [c for c in cuts.get(j, []) if a < c < a + hold]
                if cj:   # the teaser must be one continuous shot: move it to one side of the cut
                    after, before = cj[-1], cj[0] - hold
                    a = after if after + hold <= story[j].end and after <= bm else (
                        before if before >= story[j].start else after)
                if story[j].end - a >= hold - 0.05 and story[j].start <= a \
                        and not _crosses_cut(cuts.get(j, []), a + 0.03, a + hold - 0.03):
                    seg = Segment("broll", j, fj, a - fj0, a - fj0 + hold, a, t, t + hold, unit=i)
            if seg is None:
                lead = transcript.words_between(it.start - hold, it.start - 0.05)
                if clip_in - hold >= 0 and len(lead) <= 1 and not _crosses_cut(cuts.get(i, []), it.start - hold,
                                                                                it.start):
                    seg = Segment("broll", i, f, clip_in - hold, clip_in, it.start - hold, t, t + hold, unit=i)
            if seg is None:
                seg = Segment("hold", i, f, clip_in, hold, it.start, t, t + hold, unit=i)
            tl.segments.append(seg)
            t += hold
        # the clip itself, minus any dead air removed inside it (joined with hard cuts)
        keep = _keep_ranges(it.start, it.end, (trims or {}).get(i, []))
        first = None
        for a, b in keep:
            seg = Segment("clip", i, f, a - f0, b - f0, a, t, t + (b - a), unit=i)
            tl.segments.append(seg)
            first = first or seg
            t = seg.out_end
        tl.item_spans.append((first.out_start, seg.out_end))
        # narration starts at the unit start (after the incoming transition)
        nt = unit_start + (transition if i > 0 and transition else 0.0)
        for ln in lines:
            tl.narration.append(Placement(ln, nt))
            ln.t_start = nt
            nt += ln.duration + 0.15
        # original dialogue words on the output timeline
        for w in transcript.words_between(it.start, it.end):
            ws, we = tl.to_output(i, w.start), tl.to_output(i, w.end)
            if ws is None or we is None:
                continue
            if ws >= first.out_start - 0.05 and we <= seg.out_end + 0.3:
                tl.dialogue_words.append((Word(w.text, ws, min(we, seg.out_end), speaker=w.speaker), i))
        t = seg.out_end
    if lines_after and tl.segments:
        last = tl.segments[-1]
        need = sum(l.duration for l in lines_after) + 0.3
        seg = Segment("hold", last.item_index, last.src_file, max(last.src_in, last.src_out - 0.04), need,
                      last.source_start, t, t + need, unit=last.unit)
        tl.segments.append(seg)
        nt = t + 0.1
        for ln in lines_after:
            tl.narration.append(Placement(ln, nt))
            ln.t_start = nt
            nt += ln.duration + 0.15
        t += need
    tl.duration = t
    return tl
