"""ClipForge desktop interface (PySide6).

Pages: 1 Source & Topic → 2 Candidate Clips → 3 Story & Hooks → 4 Script & Voice →
5 Edit & Captions → 6 Export.  Settings and System Check open from the sidebar.
All heavy work runs in background threads (gui/workers.py) through clipforge.pipeline.
"""
from __future__ import annotations

import dataclasses
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QThread, QTimer, QUrl
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QColorDialog, QComboBox, QDialog,
                               QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame, QGridLayout,
                               QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QRadioButton,
                               QScrollArea, QSlider, QSpinBox, QSplitter, QStackedWidget, QTableWidget,
                               QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget)

from ..config import Settings
from ..core.models import RIGHTS_BASES, NarrationLine, Overlay, fmt_time
from ..intelligence.selection import filter_reasons
from ..pipeline import Pipeline
from ..providers.tts import VOICE_LABELS
from .workers import Worker

try:  # video preview (optional: works if Qt Multimedia backends are present)
    if os.environ.get("CLIPFORGE_NO_MEDIA"):
        raise ImportError("disabled")
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAVE_MM = True
except Exception:  # noqa: BLE001
    HAVE_MM = False

STYLE = """
QWidget { font-size: 10.5pt; }
QMainWindow, QDialog, QWidget#page { background: #15171c; color: #e8e8ec; }
QMessageBox QLabel { color: #e8e8ec; }
QLabel { color: #e8e8ec; }
QLabel#h1 { font-size: 17pt; font-weight: 700; }
QLabel#hint { color: #9aa0ab; }
QGroupBox { border: 1px solid #2c3039; border-radius: 8px; margin-top: 14px; padding: 10px; color: #e8e8ec; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #c9ccd3; }
QListWidget#nav { background: #0f1115; border: none; color: #c9ccd3; font-size: 11pt; }
QListWidget#nav::item { padding: 12px 14px; }
QListWidget#nav::item:selected { background: #262a33; color: #ffffff; border-left: 3px solid #ffd400; }
QPushButton { background: #2a2e37; color: #e8e8ec; border: 1px solid #3a3f4b; border-radius: 6px; padding: 6px 12px; }
QPushButton:hover { background: #343945; }
QPushButton:disabled { color: #6b707a; }
QPushButton#primary { background: #ffd400; color: #111; font-weight: 700; border: none; padding: 10px 18px; }
QPushButton#primary:hover { background: #ffe14d; }
QPushButton#primary:disabled { background: #6b6224; color: #333; }
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
  background: #1d2027; color: #e8e8ec; border: 1px solid #343945; border-radius: 5px; padding: 4px; }
QTableWidget { background: #1a1d23; color: #e8e8ec; gridline-color: #2c3039; alternate-background-color: #1f2229; }
QHeaderView { background: #23262e; }
QTableCornerButton::section { background: #23262e; border: none; }
QScrollArea, QScrollArea > QWidget > QWidget { background: #15171c; border: none; }
QHeaderView::section { background: #23262e; color: #c9ccd3; padding: 4px; border: none; }
QProgressBar { background: #1d2027; border: 1px solid #343945; border-radius: 5px; text-align: center; color: #eee; }
QProgressBar::chunk { background: #ffd400; border-radius: 4px; }
QCheckBox, QRadioButton { color: #e8e8ec; }
QFrame#taskbar { background: #15171c; border-top: 1px solid #2a2d35; }
QLabel#projlabel { padding: 10px 12px 6px 12px; }
"""


def h1(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("h1")
    return l


def hint(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("hint")
    l.setWordWrap(True)
    return l


def stale_banner() -> QLabel:
    """An 'out of date' notice: says which earlier change makes this step's results old."""
    lb = QLabel("")
    lb.setWordWrap(True)
    lb.setStyleSheet("background:#3a2e0a;color:#fbbf24;border:1px solid #6b5310;border-radius:6px;padding:6px 10px;")
    lb.hide()
    return lb


def show_stale(lb: QLabel, text: str) -> None:
    lb.setText("⚠ " + text if text else "")
    lb.setVisible(bool(text))


def open_path(p: str):
    if sys.platform == "win32":
        os.startfile(p)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


class Page(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.setObjectName("page")
        self.win = win
        self.p: Pipeline = win.pipeline

    def refresh(self):
        pass


class Player(QWidget):
    """Small preview player. The media engine is created on first use, so a missing or broken
    audio device can never stop the app from starting; without Qt Multimedia, previews open in
    the default video player."""

    def __init__(self, audio_only: bool = False):
        super().__init__()
        self.audio_only = audio_only     # voice previews: no video surface (on Windows a video surface is a
        self.lay = QVBoxLayout(self)     # native black window that can cover the buttons around it)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.path = ""
        self.player = None
        self.screen = QLabel("Preview appears here")
        self.screen.setObjectName("hint")
        self.screen.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.screen.setMinimumSize(220, 120)
        self.lay.addWidget(self.screen, 1)
        row = QHBoxLayout()
        self.play_btn = QPushButton("Play / Pause")
        self.play_btn.clicked.connect(self.toggle)
        ext = QPushButton("Open externally")
        ext.clicked.connect(lambda: self.path and open_path(self.path))
        row.addWidget(self.play_btn)
        row.addWidget(ext)
        self.lay.addLayout(row)

    def _ensure(self) -> bool:
        if self.player is not None:
            return True
        if not HAVE_MM:
            return False
        try:
            self.player = QMediaPlayer()
            self.audio = QAudioOutput()
            self.player.setAudioOutput(self.audio)
            self.player.errorOccurred.connect(self._error)
            if not self.audio_only:
                self.video = QVideoWidget()
                self.video.setMinimumSize(220, 300)
                self.player.setVideoOutput(self.video)
                self.lay.replaceWidget(self.screen, self.video)
                self.screen.hide()
            return True
        except Exception:  # noqa: BLE001
            self.player = None
            return False

    def unload(self):
        """Forget the current video (new project / restart)."""
        try:
            if self.player is not None:
                self.player.stop()
                self.player.setSource(QUrl())
        except Exception:  # noqa: BLE001
            pass
        self.path = ""

    def load(self, path: str, autoplay: bool = True):
        self.path = str(path)
        if self._ensure():
            if self.audio_only:
                self.screen.setText("▶ Playing voice preview (Play / Pause to replay)")
            self.player.setSource(QUrl.fromLocalFile(self.path))
            if autoplay:
                self.player.play()
        else:
            self.screen.setText(f"Ready: {Path(self.path).name}")
            if autoplay:
                open_path(self.path)

    def _error(self, _err, msg):
        self.screen.setText(f"Can't play the preview here ({msg or 'unknown error'}). Click Open externally.")
        if not self.audio_only and getattr(self, "video", None) is not None:
            self.lay.replaceWidget(self.video, self.screen)
            self.video.hide()
            self.screen.show()
            self.player.setVideoOutput(None)
            del self.video

    def toggle(self):
        if self.player is None:
            if self.path:
                open_path(self.path)
            return
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()


# =============================================================================== 1. Source & topic
class SourcePage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("1 · Source & Topic"))
        outer.addWidget(hint("Paste a public YouTube, Twitch or Kick video link, or open a video file. Only use "
                             "footage you have permission to edit and publish. Private, members-only, DRM-protected "
                             "and live videos are refused."))
        src = QGroupBox("Video")
        g = QGridLayout(src)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://www.youtube.com/watch?v=…   or   https://www.twitch.tv/videos/…")
        load = QPushButton("Load link")
        load.clicked.connect(self.load_url)
        browse = QPushButton("Open video file…")
        browse.clicked.connect(self.load_file)
        g.addWidget(self.url, 0, 0)
        g.addWidget(load, 0, 1)
        g.addWidget(browse, 0, 2)
        self.info = hint("No video loaded.")
        g.addWidget(self.info, 1, 0, 1, 3)
        outer.addWidget(src)

        rights = QGroupBox("Footage rights (required before export)")
        f = QFormLayout(rights)
        self.basis = QComboBox()
        self.basis.addItem("— choose —", "")
        for k, v in RIGHTS_BASES.items():
            self.basis.addItem(v, k)
        self.creator = QLineEdit()
        self.creator.setPlaceholderText("Streamer / channel who gave permission")
        self.commercial = QCheckBox("The permission covers monetized (commercial) use")
        self.publisher = QCheckBox("I checked the game publisher's video policy allows this use")
        self.notes = QLineEdit()
        self.notes.setPlaceholderText("Where the permission is stored (e.g. 'email from X, 2026-11-02')")
        self.confirm = QCheckBox("I confirm this information is true")
        f.addRow("Basis", self.basis)
        f.addRow("Creator", self.creator)
        f.addRow("", self.commercial)
        f.addRow("", self.publisher)
        f.addRow("Notes", self.notes)
        f.addRow("", self.confirm)
        for w in (self.basis,):
            w.currentIndexChanged.connect(self.save_rights)
        for w in (self.commercial, self.publisher, self.confirm):
            w.toggled.connect(self.save_rights)
        for w in (self.creator, self.notes):
            w.editingFinished.connect(self.save_rights)
        outer.addWidget(rights)

        tp = QGroupBox("What should the Short be about?")
        v = QVBoxLayout(tp)
        self.topic = QPlainTextEdit()
        self.topic.setPlaceholderText("e.g. Make the video about the police chases and describe the 4 craziest ones\n"
                                      "or: top 5 funniest NPC moments, explain why each one is funny")
        self.topic.setFixedHeight(70)
        v.addWidget(self.topic)
        v.addWidget(hint("Say what to find, and how to make it if you like: how many moments (\"the 4 coolest\", "
                         "\"top 5\"), a countdown or the story in order, and what the narration should do "
                         "(\"describe each one\", \"explain why it's funny\", \"no narration\")."))
        row = QHBoxLayout()
        row.addWidget(QLabel("Target length"))
        self.target = QComboBox()
        for s in (20, 30, 45, 60, 90):
            self.target.addItem(f"{s} seconds", s)
        self.target.setCurrentIndex(2)
        row.addWidget(self.target)
        row.addSpacing(20)
        row.addWidget(QLabel("Number of clips"))
        self.nclips = QSpinBox()
        self.nclips.setRange(0, 12)
        self.nclips.setSpecialValueText("Automatic")
        row.addWidget(self.nclips)
        row.addStretch(1)
        v.addLayout(row)
        outer.addWidget(tp)

        row = QHBoxLayout()
        self.go = QPushButton("FIND MOMENTS")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.analyze)
        row.addWidget(self.go)
        row.addWidget(hint("Progress and Cancel are in the bar at the bottom of the window."))
        row.addStretch(1)
        outer.addLayout(row)
        self.stale_lbl = hint("")
        self.stale_lbl.setStyleSheet("color:#f59e0b;")
        outer.addWidget(self.stale_lbl)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        outer.addWidget(self.log, 1)

    # ---- actions
    def _replace_ok(self) -> bool:
        """Loading a different video into a project that already has work: say what happens."""
        pr = self.p.project
        if pr.source is None or not (pr.candidates or pr.plan.story):
            return True
        return QMessageBox.question(
            self, "Load a different video?",
            f"This project already has work for “{pr.source.title}” (clips, story, script). Loading a different "
            f"video replaces it in this project and starts it again from step 1.\n\nThe old video's download and "
            f"analysis stay in the cache (reused if you load it again). To keep both, use Projects… → New "
            f"project instead.\n\nLoad the new video?") == QMessageBox.StandardButton.Yes

    def load_url(self):
        url = self.url.text().strip()
        if not url:
            return
        if self.p.project.source is not None and url == self.p.project.source.url:
            return
        if not self._replace_ok():
            return
        self.win.run(self.p.ingest, self.loaded, title="Getting the video", steps=["ingest"], url=url)

    def load_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open video", str(Path.home()),
                                              "Video (*.mp4 *.mkv *.mov *.webm *.avi *.flv *.ts *.m4v)")
        if path and self._replace_ok():
            self.win.run(self.p.ingest, self.loaded, title="Getting the video", steps=["ingest"], path=path)

    def loaded(self, src):
        self.refresh()

    def save_rights(self, *_):
        src = self.p.project.source
        if src is None:
            return
        r = src.rights
        r.basis = self.basis.currentData() or ""
        r.creator = self.creator.text().strip()
        r.commercial_use = self.commercial.isChecked()
        r.game_publisher_ok = self.publisher.isChecked()
        r.notes = self.notes.text().strip()
        r.confirmed = self.confirm.isChecked()
        self.p.save_rights()

    STEPS = ["ingest", "transcript", "audio", "visual", "sounds", "speakers", "evidence", "judge", "story"]

    def analyze(self):
        if self.p.project.source is None:
            if self.url.text().strip():
                self.win.run(self.p.ingest, lambda _: self.analyze(), title="Getting the video", steps=["ingest"],
                             url=self.url.text().strip())
            else:
                QMessageBox.information(self, "ClipForge", "Load a video link or file first.")
            return
        topic = self.topic.toPlainText().strip()
        if len(topic) < 3:
            QMessageBox.information(self, "ClipForge", "Describe the topic of the Short first.")
            return
        pr = self.p.project
        if pr.plan.story and pr.candidates:
            # make it clear what a new search replaces, and what is reused
            made = ["the clip picks (step 2)", "the story and hooks (step 3)", "the script (step 4)"]
            if pr.plan.captions:
                made.append("the edit and captions (step 5)")
            if QMessageBox.question(
                    self, "Find moments again?",
                    "Finding moments again replaces " + ", ".join(made) + ".\n\nKept and reused: the downloaded "
                    "video and its analysis (speech, sound, picture), so only the topic search runs again — "
                    "usually well under a minute.\n\nContinue?") != QMessageBox.StandardButton.Yes:
                return
        self.win.run(self.p.find_moments, lambda _: self.win.goto(1), title="Finding moments", steps=self.STEPS,
                     topic=topic, target_seconds=float(self.target.currentData()), desired_clips=self.nclips.value())

    def on_progress(self, stage: str, frac: float, msg: str):
        pass

    def clear(self):
        """Empty the page (new project / restart): nothing from the previous project may show."""
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(True)
        self.url.clear()
        self.info.setText("No video loaded.")
        self.basis.setCurrentIndex(0)
        self.creator.clear()
        self.notes.clear()
        for w in (self.commercial, self.publisher, self.confirm):
            w.setChecked(False)
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(False)
        self.topic.clear()
        self.target.setCurrentIndex(2)
        self.nclips.setValue(0)
        self.log.clear()
        self.stale_lbl.setText("")

    def refresh(self):
        src = self.p.project.source
        plan = self.p.project.plan
        if src is None:
            self.clear()
            return
        if not self.url.text().strip() and src.url:
            self.url.setText(src.url)
        if not self.topic.toPlainText().strip() and (plan.topic.raw or "").strip():
            self.topic.setPlainText(plan.topic.raw)
            i = self.target.findData(int(plan.target_seconds))
            if i >= 0:
                self.target.setCurrentIndex(i)
            self.nclips.setValue(plan.desired_clips)
        st = self.p.stale()
        cur = self.topic.toPlainText().strip().lower()
        if self.p.project.candidates and cur and cur != (plan.topic.raw or "").strip().lower():
            self.stale_lbl.setText("You changed the topic: click FIND MOMENTS to update steps 2–6 (the video's "
                                   "analysis is reused).")
        else:
            self.stale_lbl.setText("" if not st.get("candidates") else
                                   "The length or clip count changed: click FIND MOMENTS to update.")
        self.info.setText(f"<b>{src.title}</b> — {src.uploader or src.platform} — {fmt_time(src.duration)} — "
                          f"{src.width}x{src.height}")
        r = src.rights
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(True)
        self.basis.setCurrentIndex(max(0, self.basis.findData(r.basis)))
        self.creator.setText(r.creator or src.uploader)
        self.commercial.setChecked(r.commercial_use)
        self.publisher.setChecked(r.game_publisher_ok)
        self.notes.setText(r.notes)
        self.confirm.setChecked(r.confirmed)
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(False)
        self.log.setPlainText("\n".join(self.p.project.log[-200:]))
        self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())


# =============================================================================== 2. Candidates
COLS = ["Use", "Rank", "Start", "End", "Length", "Score", "Topic", "Fun", "Context", "Audio", "Visual", "Conf.",
        "What happens", "Why it matches / why filtered"]


class CandidatesPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("2 · Candidate Clips"))
        self.summary = hint("")
        outer.addWidget(self.summary)
        self.stale_lbl = stale_banner()
        outer.addWidget(self.stale_lbl)
        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(12, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(13, QHeaderView.ResizeMode.Stretch)
        self.table.itemSelectionChanged.connect(self.show_detail)
        split.addWidget(self.table)
        bottom = QWidget()
        bl = QHBoxLayout(bottom)
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        bl.addWidget(self.detail, 2)
        self.player = Player()
        bl.addWidget(self.player, 1)
        split.addWidget(bottom)
        split.setSizes([420, 260])
        outer.addWidget(split, 1)
        row = QHBoxLayout()
        b = QPushButton("Preview selected")
        b.clicked.connect(self.preview)
        row.addWidget(b)
        b = QPushButton("Replace selected with next best")
        b.clicked.connect(self.replace)
        row.addWidget(b)
        b = QPushButton("Auto-select again")
        b.clicked.connect(self.auto_select)
        row.addWidget(b)
        row.addStretch(1)
        b = QPushButton("Use ticked clips → Story")
        b.setObjectName("primary")
        b.clicked.connect(self.apply)
        row.addWidget(b)
        outer.addLayout(row)

    def clear(self):
        self.table.setRowCount(0)
        self._rows = []
        self.detail.clear()
        self.summary.setText("")
        self.stale_lbl.hide()

    def refresh(self):
        st = self.p.stale()
        show_stale(self.stale_lbl, "You changed the topic or length on step 1 after these moments were found. Go "
                                   "back to step 1 and click FIND MOMENTS to update (the video's analysis is reused)."
                   if st.get("candidates") else "")
        cands = sorted(self.p.project.candidates, key=lambda c: c.rank or 999)
        self.table.setRowCount(len(cands))
        self._rows = cands
        for r, c in enumerate(cands):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            chk.setCheckState(Qt.CheckState.Checked if c.included else Qt.CheckState.Unchecked)
            fr = filter_reasons(c)
            vals = [c.rank, fmt_time(c.start), fmt_time(c.end), f"{c.duration:.0f}s", f"{c.final_score:.0f}",
                    f"{c.topic_match:.1f}", f"{c.entertainment:.1f}", f"{c.context_completeness:.1f}",
                    f"{c.audio_quality:.1f}", f"{c.visual_quality:.1f}", f"{c.confidence:.2f}", c.description,
                    ("FILTERED: " + "; ".join(fr)) if fr else c.why_matches]
            self.table.setItem(r, 0, chk)
            for k, v in enumerate(vals, start=1):
                it = QTableWidgetItem(str(v))
                if fr:
                    it.setForeground(QColor("#80858f"))
                if c.included:
                    it.setBackground(QColor("#2b2a14"))
                self.table.setItem(r, k, it)
        used = self.p.used
        n = sum(c.included for c in cands)
        self.summary.setText(f"{len(cands)} moments judged, {n} selected. Engines — judge: <b>{used.get('judge', '?')}</b>, "
                             f"meaning search: {used.get('embedder', '?')}, vision: {used.get('vision', '?')}, "
                             f"sounds: {used.get('sound_events', '?')}, speakers: {used.get('speakers', '?')}, "
                             f"speech: {used.get('transcription', '?')}. "
                             "Tick/untick clips, then continue. Grey rows were filtered (reason shown).")

    def _sel(self):
        rows = {i.row() for i in self.table.selectedIndexes()}
        return [self._rows[r] for r in sorted(rows)] if rows else []

    def show_detail(self):
        s = self._sel()
        if not s:
            return
        c = s[0]
        e = c.evidence
        self.detail.setHtml(
            f"<b>{fmt_time(c.start)} – {fmt_time(c.end)}</b> · judged by {c.judged_by}<br><b>What happens:</b> {c.description}"
            f"<br><b>Why:</b> {c.why_matches}<br><b>Before:</b> <i>{e.transcript_before}</i><br><b>Said:</b> {e.transcript}"
            f"<br><b>After:</b> <i>{e.transcript_after}</i><br><b>On screen:</b> {', '.join(e.visual_labels[:8])}"
            f"<br>{'<br>'.join(e.frame_captions[:3])}<br><b>Audio:</b> {e.audio_summary}"
            f"<br><b>Signals:</b> {'; '.join(r for r in c.reasons if not r.startswith('context:'))}")

    def preview(self):
        s = self._sel()
        if s:
            self.win.run(self.win.make_clip_preview, self.player.load, title="Making a clip preview",
                         start=s[0].start, end=s[0].end)

    def _rebuild_ok(self) -> bool:
        """Changing the clips rebuilds the story and script: say so if the script was hand-edited."""
        if not self.p.project.meta.get("script_edited"):
            return True
        return QMessageBox.question(
            self, "Rebuild story and script?",
            "Changing the clips rebuilds the story, hooks and script (step 3 and 4). Your edits to the script "
            "will be replaced.\n\nThe video, its analysis and any clips already downloaded are reused.\n\n"
            "Continue?") == QMessageBox.StandardButton.Yes

    def replace(self):
        s = self._sel()
        if s and self._rebuild_ok():
            cid = s[0].cid
            self.win.run(lambda progress=None: self.p.replace_clip(cid), lambda _: self.refresh(),
                         title="Replacing the clip")

    def auto_select(self):
        if self._rebuild_ok():
            self.win.run(lambda progress=None: self.p.auto_select(), lambda _: self.refresh(),
                         title="Choosing clips")

    def apply(self):
        inc = {self._rows[r].cid for r in range(self.table.rowCount())
               if self.table.item(r, 0).checkState() == Qt.CheckState.Checked}
        if not inc:
            QMessageBox.information(self, "ClipForge", "Tick at least one clip.")
            return
        now = {c.cid for c in self.p.project.candidates if c.included}
        if inc == now and self.p.project.plan.story:
            self.win.goto(2)            # nothing changed: keep the story, script and edit as they are
            return
        if not self._rebuild_ok():
            return
        self.win.run(lambda progress=None: self.p.set_choices(inc), lambda _: self.win.goto(2),
                     title="Building the story", steps=["story"])


# =============================================================================== 3. Story & hooks
class StoryPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("3 · Story & Hooks"))
        self.stale_lbl = stale_banner()
        outer.addWidget(self.stale_lbl)
        outer.addWidget(hint("Clips play in this order. Each clip keeps its setup and reaction; adjust in/out points "
                             "if needed. The narration is attached to its clip and moves with it."))
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Role", "Start (s)", "End (s)", "On-screen context", "Why here",
                                              "What happens"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        outer.addWidget(self.table, 2)
        row = QHBoxLayout()
        for txt, d in (("Move up", -1), ("Move down", 1)):
            b = QPushButton(txt)
            b.clicked.connect(lambda _=False, d=d: self.move(d))
            row.addWidget(b)
        b = QPushButton("Rebuild order with AI")
        b.clicked.connect(lambda: self.win.run(lambda progress=None: self.p.build_story(progress),
                                               lambda _: self.refresh(), title="Rebuilding the story"))
        row.addWidget(b)
        row.addStretch(1)
        outer.addLayout(row)
        hg = QGroupBox("Hook (opening headline + first line). Pick one; you can export several as A/B variants.")
        self.hook_lay = QVBoxLayout(hg)
        outer.addWidget(hg, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("Save → Script")
        b.setObjectName("primary")
        b.clicked.connect(self.save_and_next)
        row.addWidget(b)
        outer.addLayout(row)
        self._hook_widgets = []

    def clear(self):
        self.table.setRowCount(0)
        while self.hook_lay.count():
            w = self.hook_lay.takeAt(0).widget()
            if w:
                w.deleteLater()
        self._hook_widgets = []
        self.stale_lbl.hide()

    def refresh(self):
        plan = self.p.project.plan
        show_stale(self.stale_lbl, "The clip choices on step 2 changed after this story was made. Click "
                                   "'Use ticked clips → Story' on step 2 to rebuild it." if self.p.stale().get("story")
                   else "")
        by_id = {c.cid: c for c in self.p.project.candidates}
        self.table.blockSignals(True)
        self.table.setRowCount(len(plan.story))
        for r, it in enumerate(plan.story):
            c = by_id.get(it.cid)
            self.table.setItem(r, 0, QTableWidgetItem(it.role))
            for col, val in ((1, it.start), (2, it.end)):
                sp = QDoubleSpinBox()
                sp.setRange(0, 1e6)
                sp.setDecimals(1)
                sp.setSingleStep(0.5)
                sp.setValue(val)
                self.table.setCellWidget(r, col, sp)
            self.table.setItem(r, 3, QTableWidgetItem(it.context_text))
            self.table.setItem(r, 4, QTableWidgetItem(it.rationale))
            self.table.setItem(r, 5, QTableWidgetItem(c.description if c else ""))
        self.table.blockSignals(False)
        while self.hook_lay.count():
            w = self.hook_lay.takeAt(0).widget()
            if w:
                w.deleteLater()
        self._hook_widgets = []
        for i, h in enumerate(plan.hooks):
            w = QWidget()
            l = QHBoxLayout(w)
            l.setContentsMargins(0, 0, 0, 0)
            rb = QRadioButton()
            rb.setChecked(i == plan.chosen_hook)
            head = QLineEdit(h.headline)
            line = QLineEdit(h.opening_line)
            head.setCursorPosition(0)
            line.setCursorPosition(0)
            l.addWidget(rb)
            l.addWidget(QLabel("Headline"))
            l.addWidget(head, 1)
            l.addWidget(QLabel("Opening line"))
            l.addWidget(line, 2)
            self.hook_lay.addWidget(w)
            self._hook_widgets.append((rb, head, line))

    def _save_table(self):
        plan = self.p.project.plan
        for r, it in enumerate(plan.story):
            s, e = self.table.cellWidget(r, 1).value(), self.table.cellWidget(r, 2).value()
            if e - s >= 1.0:
                it.start, it.end = s, e
            it.context_text = (self.table.item(r, 3).text() if self.table.item(r, 3) else "")[:60]
        self.p.edit_timeline = None

    def move(self, d):
        rows = {i.row() for i in self.table.selectedIndexes()}
        if not rows:
            return
        r = min(rows)
        self._save_table()
        self.p.move_story_item(r, d)
        self.refresh()
        self.table.selectRow(max(0, min(self.table.rowCount() - 1, r + d)))

    def commit(self):
        """Keep this page's edits (in/out points, hooks). The opening narration line only follows the
        hook when the hook actually changed, so a hand-edited first line isn't overwritten."""
        if not self.p.project.plan.story or self.table.rowCount() != len(self.p.project.plan.story):
            return
        self._save_table()
        plan = self.p.project.plan
        chosen = plan.chosen_hook
        old_line = plan.hooks[chosen].opening_line if 0 <= chosen < len(plan.hooks) else None
        for i, (rb, head, line) in enumerate(self._hook_widgets):
            if i < len(plan.hooks):
                plan.hooks[i].headline, plan.hooks[i].opening_line = head.text().strip(), line.text().strip()
                if rb.isChecked():
                    chosen = i
        if chosen != plan.chosen_hook or (0 <= chosen < len(plan.hooks) and plan.hooks[chosen].opening_line != old_line):
            self.p.choose_hook(chosen)
        else:
            for o in plan.overlays:
                if o.kind == "headline" and 0 <= chosen < len(plan.hooks):
                    o.text = plan.hooks[chosen].headline

    def save_and_next(self):
        self.commit()
        self.win.goto(3)


# =============================================================================== 4. Script & voice
class ScriptPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("4 · Script & Voice"))
        self.stale_lbl = stale_banner()
        outer.addWidget(self.stale_lbl)
        outer.addWidget(hint("The narration only describes what the clips show; quotes that aren't in the transcript "
                             "are removed automatically. Lines play in quiet moments so they don't cover what the "
                             "streamer says. Edit freely."))
        self.ai_note = QLabel("")
        self.ai_note.setWordWrap(True)
        self.ai_note.setStyleSheet("background:#3a3220; color:#f3d98b; padding:8px; border-radius:6px;")
        self.ai_note.hide()
        outer.addWidget(self.ai_note)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Clip", "When", "Narration"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        outer.addWidget(self.table, 1)
        row = QHBoxLayout()
        b = QPushButton("Add line")
        b.clicked.connect(self.add_line)
        row.addWidget(b)
        b = QPushButton("Remove line")
        b.clicked.connect(self.remove_line)
        row.addWidget(b)
        b = QPushButton("Rewrite script with AI")
        b.clicked.connect(self.rewrite)
        row.addWidget(b)
        row.addStretch(1)
        self.words = hint("")
        row.addWidget(self.words)
        outer.addLayout(row)
        vg = QGroupBox("Voice (local, free — pre-made voices only, no voice cloning)")
        f = QFormLayout(vg)
        self.voice = QComboBox()
        for k, v in VOICE_LABELS.items():
            self.voice.addItem(v, k)
        self.speed = QSlider(Qt.Orientation.Horizontal)
        self.speed.setRange(80, 130)
        self.speed_lbl = QLabel()
        self.speed.valueChanged.connect(lambda v: self.speed_lbl.setText(f"{v / 100:.2f}x"))
        sr = QHBoxLayout()
        sr.addWidget(self.speed, 1)
        sr.addWidget(self.speed_lbl)
        self.vol = QDoubleSpinBox()
        self.vol.setRange(-12, 6)
        self.vol.setSuffix(" dB")
        f.addRow("Voice", self.voice)
        f.addRow("Speed", sr)
        f.addRow("Volume", self.vol)
        b = QPushButton("Preview first line")
        b.clicked.connect(self.preview)
        f.addRow("", b)
        outer.addWidget(vg)
        self.player = Player(audio_only=True)
        self.player.setMaximumHeight(60)
        self.player.screen.setMinimumSize(220, 20)
        self.player.screen.setText("Voice preview plays here")
        outer.addWidget(self.player)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("Save → Edit")
        b.setObjectName("primary")
        b.clicked.connect(self.save_and_next)
        row.addWidget(b)
        outer.addLayout(row)

    def clear(self):
        self.table.setRowCount(0)
        self.words.setText("")
        self.stale_lbl.hide()

    def rewrite(self):
        if self.p.project.meta.get("script_edited") and QMessageBox.question(
                self, "Rewrite the script?", "This replaces your edits to the narration with a new script.\n\n"
                "Continue?") != QMessageBox.StandardButton.Yes:
            return
        self.win.run(lambda progress=None: self.p.write_script(), lambda _: self.refresh(),
                     title="Writing the script")

    def refresh(self):
        plan = self.p.project.plan
        show_stale(self.stale_lbl, "The story changed on step 3 (clips, order or hook) after this script was "
                                   "written. Lines stay attached to their clips — check them, or click 'Rewrite "
                                   "script with AI'." if self.p.stale().get("script") else "")
        n = len(plan.story)
        self.table.setRowCount(len(plan.narration))
        for r, ln in enumerate(plan.narration):
            cb = QComboBox()
            for i in range(n):
                cb.addItem(f"Clip {i + 1}", i)
            cb.setCurrentIndex(min(ln.item_index, n - 1))
            pos = QComboBox()
            pos.addItem("Before / start of clip", "before")
            pos.addItem("After this clip (after the last clip = outro)", "after")
            pos.setCurrentIndex(1 if ln.position == "after" else 0)
            self.table.setCellWidget(r, 0, cb)
            self.table.setCellWidget(r, 1, pos)
            self.table.setItem(r, 2, QTableWidgetItem(ln.text))
        v = self.p.settings.voice
        self.voice.setCurrentIndex(max(0, self.voice.findData(v.voice)))
        self.speed.setValue(int(v.speed * 100))
        self.vol.setValue(v.volume_db)
        words = sum(len(l.text.split()) for l in plan.narration)
        how = self.p.used.get("script", "?")
        self.words.setText(f"{words} words ≈ {words / 2.6:.0f}s of narration ({how})")
        if how == "rules" and plan.narration:
            self.ai_note.setText(
                "This script was written without the AI language model (Ollama isn't running), so ClipForge can't see "
                "what happens in the clips: it can only number them and quote what was actually said. For a script "
                "that describes each moment, start Ollama (see AI Models, bottom left), then click 'Rewrite script "
                "with AI'.")
            self.ai_note.show()
        else:
            self.ai_note.hide()

    def _save(self):
        plan = self.p.project.plan
        lines = []
        for r in range(self.table.rowCount()):
            text = (self.table.item(r, 2).text() if self.table.item(r, 2) else "").strip()
            if not text:
                continue
            old = plan.narration[r] if r < len(plan.narration) else None
            ln = NarrationLine(text=text, item_index=self.table.cellWidget(r, 0).currentData(),
                               position=self.table.cellWidget(r, 1).currentData())
            if old is not None and old.text == text:
                ln.audio_path, ln.duration = old.audio_path, old.duration
            lines.append(ln)
        if [(a.text, a.item_index, a.position) for a in lines] != \
                [(a.text, a.item_index, a.position) for a in plan.narration]:
            self.p.project.meta["script_edited"] = True
        plan.narration = lines
        v = self.p.settings.voice
        v.voice, v.speed, v.volume_db = self.voice.currentData(), self.speed.value() / 100, self.vol.value()
        self.p.settings.save()
        self.p.edit_timeline = None

    def add_line(self):
        self._save()
        self.p.project.plan.narration.append(NarrationLine(text="New line", item_index=0))
        self.refresh()

    def remove_line(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        self._save()
        for r in rows:
            if r < len(self.p.project.plan.narration):
                del self.p.project.plan.narration[r]
        self.refresh()

    def preview(self):
        self._save()
        plan = self.p.project.plan
        if not plan.narration:
            return

        def job(progress=None):
            from ..render.voice import synthesize_lines

            v = self.p.settings.voice
            ln = plan.narration[0]
            synthesize_lines([ln], self.p.services.tts(), v.voice, v.speed, v.volume_db, self.p.cache)
            return ln.audio_path
        self.win.run(job, self.player.load, title="Previewing the voice", steps=["voice"])

    def commit(self):
        if self.table.rowCount() or self.p.project.plan.narration:
            self._save()

    def save_and_next(self):
        self._save()
        self.win.goto(4)


# =============================================================================== 5. Edit & captions
class EditPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QHBoxLayout(self)
        left = QVBoxLayout()
        left.addWidget(h1("5 · Edit & Captions"))
        self.stale_lbl = stale_banner()
        left.addWidget(self.stale_lbl)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        form_w = QWidget()
        f = QFormLayout(form_w)
        es = self.p.settings.edit
        self.crop = QComboBox()
        for k, v in (("smart", "Smart (facecam split or action zoom)"), ("blur-fill", "Full frame + blurred fill"),
                     ("center", "Centre crop (fill screen)"), ("facecam-split", "Facecam on top")):
            self.crop.addItem(v, k)
        self.trans = QComboBox()
        self.trans.addItem("Quick cross-fade", "quick")
        self.trans.addItem("Hard cuts", "none")
        self.flash = QCheckBox("Open with a flash-forward of the best moment")
        self.tighten = QCheckBox("Cut out silent pauses inside clips (jump cuts)")
        self.music = QLineEdit()
        self.music.setPlaceholderText("Licensed music file or folder (optional)")
        mb = QPushButton("…")
        mb.setFixedWidth(30)
        mb.clicked.connect(self.pick_music)
        mrow = QHBoxLayout()
        mrow.addWidget(self.music)
        mrow.addWidget(mb)
        self.music_db = self._dspin(-40, -6, " dB")
        self.orig_db = self._dspin(-20, 6, " dB")
        self.duck_db = self._dspin(-30, 0, " dB")
        self.sfx = QCheckBox("Subtle whoosh/pop effects")
        self.cap_size = QSpinBox()
        self.cap_size.setRange(40, 140)
        self.cap_pos = self._dspin(0.4, 0.78, "", 0.01)
        self.cap_words = QSpinBox()
        self.cap_words.setRange(1, 6)
        self.cap_color = self._color_btn()
        self.cap_hi = self._color_btn()
        self.dialog_caps = QCheckBox("Caption the streamer's dialogue too")
        self.head_size = QSpinBox()
        self.head_size.setRange(40, 140)
        self.head_pos = self._dspin(0.08, 0.3, "", 0.01)
        self.end_msg = QLineEdit()
        self.monetized = QCheckBox("This Short will be monetized")
        for label, w in (("Layout", self.crop), ("Transitions", self.trans), ("", self.flash), ("", self.tighten), ("Music", mrow),
                         ("Music level", self.music_db), ("Original audio", self.orig_db),
                         ("Duck under narration", self.duck_db), ("", self.sfx), ("Caption size", self.cap_size),
                         ("Caption height (0-1)", self.cap_pos), ("Words per caption", self.cap_words),
                         ("Caption colour", self.cap_color), ("Highlight colour", self.cap_hi), ("", self.dialog_caps),
                         ("Headline size", self.head_size), ("Headline height", self.head_pos),
                         ("End message", self.end_msg), ("", self.monetized)):
            if isinstance(w, QHBoxLayout):
                f.addRow(label, w)
            else:
                f.addRow(label, w)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        form_w.setMinimumWidth(380)
        scroll.setMinimumWidth(400)
        scroll.setWidget(form_w)
        left.addWidget(scroll, 1)
        b = QPushButton("Build edit (voice + captions)")
        b.setObjectName("primary")
        b.clicked.connect(self.build)
        left.addWidget(b)
        outer.addLayout(left, 3)

        mid = QVBoxLayout()
        mid.addWidget(QLabel("Captions (double-click text to correct)"))
        self.caps = QTableWidget(0, 4)
        self.caps.setHorizontalHeaderLabels(["Start", "End", "Type", "Text"])
        self.caps.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        mid.addWidget(self.caps, 2)
        mid.addWidget(QLabel("Text overlays"))
        self.ovs = QTableWidget(0, 4)
        self.ovs.setHorizontalHeaderLabels(["Type", "Start", "End", "Text"])
        self.ovs.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        mid.addWidget(self.ovs, 1)
        row = QHBoxLayout()
        b = QPushButton("Add emphasis text")
        b.clicked.connect(self.add_overlay)
        row.addWidget(b)
        b = QPushButton("Remove overlay")
        b.clicked.connect(self.remove_overlay)
        row.addWidget(b)
        mid.addLayout(row)
        outer.addLayout(mid, 4)

        right = QVBoxLayout()
        self.player = Player()
        right.addWidget(self.player, 1)
        b = QPushButton("Render quick preview")
        b.clicked.connect(self.preview)
        right.addWidget(b)
        # ---- "Any changes?": type what you want changed, ClipForge does it and re-renders the preview
        box = QGroupBox("Any changes?")
        bl = QVBoxLayout(box)
        self.req = QPlainTextEdit()
        self.req.setPlaceholderText("Type what you'd like changed, e.g.\n"
                                    "remove clip 3, put the crash clip back in at the end,\n"
                                    "make it about 30 seconds, funnier hook, faster voice, bigger captions")
        self.req.setFixedHeight(76)
        bl.addWidget(self.req)
        rrow = QHBoxLayout()
        self.apply_btn = QPushButton("Make these changes")
        self.apply_btn.setObjectName("primary")
        self.apply_btn.clicked.connect(self.revise)
        rrow.addWidget(self.apply_btn)
        self.undo_btn = QPushButton("Undo")
        self.undo_btn.setEnabled(False)
        self.undo_btn.clicked.connect(self.undo_revision)
        rrow.addWidget(self.undo_btn)
        bl.addLayout(rrow)
        self.rev_out = QLabel("")
        self.rev_out.setTextFormat(Qt.TextFormat.RichText)
        self.rev_out.setWordWrap(True)
        self.rev_out.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        bl.addWidget(self.rev_out)
        right.addWidget(box)
        self._undo = []
        b = QPushButton("Continue → Export")
        b.setObjectName("primary")
        b.clicked.connect(lambda: (self._save(), self.win.goto(5)))
        right.addWidget(b)
        outer.addLayout(right, 2)

    def _dspin(self, lo, hi, suffix, step=0.5):
        s = QDoubleSpinBox()
        s.setRange(lo, hi)
        s.setSingleStep(step)
        s.setDecimals(2 if step < 0.1 else 1)
        s.setSuffix(suffix)
        return s

    def _color_btn(self):
        b = QPushButton()
        b.clicked.connect(lambda: self._pick_color(b))
        return b

    def _pick_color(self, b):
        c = QColorDialog.getColor(QColor(b.property("hex") or "#ffffff"), self)
        if c.isValid():
            self._set_color(b, c.name())

    def _set_color(self, b, hexv):
        b.setProperty("hex", hexv)
        b.setText(hexv)
        b.setStyleSheet(f"background:{hexv}; color:#000;")

    def pick_music(self):
        p, _ = QFileDialog.getOpenFileName(self, "Licensed music", str(Path.home()),
                                           "Audio (*.mp3 *.wav *.m4a *.ogg *.flac)")
        if p:
            self.music.setText(p)

    def refresh(self):
        es = self.p.settings.edit
        self.crop.setCurrentIndex(max(0, self.crop.findData(es.crop_mode)))
        self.trans.setCurrentIndex(max(0, self.trans.findData(es.transitions)))
        self.flash.setChecked(es.flash_forward_hook)
        self.tighten.setChecked(es.tighten_pauses)
        self.music.setText(es.music_path)
        self.music_db.setValue(es.music_db)
        self.orig_db.setValue(es.original_audio_db)
        self.duck_db.setValue(es.narration_duck_db)
        self.sfx.setChecked(es.sfx_enabled)
        self.cap_size.setValue(es.caption_size)
        self.cap_pos.setValue(es.caption_position)
        self.cap_words.setValue(es.caption_words_per_line)
        self._set_color(self.cap_color, es.caption_color)
        self._set_color(self.cap_hi, es.caption_highlight)
        self.dialog_caps.setChecked(es.show_original_dialogue_captions)
        self.head_size.setValue(es.headline_size)
        self.head_pos.setValue(es.headline_position)
        self.end_msg.setText(es.end_message)
        self.monetized.setChecked(self.p.project.plan.monetized)
        self._fill_tables()
        plan = self.p.project.plan
        st = self.p.stale()
        changed = self._what_changed()
        show_stale(self.stale_lbl, f"{changed} after this edit was made — updating it now. Downloaded clips and "
                                   f"unchanged voice lines are reused." if st.get("edit") and plan.captions else "")
        if not plan.story and self.player.player is None:
            self.player.screen.setText("No video yet.\nStart on step 1, or open a project with Projects… "
                                       "(bottom left).")
        elif plan.story and (not plan.captions or st.get("edit")):
            # nothing built yet, or built from an older story/script/settings: (re)build the edit and
            # preview automatically (once per version), so the up-to-date video simply appears here
            key = (self.p.project.project_id or str(id(self.p.project)), self.p.stage_inputs()["edit"])
            if getattr(self, "_auto_built", None) != key and not self.win.busy_now():
                self._auto_built = key
                self.player.screen.setText("Making your Short…\n(progress in the bar at the bottom)")
                QTimer.singleShot(300, self.build)
            elif self.player.player is None:
                self.player.screen.setText("Click Build edit to make the preview")

    def _what_changed(self) -> str:
        """Which earlier step made the edit out of date (in words)."""
        fp = self.p.project.meta.get("fp") or {}
        cur = self.p.stage_inputs()
        if fp.get("script") and fp.get("script") != cur["script"]:
            return "The story changed on step 3"
        parts = self.p._fp([(it.cid, round(it.start, 2), round(it.end, 2)) for it in self.p.project.plan.story])
        if fp.get("edit_story") and fp["edit_story"] != parts:
            return "The clips' timing changed on step 3"
        return "The script, voice or edit settings changed"

    def clear(self):
        self.player.unload()
        self.player.screen.setText("No video yet.")
        self.caps.setRowCount(0)
        self.ovs.setRowCount(0)
        self.stale_lbl.hide()
        self._auto_built = None
        if hasattr(self, "rev_out"):
            self.rev_out.setText("")

    def commit(self):
        if self.p.project.plan.story:
            self._save()

    STEPS = ["download", "voice", "edit", "preview"]

    def on_job_start(self):
        pass

    def on_progress(self, stage: str, frac: float, msg: str):
        from .taskbar import STEP_NAME

        if not self.player.path and self.player.player is None:
            self.player.screen.setText(f"Making your Short…\n{STEP_NAME.get(stage, stage.capitalize())}")

    def on_job_end(self):
        pass

    def on_job_failed(self, msg: str):
        first = (msg or "").strip().splitlines()[0][:200] if msg else "unknown error"
        if "Cancelled" in first:
            self.player.screen.setText("Stopped.\nClick Build edit to make the preview.")
        elif not self.player.path:
            self.player.screen.setText(f"Couldn't make the preview:\n{first}\n\nClick Build edit to try again.")

    def _fill_tables(self):
        plan = self.p.project.plan
        self.caps.setRowCount(len(plan.captions))
        for r, c in enumerate(plan.captions):
            for k, v in enumerate((f"{c.start:.2f}", f"{c.end:.2f}", c.kind, c.text)):
                it = QTableWidgetItem(v)
                if k < 3:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.caps.setItem(r, k, it)
        self.ovs.setRowCount(len(plan.overlays))
        for r, o in enumerate(plan.overlays):
            for k, v in enumerate((o.kind, f"{o.t_start:.2f}", f"{o.t_end:.2f}", o.text)):
                it = QTableWidgetItem(v)
                if k == 0:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.ovs.setItem(r, k, it)

    def _save(self):
        from ..render.captions import retime_edited

        es = self.p.settings.edit
        old = dataclasses.asdict(es)
        es.crop_mode, es.transitions = self.crop.currentData(), self.trans.currentData()
        es.flash_forward_hook = self.flash.isChecked()
        es.tighten_pauses = self.tighten.isChecked()
        es.music_path, es.music_db = self.music.text().strip(), self.music_db.value()
        es.original_audio_db, es.narration_duck_db = self.orig_db.value(), self.duck_db.value()
        es.sfx_enabled = self.sfx.isChecked()
        es.caption_size, es.caption_position = self.cap_size.value(), self.cap_pos.value()
        es.caption_words_per_line = self.cap_words.value()
        es.caption_color = self.cap_color.property("hex") or es.caption_color
        es.caption_highlight = self.cap_hi.property("hex") or es.caption_highlight
        es.show_original_dialogue_captions = self.dialog_caps.isChecked()
        es.headline_size, es.headline_position = self.head_size.value(), self.head_pos.value()
        es.end_message = self.end_msg.text().strip()
        self.p.settings.save()
        self.p.project.plan.monetized = self.monetized.isChecked()
        timing_keys = ("transitions", "flash_forward_hook", "tighten_pauses", "caption_words_per_line",
                       "show_original_dialogue_captions")
        if any(old[k] != getattr(es, k) for k in timing_keys):
            self.p.edit_timeline = None
        plan = self.p.project.plan
        for r, c in enumerate(plan.captions):
            it = self.caps.item(r, 3)
            if it is not None and it.text().strip() != c.text:
                retime_edited(c, it.text().strip())
        ovs = []
        for r in range(self.ovs.rowCount()):
            try:
                ovs.append(Overlay(self.ovs.item(r, 3).text(), self.ovs.item(r, 0).text(),
                                   float(self.ovs.item(r, 1).text()), float(self.ovs.item(r, 2).text())))
            except (AttributeError, ValueError):
                continue
        plan.overlays = ovs

    def build(self):
        self._save()

        def job(progress=None):
            self.p.prepare_edit(progress)
            return self.p.render_preview(progress)
        self.win.run(job, lambda path: (self.refresh(), self.player.load(str(path))), title="Making your Short",
                     steps=self.STEPS)

    def add_overlay(self):
        self._save()
        self.p.project.plan.overlays.append(Overlay("WAIT FOR IT", "emphasis", 2.0, 3.5))
        self._fill_tables()

    def remove_overlay(self):
        rows = sorted({i.row() for i in self.ovs.selectedIndexes()}, reverse=True)
        self._save()
        for r in rows:
            del self.p.project.plan.overlays[r]
        self._fill_tables()

    def preview(self):
        self._save()
        self.win.run(self.p.render_preview, lambda path: (self.refresh(), self.player.load(str(path))),
                     title="Rendering the preview", steps=self.STEPS)

    def revise(self):
        text = self.req.toPlainText().strip()
        if not text:
            self.rev_out.setText("Type what you'd like changed first.")
            return
        if not self.p.project.plan.story:
            self.rev_out.setText("Build the story first (pages 2–3).")
            return
        self._save()
        self.rev_out.setText("Working on it…")
        self.win.run(self.p.revise, self._revised, title="Applying your changes",
                     steps=["revise"] + self.STEPS, request=text)

    def _revised(self, r: dict):
        from html import escape

        parts = []
        if r["done"]:
            parts.append("<b>Changed:</b><br>" + "<br>".join("✅ " + escape(d) for d in r["done"]))
        if r["skipped"]:
            parts.append("<b>Not changed:</b><br>" + "<br>".join("⚠ " + escape(d) for d in r["skipped"]))
        if r.get("reply"):
            parts.append(escape(r["reply"]))
        if not r["done"] and not r["skipped"] and not r.get("reply"):
            parts.append("I didn't find anything to change in that request. Try naming the clip or line, "
                         "e.g. \"remove clip 2\" or \"make the captions bigger\".")
        self.rev_out.setText("<br><br>".join(parts))
        if r["done"]:
            self._undo.append(r["undo"])
            self.undo_btn.setEnabled(True)
            self.req.clear()
            self.refresh()
            for page in self.win.pages:            # story/script pages show the new state too
                if page is not self and hasattr(page, "refresh"):
                    try:
                        page.refresh()
                    except Exception:  # noqa: BLE001
                        pass
            if r.get("preview"):
                self.player.load(r["preview"])

    def undo_revision(self):
        if not self._undo:
            return
        snap = self._undo.pop()
        self.undo_btn.setEnabled(bool(self._undo))
        self.rev_out.setText("Undoing…")
        self.win.run(self.p.undo_revision, lambda path: (self.refresh(), self.player.load(str(path)),
                                                         self.rev_out.setText("Undone: back to the previous version.")),
                     title="Undoing the change", steps=self.STEPS, snap=snap)


# =============================================================================== 6. Export
class ExportPage(Page):
    def _ask_changes(self):
        self.win.goto(4)
        ed = self.win.pages[4]
        if hasattr(ed, "req"):
            ed.req.setFocus()

    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("6 · Export"))
        self.stale_lbl = stale_banner()
        outer.addWidget(self.stale_lbl)
        outer.addWidget(hint("Exports 1080×1920 H.264 MP4 at 30 fps with -14 LUFS audio. Each file gets a .txt next to "
                             "it with the title, description, source credit and the QC report. Export is blocked "
                             "until the footage rights are recorded on page 1."))
        f = QFormLayout()
        self.title = QLineEdit()
        self.desc = QPlainTextEdit()
        self.desc.setFixedHeight(60)
        self.out = QLineEdit()
        ob = QPushButton("…")
        ob.setFixedWidth(30)
        ob.clicked.connect(self.pick_out)
        orow = QHBoxLayout()
        orow.addWidget(self.out)
        orow.addWidget(ob)
        f.addRow("Title", self.title)
        f.addRow("Description", self.desc)
        f.addRow("Save to", orow)
        outer.addLayout(f)
        self.hg = QGroupBox("Hook variants to export (each is a separate video for A/B testing)")
        self.hl = QVBoxLayout(self.hg)
        outer.addWidget(self.hg)
        self.rights = hint("")
        outer.addWidget(self.rights)
        row = QHBoxLayout()
        self.go = QPushButton("EXPORT")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.export)
        row.addWidget(self.go)
        b = QPushButton("Open output folder")
        b.clicked.connect(lambda: open_path(self.out.text() or self.p.settings.output_dir))
        row.addWidget(b)
        b = QPushButton("← Any changes?")
        b.setToolTip("Go back to the preview and type what you'd like changed")
        b.clicked.connect(self._ask_changes)
        row.addWidget(b)
        row.addStretch(1)
        outer.addLayout(row)
        self.report = QPlainTextEdit()
        self.report.setReadOnly(True)
        outer.addWidget(self.report, 1)
        self._checks = []

    def pick_out(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.out.text())
        if d:
            self.out.setText(d)

    def refresh(self):
        show_stale(self.stale_lbl, "You changed the Short after your last export — export again to get the new "
                                   "version." if self.p.stale().get("export") else "")
        plan, src = self.p.project.plan, self.p.project.source
        self.title.setText(plan.title)
        self.desc.setPlainText(plan.description)
        self.out.setText(self.p.settings.output_dir)
        while self.hl.count():
            w = self.hl.takeAt(0).widget()
            if w:
                w.deleteLater()
        self._checks = []
        for i, h in enumerate(plan.hooks):
            cb = QCheckBox(f"{h.headline}  —  “{h.opening_line}”")
            cb.setChecked(i == plan.chosen_hook)
            self.hl.addWidget(cb)
            self._checks.append(cb)
        if src is not None:
            probs = src.rights.problems(plan.monetized)
            self.rights.setText("<span style='color:#ff7b7b'>Export blocked:<br>• " + "<br>• ".join(probs) + "</span>"
                                if probs else "<span style='color:#7bd88f'>Rights recorded ✓</span>")

    def export(self):
        plan = self.p.project.plan
        plan.title, plan.description = self.title.text().strip(), self.desc.toPlainText().strip()
        idx = [i for i, cb in enumerate(self._checks) if cb.isChecked()] or [plan.chosen_hook]
        self.p.settings.output_dir = self.out.text().strip() or self.p.settings.output_dir
        self.p.settings.save()

        def done(results):
            txt = []
            for path, rep in results:
                txt.append(f"{'✓' if rep.passed else '✗'} {path}\n{rep.summary()}\n")
            sq = getattr(self.p, "story_quality", None)
            if sq:
                txt.append("Story checks: " + ", ".join(f"{k}={v}" for k, v in sq.items() if k != "clip_lengths"))
            self.report.setPlainText("\n".join(txt))
        self.win.run(self.p.export, done, title="Exporting", steps=["download", "voice", "edit", "render"],
                     hook_indices=idx)


# =============================================================================== Settings & System Check
class SettingsDialog(QDialog):
    def __init__(self, win: "MainWindow"):
        super().__init__(win)
        self.setWindowTitle("Settings")
        self.s = win.pipeline.settings
        lay = QVBoxLayout(self)
        f = QFormLayout()
        s = self.s
        self.tb = self._combo([("parakeet", "Parakeet TDT 0.6B (fast, accurate English)"),
                               ("faster-whisper", "faster-whisper (multilingual)")], s.transcription.backend)
        self.wm = self._combo([(m, m) for m in ("small", "medium", "large-v3", "distil-large-v3")],
                              s.transcription.whisper_model)
        self.lang = QLineEdit(s.transcription.language)
        self.vb = self._combo([("clip", "CLIP (recommended)"), ("none", "Off")], s.vision.backend)
        self.every = QDoubleSpinBox()
        self.every.setRange(0.25, 5)
        self.every.setValue(s.vision.sample_every_seconds)
        self.every.setSuffix(" s between analysed frames")
        self.cap = self._combo([("ollama", "Ollama vision model"), ("none", "Off")], s.vision.captioner)
        self.capm = QLineEdit(s.vision.captioner_model)
        self.lb = self._combo([("ollama", "Ollama (local, free)"), ("openai", "OpenAI-compatible API (paid)"),
                               ("rules", "No language model (rules)")], s.llm.backend)
        self.lm = QLineEdit(s.llm.model)
        self.url = QLineEdit(s.llm.base_url)
        self.key = QLineEdit(s.llm.api_key)
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.nj = QSpinBox()
        self.nj.setRange(10, 120)
        self.nj.setValue(s.llm.max_candidates_to_judge)
        self.eb = self._combo([("ollama", "Ollama embeddings"), ("openai", "OpenAI-compatible"),
                               ("lexical", "Built-in word matching")], s.embedding.backend)
        self.em = QLineEdit(s.embedding.model)
        self.snd = self._combo([("ced", "CED-mini sound-event model (recommended)"), ("none", "Off")],
                               s.audio_ai.sound_events)
        self.dia = self._combo([("pyannote", "Identify speakers (recommended)"), ("none", "Off")], s.audio_ai.diarizer)
        self.md = QLineEdit(s.models_dir)
        self.upd = QCheckBox("Check for updates when ClipForge starts")
        self.upd.setChecked(s.check_updates)
        self.hv = QSpinBox()
        self.hv.setRange(1, 5)
        self.hv.setValue(s.hook_variants)
        self.crf = QSpinBox()
        self.crf.setRange(14, 28)
        self.crf.setValue(s.edit.crf)
        self.preset = self._combo([(p, p) for p in ("ultrafast", "veryfast", "fast", "medium", "slow")], s.edit.preset)
        for lbl, w in (("Speech-to-text", self.tb), ("Whisper model", self.wm), ("Language", self.lang),
                       ("Visual model", self.vb), ("Frame sampling", self.every), ("Frame descriptions", self.cap),
                       ("Vision LLM", self.capm), ("Language model", self.lb), ("Model", self.lm),
                       ("Server URL", self.url), ("API key", self.key), ("Moments to judge", self.nj),
                       ("Meaning search", self.eb), ("Embedding model", self.em), ("Sound events", self.snd),
                       ("Speakers", self.dia), ("Hook variants", self.hv),
                       ("Quality (CRF, lower=better)", self.crf), ("Encoding speed", self.preset),
                       ("Models folder", self.md), ("Updates", self.upd)):
            f.addRow(lbl, w)
        lay.addLayout(f)
        from .. import resources

        perf = QGroupBox("Performance")
        pf = QFormLayout(perf)
        self.perf = QComboBox()
        rec = resources.recommended_mode()
        for k in resources.MODES:
            self.perf.addItem(resources.MODE_LABELS[k] + ("  ← suggested for this PC" if k == rec else ""), k)
        self.perf.setCurrentIndex(max(0, self.perf.findData(s.performance or rec)))
        pf.addRow("Mode", self.perf)
        pf.addRow("", hint(f"This PC: {resources.cores()} CPU threads, {resources.ram_gb():.0f} GB RAM. Balanced keeps "
                           "Windows responsive (2 threads left free, lower priority, AI models unloaded between "
                           "steps). Performance uses everything. Low resource uses a quarter of the CPU. "
                           "Output quality is the same in every mode — only speed changes."))
        self.gpu = QCheckBox("Use the graphics card (GPU) when a compatible one is available")
        self.gpu.setChecked(s.use_gpu)
        g = resources.gpus()
        pf.addRow("GPU", self.gpu)
        pf.addRow("", hint(("Found: " + ", ".join(f"{x['name']} ({x['vram_total_mb'] // 1024} GB)" for x in g) +
                            ". ClipForge leaves it alone when it's nearly full.") if g else
                           "No NVIDIA graphics card found: everything runs on the CPU (Ollama manages its own "
                           "GPU use)."))
        lay.addWidget(perf)
        st = QGroupBox("Storage and diagnostics")
        sl = QGridLayout(st)
        self.cache_lbl = hint("")
        sl.addWidget(self.cache_lbl, 0, 0, 1, 4)
        b1 = QPushButton("Clean up temporary files")
        b1.clicked.connect(self.cleanup)
        b2 = QPushButton("Clear analysis cache…")
        b2.clicked.connect(self.clear_cache)
        b3 = QPushButton("Open logs folder")
        b3.clicked.connect(self.open_logs)
        b4 = QPushButton("Save diagnostic report…")
        b4.clicked.connect(self.diag)
        for i, b in enumerate((b1, b2, b3, b4)):
            sl.addWidget(b, 1, i)
        lay.addWidget(st)
        self._cache_info()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _combo(self, items, cur):
        c = QComboBox()
        for k, v in items:
            c.addItem(v, k)
        c.setCurrentIndex(max(0, c.findData(cur)))
        return c

    def _cache_info(self):
        from ..core.cache import cache_root, cache_size_bytes
        from ..core.storage import free_bytes, human

        self.cache_lbl.setText(f"Downloaded videos and analysis (cache): {human(cache_size_bytes())} · free on that "
                               f"drive: {human(free_bytes(cache_root()))}. Projects and models are not in the cache.")

    def cleanup(self):
        from ..core.cache import cache_root
        from ..core.storage import cleanup_temp, human

        if self.parent().busy_now():
            QMessageBox.information(self, "ClipForge", "Wait for the current task to finish first.")
            return
        r = cleanup_temp(cache_root(), older_than_hours=0)
        self._cache_info()
        QMessageBox.information(self, "ClipForge", f"Removed {r['files']} leftover temporary item(s), "
                                f"{human(r['bytes'])}. Downloads and analysis that can be reused were kept.")

    def open_logs(self):
        from ..crash import logs_dir
        from .shell import open_folder

        open_folder(logs_dir())

    def diag(self):
        import time as _t

        from ..crash import diagnostics_zip

        path, _ = QFileDialog.getSaveFileName(self, "Save diagnostic report",
                                              str(Path.home() / f"ClipForge_diagnostics_{_t.strftime('%Y%m%d-%H%M')}.zip"),
                                              "Zip (*.zip)")
        if path:
            diagnostics_zip(Path(path))
            QMessageBox.information(self, "ClipForge", f"Saved {path}.\nIt contains logs, crash reports, settings "
                                    "(without API keys) and basic system information — no videos or projects.")

    def clear_cache(self):
        from ..core.cache import cache_root, cache_size_bytes

        if self.parent().busy_now():
            QMessageBox.information(self, "ClipForge", "Wait for the current task to finish first.")
            return
        size = cache_size_bytes() / 1e9
        if QMessageBox.question(self, "Clear analysis cache",
                                f"Delete {size:.1f} GB of downloaded videos and analysis for ALL projects?\n\n"
                                "Your projects, settings, AI models and exported Shorts are kept, but every "
                                "project will need its video downloaded and analysed again when you next open "
                                "it.") == QMessageBox.StandardButton.Yes:
            import shutil

            shutil.rmtree(cache_root(), ignore_errors=True)
            self._cache_info()

    def save(self):
        s = self.s
        s.transcription.backend, s.transcription.whisper_model = self.tb.currentData(), self.wm.currentData()
        s.transcription.language = self.lang.text().strip() or "en"
        s.vision.backend, s.vision.sample_every_seconds = self.vb.currentData(), self.every.value()
        s.vision.captioner, s.vision.captioner_model = self.cap.currentData(), self.capm.text().strip()
        s.llm.backend, s.llm.model = self.lb.currentData(), self.lm.text().strip()
        s.llm.base_url, s.llm.api_key = self.url.text().strip(), self.key.text().strip()
        s.llm.max_candidates_to_judge = self.nj.value()
        s.embedding.backend, s.embedding.model = self.eb.currentData(), self.em.text().strip()
        s.audio_ai.sound_events, s.audio_ai.diarizer = self.snd.currentData(), self.dia.currentData()
        s.models_dir, s.hook_variants = self.md.text().strip(), self.hv.value()
        s.edit.crf, s.edit.preset = self.crf.value(), self.preset.currentData()
        s.check_updates = self.upd.isChecked()
        s.performance, s.use_gpu = self.perf.currentData(), self.gpu.isChecked()
        s.save()
        from .. import resources

        resources.set_mode(s.performance)
        self.parent().reset_services()
        self.accept()


class SystemCheckDialog(QDialog):
    def __init__(self, win: "MainWindow"):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("System Check")
        self.resize(900, 560)
        lay = QVBoxLayout(self)
        lay.addWidget(hint("Each line is checked live on this computer."))
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["", "Component", "Result", "How to fix"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.setWordWrap(True)
        lay.addWidget(self.table, 1)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setMaximumHeight(150)
        lay.addWidget(self.out)
        row = QHBoxLayout()
        b = QPushButton("Re-check")
        b.clicked.connect(self.check)
        row.addWidget(b)
        b = QPushButton("Run render self-test")
        b.clicked.connect(self.selftest)
        row.addWidget(b)
        b = QPushButton("Validate AI models")
        b.setToolTip("Runs every installed AI model on known test inputs (takes 1-5 minutes)")
        b.clicked.connect(self.validate)
        row.addWidget(b)
        row.addStretch(1)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        row.addWidget(b)
        lay.addLayout(row)
        QTimer.singleShot(50, self.check)

    def check(self):
        from ..syscheck import run_checks

        def job(progress=None):
            return run_checks(self.win.pipeline.settings)

        def show(items):
            self.table.setRowCount(len(items))
            icon = {"ok": "✅", "warn": "⚠️", "fail": "❌"}
            for r, it in enumerate(items):
                for k, v in enumerate((icon[it.status], it.name, it.detail, "" if it.status == "ok" else it.fix)):
                    self.table.setItem(r, k, QTableWidgetItem(v))
            self.table.resizeRowsToContents()
        self.win.run(job, show)

    def validate(self):
        from ..validate_models import run_all

        self.out.setPlainText("Testing each AI model on known inputs… (1-5 minutes)")
        self.win.run(lambda progress=None: run_all(self.win.pipeline.settings, progress),
                     lambda rep: self.out.setPlainText(rep.text()))

    def selftest(self):
        from ..syscheck import run_render_selftest

        self.out.setPlainText("Rendering a 6-second test Short…")
        self.win.run(lambda progress=None: run_render_selftest(self.win.pipeline.settings),
                     lambda r: self.out.setPlainText(("PASSED\n" if r[0] else "FAILED\n") + r[1]))


# =============================================================================== Main window
class MainWindow(QMainWindow):
    PAGES = ["1  Source & Topic", "2  Candidate Clips", "3  Story & Hooks", "4  Script & Voice",
             "5  Edit & Captions", "6  Export"]

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ClipForge — AI Shorts from long videos")
        self.resize(1400, 880)
        self.pipeline = Pipeline(Settings.load())
        self.worker: Optional[Worker] = None
        central = QWidget()
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        side = QVBoxLayout()
        self.proj_lbl = QLabel("")
        self.proj_lbl.setObjectName("projlabel")
        self.proj_lbl.setWordWrap(True)
        self.proj_lbl.setFixedWidth(210)
        side.addWidget(self.proj_lbl)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setFixedWidth(210)
        for p in self.PAGES:
            self.nav.addItem(QListWidgetItem(p))
        self.nav.currentRowChanged.connect(self._nav)
        side.addWidget(self.nav, 1)
        self.side_buttons = {}
        for txt, fn in (("Projects…", self.projects), ("Restart project…", self.restart_project),
                        ("Settings", self.settings), ("System Check", self.syscheck), ("AI Models", self.models),
                        ("About && Updates", self.about)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            side.addWidget(b)
            self.side_buttons[txt] = b
        lay.addLayout(side)
        self.stack = QStackedWidget()
        self.pages = [SourcePage(self), CandidatesPage(self), StoryPage(self), ScriptPage(self), EditPage(self),
                      ExportPage(self)]
        for p in self.pages:
            wrap = QWidget()
            wl = QVBoxLayout(wrap)
            wl.setContentsMargins(18, 14, 18, 14)
            wl.addWidget(p)
            wrap.setObjectName("page")
            self.stack.addWidget(wrap)
        lay.addWidget(self.stack, 1)
        outer = QWidget()
        ov = QVBoxLayout(outer)
        ov.setContentsMargins(0, 0, 0, 0)
        ov.setSpacing(0)
        ov.addWidget(central, 1)
        from .taskbar import TaskBar

        self.task = TaskBar()
        self.task.cancel_requested.connect(self.cancel_task)
        ov.addWidget(self.task)
        self.setCentralWidget(outer)
        # kept for older code paths: the task bar is the visible progress now
        self.busy = QProgressBar()
        self.busy.setRange(0, 1000)
        self.busy_lbl = QLabel("")
        from .shell import UpdateController

        self.updates = UpdateController(self)
        self._autosave = QTimer(self)        # edits are saved a few seconds after they're made
        self._autosave.setSingleShot(True)
        self._autosave.timeout.connect(self.save_project)
        self.nav.setCurrentRow(0)
        self.update_project_label()

    # ---- navigation
    def _nav(self, i: int):
        if i > 0 and not self.pipeline.project.candidates:
            QMessageBox.information(self, "ClipForge", "Find moments in a video first (step 1).")
            self.nav.blockSignals(True)
            self.nav.setCurrentRow(self.stack.currentIndex())
            self.nav.blockSignals(False)
            return
        self._leave_page()
        self.stack.setCurrentIndex(i)
        self._entered(i)

    def goto(self, i: int):
        self._leave_page()
        self.nav.blockSignals(True)
        self.nav.setCurrentRow(i)
        self.nav.blockSignals(False)
        self.stack.setCurrentIndex(i)
        self._entered(i)

    def _leave_page(self):
        """Moving between steps: keep the page's edits and save the project (safe, atomic)."""
        page = self.pages[self.stack.currentIndex()]
        if hasattr(page, "commit") and not self.busy_now():
            try:
                page.commit()
            except Exception:  # noqa: BLE001
                pass

    def _entered(self, i: int):
        pr = self.pipeline.project
        pr.meta["stage"] = i + 1
        self.save_project()
        self.pages[i].refresh()
        self.update_project_label()

    def save_project(self):
        pr = self.pipeline.project
        if pr.source is None and not pr.project_id:
            return
        try:
            pr.save()
            from .. import projects

            projects.update_session(project_path=str(projects.projects_dir() / f"{pr.project_id}.json"))
        except Exception as e:  # noqa: BLE001
            self.statusBar().showMessage(f"Couldn't save the project: {e}", 10000)

    def schedule_save(self):
        self._autosave.start(2500)

    def update_project_label(self):
        pr = self.pipeline.project
        st = pr.meta.get("status") or ""
        st = "" if (not st or st in ("new", "in progress", "restarted") or st.startswith("running")) else f" · {st}"
        self.proj_lbl.setText(f"<span style='color:#888'>Project</span><br><b>{pr.name}</b>"
                              f"<span style='color:#888'>{st}</span>")

    # ---- background jobs
    def busy_now(self) -> bool:
        return self.worker is not None and self.worker.isRunning()

    def run(self, fn, on_done, title: str = "This task", steps=None, on_fail=None, **kwargs):
        """Run one task in the background. Only one task at a time; while it runs, the pages are
        read-only (so nothing can change the project under it) and the task bar shows progress."""
        if self.busy_now():
            QMessageBox.information(self, "ClipForge", "ClipForge is still busy with "
                                    f"“{self.task.title}”. Wait for it to finish, or click Cancel.")
            return
        from .. import projects

        self.pipeline.reset_cancel()
        self._last_run = (fn, on_done, title, steps, on_fail, kwargs)
        self.worker = Worker(fn, **kwargs)
        self.worker.progress.connect(self._progress)
        self.worker.done.connect(lambda r: self._finished(on_done, r))
        self.worker.failed.connect(lambda m: self._failed(m, on_fail))
        self._job_page = self.pages[self.stack.currentIndex()]
        pr = self.pipeline.project
        self._status_before = pr.meta.get("status", "in progress")
        if pr.source is not None:
            pr.meta["status"] = f"running: {title}"     # left behind if ClipForge crashes mid-task
            self.save_project()
        projects.update_session(task=title)
        self.task.start(title, steps)
        self._lock_ui(True)
        if self._job_page is not self.pages[0] and hasattr(self._job_page, "on_job_start"):
            self._job_page.on_job_start()
        self.worker.start(QThread.Priority.LowPriority)   # the window stays responsive

    def _lock_ui(self, busy: bool):
        for w in self.pages:
            w.setEnabled(not busy)
        for name in ("Projects…", "Restart project…", "Settings", "AI Models"):
            self.side_buttons[name].setEnabled(not busy)

    def cancel_task(self):
        if self.busy_now():
            self.task.cancelling_now()
            self.pipeline.cancel()
            from ..activity import log

            log("Cancel requested")

    def _end_job(self, outcome: str, detail: str = ""):
        from .. import projects

        self._lock_ui(False)
        self.task.finish(outcome, detail)
        pr = self.pipeline.project
        if pr.meta.get("status", "").startswith("running"):
            pr.meta["status"] = self._status_before if outcome != "Finished" else (
                "exported" if pr.last_export and self._status_before == "exported" else "in progress")
        projects.update_session(task="")

    def _job_hook(self, name, *args):
        page = getattr(self, "_job_page", None)
        if page is not None and page is not self.pages[0] and hasattr(page, name):
            getattr(page, name)(*args)

    def _progress(self, stage, frac, msg):
        self.task.progress(stage, frac, msg)
        self._job_hook("on_progress", stage, frac, msg)

    def _finished(self, on_done, r):
        self._end_job("Finished", "done")
        self._job_hook("on_job_end")
        if self.pipeline.project.source is not None:
            self.pipeline.project.meta.setdefault("status", "in progress")
            if self.pipeline.project.meta["status"] in ("new", "restarted"):
                self.pipeline.project.meta["status"] = "in progress"
        self.save_project()
        try:
            on_done(r)
        finally:
            self.pages[0].refresh()
            self.update_project_label()

    def _failed(self, msg, on_fail=None):
        cancelled = "Cancelled" in (msg or "").split("\n")[0]
        self._end_job("Cancelled" if cancelled else "Error",
                      "cancelled — your project is as it was before this step" if cancelled else
                      (msg or "").strip().split("\n")[0][:140])
        self._job_hook("on_job_failed", msg)
        self.save_project()
        self.pages[0].refresh()
        self.update_project_label()
        if on_fail:
            on_fail(msg)
        if cancelled:
            return  # the user asked for it: no error dialog
        from .projects_ui import explain_failure

        fn, on_done, title, steps, of, kwargs = self._last_run
        explain_failure(self, title, msg, retry=lambda: self.run(fn, on_done, title, steps, of, **kwargs))

    def closeEvent(self, event):  # noqa: N802
        """Closing while work is running: confirm, stop the work cleanly, save the project, and
        make sure no FFmpeg is left running in the background."""
        from .. import projects, resources

        if self.busy_now():
            if QMessageBox.question(self, "ClipForge", f"“{self.task.title}” is still running. Stop it and quit? "
                                    "Finished downloads and analysis are kept and reused next time.") \
                    != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.pipeline.cancel()
            self.task.cancelling_now()
            self.worker.wait(15000)
        resources.kill_children()
        pr = self.pipeline.project
        if pr.meta.get("status", "").startswith("running"):
            pr.meta["status"] = "in progress"
        self.save_project()
        projects.end_session()
        event.accept()

    # ---- sidebar actions
    def settings(self):
        SettingsDialog(self).exec()

    def syscheck(self):
        SystemCheckDialog(self).exec()

    def models(self):
        from .shell import ModelsDialog

        ModelsDialog(self).exec()

    def about(self):
        from .shell import AboutDialog

        AboutDialog(self).exec()

    def reset_services(self):
        from ..services import Services

        self.pipeline.services = Services(self.pipeline.settings)

    # ---- projects
    def projects(self):
        from .projects_ui import ProjectsDialog

        if self.busy_now():
            return
        self._leave_page()
        self.save_project()
        ProjectsDialog(self).exec()

    def new_project(self, name: str = "", save_current: bool = True):
        if save_current:
            self._leave_page()
            self.save_project()
        self.pipeline.new_project(name)
        if name:
            self.pipeline.project.save()
        for pg in self.pages:
            if hasattr(pg, "clear"):
                pg.clear()
        self.goto(0)
        self.task.idle("New project — load a video to begin")

    def restart_project(self):
        from .projects_ui import RestartDialog

        if self.busy_now():
            return
        pr = self.pipeline.project
        if pr.source is None and not pr.candidates:
            QMessageBox.information(self, "ClipForge", "This project hasn't started yet: there's nothing to restart.")
            return
        d = RestartDialog(self)
        if d.exec() != QDialog.DialogCode.Accepted:
            return
        res = self.pipeline.restart(keep_source=d.keep.isChecked())
        for pg in self.pages:
            if hasattr(pg, "clear"):
                pg.clear()
        self.goto(0)
        msg = "Project restarted from step 1."
        if res.get("source_data_mb"):
            msg += f" Freed {res['source_data_mb']:.0f} MB."
        self.task.idle(msg)

    def open_project_path(self, path: str):
        def done(_):
            note = getattr(self.pipeline, "recovered_note", "")
            for pg in self.pages:
                if hasattr(pg, "clear"):
                    pg.clear()
            pr = self.pipeline.project
            page = max(0, min(5, int(pr.meta.get("stage") or 1) - 1))
            if page > 0 and not pr.candidates:
                page = 0
            self.goto(page)
            if note:
                QMessageBox.information(self, "ClipForge", note)
        self.run(lambda progress=None: self.pipeline.open_project(path, progress), done,
                 title="Opening the project", steps=["transcript", "audio", "visual", "sounds"])

    def open_project(self):
        self.projects()

    def reopen_last_project(self):
        """Pick up where you left off: reopen the last saved project and go to the furthest page it reached."""
        from ..config import app_dir

        try:
            path = Path((app_dir() / "last_project.txt").read_text(encoding="utf-8").strip())
        except OSError:   # projects saved by versions before 1.2.8: take the newest one
            saved = sorted((app_dir() / "projects").glob("*.json"), key=lambda q: q.stat().st_mtime)
            if not saved:
                return
            path = saved[-1]
        if not path.exists() or self.pipeline.project.source is not None:
            return

        def done(_):
            pr = self.pipeline.project
            plan = pr.plan
            page = int(pr.meta.get("stage") or 0) - 1
            if page < 0:
                page = 4 if plan.story and plan.narration is not None and plan.captions else \
                    (2 if plan.story else (1 if pr.candidates else 0))
            if page > 0 and not pr.candidates:
                page = 0
            self.goto(max(0, min(5, page)))
            self.task.idle(f"Reopened “{pr.name}”")
        self.run(lambda progress=None: self.pipeline.open_project(str(path), progress), done,
                 title="Reopening your last project")

    # used by the candidates page
    def make_clip_preview(self, start: float, end: float, progress=None) -> str:
        from ..core import ffmpeg as ff

        src = self.pipeline.project.source
        out = self.pipeline.cache.subdir("previews") / f"p_{int(start * 10)}_{int(end * 10)}.mp4"
        if not out.exists():
            if src.kind == "file" and Path(src.path).exists():
                ff.run(["-ss", f"{start:.2f}", "-i", src.path, "-t", f"{end - start:.2f}", "-vf", "scale=-2:480",
                        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-c:a", "aac", str(out)],
                       label="Preview")
            else:  # analysis copy (low frame rate) + analysis audio: fast, no download needed
                ff.run(["-ss", f"{start:.2f}", "-i", src.proxy_path, "-ss", f"{start:.2f}", "-i", src.audio_path,
                        "-t", f"{end - start:.2f}", "-map", "0:v", "-map", "1:a", "-vf", "fps=15", "-c:v", "libx264",
                        "-preset", "ultrafast", "-c:a", "aac", str(out)], label="Preview")
        return str(out)


def main(on_ready=None):
    """on_ready: called once the window is on screen (the launcher uses it to confirm that a freshly
    updated version starts correctly; otherwise it rolls back)."""
    from .. import __version__
    from .shell import after_start, app_icon

    app = QApplication(sys.argv)
    app.setApplicationName("ClipForge")
    app.setApplicationDisplayName("ClipForge")
    app.setApplicationVersion(__version__)
    app.setOrganizationName("ClipForge")
    app.setWindowIcon(app_icon())
    app.setStyleSheet(STYLE)
    f = QFont()
    f.setPointSizeF(10.5)
    app.setFont(f)
    from PySide6.QtCore import QObject, Signal

    from .. import crash

    class _Bridge(QObject):          # errors from any thread are shown on the window's thread
        err = Signal(str)
    bridge = _Bridge()
    crash.install(on_error=bridge.err.emit)
    w = MainWindow()
    w._bridge = bridge
    bridge.err.connect(lambda m: QMessageBox.warning(
        w, "ClipForge", "Something unexpected went wrong. Your project is saved and ClipForge keeps running.\n\n"
        + m[:1500]))
    w.setWindowTitle(f"ClipForge {__version__} — AI Shorts from long videos")
    w.show()

    def ready():
        if on_ready:
            on_ready()
        from .. import updater

        updater.mark_started_ok()
        after_start(w)
    QTimer.singleShot(0, ready)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
