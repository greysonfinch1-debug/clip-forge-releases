"""The task status area at the bottom of the window: what ClipForge is doing, how far along it
is (only when that can actually be measured; otherwise an honest "working" animation), the
time left when it can be estimated, and a Cancel button."""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QProgressBar, QPushButton

# what kind of work each pipeline step is
STATE_OF = {"ingest": "Downloading", "download": "Downloading", "models": "Loading AI models",
            "transcript": "Analysing", "audio": "Analysing", "visual": "Analysing", "sounds": "Analysing",
            "speakers": "Analysing", "evidence": "Analysing", "topic": "Analysing",
            "judge": "Generating", "story": "Generating", "script": "Generating", "revise": "Generating",
            "voice": "Generating", "edit": "Generating", "preview": "Rendering", "render": "Exporting",
            "qc": "Exporting", "check": "Checking", "selftest": "Rendering", "validate": "Checking"}
STEP_NAME = {"ingest": "Getting the video", "download": "Getting the clips", "models": "Loading AI models",
             "transcript": "Transcribing speech", "audio": "Analysing audio", "visual": "Analysing the picture",
             "sounds": "Recognising sounds", "speakers": "Identifying speakers", "evidence": "Gathering evidence",
             "judge": "Judging moments", "story": "Writing the story", "revise": "Applying your changes",
             "voice": "Recording narration", "edit": "Laying out the edit", "preview": "Rendering the preview",
             "render": "Rendering the Short", "qc": "Checking the result"}
COLORS = {"Idle": "#6b7280", "Downloading": "#3b82f6", "Loading AI models": "#8b5cf6", "Analysing": "#8b5cf6",
          "Generating": "#14b8a6", "Rendering": "#f59e0b", "Exporting": "#f59e0b", "Checking": "#14b8a6",
          "Preparing": "#3b82f6", "Cancelling": "#ef4444", "Cancelled": "#6b7280", "Finished": "#22c55e",
          "Error": "#ef4444", "Working": "#3b82f6"}


def _fmt(sec: float) -> str:
    sec = int(max(0, sec))
    return f"{sec // 60}:{sec % 60:02d}" if sec < 3600 else f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


class TaskBar(QFrame):
    cancel_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("taskbar")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 10, 4)
        self.chip = QLabel("Idle")
        self.chip.setObjectName("taskchip")
        self.chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.chip.setMinimumWidth(128)
        self.text = QLabel("Ready")
        self.text.setTextFormat(Qt.TextFormat.RichText)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setFixedWidth(240)
        self.bar.setTextVisible(True)
        self.eta = QLabel("")
        self.eta.setMinimumWidth(150)
        self.eta.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.cancel = QPushButton("Cancel")
        self.cancel.clicked.connect(self._cancel)
        lay.addWidget(self.chip)
        lay.addWidget(self.text, 1)
        lay.addWidget(self.eta)
        lay.addWidget(self.bar)
        lay.addWidget(self.cancel)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self.running = False
        self._set_state("Idle")
        self.bar.hide()
        self.cancel.hide()

    # ---- driven by the main window
    def start(self, title: str, steps: list[str] | None = None) -> None:
        self.running, self.cancelling = True, False
        self.title, self.steps = title, list(steps or [])
        self.t0 = self.t_step = self.t_msg = time.time()
        self.stage, self.msg = "", "Starting…"
        self.f0 = self.f_last = None
        self.determinate = False
        self._set_state("Working")
        self.bar.show()
        self.cancel.show()
        self.cancel.setEnabled(True)
        self._indeterminate()
        self._render()

    def progress(self, stage: str, frac: float, msg: str) -> None:
        if not self.running:
            return
        now = time.time()
        if stage != self.stage:
            self.stage, self.t_step = stage, now
            self.f0, self.determinate = frac, False
        if msg != self.msg:
            self.msg, self.t_msg = msg, now
        self.f_last = frac
        # a step counts as measurable once its fraction actually moves (no fake percentages)
        if stage != "models" and self.f0 is not None and frac - self.f0 > 0.005:
            self.determinate = True
        if not self.cancelling:
            st = STATE_OF.get(stage, "Working")
            if stage == "ingest" and "ownload" not in msg:
                st = "Preparing"
            self._set_state(st)
        if self.determinate:
            if self.bar.maximum() == 0:
                self.bar.setRange(0, 1000)
            self.bar.setValue(int(max(0.0, min(1.0, frac)) * 1000))
        else:
            self._indeterminate()
        self._render()

    def cancelling_now(self) -> None:
        self.cancelling = True
        self._set_state("Cancelling")
        self.msg = "Stopping safely… (your project stays as it was before this step)"
        self.cancel.setEnabled(False)
        self._indeterminate()
        self._render()

    def finish(self, outcome: str, detail: str = "") -> None:
        """outcome: Finished / Cancelled / Error."""
        self.running = False
        self._set_state(outcome)
        took = _fmt(time.time() - getattr(self, "t0", time.time()))
        self.text.setText(f"<b>{getattr(self, 'title', '')}</b> — {detail or outcome.lower()} "
                          f"<span style='color:#888'>({took})</span>")
        self.eta.setText("")
        self.bar.hide()
        self.cancel.hide()

    def idle(self, text: str = "Ready") -> None:
        if not self.running:
            self._set_state("Idle")
            self.text.setText(text)

    # ---- internals
    def _cancel(self):
        self.cancel_requested.emit()

    def _indeterminate(self):
        if self.bar.maximum() != 0:
            self.bar.setRange(0, 0)       # Qt's busy animation: honest "working, can't measure"

    def _set_state(self, st: str):
        self.state = st
        self.chip.setText(st)
        self.chip.setStyleSheet(f"background:{COLORS.get(st, '#3b82f6')};color:white;border-radius:9px;"
                                f"padding:3px 10px;font-weight:600;")

    def _render(self):
        step = ""
        if self.stage in self.steps:
            step = f"Step {self.steps.index(self.stage) + 1} of {len(self.steps)} · "
        name = STEP_NAME.get(self.stage, self.stage.capitalize() if self.stage else "")
        quiet = time.time() - self.t_msg
        wait = f" — still working ({int(quiet)} s)" if quiet >= 15 and not self.cancelling else ""
        self.text.setText(f"<b>{self.title}</b> — {step}{name + ': ' if name else ''}{self.msg}{wait}")
        self._tick()

    def _tick(self):
        if not self.running:
            return
        now = time.time()
        el = f"{_fmt(now - self.t0)} elapsed"
        eta = ""
        if self.determinate and self.f_last is not None and self.f0 is not None:
            done = self.f_last - self.f0
            span = now - self.t_step
            if done >= 0.05 and span >= 3:
                left = span * (1.0 - self.f_last) / done
                eta = f"~{_fmt(left)} left in this step · "
        self.eta.setText(eta + el)
        if now - self.t_msg >= 15:
            name = STEP_NAME.get(self.stage, "")
            step = f"Step {self.steps.index(self.stage) + 1} of {len(self.steps)} · " if self.stage in self.steps else ""
            self.text.setText(f"<b>{self.title}</b> — {step}{name + ': ' if name else ''}{self.msg}"
                              f"{'' if self.cancelling else f' — still working ({int(now - self.t_msg)} s)'}")
