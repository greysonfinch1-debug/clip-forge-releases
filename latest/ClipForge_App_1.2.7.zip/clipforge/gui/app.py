"""ClipForge desktop interface (PySide6).

Pages: 1 Source & Topic → 2 Candidate Clips → 3 Story & Hooks → 4 Script & Voice →
5 Edit & Captions → 6 Export.  Settings and System Check open from the sidebar.
All heavy work runs in background threads (gui/workers.py) through clipforge.pipeline.
"""
from __future__ import annotations

import dataclasses
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QColorDialog, QComboBox, QDialog,
                               QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame, QGridLayout,
                               QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QRadioButton,
                               QScrollArea, QSlider, QSpinBox, QSplitter, QStackedWidget, QTableWidget,
                               QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget)

from ..config import Settings
from ..core.models import RIGHTS_BASES, NarrationLine, Overlay, fmt_time
from ..intelligence.selection import filter_reasons
from ..pipeline import Pipeline
from ..providers.tts import VOICE_LABELS
from .workers import Worker

try:  # video preview (optional: works if Qt Multimedia backends are present)
    if os.environ.get("CLIPFORGE_NO_MEDIA"):
        raise ImportError("disabled")
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAVE_MM = True
except Exception:  # noqa: BLE001
    HAVE_MM = False

STYLE = """
QWidget { font-size: 10.5pt; }
QMainWindow, QDialog, QWidget#page { background: #15171c; color: #e8e8ec; }
QMessageBox QLabel { color: #e8e8ec; }
QLabel { color: #e8e8ec; }
QLabel#h1 { font-size: 17pt; font-weight: 700; }
QLabel#hint { color: #9aa0ab; }
QGroupBox { border: 1px solid #2c3039; border-radius: 8px; margin-top: 14px; padding: 10px; color: #e8e8ec; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #c9ccd3; }
QListWidget#nav { background: #0f1115; border: none; color: #c9ccd3; font-size: 11pt; }
QListWidget#nav::item { padding: 12px 14px; }
QListWidget#nav::item:selected { background: #262a33; color: #ffffff; border-left: 3px solid #ffd400; }
QPushButton { background: #2a2e37; color: #e8e8ec; border: 1px solid #3a3f4b; border-radius: 6px; padding: 6px 12px; }
QPushButton:hover { background: #343945; }
QPushButton:disabled { color: #6b707a; }
QPushButton#primary { background: #ffd400; color: #111; font-weight: 700; border: none; padding: 10px 18px; }
QPushButton#primary:hover { background: #ffe14d; }
QPushButton#primary:disabled { background: #6b6224; color: #333; }
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
  background: #1d2027; color: #e8e8ec; border: 1px solid #343945; border-radius: 5px; padding: 4px; }
QTableWidget { background: #1a1d23; color: #e8e8ec; gridline-color: #2c3039; alternate-background-color: #1f2229; }
QHeaderView { background: #23262e; }
QTableCornerButton::section { background: #23262e; border: none; }
QScrollArea, QScrollArea > QWidget > QWidget { background: #15171c; border: none; }
QHeaderView::section { background: #23262e; color: #c9ccd3; padding: 4px; border: none; }
QProgressBar { background: #1d2027; border: 1px solid #343945; border-radius: 5px; text-align: center; color: #eee; }
QProgressBar::chunk { background: #ffd400; border-radius: 4px; }
QCheckBox, QRadioButton { color: #e8e8ec; }
"""


def h1(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("h1")
    return l


def hint(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("hint")
    l.setWordWrap(True)
    return l


def open_path(p: str):
    if sys.platform == "win32":
        os.startfile(p)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


class Page(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.setObjectName("page")
        self.win = win
        self.p: Pipeline = win.pipeline

    def refresh(self):
        pass


class Player(QWidget):
    """Small preview player. The media engine is created on first use, so a missing or broken
    audio device can never stop the app from starting; without Qt Multimedia, previews open in
    the default video player."""

    def __init__(self, audio_only: bool = False):
        super().__init__()
        self.audio_only = audio_only     # voice previews: no video surface (on Windows a video surface is a
        self.lay = QVBoxLayout(self)     # native black window that can cover the buttons around it)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.path = ""
        self.player = None
        self.screen = QLabel("Preview appears here")
        self.screen.setObjectName("hint")
        self.screen.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.screen.setMinimumSize(220, 120)
        self.lay.addWidget(self.screen, 1)
        row = QHBoxLayout()
        self.play_btn = QPushButton("Play / Pause")
        self.play_btn.clicked.connect(self.toggle)
        ext = QPushButton("Open externally")
        ext.clicked.connect(lambda: self.path and open_path(self.path))
        row.addWidget(self.play_btn)
        row.addWidget(ext)
        self.lay.addLayout(row)

    def _ensure(self) -> bool:
        if self.player is not None:
            return True
        if not HAVE_MM:
            return False
        try:
            self.player = QMediaPlayer()
            self.audio = QAudioOutput()
            self.player.setAudioOutput(self.audio)
            self.player.errorOccurred.connect(self._error)
            if not self.audio_only:
                self.video = QVideoWidget()
                self.video.setMinimumSize(220, 300)
                self.player.setVideoOutput(self.video)
                self.lay.replaceWidget(self.screen, self.video)
                self.screen.hide()
            return True
        except Exception:  # noqa: BLE001
            self.player = None
            return False

    def load(self, path: str, autoplay: bool = True):
        self.path = str(path)
        if self._ensure():
            if self.audio_only:
                self.screen.setText("▶ Playing voice preview (Play / Pause to replay)")
            self.player.setSource(QUrl.fromLocalFile(self.path))
            if autoplay:
                self.player.play()
        else:
            self.screen.setText(f"Ready: {Path(self.path).name}")
            if autoplay:
                open_path(self.path)

    def _error(self, _err, msg):
        self.screen.setText(f"Can't play the preview here ({msg or 'unknown error'}). Click Open externally.")
        if not self.audio_only and getattr(self, "video", None) is not None:
            self.lay.replaceWidget(self.video, self.screen)
            self.video.hide()
            self.screen.show()
            self.player.setVideoOutput(None)
            del self.video

    def toggle(self):
        if self.player is None:
            if self.path:
                open_path(self.path)
            return
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()


# =============================================================================== 1. Source & topic
class SourcePage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("1 · Source & Topic"))
        outer.addWidget(hint("Paste a public YouTube, Twitch or Kick video link, or open a video file. Only use "
                             "footage you have permission to edit and publish. Private, members-only, DRM-protected "
                             "and live videos are refused."))
        src = QGroupBox("Video")
        g = QGridLayout(src)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://www.youtube.com/watch?v=…   or   https://www.twitch.tv/videos/…")
        load = QPushButton("Load link")
        load.clicked.connect(self.load_url)
        browse = QPushButton("Open video file…")
        browse.clicked.connect(self.load_file)
        g.addWidget(self.url, 0, 0)
        g.addWidget(load, 0, 1)
        g.addWidget(browse, 0, 2)
        self.info = hint("No video loaded.")
        g.addWidget(self.info, 1, 0, 1, 3)
        outer.addWidget(src)

        rights = QGroupBox("Footage rights (required before export)")
        f = QFormLayout(rights)
        self.basis = QComboBox()
        self.basis.addItem("— choose —", "")
        for k, v in RIGHTS_BASES.items():
            self.basis.addItem(v, k)
        self.creator = QLineEdit()
        self.creator.setPlaceholderText("Streamer / channel who gave permission")
        self.commercial = QCheckBox("The permission covers monetized (commercial) use")
        self.publisher = QCheckBox("I checked the game publisher's video policy allows this use")
        self.notes = QLineEdit()
        self.notes.setPlaceholderText("Where the permission is stored (e.g. 'email from X, 2026-11-02')")
        self.confirm = QCheckBox("I confirm this information is true")
        f.addRow("Basis", self.basis)
        f.addRow("Creator", self.creator)
        f.addRow("", self.commercial)
        f.addRow("", self.publisher)
        f.addRow("Notes", self.notes)
        f.addRow("", self.confirm)
        for w in (self.basis,):
            w.currentIndexChanged.connect(self.save_rights)
        for w in (self.commercial, self.publisher, self.confirm):
            w.toggled.connect(self.save_rights)
        for w in (self.creator, self.notes):
            w.editingFinished.connect(self.save_rights)
        outer.addWidget(rights)

        tp = QGroupBox("What should the Short be about?")
        v = QVBoxLayout(tp)
        self.topic = QPlainTextEdit()
        self.topic.setPlaceholderText("e.g. Find exciting police chases where the cops are after the streamer")
        self.topic.setFixedHeight(70)
        v.addWidget(self.topic)
        row = QHBoxLayout()
        row.addWidget(QLabel("Target length"))
        self.target = QComboBox()
        for s in (20, 30, 45, 60, 90):
            self.target.addItem(f"{s} seconds", s)
        self.target.setCurrentIndex(2)
        row.addWidget(self.target)
        row.addSpacing(20)
        row.addWidget(QLabel("Number of clips"))
        self.nclips = QSpinBox()
        self.nclips.setRange(0, 12)
        self.nclips.setSpecialValueText("Automatic")
        row.addWidget(self.nclips)
        row.addStretch(1)
        v.addLayout(row)
        outer.addWidget(tp)

        row = QHBoxLayout()
        self.go = QPushButton("ANALYZE VIDEO")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.analyze)
        self.cancel = QPushButton("Cancel")
        self.cancel.clicked.connect(self.p.cancel)
        row.addWidget(self.go)
        row.addWidget(self.cancel)
        row.addStretch(1)
        outer.addLayout(row)
        self.stage = QLabel("")
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        outer.addWidget(self.stage)
        outer.addWidget(self.bar)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        outer.addWidget(self.log, 1)

    # ---- actions
    def load_url(self):
        url = self.url.text().strip()
        if not url:
            return
        self.win.run(self.p.ingest, self.loaded, url=url)

    def load_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open video", str(Path.home()),
                                              "Video (*.mp4 *.mkv *.mov *.webm *.avi *.flv *.ts *.m4v)")
        if path:
            self.win.run(self.p.ingest, self.loaded, path=path)

    def loaded(self, src):
        self.refresh()

    def save_rights(self, *_):
        src = self.p.project.source
        if src is None:
            return
        r = src.rights
        r.basis = self.basis.currentData() or ""
        r.creator = self.creator.text().strip()
        r.commercial_use = self.commercial.isChecked()
        r.game_publisher_ok = self.publisher.isChecked()
        r.notes = self.notes.text().strip()
        r.confirmed = self.confirm.isChecked()
        self.p.save_rights()

    def analyze(self):
        if self.p.project.source is None:
            if self.url.text().strip():
                self.win.run(self.p.ingest, lambda _: self.analyze(), url=self.url.text().strip())
            else:
                QMessageBox.information(self, "ClipForge", "Load a video link or file first.")
            return
        topic = self.topic.toPlainText().strip()
        if len(topic) < 3:
            QMessageBox.information(self, "ClipForge", "Describe the topic of the Short first.")
            return
        self.win.run(self.p.find_moments, lambda _: self.win.goto(1), topic=topic,
                     target_seconds=float(self.target.currentData()), desired_clips=self.nclips.value())

    def on_progress(self, stage: str, frac: float, msg: str):
        self.stage.setText(f"{stage.capitalize()}: {msg}")
        self.bar.setValue(int(frac * 1000))

    def refresh(self):
        src = self.p.project.source
        if src is None:
            return
        self.info.setText(f"<b>{src.title}</b> — {src.uploader or src.platform} — {fmt_time(src.duration)} — "
                          f"{src.width}x{src.height}")
        r = src.rights
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(True)
        self.basis.setCurrentIndex(max(0, self.basis.findData(r.basis)))
        self.creator.setText(r.creator or src.uploader)
        self.commercial.setChecked(r.commercial_use)
        self.publisher.setChecked(r.game_publisher_ok)
        self.notes.setText(r.notes)
        self.confirm.setChecked(r.confirmed)
        for w in (self.basis, self.commercial, self.publisher, self.confirm):
            w.blockSignals(False)
        self.log.setPlainText("\n".join(self.p.project.log[-200:]))
        self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())


# =============================================================================== 2. Candidates
COLS = ["Use", "Rank", "Start", "End", "Length", "Score", "Topic", "Fun", "Context", "Audio", "Visual", "Conf.",
        "What happens", "Why it matches / why filtered"]


class CandidatesPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("2 · Candidate Clips"))
        self.summary = hint("")
        outer.addWidget(self.summary)
        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(12, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(13, QHeaderView.ResizeMode.Stretch)
        self.table.itemSelectionChanged.connect(self.show_detail)
        split.addWidget(self.table)
        bottom = QWidget()
        bl = QHBoxLayout(bottom)
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        bl.addWidget(self.detail, 2)
        self.player = Player()
        bl.addWidget(self.player, 1)
        split.addWidget(bottom)
        split.setSizes([420, 260])
        outer.addWidget(split, 1)
        row = QHBoxLayout()
        b = QPushButton("Preview selected")
        b.clicked.connect(self.preview)
        row.addWidget(b)
        b = QPushButton("Replace selected with next best")
        b.clicked.connect(self.replace)
        row.addWidget(b)
        b = QPushButton("Auto-select again")
        b.clicked.connect(lambda: self.win.run_sync(self.p.auto_select, self.refresh))
        row.addWidget(b)
        row.addStretch(1)
        b = QPushButton("Use ticked clips → Story")
        b.setObjectName("primary")
        b.clicked.connect(self.apply)
        row.addWidget(b)
        outer.addLayout(row)

    def refresh(self):
        cands = sorted(self.p.project.candidates, key=lambda c: c.rank or 999)
        self.table.setRowCount(len(cands))
        self._rows = cands
        for r, c in enumerate(cands):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            chk.setCheckState(Qt.CheckState.Checked if c.included else Qt.CheckState.Unchecked)
            fr = filter_reasons(c)
            vals = [c.rank, fmt_time(c.start), fmt_time(c.end), f"{c.duration:.0f}s", f"{c.final_score:.0f}",
                    f"{c.topic_match:.1f}", f"{c.entertainment:.1f}", f"{c.context_completeness:.1f}",
                    f"{c.audio_quality:.1f}", f"{c.visual_quality:.1f}", f"{c.confidence:.2f}", c.description,
                    ("FILTERED: " + "; ".join(fr)) if fr else c.why_matches]
            self.table.setItem(r, 0, chk)
            for k, v in enumerate(vals, start=1):
                it = QTableWidgetItem(str(v))
                if fr:
                    it.setForeground(QColor("#80858f"))
                if c.included:
                    it.setBackground(QColor("#2b2a14"))
                self.table.setItem(r, k, it)
        used = self.p.used
        n = sum(c.included for c in cands)
        self.summary.setText(f"{len(cands)} moments judged, {n} selected. Engines — judge: <b>{used.get('judge', '?')}</b>, "
                             f"meaning search: {used.get('embedder', '?')}, vision: {used.get('vision', '?')}, "
                             f"sounds: {used.get('sound_events', '?')}, speakers: {used.get('speakers', '?')}, "
                             f"speech: {used.get('transcription', '?')}. "
                             "Tick/untick clips, then continue. Grey rows were filtered (reason shown).")

    def _sel(self):
        rows = {i.row() for i in self.table.selectedIndexes()}
        return [self._rows[r] for r in sorted(rows)] if rows else []

    def show_detail(self):
        s = self._sel()
        if not s:
            return
        c = s[0]
        e = c.evidence
        self.detail.setHtml(
            f"<b>{fmt_time(c.start)} – {fmt_time(c.end)}</b> · judged by {c.judged_by}<br><b>What happens:</b> {c.description}"
            f"<br><b>Why:</b> {c.why_matches}<br><b>Before:</b> <i>{e.transcript_before}</i><br><b>Said:</b> {e.transcript}"
            f"<br><b>After:</b> <i>{e.transcript_after}</i><br><b>On screen:</b> {', '.join(e.visual_labels[:8])}"
            f"<br>{'<br>'.join(e.frame_captions[:3])}<br><b>Audio:</b> {e.audio_summary}"
            f"<br><b>Signals:</b> {'; '.join(r for r in c.reasons if not r.startswith('context:'))}")

    def preview(self):
        s = self._sel()
        if s:
            self.win.run(self.win.make_clip_preview, self.player.load, start=s[0].start, end=s[0].end)

    def replace(self):
        s = self._sel()
        if s:
            self.win.run_sync(lambda: self.p.replace_clip(s[0].cid), self.refresh)

    def apply(self):
        inc = {self._rows[r].cid for r in range(self.table.rowCount())
               if self.table.item(r, 0).checkState() == Qt.CheckState.Checked}
        if not inc:
            QMessageBox.information(self, "ClipForge", "Tick at least one clip.")
            return
        self.win.run_sync(lambda: self.p.set_choices(inc), lambda _=None: self.win.goto(2))


# =============================================================================== 3. Story & hooks
class StoryPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("3 · Story & Hooks"))
        outer.addWidget(hint("Clips play in this order. Each clip keeps its setup and reaction; adjust in/out points "
                             "if needed. The narration is attached to its clip and moves with it."))
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Role", "Start (s)", "End (s)", "On-screen context", "Why here",
                                              "What happens"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        outer.addWidget(self.table, 2)
        row = QHBoxLayout()
        for txt, d in (("Move up", -1), ("Move down", 1)):
            b = QPushButton(txt)
            b.clicked.connect(lambda _=False, d=d: self.move(d))
            row.addWidget(b)
        b = QPushButton("Rebuild order with AI")
        b.clicked.connect(lambda: self.win.run(lambda progress=None: self.p.build_story(progress), lambda _: self.refresh()))
        row.addWidget(b)
        row.addStretch(1)
        outer.addLayout(row)
        hg = QGroupBox("Hook (opening headline + first line). Pick one; you can export several as A/B variants.")
        self.hook_lay = QVBoxLayout(hg)
        outer.addWidget(hg, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("Save → Script")
        b.setObjectName("primary")
        b.clicked.connect(self.save_and_next)
        row.addWidget(b)
        outer.addLayout(row)
        self._hook_widgets = []

    def refresh(self):
        plan = self.p.project.plan
        by_id = {c.cid: c for c in self.p.project.candidates}
        self.table.blockSignals(True)
        self.table.setRowCount(len(plan.story))
        for r, it in enumerate(plan.story):
            c = by_id.get(it.cid)
            self.table.setItem(r, 0, QTableWidgetItem(it.role))
            for col, val in ((1, it.start), (2, it.end)):
                sp = QDoubleSpinBox()
                sp.setRange(0, 1e6)
                sp.setDecimals(1)
                sp.setSingleStep(0.5)
                sp.setValue(val)
                self.table.setCellWidget(r, col, sp)
            self.table.setItem(r, 3, QTableWidgetItem(it.context_text))
            self.table.setItem(r, 4, QTableWidgetItem(it.rationale))
            self.table.setItem(r, 5, QTableWidgetItem(c.description if c else ""))
        self.table.blockSignals(False)
        while self.hook_lay.count():
            w = self.hook_lay.takeAt(0).widget()
            if w:
                w.deleteLater()
        self._hook_widgets = []
        for i, h in enumerate(plan.hooks):
            w = QWidget()
            l = QHBoxLayout(w)
            l.setContentsMargins(0, 0, 0, 0)
            rb = QRadioButton()
            rb.setChecked(i == plan.chosen_hook)
            head = QLineEdit(h.headline)
            line = QLineEdit(h.opening_line)
            head.setCursorPosition(0)
            line.setCursorPosition(0)
            l.addWidget(rb)
            l.addWidget(QLabel("Headline"))
            l.addWidget(head, 1)
            l.addWidget(QLabel("Opening line"))
            l.addWidget(line, 2)
            self.hook_lay.addWidget(w)
            self._hook_widgets.append((rb, head, line))

    def _save_table(self):
        plan = self.p.project.plan
        for r, it in enumerate(plan.story):
            s, e = self.table.cellWidget(r, 1).value(), self.table.cellWidget(r, 2).value()
            if e - s >= 1.0:
                it.start, it.end = s, e
            it.context_text = (self.table.item(r, 3).text() if self.table.item(r, 3) else "")[:60]
        self.p.edit_timeline = None

    def move(self, d):
        rows = {i.row() for i in self.table.selectedIndexes()}
        if not rows:
            return
        r = min(rows)
        self._save_table()
        self.p.move_story_item(r, d)
        self.refresh()
        self.table.selectRow(max(0, min(self.table.rowCount() - 1, r + d)))

    def save_and_next(self):
        self._save_table()
        plan = self.p.project.plan
        chosen = plan.chosen_hook
        for i, (rb, head, line) in enumerate(self._hook_widgets):
            plan.hooks[i].headline, plan.hooks[i].opening_line = head.text().strip(), line.text().strip()
            if rb.isChecked():
                chosen = i
        self.p.choose_hook(chosen)
        self.win.goto(3)


# =============================================================================== 4. Script & voice
class ScriptPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("4 · Script & Voice"))
        outer.addWidget(hint("The narration only describes what the clips show; quotes that aren't in the transcript "
                             "are removed automatically. Lines play in quiet moments so they don't cover what the "
                             "streamer says. Edit freely."))
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Clip", "When", "Narration"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        outer.addWidget(self.table, 1)
        row = QHBoxLayout()
        b = QPushButton("Add line")
        b.clicked.connect(self.add_line)
        row.addWidget(b)
        b = QPushButton("Remove line")
        b.clicked.connect(self.remove_line)
        row.addWidget(b)
        b = QPushButton("Rewrite script with AI")
        b.clicked.connect(lambda: self.win.run_sync(self.p.write_script, self.refresh))
        row.addWidget(b)
        row.addStretch(1)
        self.words = hint("")
        row.addWidget(self.words)
        outer.addLayout(row)
        vg = QGroupBox("Voice (local, free — pre-made voices only, no voice cloning)")
        f = QFormLayout(vg)
        self.voice = QComboBox()
        for k, v in VOICE_LABELS.items():
            self.voice.addItem(v, k)
        self.speed = QSlider(Qt.Orientation.Horizontal)
        self.speed.setRange(80, 130)
        self.speed_lbl = QLabel()
        self.speed.valueChanged.connect(lambda v: self.speed_lbl.setText(f"{v / 100:.2f}x"))
        sr = QHBoxLayout()
        sr.addWidget(self.speed, 1)
        sr.addWidget(self.speed_lbl)
        self.vol = QDoubleSpinBox()
        self.vol.setRange(-12, 6)
        self.vol.setSuffix(" dB")
        f.addRow("Voice", self.voice)
        f.addRow("Speed", sr)
        f.addRow("Volume", self.vol)
        b = QPushButton("Preview first line")
        b.clicked.connect(self.preview)
        f.addRow("", b)
        outer.addWidget(vg)
        self.player = Player(audio_only=True)
        self.player.setMaximumHeight(60)
        self.player.screen.setMinimumSize(220, 20)
        self.player.screen.setText("Voice preview plays here")
        outer.addWidget(self.player)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("Save → Edit")
        b.setObjectName("primary")
        b.clicked.connect(self.save_and_next)
        row.addWidget(b)
        outer.addLayout(row)

    def refresh(self):
        plan = self.p.project.plan
        n = len(plan.story)
        self.table.setRowCount(len(plan.narration))
        for r, ln in enumerate(plan.narration):
            cb = QComboBox()
            for i in range(n):
                cb.addItem(f"Clip {i + 1}", i)
            cb.setCurrentIndex(min(ln.item_index, n - 1))
            pos = QComboBox()
            pos.addItem("Before / start of clip", "before")
            pos.addItem("After last clip (outro)", "after")
            pos.setCurrentIndex(1 if ln.position == "after" else 0)
            self.table.setCellWidget(r, 0, cb)
            self.table.setCellWidget(r, 1, pos)
            self.table.setItem(r, 2, QTableWidgetItem(ln.text))
        v = self.p.settings.voice
        self.voice.setCurrentIndex(max(0, self.voice.findData(v.voice)))
        self.speed.setValue(int(v.speed * 100))
        self.vol.setValue(v.volume_db)
        words = sum(len(l.text.split()) for l in plan.narration)
        self.words.setText(f"{words} words ≈ {words / 2.6:.0f}s of narration ({self.p.used.get('script', '?')})")

    def _save(self):
        plan = self.p.project.plan
        lines = []
        for r in range(self.table.rowCount()):
            text = (self.table.item(r, 2).text() if self.table.item(r, 2) else "").strip()
            if not text:
                continue
            old = plan.narration[r] if r < len(plan.narration) else None
            ln = NarrationLine(text=text, item_index=self.table.cellWidget(r, 0).currentData(),
                               position=self.table.cellWidget(r, 1).currentData())
            if old is not None and old.text == text:
                ln.audio_path, ln.duration = old.audio_path, old.duration
            lines.append(ln)
        plan.narration = lines
        v = self.p.settings.voice
        v.voice, v.speed, v.volume_db = self.voice.currentData(), self.speed.value() / 100, self.vol.value()
        self.p.settings.save()
        self.p.edit_timeline = None

    def add_line(self):
        self._save()
        self.p.project.plan.narration.append(NarrationLine(text="New line", item_index=0))
        self.refresh()

    def remove_line(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        self._save()
        for r in rows:
            if r < len(self.p.project.plan.narration):
                del self.p.project.plan.narration[r]
        self.refresh()

    def preview(self):
        self._save()
        plan = self.p.project.plan
        if not plan.narration:
            return

        def job(progress=None):
            from ..render.voice import synthesize_lines

            v = self.p.settings.voice
            ln = plan.narration[0]
            synthesize_lines([ln], self.p.services.tts(), v.voice, v.speed, v.volume_db, self.p.cache)
            return ln.audio_path
        self.win.run(job, self.player.load)

    def save_and_next(self):
        self._save()
        self.win.goto(4)


# =============================================================================== 5. Edit & captions
class EditPage(Page):
    def __init__(self, win):
        super().__init__(win)
        outer = QHBoxLayout(self)
        left = QVBoxLayout()
        left.addWidget(h1("5 · Edit & Captions"))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        form_w = QWidget()
        f = QFormLayout(form_w)
        es = self.p.settings.edit
        self.crop = QComboBox()
        for k, v in (("smart", "Smart (facecam split or action zoom)"), ("blur-fill", "Full frame + blurred fill"),
                     ("center", "Centre crop (fill screen)"), ("facecam-split", "Facecam on top")):
            self.crop.addItem(v, k)
        self.trans = QComboBox()
        self.trans.addItem("Quick cross-fade", "quick")
        self.trans.addItem("Hard cuts", "none")
        self.flash = QCheckBox("Open with a flash-forward of the best moment")
        self.music = QLineEdit()
        self.music.setPlaceholderText("Licensed music file or folder (optional)")
        mb = QPushButton("…")
        mb.setFixedWidth(30)
        mb.clicked.connect(self.pick_music)
        mrow = QHBoxLayout()
        mrow.addWidget(self.music)
        mrow.addWidget(mb)
        self.music_db = self._dspin(-40, -6, " dB")
        self.orig_db = self._dspin(-20, 6, " dB")
        self.duck_db = self._dspin(-30, 0, " dB")
        self.sfx = QCheckBox("Subtle whoosh/pop effects")
        self.cap_size = QSpinBox()
        self.cap_size.setRange(40, 140)
        self.cap_pos = self._dspin(0.4, 0.78, "", 0.01)
        self.cap_words = QSpinBox()
        self.cap_words.setRange(1, 6)
        self.cap_color = self._color_btn()
        self.cap_hi = self._color_btn()
        self.dialog_caps = QCheckBox("Caption the streamer's dialogue too")
        self.head_size = QSpinBox()
        self.head_size.setRange(40, 140)
        self.head_pos = self._dspin(0.08, 0.3, "", 0.01)
        self.end_msg = QLineEdit()
        self.monetized = QCheckBox("This Short will be monetized")
        for label, w in (("Layout", self.crop), ("Transitions", self.trans), ("", self.flash), ("Music", mrow),
                         ("Music level", self.music_db), ("Original audio", self.orig_db),
                         ("Duck under narration", self.duck_db), ("", self.sfx), ("Caption size", self.cap_size),
                         ("Caption height (0-1)", self.cap_pos), ("Words per caption", self.cap_words),
                         ("Caption colour", self.cap_color), ("Highlight colour", self.cap_hi), ("", self.dialog_caps),
                         ("Headline size", self.head_size), ("Headline height", self.head_pos),
                         ("End message", self.end_msg), ("", self.monetized)):
            if isinstance(w, QHBoxLayout):
                f.addRow(label, w)
            else:
                f.addRow(label, w)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        form_w.setMinimumWidth(380)
        scroll.setMinimumWidth(400)
        scroll.setWidget(form_w)
        left.addWidget(scroll, 1)
        b = QPushButton("Build edit (voice + captions)")
        b.setObjectName("primary")
        b.clicked.connect(self.build)
        left.addWidget(b)
        outer.addLayout(left, 3)

        mid = QVBoxLayout()
        mid.addWidget(QLabel("Captions (double-click text to correct)"))
        self.caps = QTableWidget(0, 4)
        self.caps.setHorizontalHeaderLabels(["Start", "End", "Type", "Text"])
        self.caps.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        mid.addWidget(self.caps, 2)
        mid.addWidget(QLabel("Text overlays"))
        self.ovs = QTableWidget(0, 4)
        self.ovs.setHorizontalHeaderLabels(["Type", "Start", "End", "Text"])
        self.ovs.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        mid.addWidget(self.ovs, 1)
        row = QHBoxLayout()
        b = QPushButton("Add emphasis text")
        b.clicked.connect(self.add_overlay)
        row.addWidget(b)
        b = QPushButton("Remove overlay")
        b.clicked.connect(self.remove_overlay)
        row.addWidget(b)
        mid.addLayout(row)
        outer.addLayout(mid, 4)

        right = QVBoxLayout()
        self.player = Player()
        right.addWidget(self.player, 1)
        b = QPushButton("Render quick preview")
        b.clicked.connect(self.preview)
        right.addWidget(b)
        # ---- "Any changes?": type what you want changed, ClipForge does it and re-renders the preview
        box = QGroupBox("Any changes?")
        bl = QVBoxLayout(box)
        self.req = QPlainTextEdit()
        self.req.setPlaceholderText("Type what you'd like changed, e.g.\n"
                                    "remove clip 3, put the crash clip back in at the end,\n"
                                    "make it about 30 seconds, funnier hook, faster voice, bigger captions")
        self.req.setFixedHeight(76)
        bl.addWidget(self.req)
        rrow = QHBoxLayout()
        self.apply_btn = QPushButton("Make these changes")
        self.apply_btn.setObjectName("primary")
        self.apply_btn.clicked.connect(self.revise)
        rrow.addWidget(self.apply_btn)
        self.undo_btn = QPushButton("Undo")
        self.undo_btn.setEnabled(False)
        self.undo_btn.clicked.connect(self.undo_revision)
        rrow.addWidget(self.undo_btn)
        bl.addLayout(rrow)
        self.rev_out = QLabel("")
        self.rev_out.setTextFormat(Qt.TextFormat.RichText)
        self.rev_out.setWordWrap(True)
        self.rev_out.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        bl.addWidget(self.rev_out)
        right.addWidget(box)
        self._undo = []
        b = QPushButton("Continue → Export")
        b.setObjectName("primary")
        b.clicked.connect(lambda: (self._save(), self.win.goto(5)))
        right.addWidget(b)
        outer.addLayout(right, 2)

    def _dspin(self, lo, hi, suffix, step=0.5):
        s = QDoubleSpinBox()
        s.setRange(lo, hi)
        s.setSingleStep(step)
        s.setDecimals(2 if step < 0.1 else 1)
        s.setSuffix(suffix)
        return s

    def _color_btn(self):
        b = QPushButton()
        b.clicked.connect(lambda: self._pick_color(b))
        return b

    def _pick_color(self, b):
        c = QColorDialog.getColor(QColor(b.property("hex") or "#ffffff"), self)
        if c.isValid():
            self._set_color(b, c.name())

    def _set_color(self, b, hexv):
        b.setProperty("hex", hexv)
        b.setText(hexv)
        b.setStyleSheet(f"background:{hexv}; color:#000;")

    def pick_music(self):
        p, _ = QFileDialog.getOpenFileName(self, "Licensed music", str(Path.home()),
                                           "Audio (*.mp3 *.wav *.m4a *.ogg *.flac)")
        if p:
            self.music.setText(p)

    def refresh(self):
        es = self.p.settings.edit
        self.crop.setCurrentIndex(max(0, self.crop.findData(es.crop_mode)))
        self.trans.setCurrentIndex(max(0, self.trans.findData(es.transitions)))
        self.flash.setChecked(es.flash_forward_hook)
        self.music.setText(es.music_path)
        self.music_db.setValue(es.music_db)
        self.orig_db.setValue(es.original_audio_db)
        self.duck_db.setValue(es.narration_duck_db)
        self.sfx.setChecked(es.sfx_enabled)
        self.cap_size.setValue(es.caption_size)
        self.cap_pos.setValue(es.caption_position)
        self.cap_words.setValue(es.caption_words_per_line)
        self._set_color(self.cap_color, es.caption_color)
        self._set_color(self.cap_hi, es.caption_highlight)
        self.dialog_caps.setChecked(es.show_original_dialogue_captions)
        self.head_size.setValue(es.headline_size)
        self.head_pos.setValue(es.headline_position)
        self.end_msg.setText(es.end_message)
        self.monetized.setChecked(self.p.project.plan.monetized)
        self._fill_tables()

    def _fill_tables(self):
        plan = self.p.project.plan
        self.caps.setRowCount(len(plan.captions))
        for r, c in enumerate(plan.captions):
            for k, v in enumerate((f"{c.start:.2f}", f"{c.end:.2f}", c.kind, c.text)):
                it = QTableWidgetItem(v)
                if k < 3:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.caps.setItem(r, k, it)
        self.ovs.setRowCount(len(plan.overlays))
        for r, o in enumerate(plan.overlays):
            for k, v in enumerate((o.kind, f"{o.t_start:.2f}", f"{o.t_end:.2f}", o.text)):
                it = QTableWidgetItem(v)
                if k == 0:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.ovs.setItem(r, k, it)

    def _save(self):
        from ..render.captions import retime_edited

        es = self.p.settings.edit
        old = dataclasses.asdict(es)
        es.crop_mode, es.transitions = self.crop.currentData(), self.trans.currentData()
        es.flash_forward_hook = self.flash.isChecked()
        es.music_path, es.music_db = self.music.text().strip(), self.music_db.value()
        es.original_audio_db, es.narration_duck_db = self.orig_db.value(), self.duck_db.value()
        es.sfx_enabled = self.sfx.isChecked()
        es.caption_size, es.caption_position = self.cap_size.value(), self.cap_pos.value()
        es.caption_words_per_line = self.cap_words.value()
        es.caption_color = self.cap_color.property("hex") or es.caption_color
        es.caption_highlight = self.cap_hi.property("hex") or es.caption_highlight
        es.show_original_dialogue_captions = self.dialog_caps.isChecked()
        es.headline_size, es.headline_position = self.head_size.value(), self.head_pos.value()
        es.end_message = self.end_msg.text().strip()
        self.p.settings.save()
        self.p.project.plan.monetized = self.monetized.isChecked()
        timing_keys = ("transitions", "flash_forward_hook", "caption_words_per_line", "show_original_dialogue_captions")
        if any(old[k] != getattr(es, k) for k in timing_keys):
            self.p.edit_timeline = None
        plan = self.p.project.plan
        for r, c in enumerate(plan.captions):
            it = self.caps.item(r, 3)
            if it is not None and it.text().strip() != c.text:
                retime_edited(c, it.text().strip())
        ovs = []
        for r in range(self.ovs.rowCount()):
            try:
                ovs.append(Overlay(self.ovs.item(r, 3).text(), self.ovs.item(r, 0).text(),
                                   float(self.ovs.item(r, 1).text()), float(self.ovs.item(r, 2).text())))
            except (AttributeError, ValueError):
                continue
        plan.overlays = ovs

    def build(self):
        self._save()

        def job(progress=None):
            self.p.prepare_edit(progress)
            return self.p.render_preview(progress)
        self.win.run(job, lambda path: (self.refresh(), self.player.load(str(path))))

    def add_overlay(self):
        self._save()
        self.p.project.plan.overlays.append(Overlay("WAIT FOR IT", "emphasis", 2.0, 3.5))
        self._fill_tables()

    def remove_overlay(self):
        rows = sorted({i.row() for i in self.ovs.selectedIndexes()}, reverse=True)
        self._save()
        for r in rows:
            del self.p.project.plan.overlays[r]
        self._fill_tables()

    def preview(self):
        self._save()
        self.win.run(self.p.render_preview, lambda path: (self.refresh(), self.player.load(str(path))))

    def revise(self):
        text = self.req.toPlainText().strip()
        if not text:
            self.rev_out.setText("Type what you'd like changed first.")
            return
        if not self.p.project.plan.story:
            self.rev_out.setText("Build the story first (pages 2–3).")
            return
        self._save()
        self.rev_out.setText("Working on it…")
        self.win.run(self.p.revise, self._revised, request=text)

    def _revised(self, r: dict):
        from html import escape

        parts = []
        if r["done"]:
            parts.append("<b>Changed:</b><br>" + "<br>".join("✅ " + escape(d) for d in r["done"]))
        if r["skipped"]:
            parts.append("<b>Not changed:</b><br>" + "<br>".join("⚠ " + escape(d) for d in r["skipped"]))
        if r.get("reply"):
            parts.append(escape(r["reply"]))
        if not r["done"] and not r["skipped"] and not r.get("reply"):
            parts.append("I didn't find anything to change in that request. Try naming the clip or line, "
                         "e.g. \"remove clip 2\" or \"make the captions bigger\".")
        self.rev_out.setText("<br><br>".join(parts))
        if r["done"]:
            self._undo.append(r["undo"])
            self.undo_btn.setEnabled(True)
            self.req.clear()
            self.refresh()
            for page in self.win.pages:            # story/script pages show the new state too
                if page is not self and hasattr(page, "refresh"):
                    try:
                        page.refresh()
                    except Exception:  # noqa: BLE001
                        pass
            if r.get("preview"):
                self.player.load(r["preview"])

    def undo_revision(self):
        if not self._undo:
            return
        snap = self._undo.pop()
        self.undo_btn.setEnabled(bool(self._undo))
        self.rev_out.setText("Undoing…")
        self.win.run(self.p.undo_revision, lambda path: (self.refresh(), self.player.load(str(path)),
                                                         self.rev_out.setText("Undone: back to the previous version.")),
                     snap=snap)


# =============================================================================== 6. Export
class ExportPage(Page):
    def _ask_changes(self):
        self.win.goto(4)
        ed = self.win.pages[4]
        if hasattr(ed, "req"):
            ed.req.setFocus()

    def __init__(self, win):
        super().__init__(win)
        outer = QVBoxLayout(self)
        outer.addWidget(h1("6 · Export"))
        outer.addWidget(hint("Exports 1080×1920 H.264 MP4 at 30 fps with -14 LUFS audio. Each file gets a .txt next to "
                             "it with the title, description, source credit and the QC report. Export is blocked "
                             "until the footage rights are recorded on page 1."))
        f = QFormLayout()
        self.title = QLineEdit()
        self.desc = QPlainTextEdit()
        self.desc.setFixedHeight(60)
        self.out = QLineEdit()
        ob = QPushButton("…")
        ob.setFixedWidth(30)
        ob.clicked.connect(self.pick_out)
        orow = QHBoxLayout()
        orow.addWidget(self.out)
        orow.addWidget(ob)
        f.addRow("Title", self.title)
        f.addRow("Description", self.desc)
        f.addRow("Save to", orow)
        outer.addLayout(f)
        self.hg = QGroupBox("Hook variants to export (each is a separate video for A/B testing)")
        self.hl = QVBoxLayout(self.hg)
        outer.addWidget(self.hg)
        self.rights = hint("")
        outer.addWidget(self.rights)
        row = QHBoxLayout()
        self.go = QPushButton("EXPORT")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.export)
        row.addWidget(self.go)
        b = QPushButton("Open output folder")
        b.clicked.connect(lambda: open_path(self.out.text() or self.p.settings.output_dir))
        row.addWidget(b)
        b = QPushButton("← Any changes?")
        b.setToolTip("Go back to the preview and type what you'd like changed")
        b.clicked.connect(self._ask_changes)
        row.addWidget(b)
        row.addStretch(1)
        outer.addLayout(row)
        self.report = QPlainTextEdit()
        self.report.setReadOnly(True)
        outer.addWidget(self.report, 1)
        self._checks = []

    def pick_out(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.out.text())
        if d:
            self.out.setText(d)

    def refresh(self):
        plan, src = self.p.project.plan, self.p.project.source
        self.title.setText(plan.title)
        self.desc.setPlainText(plan.description)
        self.out.setText(self.p.settings.output_dir)
        while self.hl.count():
            w = self.hl.takeAt(0).widget()
            if w:
                w.deleteLater()
        self._checks = []
        for i, h in enumerate(plan.hooks):
            cb = QCheckBox(f"{h.headline}  —  “{h.opening_line}”")
            cb.setChecked(i == plan.chosen_hook)
            self.hl.addWidget(cb)
            self._checks.append(cb)
        if src is not None:
            probs = src.rights.problems(plan.monetized)
            self.rights.setText("<span style='color:#ff7b7b'>Export blocked:<br>• " + "<br>• ".join(probs) + "</span>"
                                if probs else "<span style='color:#7bd88f'>Rights recorded ✓</span>")

    def export(self):
        plan = self.p.project.plan
        plan.title, plan.description = self.title.text().strip(), self.desc.toPlainText().strip()
        idx = [i for i, cb in enumerate(self._checks) if cb.isChecked()] or [plan.chosen_hook]
        self.p.settings.output_dir = self.out.text().strip() or self.p.settings.output_dir
        self.p.settings.save()

        def done(results):
            txt = []
            for path, rep in results:
                txt.append(f"{'✓' if rep.passed else '✗'} {path}\n{rep.summary()}\n")
            sq = getattr(self.p, "story_quality", None)
            if sq:
                txt.append("Story checks: " + ", ".join(f"{k}={v}" for k, v in sq.items() if k != "clip_lengths"))
            self.report.setPlainText("\n".join(txt))
        self.win.run(self.p.export, done, hook_indices=idx)


# =============================================================================== Settings & System Check
class SettingsDialog(QDialog):
    def __init__(self, win: "MainWindow"):
        super().__init__(win)
        self.setWindowTitle("Settings")
        self.s = win.pipeline.settings
        lay = QVBoxLayout(self)
        f = QFormLayout()
        s = self.s
        self.tb = self._combo([("parakeet", "Parakeet TDT 0.6B (fast, accurate English)"),
                               ("faster-whisper", "faster-whisper (multilingual)")], s.transcription.backend)
        self.wm = self._combo([(m, m) for m in ("small", "medium", "large-v3", "distil-large-v3")],
                              s.transcription.whisper_model)
        self.lang = QLineEdit(s.transcription.language)
        self.vb = self._combo([("clip", "CLIP (recommended)"), ("none", "Off")], s.vision.backend)
        self.every = QDoubleSpinBox()
        self.every.setRange(0.25, 5)
        self.every.setValue(s.vision.sample_every_seconds)
        self.every.setSuffix(" s between analysed frames")
        self.cap = self._combo([("ollama", "Ollama vision model"), ("none", "Off")], s.vision.captioner)
        self.capm = QLineEdit(s.vision.captioner_model)
        self.lb = self._combo([("ollama", "Ollama (local, free)"), ("openai", "OpenAI-compatible API (paid)"),
                               ("rules", "No language model (rules)")], s.llm.backend)
        self.lm = QLineEdit(s.llm.model)
        self.url = QLineEdit(s.llm.base_url)
        self.key = QLineEdit(s.llm.api_key)
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.nj = QSpinBox()
        self.nj.setRange(10, 120)
        self.nj.setValue(s.llm.max_candidates_to_judge)
        self.eb = self._combo([("ollama", "Ollama embeddings"), ("openai", "OpenAI-compatible"),
                               ("lexical", "Built-in word matching")], s.embedding.backend)
        self.em = QLineEdit(s.embedding.model)
        self.snd = self._combo([("ced", "CED-mini sound-event model (recommended)"), ("none", "Off")],
                               s.audio_ai.sound_events)
        self.dia = self._combo([("pyannote", "Identify speakers (recommended)"), ("none", "Off")], s.audio_ai.diarizer)
        self.md = QLineEdit(s.models_dir)
        self.upd = QCheckBox("Check for updates when ClipForge starts")
        self.upd.setChecked(s.check_updates)
        self.hv = QSpinBox()
        self.hv.setRange(1, 5)
        self.hv.setValue(s.hook_variants)
        self.crf = QSpinBox()
        self.crf.setRange(14, 28)
        self.crf.setValue(s.edit.crf)
        self.preset = self._combo([(p, p) for p in ("ultrafast", "veryfast", "fast", "medium", "slow")], s.edit.preset)
        for lbl, w in (("Speech-to-text", self.tb), ("Whisper model", self.wm), ("Language", self.lang),
                       ("Visual model", self.vb), ("Frame sampling", self.every), ("Frame descriptions", self.cap),
                       ("Vision LLM", self.capm), ("Language model", self.lb), ("Model", self.lm),
                       ("Server URL", self.url), ("API key", self.key), ("Moments to judge", self.nj),
                       ("Meaning search", self.eb), ("Embedding model", self.em), ("Sound events", self.snd),
                       ("Speakers", self.dia), ("Hook variants", self.hv),
                       ("Quality (CRF, lower=better)", self.crf), ("Encoding speed", self.preset),
                       ("Models folder", self.md), ("Updates", self.upd)):
            f.addRow(lbl, w)
        lay.addLayout(f)
        row = QHBoxLayout()
        clr = QPushButton("Clear analysis cache")
        clr.clicked.connect(self.clear_cache)
        row.addWidget(clr)
        row.addStretch(1)
        lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _combo(self, items, cur):
        c = QComboBox()
        for k, v in items:
            c.addItem(v, k)
        c.setCurrentIndex(max(0, c.findData(cur)))
        return c

    def clear_cache(self):
        from ..core.cache import cache_root, cache_size_bytes

        size = cache_size_bytes() / 1e9
        if QMessageBox.question(self, "Clear cache", f"Delete {size:.1f} GB of cached analysis? Videos will need "
                                "re-analysing.") == QMessageBox.StandardButton.Yes:
            import shutil

            shutil.rmtree(cache_root(), ignore_errors=True)

    def save(self):
        s = self.s
        s.transcription.backend, s.transcription.whisper_model = self.tb.currentData(), self.wm.currentData()
        s.transcription.language = self.lang.text().strip() or "en"
        s.vision.backend, s.vision.sample_every_seconds = self.vb.currentData(), self.every.value()
        s.vision.captioner, s.vision.captioner_model = self.cap.currentData(), self.capm.text().strip()
        s.llm.backend, s.llm.model = self.lb.currentData(), self.lm.text().strip()
        s.llm.base_url, s.llm.api_key = self.url.text().strip(), self.key.text().strip()
        s.llm.max_candidates_to_judge = self.nj.value()
        s.embedding.backend, s.embedding.model = self.eb.currentData(), self.em.text().strip()
        s.audio_ai.sound_events, s.audio_ai.diarizer = self.snd.currentData(), self.dia.currentData()
        s.models_dir, s.hook_variants = self.md.text().strip(), self.hv.value()
        s.edit.crf, s.edit.preset = self.crf.value(), self.preset.currentData()
        s.check_updates = self.upd.isChecked()
        s.save()
        self.parent().reset_services()
        self.accept()


class SystemCheckDialog(QDialog):
    def __init__(self, win: "MainWindow"):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("System Check")
        self.resize(900, 560)
        lay = QVBoxLayout(self)
        lay.addWidget(hint("Each line is checked live on this computer."))
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["", "Component", "Result", "How to fix"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.setWordWrap(True)
        lay.addWidget(self.table, 1)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setMaximumHeight(150)
        lay.addWidget(self.out)
        row = QHBoxLayout()
        b = QPushButton("Re-check")
        b.clicked.connect(self.check)
        row.addWidget(b)
        b = QPushButton("Run render self-test")
        b.clicked.connect(self.selftest)
        row.addWidget(b)
        b = QPushButton("Validate AI models")
        b.setToolTip("Runs every installed AI model on known test inputs (takes 1-5 minutes)")
        b.clicked.connect(self.validate)
        row.addWidget(b)
        row.addStretch(1)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        row.addWidget(b)
        lay.addLayout(row)
        QTimer.singleShot(50, self.check)

    def check(self):
        from ..syscheck import run_checks

        def job(progress=None):
            return run_checks(self.win.pipeline.settings)

        def show(items):
            self.table.setRowCount(len(items))
            icon = {"ok": "✅", "warn": "⚠️", "fail": "❌"}
            for r, it in enumerate(items):
                for k, v in enumerate((icon[it.status], it.name, it.detail, "" if it.status == "ok" else it.fix)):
                    self.table.setItem(r, k, QTableWidgetItem(v))
            self.table.resizeRowsToContents()
        self.win.run(job, show)

    def validate(self):
        from ..validate_models import run_all

        self.out.setPlainText("Testing each AI model on known inputs… (1-5 minutes)")
        self.win.run(lambda progress=None: run_all(self.win.pipeline.settings, progress),
                     lambda rep: self.out.setPlainText(rep.text()))

    def selftest(self):
        from ..syscheck import run_render_selftest

        self.out.setPlainText("Rendering a 6-second test Short…")
        self.win.run(lambda progress=None: run_render_selftest(self.win.pipeline.settings),
                     lambda r: self.out.setPlainText(("PASSED\n" if r[0] else "FAILED\n") + r[1]))


# =============================================================================== Main window
class MainWindow(QMainWindow):
    PAGES = ["1  Source & Topic", "2  Candidate Clips", "3  Story & Hooks", "4  Script & Voice",
             "5  Edit & Captions", "6  Export"]

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ClipForge — AI Shorts from long videos")
        self.resize(1400, 880)
        self.pipeline = Pipeline(Settings.load())
        self.worker: Optional[Worker] = None
        central = QWidget()
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        side = QVBoxLayout()
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setFixedWidth(210)
        for p in self.PAGES:
            self.nav.addItem(QListWidgetItem(p))
        self.nav.currentRowChanged.connect(self._nav)
        side.addWidget(self.nav, 1)
        for txt, fn in (("Open project…", self.open_project), ("Settings", self.settings),
                        ("System Check", self.syscheck), ("AI Models", self.models),
                        ("About && Updates", self.about)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            side.addWidget(b)
        lay.addLayout(side)
        self.stack = QStackedWidget()
        self.pages = [SourcePage(self), CandidatesPage(self), StoryPage(self), ScriptPage(self), EditPage(self),
                      ExportPage(self)]
        for p in self.pages:
            wrap = QWidget()
            wl = QVBoxLayout(wrap)
            wl.setContentsMargins(18, 14, 18, 14)
            wl.addWidget(p)
            wrap.setObjectName("page")
            self.stack.addWidget(wrap)
        lay.addWidget(self.stack, 1)
        self.setCentralWidget(central)
        self.busy = QProgressBar()
        self.busy.setRange(0, 1000)
        self.busy.setMaximumWidth(320)
        self.busy_lbl = QLabel("Ready")
        self.statusBar().addWidget(self.busy_lbl, 1)
        self.statusBar().addPermanentWidget(self.busy)
        from .shell import UpdateController

        self.updates = UpdateController(self)
        self.nav.setCurrentRow(0)

    # ---- navigation
    def _nav(self, i: int):
        if i > 0 and not self.pipeline.project.candidates:
            QMessageBox.information(self, "ClipForge", "Analyse a video first (page 1).")
            self.nav.blockSignals(True)
            self.nav.setCurrentRow(0)
            self.nav.blockSignals(False)
            return
        self.stack.setCurrentIndex(i)
        self.pages[i].refresh()

    def goto(self, i: int):
        self.nav.setCurrentRow(i)
        self.stack.setCurrentIndex(i)
        self.pages[i].refresh()

    # ---- background jobs
    def run(self, fn, on_done, **kwargs):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "ClipForge", "Please wait for the current task to finish (or cancel it).")
            return
        self.worker = Worker(fn, **kwargs)
        self.worker.progress.connect(self._progress)
        self.worker.done.connect(lambda r: self._finished(on_done, r))
        self.worker.failed.connect(self._failed)
        self.busy_lbl.setText("Working…")
        self.worker.start()

    def run_sync(self, fn, on_done):
        try:
            fn()
            on_done()
        except Exception as e:  # noqa: BLE001
            self._failed(str(e))

    def _progress(self, stage, frac, msg):
        self.busy.setValue(int(frac * 1000))
        self.busy_lbl.setText(f"{stage}: {msg}")
        self.pages[0].on_progress(stage, frac, msg)

    def _finished(self, on_done, r):
        self.busy.setValue(1000)
        self.busy_lbl.setText("Done")
        self.pipeline.project.save() if self.pipeline.project.source else None
        on_done(r)
        self.pages[0].refresh()

    def _failed(self, msg):
        self.busy_lbl.setText("Stopped")
        self.pages[0].refresh()
        if "Cancelled" in msg.split("\n")[0]:
            return  # the user asked for it: no error dialog
        QMessageBox.warning(self, "ClipForge", msg[:3000])

    def closeEvent(self, event):  # noqa: N802
        """Closing while work is running: confirm, stop the work cleanly, save the project."""
        if self.worker is not None and self.worker.isRunning():
            if QMessageBox.question(self, "ClipForge", "A task is still running. Stop it and quit? "
                                    "Finished analysis is kept and reused next time.") \
                    != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.pipeline.cancel()
            self.worker.wait(15000)
        try:
            if self.pipeline.project.source is not None:
                self.pipeline.project.save()
        except Exception:  # noqa: BLE001
            pass
        event.accept()

    # ---- sidebar actions
    def settings(self):
        SettingsDialog(self).exec()

    def syscheck(self):
        SystemCheckDialog(self).exec()

    def models(self):
        from .shell import ModelsDialog

        ModelsDialog(self).exec()

    def about(self):
        from .shell import AboutDialog

        AboutDialog(self).exec()

    def reset_services(self):
        from ..services import Services

        self.pipeline.services = Services(self.pipeline.settings)

    def open_project(self):
        from ..config import app_dir

        path, _ = QFileDialog.getOpenFileName(self, "Open project", str(app_dir() / "projects"), "Project (*.json)")
        if path:
            self.run(lambda progress=None: self.pipeline.open_project(path, progress), lambda _: self.goto(1))

    # used by the candidates page
    def make_clip_preview(self, start: float, end: float, progress=None) -> str:
        from ..core import ffmpeg as ff

        src = self.pipeline.project.source
        out = self.pipeline.cache.subdir("previews") / f"p_{int(start * 10)}_{int(end * 10)}.mp4"
        if not out.exists():
            if src.kind == "file" and Path(src.path).exists():
                ff.run(["-ss", f"{start:.2f}", "-i", src.path, "-t", f"{end - start:.2f}", "-vf", "scale=-2:480",
                        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-c:a", "aac", str(out)],
                       label="Preview")
            else:  # analysis copy (low frame rate) + analysis audio: fast, no download needed
                ff.run(["-ss", f"{start:.2f}", "-i", src.proxy_path, "-ss", f"{start:.2f}", "-i", src.audio_path,
                        "-t", f"{end - start:.2f}", "-map", "0:v", "-map", "1:a", "-vf", "fps=15", "-c:v", "libx264",
                        "-preset", "ultrafast", "-c:a", "aac", str(out)], label="Preview")
        return str(out)


def main(on_ready=None):
    """on_ready: called once the window is on screen (the launcher uses it to confirm that a freshly
    updated version starts correctly; otherwise it rolls back)."""
    from .. import __version__
    from .shell import after_start, app_icon

    app = QApplication(sys.argv)
    app.setApplicationName("ClipForge")
    app.setApplicationDisplayName("ClipForge")
    app.setApplicationVersion(__version__)
    app.setOrganizationName("ClipForge")
    app.setWindowIcon(app_icon())
    app.setStyleSheet(STYLE)
    f = QFont()
    f.setPointSizeF(10.5)
    app.setFont(f)
    w = MainWindow()
    w.setWindowTitle(f"ClipForge {__version__} — AI Shorts from long videos")
    w.show()

    def ready():
        if on_ready:
            on_ready()
        from .. import updater

        updater.mark_started_ok()
        after_start(w)
    QTimer.singleShot(0, ready)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
