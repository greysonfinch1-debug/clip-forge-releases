"""Resource management: how much of the PC ClipForge uses, and keeping child processes in check.

Performance modes (Settings → Performance):
  balanced     (default) leaves 2 CPU cores free, runs heavy work at below-normal priority so
               Windows and other programs stay responsive, frees AI models between stages.
  performance  uses every core at normal priority and keeps models loaded (fastest).
  low          uses about a quarter of the cores at low priority and frees every model as soon as
               a stage no longer needs it (slowest; the rest of the PC barely notices).
None of the modes changes output quality: they change speed, priority and memory use only.

Child processes (FFmpeg): each one runs at the mode's priority and is placed in a Windows job
object that kills it if ClipForge ends unexpectedly, so nothing keeps running in the background.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from typing import Optional

MODES = ("balanced", "performance", "low")
MODE_LABELS = {"balanced": "Balanced (recommended)", "performance": "Performance (fastest)",
               "low": "Low resource (keeps the PC free)"}
_mode = "balanced"
_lock = threading.Lock()
_children: set = set()
_job = None

# Windows priority classes
BELOW_NORMAL = 0x00004000
IDLE = 0x00000040


def cores() -> int:
    return max(1, os.cpu_count() or 2)


def free_ram_gb() -> float:
    """Memory available right now (GB); a generous guess when it can't be read."""
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                            ("avail", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong),
                            ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
            m = MS()
            m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.avail / 2**30
        with open("/proc/meminfo") as f:
            for ln in f:
                if ln.startswith("MemAvailable:"):
                    return int(ln.split()[1]) / 2**20
    except (OSError, ValueError, AttributeError):
        pass
    return 16.0


def ram_gb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                            ("avail", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong),
                            ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
            m = MS()
            m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.total / 2**30
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
    except (OSError, ValueError, AttributeError):
        return 8.0


def recommended_mode() -> str:
    """Balanced on almost every PC (it already leaves 2 threads free and runs at lower priority);
    Low only on very small machines (2 threads or less than 6 GB of memory), where a quarter of
    the threads is still enough. Performance is opt-in."""
    return "low" if (cores() <= 2 or ram_gb() < 6.0) else "balanced"


def set_mode(mode: str) -> None:
    global _mode
    _mode = mode if mode in MODES else "balanced"


def mode() -> str:
    return _mode


def ai_threads() -> int:
    """Threads for speech, sound and speaker models."""
    n = cores()
    return {"performance": min(16, n), "balanced": max(1, min(8, n - 2)), "low": max(1, n // 4)}[_mode]


def encode_threads() -> list[str]:
    """FFmpeg thread limit for encoding (empty = FFmpeg decides, i.e. all cores)."""
    n = cores()
    if _mode == "performance":
        return []
    return ["-threads", str(max(2, n - 2) if _mode == "balanced" else max(1, n // 4))]


def parallel_analysis() -> bool:
    """Run speech and picture analysis side by side? Measured on a 2-thread machine: 95 s -> 61 s
    for a 5-minute video (the two models wait on different things). Not in Low mode, and only
    with enough free memory for both models at once (~2.5 GB)."""
    forced = os.environ.get("CLIPFORGE_PARALLEL_ANALYSIS")
    if forced in ("0", "1"):
        return forced == "1"
    return _mode != "low" and cores() >= 2 and free_ram_gb() >= 4.0


def release_models_between_stages() -> bool:
    """Free AI models between stages? Reloading them costs seconds every time (CLIP ~8 s on the
    user's PC), so they stay loaded unless memory is actually short (or Low mode is chosen)."""
    if _mode == "performance":
        return False
    return _mode == "low" or free_ram_gb() < 3.0


def child_flags() -> int:
    """Extra creation flags for child processes (priority) on Windows."""
    if sys.platform != "win32":
        return 0
    return {"performance": 0, "balanced": BELOW_NORMAL, "low": IDLE}[_mode]


def child_preexec():
    """POSIX: lower the child's priority (nice) in Balanced / Low modes, and (Linux) have the child
    killed if ClipForge dies (the Windows job object does this on Windows)."""
    if sys.platform == "win32":
        return None
    inc = {"performance": 0, "balanced": 5, "low": 15}[_mode]

    def pre():
        if inc:
            os.nice(inc)
        if sys.platform.startswith("linux"):
            try:
                import ctypes

                ctypes.CDLL("libc.so.6", use_errno=True).prctl(1, 9)   # PR_SET_PDEATHSIG, SIGKILL
            except Exception:  # noqa: BLE001
                pass
    return pre


# ---------------------------------------------------------------- the task's own priority
NORMAL = 0x00000020


def lower_task_priority() -> None:
    """Called at the start of a heavy background task, in the task's own thread. In Balanced and
    Low modes the work (AI models run inside ClipForge, not only in FFmpeg) gets a lower priority,
    so the rest of the PC stays responsive; it still uses all the time nothing else needs.
    Windows: the whole ClipForge process is set to below-normal while the task runs (the window
    keeps Windows' foreground boost). Linux/macOS: this thread and the threads it starts are niced."""
    if _mode == "performance":
        return
    try:
        if sys.platform == "win32":
            import ctypes

            k32 = ctypes.windll.kernel32
            k32.GetCurrentProcess.restype = ctypes.c_void_p
            k32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            k32.SetPriorityClass(k32.GetCurrentProcess(), BELOW_NORMAL)
        else:
            inc = {"balanced": 5, "low": 15}[_mode]
            tid = threading.get_native_id()
            os.setpriority(os.PRIO_PROCESS, tid, min(19, os.getpriority(os.PRIO_PROCESS, tid) + inc))
    except Exception:  # noqa: BLE001  (best effort)
        pass


def restore_task_priority() -> None:
    """After the task (Windows: back to normal; elsewhere the niced thread simply ends)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        k32 = ctypes.windll.kernel32
        k32.GetCurrentProcess.restype = ctypes.c_void_p
        k32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        k32.SetPriorityClass(k32.GetCurrentProcess(), NORMAL)
    except Exception:  # noqa: BLE001
        pass


# ---------------------------------------------------------------- child process tracking
def _job_handle():
    """A Windows job object with 'kill on close': when ClipForge exits or crashes, Windows closes
    the handle and ends every FFmpeg still running in it."""
    global _job
    if _job is not None or sys.platform != "win32":
        return _job
    try:
        import ctypes
        from ctypes import wintypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateJobObjectW.restype = wintypes.HANDLE
        h = k32.CreateJobObjectW(None, None)
        if not h:
            return None

        class BASIC(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]

        class IO(ctypes.Structure):
            _fields_ = [(n, ctypes.c_uint64) for n in ("r", "w", "o", "rt", "wt", "ot")]

        class EXT(ctypes.Structure):
            _fields_ = [("Basic", BASIC), ("Io", IO), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t),
                        ("PeakJobMemoryUsed", ctypes.c_size_t)]
        info = EXT()
        info.Basic.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        k32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        if not k32.SetInformationJobObject(h, 9, ctypes.byref(info), ctypes.sizeof(info)):
            return None
        _job = h
    except Exception:  # noqa: BLE001  (best effort; tracking + kill on exit still apply)
        _job = None
    return _job


def adopt(proc: subprocess.Popen) -> subprocess.Popen:
    """Track a child process (killed on cancel/exit; on Windows also if ClipForge crashes)."""
    with _lock:
        _children.add(proc)
    h = _job_handle()
    if h is not None:
        try:
            import ctypes
            from ctypes import wintypes

            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            k32.AssignProcessToJobObject(h, wintypes.HANDLE(int(proc._handle)))  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass
    return proc


def forget(proc: subprocess.Popen) -> None:
    with _lock:
        _children.discard(proc)


def running_children() -> int:
    with _lock:
        return sum(1 for p in _children if p.poll() is None)


def kill_children(timeout: float = 3.0) -> int:
    """Stop every tracked child process (used when quitting). Returns how many were stopped."""
    with _lock:
        procs = [p for p in _children if p.poll() is None]
    for p in procs:
        try:
            p.kill()
        except OSError:
            pass
    for p in procs:
        try:
            p.wait(timeout)
        except Exception:  # noqa: BLE001
            pass
    return len(procs)


def popen(cmd, **kw) -> subprocess.Popen:
    """subprocess.Popen with this mode's priority, tracked and job-controlled."""
    if sys.platform == "win32":
        kw["creationflags"] = kw.get("creationflags", 0) | child_flags()
    else:
        pre = child_preexec()
        if pre and "preexec_fn" not in kw:
            kw["preexec_fn"] = pre
    return adopt(subprocess.Popen(cmd, **kw))


# ---------------------------------------------------------------- GPU
def gpus() -> list[dict]:
    """NVIDIA GPUs with memory in MB ([] when there's none or no driver tool)."""
    exe = shutil.which("nvidia-smi")
    if not exe:
        return []
    try:
        out = subprocess.run([exe, "--query-gpu=name,memory.total,memory.used,utilization.gpu",
                              "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=8,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        res = []
        for line in out.strip().splitlines():
            name, tot, used, util = [x.strip() for x in line.split(",")]
            res.append({"name": name, "vram_total_mb": int(tot), "vram_used_mb": int(used), "util": int(util)})
        return res
    except Exception:  # noqa: BLE001
        return []


def vram_ok(need_mb: int = 1500) -> Optional[bool]:
    """True/False if an NVIDIA GPU has / lacks ``need_mb`` free; None when unknown."""
    g = gpus()
    if not g:
        return None
    return any(x["vram_total_mb"] - x["vram_used_mb"] >= need_mb for x in g)


def process_rss_mb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                            ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                            ("a", ctypes.c_size_t), ("b", ctypes.c_size_t), ("c", ctypes.c_size_t),
                            ("d", ctypes.c_size_t), ("e", ctypes.c_size_t), ("f", ctypes.c_size_t)]
            pmc = PMC()
            pmc.cb = ctypes.sizeof(PMC)
            k32 = ctypes.WinDLL("kernel32")
            k32.GetCurrentProcess.restype = wintypes.HANDLE
            fn = getattr(k32, "K32GetProcessMemoryInfo")
            fn.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
            fn(k32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
            return pmc.WorkingSetSize / 2**20
        with open("/proc/self/status") as f:
            for ln in f:
                if ln.startswith("VmRSS"):
                    return int(ln.split()[1]) / 1024
    except Exception:  # noqa: BLE001
        pass
    return -1.0
