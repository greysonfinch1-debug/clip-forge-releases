"""Disk space checks and clean-up of temporary files (never of reusable caches or user files)."""
from __future__ import annotations

import os
import shutil
import time
from pathlib import Path

MARGIN = 1.0 * 2**30          # always leave at least 1 GB free for Windows and other programs
LARGE = 2.0 * 2**30           # operations above this ask first


class StorageError(Exception):
    """Not enough free disk space (message says how much is needed and where)."""


def human(n: float) -> str:
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("bytes", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def free_bytes(path: str | Path) -> int:
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free


def drive_name(path: str | Path) -> str:
    p = Path(path).resolve()
    return p.drive or p.anchor or str(p)


_FULL = ("no space left on device", "not enough space on the disk", "there is not enough space", "disk quota exceeded",
         "[errno 28]", "enospc", "error code 112", "winerror 112")


def is_disk_full(text: str) -> bool:
    """Does an error (FFmpeg, the downloader, Python) say the drive is full?"""
    low = (text or "").lower()
    return any(m in low for m in _FULL)


def disk_full_error(what: str, path: str | Path | None = None) -> "StorageError":
    """The message for a drive that filled up while working (another program, or a bigger file than
    expected): what happened, that nothing half-finished is kept, and what to do."""
    where = ""
    if path:
        try:
            where = f" (drive {drive_name(path)}, {human(free_bytes(path))} free now)"
        except OSError:
            where = ""
    return StorageError(f"The drive ran out of space while {what}{where}. The half-finished file was removed and "
                        f"your project is safe.\nFree up some space (Settings → Storage can clean up ClipForge's "
                        f"temporary files and old analysis) and try again.")


def check_space(path: str | Path, need: float, what: str) -> None:
    """Raise StorageError if ``need`` bytes (plus a safety margin) won't fit where ``path`` lives."""
    free = free_bytes(path)
    if need + MARGIN > free:
        raise StorageError(
            f"Not enough free disk space for {what}: it needs about {human(need)}, and drive "
            f"{drive_name(path)} has {human(free)} free (ClipForge keeps {human(MARGIN)} spare for Windows).\n"
            f"Free up some space (Settings → Storage can clean up ClipForge's temporary files) and try again.")


def cleanup_temp(cache_root: Path, older_than_hours: float = 12.0) -> dict:
    """Remove leftovers of interrupted work: half-written files and abandoned render folders.
    Downloads that can resume (yt-dlp .part files) are kept for a week. Analysis, downloaded
    videos, clips and voice lines (reusable) are never removed here."""
    now = time.time()
    freed, n = 0, 0
    if not cache_root.is_dir():
        return {"files": 0, "bytes": 0}
    for f in cache_root.rglob("*"):
        try:
            if not f.is_file():
                continue
            age_h = (now - f.stat().st_mtime) / 3600
            name = f.name
            stale_partial = ".partial." in name or name.endswith(".tmp")
            stale_part = (name.endswith(".part") or name.endswith(".ytdl")) and age_h > 24 * 7
            if (stale_partial and age_h > older_than_hours) or stale_part:
                freed += f.stat().st_size
                f.unlink()
                n += 1
        except OSError:
            continue
    # render work folders left by an interrupted export/preview (finished ones delete themselves)
    for d in cache_root.glob("*/render/*"):
        try:
            if d.is_dir() and (now - d.stat().st_mtime) / 3600 > older_than_hours:
                size = sum(x.stat().st_size for x in d.rglob("*") if x.is_file())
                shutil.rmtree(d, ignore_errors=True)
                freed += size
                n += 1
        except OSError:
            continue
    return {"files": n, "bytes": freed}


def folder_size(d: Path) -> int:
    total = 0
    for root, _, files in os.walk(d):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total
