"""FFmpeg / FFprobe helpers.

All heavy media work goes through FFmpeg subprocesses, so multi-hour videos are streamed
from disk and never loaded into memory.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from ..config import PROJECT_ROOT

ProgressFn = Optional[Callable[[float, str], None]]  # (fraction 0..1, message)


class FFmpegError(RuntimeError):
    pass


_BIN_CACHE: dict[str, str] = {}


def _find(name: str) -> str:
    if name in _BIN_CACHE:
        return _BIN_CACHE[name]
    exe = name + (".exe" if sys.platform == "win32" else "")
    candidates = []
    if os.environ.get("CLIPFORGE_FFMPEG_DIR"):  # set by the installed app: its bundled FFmpeg
        candidates.append(Path(os.environ["CLIPFORGE_FFMPEG_DIR"]) / exe)
    candidates.append(PROJECT_ROOT / "bin" / exe)
    for c in candidates:
        if c.exists():
            _BIN_CACHE[name] = str(c)
            return str(c)
    found = shutil.which(name)
    if found:
        _BIN_CACHE[name] = found
        return found
    try:  # optional pip package that ships FFmpeg binaries
        import static_ffmpeg  # type: ignore

        static_ffmpeg.add_paths()
        found = shutil.which(name)
        if found:
            _BIN_CACHE[name] = found
            return found
    except Exception:
        pass
    raise FFmpegError(
        f"{name} was not found. Install FFmpeg (Windows: `winget install Gyan.FFmpeg`) "
        f"or place {exe} in the ClipForge 'bin' folder."
    )


def ffmpeg_bin() -> str:
    return _find("ffmpeg")


def ffprobe_bin() -> str:
    return _find("ffprobe")


_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0  # hide console windows on Windows


class FFmpegStalled(Exception):
    pass


def run(args: list[str], progress: ProgressFn = None, total_seconds: float = 0.0,
        label: str = "", cancel: Optional[Callable[[], bool]] = None, cwd: Optional[str] = None,
        stall: Optional[float] = None, min_speed: float = 0.0) -> None:
    """Run ffmpeg with progress parsing. ``args`` excludes the binary name.

    ``stall``: stop FFmpeg if the output hasn't moved forward for this many seconds (a network
    read that hangs while connecting, or crawls along without producing anything).
    ``min_speed``: after 45 s, stop if it makes less than this many seconds of output per second
    (a throttled read that would take far too long)."""
    from .. import resources as _res

    if "libx264" in args and "-threads" not in args:     # this mode's CPU limit for encoding
        i = args.index("libx264") + 1
        args = args[:i] + _res.encode_threads() + args[i:]
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-y", "-progress", "pipe:1", "-nostats"] + args
    if os.environ.get("CLIPFORGE_LOG_FFMPEG"):     # troubleshooting: record every FFmpeg command
        try:
            with open(os.environ["CLIPFORGE_LOG_FFMPEG"], "a", encoding="utf-8") as f:
                f.write(json.dumps(cmd) + "\n")
        except OSError:
            pass
    from .. import resources

    proc = resources.popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=cwd,
                           encoding="utf-8", errors="replace", creationflags=_NO_WINDOW)
    err_tail: list[str] = []

    import threading

    def _drain_err():
        assert proc.stderr is not None
        for line in proc.stderr:
            err_tail.append(line.rstrip())
            if len(err_tail) > 40:
                del err_tail[:-40]

    t = threading.Thread(target=_drain_err, daemon=True)
    t.start()
    assert proc.stdout is not None
    import queue
    import time as _time

    lines: "queue.Queue[str | None]" = queue.Queue()

    def _read_out():
        try:
            for ln in proc.stdout:
                lines.put(ln)
        except (OSError, ValueError):     # pipe closed under us: FFmpeg's exit code still decides
            pass
        finally:
            lines.put(None)               # always: the loop below must never wait forever
    threading.Thread(target=_read_out, daemon=True).start()
    started = last_adv = _time.time()
    best_us = 0
    while True:
        try:
            line = lines.get(timeout=0.25)
        except queue.Empty:
            line = ""
        if line is None:
            break
        if cancel and cancel():
            proc.kill()
            proc.wait()
            resources.forget(proc)
            _drop_partial(args)
            raise FFmpegError("Cancelled")
        now = _time.time()
        if line.startswith("out_time_us="):
            try:
                us = int(line.split("=", 1)[1])
            except ValueError:
                us = 0
            if us > best_us:
                best_us, last_adv = us, now
                if progress and total_seconds > 0:
                    progress(min(1.0, us / 1e6 / total_seconds), label)
        if stall and now - last_adv > stall:
            proc.kill()
            resources.forget(proc)
            _drop_partial(args)
            raise FFmpegStalled(f"FFmpeg made no progress for {stall:.0f} s ({label}):\n" + "\n".join(err_tail[-8:]))
        if min_speed and now - started > 45 and best_us / 1e6 < min_speed * (now - started):
            proc.kill()
            resources.forget(proc)
            _drop_partial(args)
            raise FFmpegStalled(f"FFmpeg is too slow ({best_us / 1e6:.1f} s of video in {now - started:.0f} s, "
                                f"{label}):\n" + "\n".join(err_tail[-8:]))
    proc.wait()
    resources.forget(proc)
    t.join(timeout=2)
    if proc.returncode != 0:
        _drop_partial(args)
        from .storage import disk_full_error, is_disk_full

        if is_disk_full("\n".join(err_tail)):
            raise disk_full_error(label[:1].lower() + label[1:] if label else "writing a video file",
                                  args[-1] if args and not str(args[-1]).startswith("-") else None)
        raise FFmpegError(f"FFmpeg failed ({label}):\n" + "\n".join(err_tail[-15:]))


def probe(path: str) -> dict:
    cmd = [ffprobe_bin(), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=_NO_WINDOW)
    if r.returncode != 0:
        raise FFmpegError(f"Could not read media file: {path}\n{r.stderr.strip()[:400]}")
    return json.loads(r.stdout)


def media_info(path: str) -> dict:
    """Duration, resolution, fps and whether audio/video exist."""
    d = probe(path)
    info = {"duration": 0.0, "width": 0, "height": 0, "fps": 0.0, "has_audio": False, "has_video": False}
    try:
        info["duration"] = float(d.get("format", {}).get("duration") or 0.0)
    except ValueError:
        pass
    for s in d.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            if s.get("disposition", {}).get("attached_pic"):
                continue
            info["has_video"] = True
            info["width"] = int(s.get("width") or 0)
            info["height"] = int(s.get("height") or 0)
            # phone recordings are often stored sideways with a rotation flag; FFmpeg turns the
            # frames upright when decoding, so report the size as it will actually be decoded
            rot = 0.0
            for sd in s.get("side_data_list") or []:
                if "rotation" in sd:
                    try:
                        rot = float(sd["rotation"])
                    except (TypeError, ValueError):
                        pass
            if not rot:
                try:
                    rot = float((s.get("tags") or {}).get("rotate") or 0)
                except ValueError:
                    rot = 0.0
            info["rotation"] = int(rot) % 360
            if info["rotation"] in (90, 270):
                info["width"], info["height"] = info["height"], info["width"]
            rate = s.get("avg_frame_rate") or s.get("r_frame_rate") or "0/1"
            try:
                num, den = rate.split("/")
                info["fps"] = float(num) / float(den) if float(den) else 0.0
            except Exception:
                info["fps"] = 0.0
            if not info["duration"]:
                try:
                    info["duration"] = float(s.get("duration") or 0.0)
                except ValueError:
                    pass
        elif s.get("codec_type") == "audio":
            info["has_audio"] = True
    return info


def extract_analysis_audio(src: str, dst: str, duration: float, progress: ProgressFn = None,
                           cancel=None) -> None:
    """16 kHz mono 16-bit WAV for transcription and audio analysis."""
    tmp = _partial(dst)
    # the FIRST audio track, like the renderer uses (OBS recordings often carry extra tracks,
    # e.g. a separate mic or music track; FFmpeg's own pick could be a different one)
    run(["-i", src, "-map", "0:a:0", "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", "-f", "wav", tmp],
        progress, duration, "Extracting audio", cancel)
    os.replace(tmp, dst)  # only a complete file ever appears under the final name


def make_proxy(src: str, dst: str, duration: float, height: int = 360, fps: float = 2.0,
               progress: ProgressFn = None, cancel=None) -> None:
    """Low-resolution, low-frame-rate, video-only copy used for visual analysis."""
    tmp = _partial(dst)
    args = ["-i", src, "-an", "-vf", f"fps={fps},scale=-2:{height}", "-c:v", "libx264", "-preset", "ultrafast",
            "-crf", "30", "-g", str(int(fps * 10)), "-f", "mp4", tmp]
    # decoding the full-resolution original is the slow part: let the graphics card do it where it
    # can (FFmpeg uses the processor when it can't); a failure retries in software
    hw = os.environ.get("CLIPFORGE_HWDECODE", "1") != "0" and Path(src).exists()
    try:
        run((["-hwaccel", "auto"] if hw else []) + args, progress, duration, "Building analysis copy", cancel)
    except FFmpegError as e:
        if not hw or "Cancelled" in str(e):
            raise
        run(args, progress, duration, "Building analysis copy", cancel)
    os.replace(tmp, dst)


def _drop_partial(args: list[str]) -> None:
    """A stopped or failed run leaves no half-written ``.partial`` output behind."""
    out = args[-1] if args else ""
    if ".partial" in out:
        try:
            Path(out).unlink(missing_ok=True)
        except OSError:
            pass


def _partial(dst: str) -> str:
    """Temporary name for an output being written; a cancelled or killed job leaves only this
    behind, which is never mistaken for a finished file (and is overwritten next time)."""
    p = Path(dst)
    return str(p.with_name(p.stem + ".partial" + p.suffix))


def iter_wav_chunks(wav_path: str, chunk_seconds: float, overlap_seconds: float = 0.0
                    ) -> Iterator[tuple[float, np.ndarray]]:
    """Yield (start_time, float32 samples) chunks of a 16 kHz mono PCM WAV without loading it all."""
    import soundfile as sf

    with sf.SoundFile(wav_path) as f:
        sr = f.samplerate
        step = int(chunk_seconds * sr)
        ov = int(overlap_seconds * sr)
        pos = 0
        total = f.frames
        while pos < total:
            f.seek(max(0, pos - ov))
            start = max(0, pos - ov)
            data = f.read(step + (pos - start), dtype="float32", always_2d=False)
            if data.ndim > 1:
                data = data.mean(axis=1)
            yield start / sr, data
            pos += step


def read_wav_segment(wav_path: str, start: float, end: float) -> tuple[np.ndarray, int]:
    import soundfile as sf

    with sf.SoundFile(wav_path) as f:
        sr = f.samplerate
        f.seek(int(max(0, start) * sr))
        data = f.read(int(max(0.0, end - start) * sr), dtype="float32", always_2d=False)
    if data.ndim > 1:
        data = data.mean(axis=1)
    return data, sr


def extract_frames_at(src: str, times: list[float], out_dir: str, height: int = 480) -> list[str]:
    """Grab single frames at exact timestamps (fast seek per frame)."""
    os.makedirs(out_dir, exist_ok=True)
    out = []
    for i, t in enumerate(times):
        p = os.path.join(out_dir, f"kf_{int(t * 1000):010d}.jpg")
        if not os.path.exists(p):
            subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t:.3f}",
                            "-i", src, "-frames:v", "1", "-vf", f"scale=-2:{height}", "-q:v", "3", p],
                           capture_output=True, creationflags=_NO_WINDOW)
        if os.path.exists(p):
            out.append(p)
    return out


def iter_frames(src: str, every_seconds: float, height: int, cancel=None
                ) -> Iterator[tuple[float, np.ndarray]]:
    """Stream RGB frames sampled every N seconds as numpy arrays (no temp files)."""
    info = media_info(src)
    w0, h0 = info["width"], info["height"]
    if not w0 or not h0:
        return
    h = height
    w = int(round(w0 * h / h0 / 2)) * 2
    cmd = [ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-nostdin", "-i", src, "-an",
           "-vf", f"fps=1/{every_seconds},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    frame_bytes = w * h * 3
    idx = 0
    assert proc.stdout is not None
    try:
        while True:
            if cancel and cancel():
                break
            buf = proc.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                break
            arr = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 3)
            # fps filter emits the frame nearest to each tick; tick k is at (k + 0.5) * every
            yield (idx + 0.5) * every_seconds, arr
            idx += 1
    finally:
        proc.kill()
        proc.wait()


def has_filter(name: str) -> bool:
    r = subprocess.run([ffmpeg_bin(), "-hide_banner", "-filters"], capture_output=True, text=True,
                       creationflags=_NO_WINDOW)
    return re.search(rf"\s{re.escape(name)}\s", r.stdout) is not None


def ffmpeg_escape_path(p: str) -> str:
    """Escape a path for use inside an FFmpeg filter argument (e.g. subtitles=...)."""
    p = p.replace("\\", "/")
    p = p.replace(":", r"\:").replace("'", r"\'")
    return p


def detect_cuts(path: str, start: float, end: float, fps: int = 10, threshold: float = 0.55) -> list[float]:
    """Hard scene changes (cuts to a different scene) between ``start`` and ``end`` (seconds in
    ``path``). Compares the colour make-up of the second before each frame with the second
    after it, so flashing lights, explosions and camera moves inside one scene don't count,
    while a cut from one scene to another stands out sharply. Returns cut times in seconds."""
    start = max(0.0, start)
    if end - start < 0.5:
        return []
    w, h, bins = 64, 36, 4
    r = subprocess.run([ffmpeg_bin(), "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", path,
                        "-an", "-sn", "-vf", f"fps={fps},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                       capture_output=True, creationflags=_NO_WINDOW)
    n = len(r.stdout) // (w * h * 3)
    if n < 4:
        return []
    q = np.frombuffer(r.stdout[: n * w * h * 3], np.uint8).reshape(n, h * w, 3) // (256 // bins)
    idx = q[..., 0].astype(np.int32) * bins * bins + q[..., 1] * bins + q[..., 2]
    H = np.stack([np.bincount(x, minlength=bins ** 3) for x in idx]).astype(np.float32) / (h * w)
    win = fps
    d = np.zeros(n, np.float32)
    for k in range(1, n):
        a, b = H[max(0, k - win):k].mean(0), H[k:k + win].mean(0)
        d[k] = 0.5 * float(np.abs(a - b).sum())
    cuts = []
    edge = int(win * 0.8)     # both sides need (nearly) a full second to compare
    for k in range(edge, n - edge + 1):
        if d[k] >= threshold and d[k] >= d[k - 1] and (k + 1 >= n or d[k] >= d[k + 1]):
            # a cut, not a long fade: the frame right at it changes sharply as well
            step = 0.5 * float(np.abs(H[k] - H[k - 1]).sum())
            if step >= 0.5 * threshold:
                cuts.append(round(start + k / fps, 3))
    return cuts


def stream_times(path: str) -> dict[str, tuple[float, float]]:
    """{"video": (start, duration), "audio": (start, duration)} of the first stream of each kind."""
    r = subprocess.run([ffprobe_bin(), "-v", "error", "-show_entries", "stream=codec_type,start_time,duration",
                        "-of", "json", path], capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=_NO_WINDOW)
    out: dict[str, tuple[float, float]] = {}
    try:
        for st in json.loads(r.stdout or "{}").get("streams", []):
            kind = st.get("codec_type")
            if kind in ("video", "audio") and kind not in out:
                out[kind] = (float(st.get("start_time") or 0.0), float(st.get("duration") or 0.0))
    except (ValueError, TypeError):
        pass
    return out
