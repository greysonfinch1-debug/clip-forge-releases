"""Command-line use (for batches / scheduling). The desktop app is the main interface.

Example:
  python -m clipforge.cli --file "D:/streams/ep12.mp4" --topic "police chases" --seconds 45 \
      --rights own --creator "MyChannel" --export --hooks 2
"""
from __future__ import annotations

import argparse
import sys

from .config import Settings
from .core.models import RIGHTS_BASES
from .pipeline import Pipeline


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "fieldtest":          # run many recordings end to end, keep every result
        from .fieldtest import main as ft
        return ft(argv[1:])
    if argv and argv[0] == "fieldtest-one":      # (internal: one recording in its own process)
        from .fieldtest import main_one
        return main_one(argv[1:])
    if argv and argv[0] == "create":             # any kind of video from a prompt (clip / narration / hybrid)
        from .creative.cli import main as cr
        return cr(argv[1:])
    if argv and argv[0] == "creativecheck":      # narration / hybrid videos with this PC's real AI models
        from .creative.check import main as cc
        return cc(argv[1:])
    if argv and argv[0] == "expandcheck":        # AI prompt expansion with this PC's real language model
        from .creative.expandcheck import main as ec
        return ec(argv[1:])
    if argv and argv[0] == "stabilitycheck":     # cancel / recovery / resource checks on this PC
        from .stabilitycheck import main as sc
        return sc(argv[1:])
    if argv and argv[0] == "stabilitycheck-child":   # (internal: one check in its own process)
        from .stabilitycheck import child
        return child(argv[1:])
    if argv and argv[0] == "review":             # objective checks + contact sheet for a finished Short
        from .review import main as rv
        return rv(argv[1:])
    ap = argparse.ArgumentParser(prog="clipforge")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--url", help="public YouTube / Twitch / Kick video link")
    src.add_argument("--file", help="local video file")
    ap.add_argument("--topic", required=True)
    ap.add_argument("--seconds", type=float, default=45)
    ap.add_argument("--clips", type=int, default=0, help="0 = automatic")
    ap.add_argument("--rights", choices=list(RIGHTS_BASES), help="how you have permission to use the footage")
    ap.add_argument("--creator", default="")
    ap.add_argument("--commercial", action="store_true", help="permission covers monetized use")
    ap.add_argument("--publisher-ok", action="store_true", help="game publisher policy checked")
    ap.add_argument("--monetized", action="store_true")
    ap.add_argument("--export", action="store_true", help="render the video (otherwise only print the plan)")
    ap.add_argument("--hooks", type=int, default=1, help="number of hook variants to export")
    a = ap.parse_args(argv)

    def prog(stage, f, msg):
        print(f"\r[{stage:<10}] {f * 100:5.1f}%  {msg[:60]:<60}", end="", flush=True)

    p = Pipeline(Settings.load())
    p.ingest(url=a.url or "", path=a.file or "", progress=prog)
    if a.rights:
        r = p.project.source.rights
        r.basis, r.creator, r.confirmed = a.rights, a.creator or p.project.source.uploader, True
        r.commercial_use, r.game_publisher_ok = a.commercial, a.publisher_ok
        p.save_rights()
    p.project.plan.monetized = a.monetized
    p.find_moments(a.topic, a.seconds, a.clips, prog)
    p.project.plan.monetized = a.monetized
    print("\n\nEngines:", p.used)
    for it, c in p.story_candidates():
        print(f"  {it.role:<11} {c.start:8.1f}-{c.end:8.1f}  score {c.final_score:3.0f}  {c.description[:80]}")
    for ln in p.project.plan.narration:
        print("  VO:", ln.text)
    if a.export:
        res = p.export(list(range(min(a.hooks, len(p.project.plan.hooks)))) or None, prog)
        print()
        for path, rep in res:
            print(path)
            print(rep.summary())
    p.project.save()
    return 0


if __name__ == "__main__":
    sys.exit(main())
