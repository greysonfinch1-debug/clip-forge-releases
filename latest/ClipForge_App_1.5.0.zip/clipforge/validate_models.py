"""Validate the REAL AI models on this computer with known-answer tests.

    python -m clipforge.validate_models          (also: System Check → "Validate AI models")

Every check runs the actual configured model (no stand-ins) on inputs whose correct answer
is known, then reports PASS / FAIL / SKIPPED (with the reason) and timings. The report is
saved to %APPDATA%\\ClipForge\\model_validation.txt so it can be shared.
"""
from __future__ import annotations

import json
import platform
import tempfile
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .config import ASSETS_DIR, Settings, app_dir
from .core.models import Candidate, Evidence, Sentence, StoryItem, TopicSpec, Transcript, Word


@dataclass
class Result:
    name: str
    status: str            # PASS / FAIL / SKIPPED
    detail: str
    seconds: float = 0.0
    engine: str = ""


@dataclass
class Report:
    results: list[Result] = field(default_factory=list)

    def add(self, *a, **k):
        self.results.append(Result(*a, **k))

    def text(self) -> str:
        lines = [f"ClipForge model validation — {time.strftime('%Y-%m-%d %H:%M')} — {platform.platform()}"]
        for r in self.results:
            lines.append(f"{r.status:<8} {r.name:<38} {r.seconds:7.1f}s  [{r.engine}]  {r.detail}")
        n = {s: sum(r.status == s for r in self.results) for s in ("PASS", "FAIL", "SKIPPED")}
        lines.append(f"\n{n['PASS']} passed, {n['FAIL']} failed, {n['SKIPPED']} skipped")
        return "\n".join(lines)


# ----------------------------------------------------------------------------- test inputs

def _word_image(word: str, bg=(30, 30, 30), fg=(255, 255, 255), size=(448, 252)) -> np.ndarray:
    from PIL import Image, ImageDraw, ImageFont

    im = Image.new("RGB", size, bg)
    d = ImageDraw.Draw(im)
    font_path = ASSETS_DIR / "fonts" / "Poppins-Bold.ttf"
    font = ImageFont.truetype(str(font_path), 64) if font_path.exists() else ImageFont.load_default()
    w = d.textlength(word, font=font)
    d.text(((size[0] - w) / 2, size[1] / 2 - 40), word, fill=fg, font=font)
    return np.array(im)


def _solid(rgb) -> np.ndarray:
    return np.full((252, 448, 3), rgb, np.uint8)


JUDGE_CASES = [  # (id, transcript, audio, visual, expected: "on" | "off" | "house")
    ("A", "[+0.5s] The cops are right behind me!\n[+4.0s] They're still chasing me, I need to lose them!\n"
          "[+11.0s] No way, I flew off the bridge!", "sounds detected: siren 0.82, skidding 0.40",
     "police cars with flashing lights 0.31; a car being chased by police cars 0.29", "on"),
    ("B", "[+0.5s] Thank you so much for the five gifted subs!\n[+3.0s] Appreciate you, welcome to the stream.",
     "sounds detected: music 0.40", "a menu screen 0.27", "house"),
    ("C", "[+0.5s] So yesterday I made pasta for dinner.\n[+5.0s] I think I need a new chair.",
     "sounds detected: nothing notable", "a calm empty street 0.28", "off"),
    ("D", "[+0.5s] Police helicopter above me!\n[+6.0s] I'm hiding under the bridge, they lost me!",
     "sounds detected: siren 0.71, aircraft 0.55", "a police helicopter overhead 0.30", "on"),
    ("E", "(no speech)", "sounds detected: music 0.6", "a loading screen 0.33", "off"),
]


def _judge_prompt_inputs():
    from .intelligence import judge as J

    cands = []
    for cid, said, aud, vis, _ in JUDGE_CASES:
        c = Candidate(cid=cid, start=100.0, end=118.0)
        c.evidence = Evidence(transcript=said, transcript_before="(nothing)", transcript_after="(nothing)",
                              audio_summary=aud, visual_labels=[vis])
        cands.append(c)
    return J, cands


# ----------------------------------------------------------------------------- checks

def check_vision(s: Settings, rep: Report):
    from .providers.base import ProviderUnavailable, create

    t0 = time.time()
    try:
        enc = create("vision", s.vision.backend, model=s.vision.clip_model, pretrained=s.vision.clip_pretrained,
                     device=s.vision.device, models_dir=s.models_dir)
    except ProviderUnavailable as e:
        rep.add("Vision model loads", "SKIPPED" if s.vision.backend == "none" else "FAIL", str(e)[:300],
                time.time() - t0, s.vision.backend)
        return
    rep.add("Vision model loads", "PASS", f"device={getattr(enc, 'device', '?')}", time.time() - t0, enc.model_id)
    # known answers: colours and large words (CLIP reads big text reliably)
    imgs = [_solid((220, 20, 20)), _solid((20, 40, 220)), _solid((20, 180, 40)),
            _word_image("POLICE"), _word_image("PIZZA"), _word_image("OCEAN")]
    prompts = ["a solid red image", "a solid blue image", "a solid green image",
               "the word POLICE", "the word PIZZA", "the word OCEAN"]
    t0 = time.time()
    ie, te = enc.encode_images(imgs), enc.encode_texts(prompts)
    hits = int(sum(int(np.argmax(ie[i] @ te.T)) == i for i in range(len(imgs))))
    rep.add("Vision understands images", "PASS" if hits >= 5 else "FAIL", f"{hits}/6 known images matched",
            time.time() - t0, enc.model_id)
    batch = [(np.random.default_rng(i).random((360, 640, 3)) * 255).astype(np.uint8) for i in range(32)]
    t0 = time.time()
    enc.encode_images(batch)
    dt = time.time() - t0
    rep.add("Vision speed", "PASS", f"{32 / dt:.1f} frames/s → ~{3600 / (32 / dt) / 60:.1f} min per hour of video "
            f"at 1 frame/s", dt, enc.model_id)


def check_embedder(s: Settings, rep: Report):
    from .services import Services

    sv = Services(s)
    t0 = time.time()
    emb = sv.embedder()
    st = sv.status["embedder"]
    if not st.ok:
        rep.add("Meaning-search model", "FAIL", st.message[:300], time.time() - t0, st.active)
        return
    q = emb.embed(["a police car chase"])
    docs = ["the cops are chasing me down the highway", "they're right behind me with the sirens on",
            "I made pasta for dinner yesterday", "thanks for the gifted subs"]
    d = emb.embed(docs)
    sims = (d @ q.T).ravel()
    ok = min(sims[0], sims[1]) > max(sims[2], sims[3])
    rep.add("Meaning search ranks paraphrases", "PASS" if ok else "FAIL",
            "similarities " + ", ".join(f"{x:.2f}" for x in sims), time.time() - t0, st.active)


def check_llm(s: Settings, rep: Report):
    from .intelligence.story import _ground, write_script
    from .intelligence.topic import understand_topic
    from .providers.base import MalformedResponse, ProviderUnavailable
    from .services import Services

    sv = Services(s)
    t0 = time.time()
    llm = sv.llm()
    st = sv.status["llm"]
    if not st.ok:
        rep.add("Language model loads", "FAIL", st.message[:300], time.time() - t0, st.active)
        return
    rep.add("Language model loads", "PASS", "", time.time() - t0, f"{st.active}:{s.llm.model}")
    eng = f"{st.active}:{s.llm.model}"
    # 1. topic understanding
    t0 = time.time()
    spec = understand_topic("police chases where the cops are after the streamer", llm)
    ok = bool(spec.visual_positive and spec.speech_cues and spec.summary)
    rep.add("LLM: topic understanding (valid JSON)", "PASS" if ok else "FAIL",
            f"{len(spec.visual_positive)} visual, {len(spec.speech_cues)} speech cues, sounds={spec.sounds}",
            time.time() - t0, eng)
    # 2. judging known cases
    J, cands = _judge_prompt_inputs()
    t0 = time.time()
    try:
        prompt = J.PROMPT.format(topic=spec.summary, details="; ".join(spec.sub_topics),
                                 criteria="; ".join(spec.entertainment_criteria), exclude="; ".join(spec.exclude),
                                 blocks="\n\n".join(J._block(c) for c in cands))  # exactly what the app sends
        d = llm.complete_json(J.SYSTEM, prompt, max_tokens=2400)
        res = {str(r.get("id")): r for r in d.get("results", []) if isinstance(r, dict)}
        wrong = []
        for cid, *_, exp in JUDGE_CASES:
            r = res.get(cid)
            if r is None:
                wrong.append(f"{cid}: missing")
                continue
            tm = float(r.get("topic_match", 0) or 0)
            if exp == "on" and (tm < 6 or r.get("reject")):
                wrong.append(f"{cid}: on-topic scored {tm:.0f}")
            if exp in ("off", "house") and tm > 4 and not r.get("reject"):
                wrong.append(f"{cid}: off-topic scored {tm:.0f}")
        rep.add("LLM: judges known clips correctly", "PASS" if not wrong else "FAIL",
                "all 5 correct" if not wrong else "; ".join(wrong), time.time() - t0, eng)
    except (MalformedResponse, ProviderUnavailable) as e:
        rep.add("LLM: judges known clips correctly", "FAIL", f"{e}"[:300], time.time() - t0, eng)
    # 3. grounded script (no invented quotes survive)
    t0 = time.time()
    tr = Transcript(sentences=[Sentence(0, 100.5, 102, "The cops are right behind me!",
                                        [Word("The", 100.5, 100.7), Word("cops", 100.7, 101)]),
                               Sentence(1, 111, 113, "No way, I flew off the bridge!", [Word("No", 111, 111.2)])])
    story = [StoryItem("A", "hook", "", 100, 118)]
    by_id = {"A": cands[0]}
    cands[0].description = "A police chase that ends with the car flying off a bridge"
    lines, extras, how = write_script(story, by_id, spec, None, llm, tr, 30)
    bad = [l.text for l in lines if l.text != _ground(l.text, tr)]
    words = sum(len(l.text.split()) for l in lines)
    rep.add("LLM: script is grounded and short", "PASS" if lines and not bad and words <= 40 else "FAIL",
            f"{len(lines)} lines, {words} words, via {how}" + (f"; invented quotes: {bad}" if bad else ""),
            time.time() - t0, eng)


def check_captioner(s: Settings, rep: Report):
    from .services import Services

    sv = Services(s)
    t0 = time.time()
    cap = sv.captioner()
    st = sv.status["captioner"]
    if cap is None:
        rep.add("Frame-description model", "SKIPPED" if s.vision.captioner == "none" else "FAIL", st.message[:300],
                time.time() - t0, st.active)
        return
    from PIL import Image

    tmp = Path(tempfile.mkdtemp())
    p = tmp / "f.png"
    Image.fromarray(_word_image("POLICE", bg=(20, 40, 200))).save(p)
    txt = cap.describe([str(p)], "Describe this image in one sentence.")
    ok = "police" in txt.lower()
    rep.add("Frame-description model reads a frame", "PASS" if ok else "FAIL", txt[:160], time.time() - t0, st.active)


def check_audio_models(s: Settings, rep: Report):
    from .services import Services

    sv = Services(s)
    sr = 16000
    t0 = time.time()
    tr = sv.transcriber()
    st = sv.status.get("transcriber")
    try:
        from .providers.tts import KokoroTTS

        tts = KokoroTTS(models_dir=s.models_dir)
        x, tsr = tts.synthesize("The police are chasing me across the bridge.", "am_michael", 1.0)
        x = np.interp(np.arange(int(len(x) * sr / tsr)) * tsr / sr, np.arange(len(x)), x).astype(np.float32)
        tmp = Path(tempfile.mkdtemp()) / "a.wav"
        import soundfile as sf

        sf.write(tmp, np.concatenate([np.zeros(sr, np.float32), x, np.zeros(sr, np.float32)]), sr)
        out = tr.transcribe(str(tmp))
        text = " ".join(x.text for x in out.sentences).lower()
        ok = all(w in text for w in ("police", "chasing", "bridge"))
        rep.add("Speech-to-text transcribes a known sentence", "PASS" if ok else "FAIL", f'heard: "{text}"',
                time.time() - t0, st.active if st else "?")
    except Exception as e:  # noqa: BLE001
        rep.add("Speech-to-text transcribes a known sentence", "FAIL", str(e)[:300], time.time() - t0,
                st.active if st else "?")
    t0 = time.time()
    tg = _really(sv, sv.sound_tagger(), "sound_events")
    if tg is None:
        rep.add("Sound-event model", "FAIL" if s.audio_ai.sound_events != "none" else "SKIPPED",
                sv.status["sound_events"].message[:300], time.time() - t0, "none")
    else:
        # known answers: synthesized speech must be heard as speech; white noise must not
        try:
            from .providers.tts import KokoroTTS

            x, tsr = KokoroTTS(models_dir=s.models_dir).synthesize("Watch out, the police are coming!", "am_michael", 1.0)
            x = np.interp(np.arange(int(len(x) * sr / tsr)) * tsr / sr, np.arange(len(x)), x).astype(np.float32)
        except Exception:  # noqa: BLE001
            x = None
        labels = tg.labels()
        noise = (np.random.default_rng(0).normal(0, 0.1, 3 * sr)).astype(np.float32)
        pn = tg.tag(noise, sr)
        top_noise = [labels[i] for i in np.argsort(-pn)[:3]]
        if x is not None:
            ps = tg.tag(x, sr)
            top_speech = [labels[i] for i in np.argsort(-ps)[:3]]
            ok = "Speech" in top_speech and "Speech" not in top_noise[:1]
            detail = f"speech clip → {top_speech}; noise → {top_noise}"
        else:
            ok, detail = "Speech" not in top_noise[:1], f"noise → {top_noise} (voice model unavailable)"
        rep.add("Sound-event model classifies known sounds", "PASS" if ok else "FAIL", detail, time.time() - t0,
                tg.model_id)
    t0 = time.time()
    dz = _really(sv, sv.diarizer(), "diarizer")
    rep.add("Speaker-identification model loads", "PASS" if dz is not None else
            ("SKIPPED" if s.audio_ai.diarizer == "none" else "FAIL"),
            "" if dz is not None else sv.status["diarizer"].message[:300], time.time() - t0,
            dz.model_id if dz is not None else "none")
    check_voice(s, rep)
    if dz is not None:
        check_speakers(s, rep, dz)


def _voice16k(tts, text: str, voice: str) -> np.ndarray:
    x, tsr = tts.synthesize(text, voice, 1.0)
    sr = 16000
    return np.interp(np.arange(int(len(x) * sr / tsr)) * tsr / sr, np.arange(len(x)), x).astype(np.float32)


def check_voice(s: Settings, rep: Report):
    """The narration voice: speaks a sentence at a natural rate, not silent, not clipped."""
    t0 = time.time()
    try:
        from .providers.tts import KokoroTTS

        tts = KokoroTTS(models_dir=s.models_dir)
        text = "He thought he had lost them. Then the helicopter showed up."
        x = _voice16k(tts, text, s.voice.voice)
        secs = len(x) / 16000
        rms = float(np.sqrt(np.mean(x ** 2)))
        peak = float(np.abs(x).max())
        wps = len(text.split()) / max(0.1, secs)
        ok = 1.6 <= wps <= 4.5 and rms > 0.01 and peak < 1.0
        rep.add("Narration voice speaks a known script", "PASS" if ok else "FAIL",
                f"{secs:.1f}s for {len(text.split())} words ({wps:.1f} words/s), level {20 * np.log10(rms + 1e-9):.0f} dBFS, "
                f"peak {peak:.2f}; voices available: {len(tts.voices())}", time.time() - t0, f"kokoro:{s.voice.voice}")
    except Exception as e:  # noqa: BLE001
        rep.add("Narration voice speaks a known script", "FAIL", str(e)[:300], time.time() - t0, "kokoro")


def check_speakers(s: Settings, rep: Report, dz):
    """Two different (built-in) voices in one recording: speaker A, B, then A again must come
    out as two people, with the first and last parts matched to the same person."""
    t0 = time.time()
    try:
        from .providers.tts import KokoroTTS

        tts = KokoroTTS(models_dir=s.models_dir)
        vs = tts.voices()
        a_voice = "am_michael" if "am_michael" in vs else vs[0]
        b_voice = next((v for v in ("af_heart", "bf_emma", "af_bella") if v in vs), vs[-1])
        gap = np.zeros(8000, np.float32)
        a1 = _voice16k(tts, "Okay we need to get out of here right now, they are everywhere.", a_voice)
        b = _voice16k(tts, "No way, I told you to take the other road, this is your fault.", b_voice)
        a2 = _voice16k(tts, "Fine, fine, just drive and stop yelling at me please.", a_voice)
        x = np.concatenate([gap, a1, gap, b, gap, a2, gap])
        spans = []
        t = 0.5
        for part in (a1, b, a2):
            spans.append((t, t + len(part) / 16000))
            t += len(part) / 16000 + 0.5
        from .analysis.speakers import regroup_by_voice

        segs = regroup_by_voice(dz.diarize(x, 16000), x, 16000, dz)   # exactly what ClipForge does

        def who(a, b_):
            best, cov = None, 0.0
            for s0, s1, spk in segs:
                o = min(s1, b_) - max(s0, a)
                if o > cov:
                    best, cov = spk, o
            return best
        lab = [who(*sp) for sp in spans]
        e1 = dz.embed(a1, 16000)
        e2 = dz.embed(a2, 16000)
        e3 = dz.embed(b, 16000)
        same, diff = float(e1 @ e2), float(e1 @ e3)
        ok = lab[0] is not None and lab[0] == lab[2] and lab[1] != lab[0] and same > diff
        rep.add("Speaker identification tells two voices apart", "PASS" if ok else "FAIL",
                f"labels A,B,A = {lab}; voice similarity same-person {same:.2f} vs different {diff:.2f}",
                time.time() - t0, getattr(dz, "model_id", "?"))
    except Exception as e:  # noqa: BLE001
        rep.add("Speaker identification tells two voices apart", "FAIL", str(e)[:300], time.time() - t0, "?")


def check_gpu(rep: Report):
    t0 = time.time()
    try:
        import torch  # type: ignore

        if torch.cuda.is_available():
            rep.add("GPU acceleration", "PASS", torch.cuda.get_device_name(0), time.time() - t0, "cuda")
        else:
            rep.add("GPU acceleration", "SKIPPED", "No CUDA GPU found: CLIP runs on the CPU (slower, same results)",
                    time.time() - t0, "cpu")
    except ImportError:
        rep.add("GPU acceleration", "SKIPPED", "PyTorch not installed (visual model not installed)", 0.0, "")


def run_all(settings: Settings | None = None, progress=None) -> Report:
    s = settings or Settings.load()
    rep = Report()
    steps = [("audio models", check_audio_models), ("vision", check_vision), ("meaning search", check_embedder),
             ("language model", check_llm), ("frame descriptions", check_captioner)]
    for i, (label, fn) in enumerate(steps):
        if progress:
            progress("validate", i / (len(steps) + 1), f"Testing {label}…")
        try:
            fn(s, rep)
        except Exception as e:  # noqa: BLE001  (a crash in one check is itself a result)
            rep.add(f"{label} (crashed)", "FAIL", f"{type(e).__name__}: {e}"[:300] + " | "
                    + traceback.format_exc().splitlines()[-2][:120])
    check_gpu(rep)
    try:
        (app_dir() / "model_validation.txt").write_text(rep.text(), encoding="utf-8")
    except OSError:
        pass
    return rep


if __name__ == "__main__":
    r = run_all(progress=lambda st, f, m: print(m, flush=True))
    print(r.text())
    raise SystemExit(0 if not any(x.status == "FAIL" for x in r.results) else 1)


def _really(sv, model, kind: str):
    """Validation must load the model itself (the app normally loads it only when it's needed)."""
    from .services import Lazy

    if isinstance(model, Lazy):
        try:
            return model.get()
        except Exception as e:  # noqa: BLE001
            st = sv.status.get(kind)
            if st is not None:
                st.ok, st.active, st.message = False, "none", str(e)[:300]
            return None
    return model
