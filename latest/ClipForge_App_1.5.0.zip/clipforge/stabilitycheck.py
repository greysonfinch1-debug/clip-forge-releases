"""Stability, cancel and resource checks on this PC, with a recording you own or have permission
to use:

    clipforge-cli stabilitycheck "D:\\Videos\\my stream.mp4" --rights own [--modes balanced,low,performance]

Everything runs in a temporary data folder (deleted afterwards), so your projects, settings and
models are never touched; your installed AI models and settings are used read-only.
Checks:
  kill       a running FFmpeg is ended by Windows when ClipForge is force-killed
  priority   Balanced / Low lower ClipForge's priority during a task and restore it afterwards
  cancel     Cancel during: getting the video, transcript, picture analysis, speakers, AI judging,
             voice, preview and export → time to stop, leftover FFmpeg, half-written files,
             project still readable, the same step works again
  recovery   ClipForge killed while rendering → crash detected at the next start, project intact,
             nothing left running
  analysis   per mode: time, peak memory, GPU memory, and how much another program slows down
Results: report.md and results.json in %APPDATA%\\ClipForge\\checks\\stability_<date>.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

CANCEL_STAGES = ["ingest", "transcript", "visual", "speakers", "judge", "voice", "preview", "render"]
STAGE_LABEL = {"ingest": "getting the video", "transcript": "transcript", "visual": "picture analysis",
               "speakers": "speakers", "judge": "AI judging", "voice": "voice", "preview": "preview render",
               "render": "export render"}
PROBE = r'''
import sys, time
end = time.time() + float(sys.argv[1])
while time.time() < end:
    t = time.perf_counter()
    x = 0
    for i in range(60000):
        x += i * i
    print(time.perf_counter() - t, flush=True)     # one line per sample: nothing is lost when stopped
    time.sleep(0.05)
'''


# ------------------------------------------------------------------ helpers
def _python() -> str:
    """A plain Python for helper processes (the installed build's runtime when there is one)."""
    inst = os.environ.get("CLIPFORGE_INSTALL_DIR")
    if inst:
        for name in ("python.exe", "pythonw.exe"):
            p = Path(inst) / "runtime" / name
            if p.exists():
                return str(p)
    return sys.executable


def _self_command() -> list[str]:
    from .fieldtest import _self_command as sc

    return sc()


def _pctl(xs):
    xs = sorted(xs)
    if not xs:
        return None
    return {"median_ms": round(xs[len(xs) // 2] * 1000, 2), "p95_ms": round(xs[int(0.95 * (len(xs) - 1))] * 1000, 2)}


def _samples(text: str) -> list[float]:
    xs = []
    for ln in (text or "").splitlines():
        try:
            xs.append(float(ln))
        except ValueError:
            pass
    return xs


def _alive(pid: int) -> bool:
    from .projects import _pid_alive

    return _pid_alive(pid)


def _write_settings(home: Path, base: dict) -> None:
    home.mkdir(parents=True, exist_ok=True)
    (home / "settings.json").write_text(json.dumps(base, indent=1), encoding="utf-8")


def _run_child(spec: dict, home: Path, timeout: float) -> dict:
    spec_f = home / f"spec_{spec['kind']}_{spec.get('stage', spec.get('mode', ''))}.json"
    res_f = spec_f.with_suffix(".result.json")
    spec["result"] = str(res_f)
    spec_f.write_text(json.dumps(spec), encoding="utf-8")
    env = dict(os.environ, CLIPFORGE_HOME=str(home))
    t = time.time()
    try:
        p = subprocess.run(_self_command() + ["stabilitycheck-child", str(spec_f)], env=env, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        rc = p.returncode
    except subprocess.TimeoutExpired:
        return {"error": f"did not finish within {timeout / 60:.0f} min"}
    try:
        return json.loads(res_f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"exit_code": rc, "wall_s": round(time.time() - t, 1), "no_result": True}


# ------------------------------------------------------------------ parent
def main(argv=None) -> int:
    from .config import Settings, app_dir

    ap = argparse.ArgumentParser(prog="clipforge-cli stabilitycheck", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", help="a local recording you own or have permission to use (20-60 min is ideal)")
    ap.add_argument("--rights", required=True, choices=["own", "permission"],
                    help="own = your own footage; permission = the creator gave you permission")
    ap.add_argument("--creator", default="", help="whose footage it is (for the record)")
    ap.add_argument("--modes", default="balanced,low,performance", help="modes to time the full analysis in")
    ap.add_argument("--skip", default="", help="comma list of checks to skip: kill,priority,cancel,recovery,analysis")
    ap.add_argument("--out", default="", help="report folder")
    a = ap.parse_args(argv)
    video = Path(a.video).expanduser().resolve()
    if not video.is_file():
        print(f"File not found: {video}")
        return 2
    skip = {s.strip() for s in a.skip.split(",") if s.strip()}
    from dataclasses import asdict

    real = Settings.load()                      # read only: models folder, AI choices
    base = asdict(real)
    base.update(first_run_done=True, check_updates=False, auto_install_updates=False)
    out = Path(a.out) if a.out else app_dir() / "checks" / time.strftime("stability_%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="cf_stability_"))
    base["output_dir"] = str(work / "exports")
    rights = {"basis": "own" if a.rights == "own" else "written_permission", "creator": a.creator or "(not given)"}
    from .fieldtest import environment

    res = {"environment": environment(), "video": str(video), "checks": [], "analysis": []}
    try:
        from . import resources

        res["environment"]["recommended_mode"] = resources.recommended_mode()
        res["environment"]["chosen_mode"] = real.performance or "(automatic)"
        res["environment"]["gpus"] = resources.gpus()
    except Exception:  # noqa: BLE001
        pass

    def add(name, status, detail, data=None):
        res["checks"].append({"check": name, "result": status, "detail": detail, "data": data or {}})
        print(f"{status:5s} {name}: {detail}", flush=True)
        _report(out, res)

    print(f"ClipForge stability check → {out}\n(temporary data folder {work}; your projects are not touched)\n")
    try:
        if "kill" not in skip:
            home = work / "kill"
            _write_settings(home, base)
            r = _run_child({"kind": "kill"}, home, 120)
            pid = r.get("ffmpeg_pid")
            time.sleep(3)
            alive = bool(pid) and _alive(int(pid))
            add("FFmpeg ends when ClipForge is force-killed", "PASS" if pid and not alive else "FAIL",
                f"FFmpeg pid {pid}: {'still running' if alive else 'ended'}"
                + ("" if r.get("job") else " (no Windows job object)"), r)
            if alive:
                _kill_pid(int(pid))
        if "priority" not in skip:
            add(*_priority_check())
        cancel_home = work / "cancel"
        _write_settings(cancel_home, base)
        if "cancel" not in skip:
            for st in CANCEL_STAGES:
                r = _run_child({"kind": "cancel", "stage": st, "video": str(video), "rights": rights}, cancel_home,
                               4 * 3600)
                name = f"Cancel during {STAGE_LABEL[st]}"
                if r.get("finished_before_cancel"):
                    add(name, "INFO", "the step finished before Cancel could be clicked (too quick to test)", r)
                elif not r.get("triggered"):
                    add(name, "INFO", f"this step didn't run with your settings ({r.get('error', '')[:120]})", r)
                else:
                    ok = (r.get("stopped") and r.get("stop_s", 99) <= 15 and not r.get("children_left")
                          and not r.get("partials") and r.get("project_valid") is True
                          and r.get("rerun_ok") in (True, None))
                    add(name, "PASS" if ok else "FAIL",
                        f"stopped in {r.get('stop_s')} s, FFmpeg left {r.get('children_left')}, half-written files "
                        f"{len(r.get('partials') or [])}, project readable {r.get('project_valid')}, "
                        f"works again {r.get('rerun_ok')}", r)
        if "recovery" not in skip:
            r = _run_child({"kind": "recover", "video": str(video), "rights": rights}, cancel_home, 4 * 3600)
            time.sleep(3)
            pids = r.get("ffmpeg_pids") or []
            left = [p for p in pids if _alive(int(p))]
            for p in left:
                _kill_pid(int(p))
            chk = _run_child({"kind": "recover-check"}, cancel_home, 600)
            ok = bool(pids) and not left and chk.get("crash_detected") and chk.get("project_ok")
            add("Recovery after ClipForge is killed mid-render", "PASS" if ok else "FAIL",
                f"FFmpeg running at the kill {len(pids)}, still running after {len(left)}; crash detected at next "
                f"start {chk.get('crash_detected')}; project intact {chk.get('project_ok')}; "
                f"interrupted render works again {chk.get('rerun_ok')}", {"kill": r, "check": chk})
        if "analysis" not in skip:
            for m in [x.strip() for x in a.modes.split(",") if x.strip()]:
                home = work / f"mode_{m}"
                b = dict(base, performance=m)
                _write_settings(home, b)
                print(f"\nTiming the full analysis in {m} mode (this takes a while)…", flush=True)
                r = _run_child({"kind": "analysis", "mode": m, "video": str(video), "python": _python()}, home,
                               6 * 3600)
                r["mode"] = m
                res["analysis"].append(r)
                add(f"Full analysis in {m} mode", "FAIL" if r.get("error") or r.get("no_result") else "INFO",
                    r.get("error") or f"{r.get('total_s')} s, peak memory {r.get('peak_mb')} MB, GPU memory peak "
                    f"{r.get('gpu_peak_mb', '-')} MB, other programs {r.get('other_slowdown', '?')}× slower (p95)", r)
                shutil.rmtree(home, ignore_errors=True)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    _report(out, res)
    print(f"\nDone. Report: {out / 'report.md'}")
    return 0 if not [c for c in res["checks"] if c["result"] == "FAIL"] else 1


def _kill_pid(pid: int) -> None:
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            os.kill(pid, 9)
    except OSError:
        pass


def _priority_check():
    from . import resources

    name = "Balanced / Low lower ClipForge's priority during a task"
    if sys.platform != "win32":
        return name, "INFO", "Windows-only check (skipped here)", {}
    import ctypes

    k32 = ctypes.windll.kernel32
    k32.GetCurrentProcess.restype = ctypes.c_void_p
    k32.GetPriorityClass.argtypes = [ctypes.c_void_p]
    got, ok = {}, True
    for mode, want in (("balanced", 0x4000), ("low", 0x4000), ("performance", 0x20)):
        resources.set_mode(mode)
        resources.lower_task_priority()
        during = k32.GetPriorityClass(k32.GetCurrentProcess())
        resources.restore_task_priority()
        after = k32.GetPriorityClass(k32.GetCurrentProcess())
        got[mode] = {"during": hex(during), "after": hex(after)}
        ok &= during == want and after == 0x20
    names = {"0x20": "normal", "0x4000": "below normal"}
    return (name, "PASS" if ok else "FAIL",
            "; ".join(f"{m}: {names.get(v['during'], v['during'])} during, {names.get(v['after'], v['after'])} after"
                      for m, v in got.items()), got)


def _report(out: Path, res: dict) -> None:
    (out / "results.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    env = res["environment"]
    lines = ["# ClipForge stability check", "",
             f"ClipForge {env.get('clipforge')} · {env.get('os')} · {env.get('cores')} CPU threads · "
             f"{env.get('ram_gb', '?')} GB RAM · GPU: {env.get('gpu') or 'none found'} · {env.get('time')}",
             f"Video: {res['video']}", "", "| Result | Check | Details |", "| --- | --- | --- |"]
    for c in res["checks"]:
        lines.append(f"| {c['result']} | {c['check']} | {c['detail']} |")
    if res["analysis"]:
        lines += ["", "## Full analysis by mode", "",
                  "| Mode | Getting the video (s) | Analysis (s) | Peak memory (MB) | GPU memory peak (MB) | "
                  "Other program, idle p95 (ms) | … during analysis p95 (ms) | Slowdown |",
                  "| --- | --- | --- | --- | --- | --- | --- | --- |"]
        for r in res["analysis"]:
            lines.append(f"| {r.get('mode')} | {r.get('ingest_s', '-')} | {r.get('analysis_s', '-')} | "
                         f"{r.get('peak_mb', '-')} | {r.get('gpu_peak_mb', '-')} | "
                         f"{(r.get('other_idle') or {}).get('p95_ms', '-')} | "
                         f"{(r.get('other_busy') or {}).get('p95_ms', '-')} | {r.get('other_slowdown', '-')}× |")
    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


# ------------------------------------------------------------------ children (one process per check)
def child(argv) -> int:
    spec = json.loads(Path(argv[0]).read_text(encoding="utf-8"))
    home = os.environ.get("CLIPFORGE_HOME", "")
    if "cf_stability_" not in home:          # never run against the real data folder
        print("stabilitycheck-child must run in its temporary data folder")
        return 2
    out: dict = {}
    try:
        {"kill": _c_kill, "cancel": _c_cancel, "recover": _c_recover, "recover-check": _c_recover_check,
         "analysis": _c_analysis}[spec["kind"]](spec, out)
    except Exception as e:  # noqa: BLE001
        out["error"] = f"{type(e).__name__}: {e}"[:500]
    Path(spec["result"]).write_text(json.dumps(out, indent=1, default=str), encoding="utf-8")
    return 0


def _pipeline():
    from .config import Settings
    from .pipeline import Pipeline

    return Pipeline(Settings.load())


def _ensure_source(p, spec):
    p.ingest(path=spec["video"])
    r = p.project.source.rights
    r.basis, r.creator, r.confirmed = spec["rights"]["basis"], spec["rights"]["creator"], True
    p.save_rights()


def _c_kill(spec, out):
    from . import resources
    from .core import ffmpeg as ff

    resources.set_mode("balanced")
    p = resources.popen([ff.ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-re", "-f", "lavfi", "-i",
                         "testsrc2=s=320x240:r=30:d=300", "-f", "null", "-"],
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    out["ffmpeg_pid"] = p.pid
    out["job"] = resources._job is not None
    Path(spec["result"]).write_text(json.dumps(out), encoding="utf-8")
    time.sleep(2)
    os.kill(os.getpid(), 9)              # TerminateProcess on Windows: as if ClipForge crashed


def _c_cancel(spec, out):
    import glob

    from . import resources

    stage = spec["stage"]
    kind = {"ingest": "ingest", "voice": "edit", "preview": "preview", "render": "export"}.get(stage, "find")
    p = _pipeline()
    if kind != "ingest":
        _ensure_source(p, spec)
    if kind in ("edit", "preview", "export"):
        p.find_moments("funny moments", 45)
        # start the edit steps from nothing so there is something to cancel
        for sub in ("narration", "render"):
            shutil.rmtree(p.cache.dir / sub, ignore_errors=True)
        p.edit_timeline = None
    if kind == "preview":
        p.prepare_edit()
    if kind == "find":
        # an earlier check analysed the video completely: remove this step's saved results and
        # everything after it, so the step really runs again (the video itself is kept)
        order = [("transcript", ["transcript.json"]), ("visual", ["visual_features.npz", "keyframes"]),
                 ("sounds", ["sound_events.npz"]), ("speakers", ["speakers.json"]),
                 ("judge", ["cands_*.json", "topic_*.json"])]
        names = [n for n, _ in order]
        start = names.index(stage) if stage in names else len(names) - 1
        for _, pats in order[start:]:
            for pat in pats:
                for f in p.cache.dir.glob(pat):
                    shutil.rmtree(f, ignore_errors=True) if f.is_dir() else f.unlink(missing_ok=True)
    hit, box = threading.Event(), {}

    def prog(st, f, m):
        if st == stage:
            hit.set()

    def job():
        resources.lower_task_priority()
        try:
            if kind == "ingest":
                p.ingest(path=spec["video"], progress=prog)
            elif kind == "find":
                p.find_moments("funny moments", 45, progress=prog)
            elif kind == "edit":
                p.prepare_edit(prog)
            elif kind == "preview":
                p.render_preview(prog)
            else:
                p.export(progress=prog, out_dir=str(Path(p.settings.output_dir)))
            box["finished"] = True
        except Exception as e:  # noqa: BLE001
            box["error"] = f"{type(e).__name__}: {e}"[:300]
    th = threading.Thread(target=job, daemon=True)
    th.start()
    while th.is_alive() and not hit.is_set():
        th.join(0.05)
    out["triggered"] = hit.is_set()
    if not hit.is_set():
        out["finished_before_cancel"] = bool(box.get("finished")) and stage in ("judge",)
        out["error"] = box.get("error", "stage not reached")
        return
    time.sleep(1.0)
    t = time.time()
    p.cancel()
    th.join(600)
    out["stopped"] = not th.is_alive()
    out["stop_s"] = round(time.time() - t, 2)
    if box.get("finished"):
        out["finished_before_cancel"] = True
    out["result"] = box
    time.sleep(0.5)
    out["children_left"] = resources.running_children()
    home = os.environ["CLIPFORGE_HOME"]
    out["partials"] = [os.path.basename(x) for x in glob.glob(os.path.join(home, "**", "*.partial.*"), recursive=True)]
    try:
        if p.project.source is not None:
            p.project.save()
            from .projects import load_project_dict, projects_dir

            _, note = load_project_dict(projects_dir() / f"{p.project.project_id}.json")
            out["project_valid"] = not note
        else:
            out["project_valid"] = True
    except Exception as e:  # noqa: BLE001
        out["project_valid"] = f"{e}"[:200]
    if kind != "ingest":
        p.reset_cancel()
        try:
            {"find": lambda: p.find_moments("funny moments", 45), "edit": lambda: p.prepare_edit(),
             "preview": lambda: p.render_preview(),
             "export": lambda: p.export(out_dir=str(Path(p.settings.output_dir)))}[kind]()
            out["rerun_ok"] = True
        except Exception as e:  # noqa: BLE001
            out["rerun_ok"] = f"{type(e).__name__}: {e}"[:200]


def _c_recover(spec, out):
    from . import projects as P
    from . import resources

    p = _pipeline()
    _ensure_source(p, spec)
    p.find_moments("funny moments", 45)
    p.prepare_edit()
    shutil.rmtree(p.cache.dir / "render", ignore_errors=True)
    path = p.project.save()
    P.start_session()
    p.project.meta["status"] = "running: Rendering the preview"
    p.project.save()
    P.update_session(task="Rendering the preview", project_path=str(path))
    hit = threading.Event()
    th = threading.Thread(target=lambda: p.render_preview(lambda st, f, m: hit.set() if st == "preview" else None),
                          daemon=True)
    th.start()
    hit.wait(1800)
    deadline = time.time() + 120
    while time.time() < deadline and not resources.running_children():
        time.sleep(0.1)
    with resources._lock:
        out["ffmpeg_pids"] = [c.pid for c in resources._children if c.poll() is None]
    out["project_path"] = str(path)
    Path(spec["result"]).write_text(json.dumps(out), encoding="utf-8")
    os.kill(os.getpid(), 9)


def _c_recover_check(spec, out):
    from . import projects as P
    from .crash import report_unclean_shutdown

    prev = P.start_session()
    out["crash_detected"] = bool(prev and prev.get("task"))
    if prev:
        out["crash_report"] = str(report_unclean_shutdown(prev))
    p = _pipeline()
    path = (prev or {}).get("project_path")
    try:
        p.open_project(path)
        out["project_ok"] = p.project.source is not None and bool(p.project.candidates)
        p.render_preview()
        out["rerun_ok"] = True
    except Exception as e:  # noqa: BLE001
        out.setdefault("project_ok", False)
        out["rerun_ok"] = f"{type(e).__name__}: {e}"[:200]
    P.end_session()


def _c_analysis(spec, out):
    from . import resources
    from .fieldtest import GpuSampler, peak_rss_mb

    probe_py = spec.get("python") or sys.executable
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    pr = subprocess.run([probe_py, "-c", PROBE, "6"], capture_output=True, text=True, creationflags=flags)
    out["other_idle"] = _pctl(_samples(pr.stdout))
    gpu = GpuSampler()
    gpu.start()
    probe = subprocess.Popen([probe_py, "-c", PROBE, str(24 * 3600)], stdout=subprocess.PIPE, text=True,
                             creationflags=flags)
    p = _pipeline()
    box = {}

    def job():
        resources.lower_task_priority()
        try:
            t = time.time()
            p.ingest(path=spec["video"])
            box["ingest_s"] = round(time.time() - t, 1)
            t = time.time()
            p.find_moments("funny moments", 45)
            box["analysis_s"] = round(time.time() - t, 1)
        except Exception as e:  # noqa: BLE001
            box["error"] = f"{type(e).__name__}: {e}"[:300]
        finally:
            resources.restore_task_priority()
    t0 = time.time()
    th = threading.Thread(target=job)
    th.start()
    th.join()
    out.update(box)
    out["total_s"] = round(time.time() - t0, 1)
    out["peak_mb"] = peak_rss_mb()
    gpu.stop.set()
    out["gpu_peak_mb"] = gpu.peak_mem if gpu.exe else None
    out["gpu_peak_util"] = gpu.peak_util if gpu.exe else None
    out["threads"] = resources.ai_threads()
    probe.terminate()
    try:
        out["other_busy"] = _pctl(_samples(probe.communicate(timeout=10)[0]))
    except Exception:  # noqa: BLE001
        out["other_busy"] = None
    if out.get("other_idle") and out.get("other_busy"):
        out["other_slowdown"] = round(out["other_busy"]["p95_ms"] / max(0.01, out["other_idle"]["p95_ms"]), 2)
