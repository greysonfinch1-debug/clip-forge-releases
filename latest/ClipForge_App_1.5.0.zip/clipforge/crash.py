"""Crash reports and diagnostics (%APPDATA%\\ClipForge\\logs).

  faults.log            low-level crashes (e.g. inside a native library) via faulthandler
  crash_<time>.txt      an unexpected error or an unclean shutdown, with the context needed to fix it
  activity.log          what ClipForge was doing (see activity.py)
"""
from __future__ import annotations

import faulthandler
import platform
import sys
import threading
import time
import traceback
import zipfile
from pathlib import Path

_fault_file = None


def logs_dir() -> Path:
    from .config import app_dir

    d = app_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _context() -> str:
    from . import __version__, resources

    lines = [f"ClipForge {__version__}", f"Python {sys.version.split()[0]} on {platform.platform()}",
             f"Performance mode: {resources.mode()} · {resources.cores()} cores · {resources.ram_gb():.1f} GB RAM",
             f"Memory in use: {resources.process_rss_mb():.0f} MB", ""]
    try:
        act = (logs_dir() / "activity.log").read_text(encoding="utf-8", errors="replace").splitlines()[-80:]
        lines += ["Last activity:"] + act
    except OSError:
        pass
    return "\n".join(lines)


def write_report(title: str, details: str) -> Path:
    p = logs_dir() / f"crash_{time.strftime('%Y%m%d-%H%M%S')}.txt"
    try:
        p.write_text(f"{title}\n{'=' * len(title)}\n{time.strftime('%Y-%m-%d %H:%M:%S')}\n\n{details}\n\n"
                     f"{_context()}\n", encoding="utf-8")
    except OSError:
        pass
    # keep the folder tidy: the 20 newest reports
    for old in sorted(logs_dir().glob("crash_*.txt"))[:-20]:
        old.unlink(missing_ok=True)
    return p


def install(on_error=None) -> None:
    """Record crashes instead of losing them. ``on_error(text)`` is called (from any thread) for an
    unexpected Python error so the window can show it; the app keeps running."""
    global _fault_file
    try:
        _fault_file = open(logs_dir() / "faults.log", "a", encoding="utf-8")
        _fault_file.write(f"\n--- session {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        _fault_file.flush()
        faulthandler.enable(_fault_file, all_threads=True)
    except OSError:
        pass

    def hook(exc_type, exc, tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc, tb)
            return
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        p = write_report("Unexpected error", text)
        try:
            from .activity import log

            log(f"UNEXPECTED ERROR (report: {p.name}): {exc_type.__name__}: {exc}")
        except Exception:  # noqa: BLE001
            pass
        if on_error:
            try:
                on_error(f"{exc_type.__name__}: {exc}\n\nA crash report was saved: {p}")
            except Exception:  # noqa: BLE001
                pass
    sys.excepthook = hook
    threading.excepthook = lambda a: hook(a.exc_type, a.exc_value, a.exc_traceback)


def report_unclean_shutdown(previous: dict) -> Path:
    faults = ""
    try:
        txt = (logs_dir() / "faults.log").read_text(encoding="utf-8", errors="replace")
        last = txt.split("--- session")[-2] if txt.count("--- session") >= 2 else ""
        faults = last.strip()[-6000:]
    except OSError:
        pass
    return write_report("ClipForge did not close normally",
                        f"Previous session: {previous}\n\nLow-level crash information:\n{faults or '(none)'}")


def diagnostics_zip(dest: Path) -> Path:
    """Logs + settings (without API keys) + system info, to send for help."""
    from .config import app_dir

    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for f in logs_dir().glob("*"):
            if f.is_file() and f.stat().st_size < 20 * 2**20:
                z.write(f, f"logs/{f.name}")
        s = app_dir() / "settings.json"
        if s.exists():
            import json
            import re

            try:
                d = json.loads(s.read_text(encoding="utf-8"))
                text = json.dumps(d, indent=1)
            except ValueError:
                text = s.read_text(encoding="utf-8", errors="replace")
            text = re.sub(r'("api_key"\s*:\s*")[^"]*"', r'\1(removed)"', text)
            z.writestr("settings.json", text)
        for f in ("startup_log.txt", "error_log.txt"):
            if (app_dir() / f).exists():
                z.write(app_dir() / f, f)
        z.writestr("system.txt", _context())
    return dest
