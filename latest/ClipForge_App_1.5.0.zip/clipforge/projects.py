"""Project files: safe saving, checkpoints, recovery, listing, deleting and restarting.

Layout (in %APPDATA%\\ClipForge):
  projects/<id>.json                 the project (written atomically: temp file + fsync + rename)
  projects/.checkpoints/<id>/*.json  the last few saved versions (a damaged file is never the only copy)
  session.lock                       present while ClipForge runs; left behind by a crash or power cut

Nothing here touches settings, AI models or other projects. The downloaded video and its
analysis live in the cache (%LOCALAPPDATA%\\ClipForge\\cache\\<source id>) and may be shared by
several projects that use the same video; they are only deleted when no other project uses them.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .config import app_dir
from .core.cache import cache_root as cache_dir

CHECKPOINTS = 5
STAGE_NAMES = {1: "Source & Topic", 2: "Candidate Clips", 3: "Story & Hooks", 4: "Script & Voice",
               5: "Edit & Captions", 6: "Export"}


def projects_dir() -> Path:
    d = app_dir() / "projects"
    d.mkdir(parents=True, exist_ok=True)
    return d


def new_project_id() -> str:
    """Time-based and unique (two projects started in the same second must not overwrite each other)."""
    base = time.strftime("%Y%m%d-%H%M%S")
    pid, k = base, 1
    while (projects_dir() / f"{pid}.json").exists() or (projects_dir() / ".checkpoints" / pid).exists():
        k += 1
        pid = f"{base}-{k}"
    return pid


def atomic_write(path: Path, text: str) -> None:
    """Write so that a crash or power cut leaves either the old file or the new one, never half."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    for attempt in range(20):           # Windows: a virus scanner may hold the old file briefly
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            time.sleep(0.1 * (attempt + 1))
    os.replace(tmp, path)


def save_project_dict(project_id: str, data: dict) -> Path:
    p = projects_dir() / f"{project_id}.json"
    text = json.dumps(data, indent=1)
    json.loads(text)                     # never write something that can't be read back
    atomic_write(p, text)
    # checkpoint: keep the last few versions (cheap: projects are small)
    cp = projects_dir() / ".checkpoints" / project_id
    cp.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    k = 0
    while (cp / f"{stamp}_{k}.json").exists():
        k += 1
    try:
        atomic_write(cp / f"{stamp}_{k}.json", text)
        old = sorted(cp.glob("*.json"))
        for f in old[:-CHECKPOINTS]:
            f.unlink(missing_ok=True)
    except OSError:
        pass
    try:
        atomic_write(app_dir() / "last_project.txt", str(p))
    except OSError:
        pass
    return p


def load_project_dict(path: Path) -> tuple[dict, str]:
    """Read a project; if the file is damaged, fall back to its newest good checkpoint.
    Returns (data, note) where note says what was recovered ("" when the file was fine)."""
    try:
        return json.loads(Path(path).read_text(encoding="utf-8")), ""
    except (OSError, ValueError) as first:
        cp = projects_dir() / ".checkpoints" / Path(path).stem
        for f in sorted(cp.glob("*.json"), reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                return data, (f"The project file was damaged ({type(first).__name__}); restored the copy saved "
                              f"{_fmt_stamp(f.stem)}.")
            except (OSError, ValueError):
                continue
        raise ValueError(f"This project file is damaged and no saved copy could be read: {first}") from first


def _fmt_stamp(stem: str) -> str:
    try:
        t = time.strptime(stem.split("_")[0], "%Y%m%d-%H%M%S")
        return time.strftime("%Y-%m-%d %H:%M:%S", t)
    except ValueError:
        return stem


@dataclass
class ProjectInfo:
    project_id: str
    path: Path
    name: str
    source: str
    topic: str
    stage: int
    modified: float
    status: str
    source_id: str
    damaged: bool = False

    @property
    def stage_name(self) -> str:
        return f"{self.stage} · {STAGE_NAMES.get(self.stage, '?')}"


def list_projects() -> list[ProjectInfo]:
    out = []
    for f in projects_dir().glob("*.json"):
        try:
            d, note = load_project_dict(f)
            damaged = bool(note)
        except ValueError:
            out.append(ProjectInfo(f.stem, f, f.stem, "?", "", 1, f.stat().st_mtime, "damaged", "", True))
            continue
        src = d.get("source") or {}
        plan = d.get("plan") or {}
        topic = ((plan.get("topic") or {}).get("raw") or (plan.get("topic") or {}).get("summary") or "")
        meta = d.get("meta") or {}
        out.append(ProjectInfo(
            project_id=d.get("project_id") or f.stem, path=f,
            name=meta.get("name") or src.get("title") or "Untitled project",
            source=src.get("url") or src.get("path") or "(no video yet)",
            topic=topic, stage=int(meta.get("stage") or _guess_stage(d)),
            modified=float(meta.get("modified") or f.stat().st_mtime),
            status=meta.get("status") or ("exported" if d.get("last_export") else "in progress"),
            source_id=src.get("source_id") or "", damaged=damaged))
    return sorted(out, key=lambda p: -p.modified)


def _guess_stage(d: dict) -> int:
    plan = d.get("plan") or {}
    if d.get("last_export"):
        return 6
    if plan.get("captions"):
        return 5
    if plan.get("narration"):
        return 4
    if plan.get("story"):
        return 3
    if d.get("candidates"):
        return 2
    return 1


def source_in_use(source_id: str, except_project: str = "") -> list[str]:
    """Other projects that use the same downloaded video / analysis."""
    return [p.project_id for p in list_projects() if p.source_id == source_id and p.project_id != except_project]


def cache_size(source_id: str) -> int:
    d = cache_dir() / source_id
    if not source_id or not d.is_dir():
        return 0
    return sum(f.stat().st_size for f in d.rglob("*") if f.is_file())


def delete_project(project_id: str, delete_source_data: bool) -> dict:
    """Delete one project (file + checkpoints). With ``delete_source_data``, also its downloaded
    video and analysis — but only if no other project uses them. Settings, models and other
    projects are never touched. Returns what was removed."""
    f = projects_dir() / f"{project_id}.json"
    src_id = ""
    try:
        d, _ = load_project_dict(f)
        src_id = (d.get("source") or {}).get("source_id") or ""
    except (ValueError, OSError):
        pass
    removed = {"project": False, "checkpoints": False, "source_data_mb": 0.0, "kept_shared": False}
    if f.exists():
        f.unlink()
        removed["project"] = True
    for extra in (f.with_name(f.name + ".tmp"),):
        extra.unlink(missing_ok=True)
    cp = projects_dir() / ".checkpoints" / project_id
    if cp.exists():
        shutil.rmtree(cp, ignore_errors=True)
        removed["checkpoints"] = True
    if delete_source_data and src_id:
        if source_in_use(src_id, project_id):
            removed["kept_shared"] = True
        else:
            removed["source_data_mb"] = round(cache_size(src_id) / 2**20, 1)
            _safe_rmtree_cache(src_id)
    try:
        last = Path((app_dir() / "last_project.txt").read_text(encoding="utf-8").strip())
        if last.stem == project_id:
            (app_dir() / "last_project.txt").unlink(missing_ok=True)
    except OSError:
        pass
    return removed


def _safe_rmtree_cache(source_id: str) -> None:
    """Remove one source's cache folder, and nothing else (guards against odd ids)."""
    if not source_id or any(c in source_id for c in "/\\:.") or source_id.strip() != source_id:
        return
    d = (cache_dir() / source_id).resolve()
    if d.parent != cache_dir().resolve():
        return
    shutil.rmtree(d, ignore_errors=True)


# ------------------------------------------------------------------ crash detection
def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes

        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def start_session() -> Optional[dict]:
    """Called at start-up. Returns the previous session's record if ClipForge did not close
    properly last time (crash, forced quit, Windows shut down), else None."""
    lock = app_dir() / "session.lock"
    previous = None
    if lock.exists():
        try:
            d = json.loads(lock.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            d = {"pid": 0}
        if not _pid_alive(int(d.get("pid") or 0)) or int(d.get("pid") or 0) == os.getpid():
            previous = d
    update_session(started=time.time())
    return previous


def update_session(**fields) -> None:
    lock = app_dir() / "session.lock"
    try:
        d = json.loads(lock.read_text(encoding="utf-8")) if lock.exists() else {}
    except (OSError, ValueError):
        d = {}
    if d.get("pid") != os.getpid():
        d = {"pid": os.getpid(), "started": time.time()}
    d.update(fields)
    try:
        atomic_write(lock, json.dumps(d))
    except OSError:
        pass


def end_session() -> None:
    try:
        (app_dir() / "session.lock").unlink(missing_ok=True)
    except OSError:
        pass
