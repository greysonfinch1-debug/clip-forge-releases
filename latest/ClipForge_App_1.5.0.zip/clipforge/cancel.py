"""One cancel signal for the running task, reachable from every layer (pipeline stages,
language-model calls, voice generation, downloads). Only one task runs at a time."""
from __future__ import annotations

import threading

_flag = threading.Event()


class Cancelled(RuntimeError):
    def __init__(self, msg: str = "Cancelled"):
        super().__init__(msg)


def request() -> None:
    _flag.set()


def reset() -> None:
    _flag.clear()


def requested() -> bool:
    return _flag.is_set()


def check() -> None:
    if _flag.is_set():
        raise Cancelled()
