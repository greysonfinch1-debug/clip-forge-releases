"""Topic understanding: turn the user's request into a structured search specification.

With a language model, the request is decomposed into visual concepts (what should be on
screen), look-alikes to reject, things people would say, entertainment criteria and
exclusions. Without one, a built-in gaming vocabulary does a simpler expansion.
"""
from __future__ import annotations

import re

from ..core.models import TopicSpec
from ..providers.base import LLM, ProviderUnavailable

VERSION = 6  # bump when topic expansion changes (invalidates cached topic specs)

SYSTEM = """You turn a video editor's request into a precise search specification for finding moments in a long gameplay livestream.
The search uses four signals: (1) a CLIP image model that compares video frames to short visual descriptions, (2) the transcript of what the streamer says, (3) a sound-event model (sirens, crashes, laughter, engines...), (4) audio energy.
Be concrete and literal. Visual concepts must describe what is VISIBLE in a single frame (CLIP cannot see motion or story).
Reply with JSON only."""

PROMPT = """Request: "{raw}"

Return JSON with these keys:
- "summary": one sentence restating exactly what moments are wanted.
- "sub_topics": list of 1-5 distinct kinds of moments contained in the request.
- "visual_positive": 4-10 short concrete visual descriptions of frames that would appear in these moments (e.g. "police cars with flashing red and blue lights chasing a car", "a car crashing into a wall").
- "visual_negative": 3-6 visually similar frames that are NOT what is wanted (e.g. "a parked police car with no action", "a menu screen").
- "speech_cues": 6-15 short phrases a streamer might actually say during these moments (e.g. "the cops are behind me", "oh my god", "no way").
- "keywords": 5-15 single words or short terms strongly tied to the topic.
- "entertainment_criteria": 3-6 things that make such a moment entertaining for a stranger (e.g. "an unexpected outcome", "a big reaction").
- "exclude": things that must not be selected (e.g. "reading donations", "menu screens", "talking about unrelated topics").
- "sounds": 0-4 sound types typical of these moments, chosen ONLY from: {sound_groups}. Use [] if sound says nothing about the topic.
- "needs_visual": true if the topic is mainly about what happens on screen.
- "needs_speech": true if the topic is mainly about what is said.
The request may also say HOW to make the Short. Read that too:
- "count": how many moments the request asks for (e.g. "the four coolest things" = 4, "top 5" = 5), 0 if it doesn't say.
- "format": "countdown" for a ranking (top N, the N best/coolest..., number one last), "list" for N moments without a ranking, "story" if it asks for what happened in order, "" if it doesn't say.
- "detail": "detailed" if the narration should describe or explain each moment, "none" if it asks for no narration/voice-over, "" otherwise.
- "instructions": what the narration should say about the moments, in the request's own words ("" if nothing).
- "search": only the part of the request that says WHAT to look for, without the instructions about the video."""

# ---------------------------------------------------------------- built-in vocabulary (fallback)

LEXICON: list[tuple[tuple[str, ...], dict]] = [
    (("police", "cop", "cops", "chase", "pursuit", "wanted", "stars"), {
        "visual": ["police cars with flashing red and blue lights", "a car being chased by police cars",
                   "a high speed car chase on a city street", "a police helicopter overhead"],
        "neg": ["a parked police car with no action", "a calm empty street"],
        "speech": ["the cops are behind me", "police", "lose them", "they're chasing me", "go go go", "wanted level",
                   "they're still on me", "get away"]}),
    (("crash", "crashes", "wreck", "accident", "collision"), {
        "visual": ["a car crashing into another car", "a wrecked car with smoke", "a car flipping over"],
        "neg": ["a clean parked car"], "speech": ["I crashed", "oh no", "my car", "wrecked", "no no no"]}),
    (("explosion", "explode", "blow", "boom", "bomb"), {
        "visual": ["a large fiery explosion", "a car on fire", "smoke and flames"],
        "neg": ["a sunset sky"], "speech": ["it exploded", "boom", "blew up", "oh my god"]}),
    (("npc", "npcs", "pedestrian", "civilian", "people"), {
        "visual": ["a pedestrian standing close to the player character", "people on a sidewalk reacting",
                   "a character talking to another character"],
        "neg": ["an empty road"], "speech": ["this guy", "this lady", "what is he doing", "bro", "the people in this game"]}),
    (("drive", "driving", "car", "cars", "vehicle", "drift", "stunt", "jump"), {
        "visual": ["a sports car driving fast", "a car in mid-air after a jump", "a car drifting around a corner"],
        "neg": ["a car garage menu"], "speech": ["watch this", "full send", "look at this jump", "drifting"]}),
    (("funny", "hilarious", "laugh", "comedy", "lol"), {
        "visual": ["a character falling over", "an absurd situation in a video game"],
        "neg": [], "speech": ["I'm dying", "ha ha", "that's hilarious", "what", "bro", "no way"]}),
    (("surprise", "surprised", "unexpected", "shock", "wtf", "insane", "crazy"), {
        "visual": ["a sudden dramatic event in a video game"], "neg": [],
        "speech": ["no way", "what", "wait wait", "oh my god", "that is insane", "did you see that"]}),
    (("boat", "water", "ocean", "beach", "swim"), {
        "visual": ["a car sinking in the ocean", "a speedboat on the water", "a beach with palm trees"],
        "neg": [], "speech": ["into the water", "the ocean", "swimming", "boat"]}),
    (("plane", "helicopter", "fly", "flying", "airport"), {
        "visual": ["an airplane flying low over a city", "a helicopter in the air", "an aircraft crash"],
        "neg": [], "speech": ["flying", "the plane", "helicopter", "landing"]}),
    (("discover", "discovery", "secret", "hidden", "easter", "found"), {
        "visual": ["a hidden room in a video game", "a strange object in a video game world"],
        "neg": [], "speech": ["look at this", "I found", "what is this", "secret", "did you know", "hidden"]}),
    (("fight", "shootout", "gun", "shooting", "heist", "robbery", "rob"), {
        "visual": ["a shootout between characters", "a bank robbery in a video game", "characters with weapons"],
        "neg": [], "speech": ["heist", "rob", "shoot", "get the money", "the vault"]}),
]

# sound groups that can describe a topic (reaction sounds like laughter are entertainment, not topic)
TOPIC_SOUNDS = ["siren", "explosion", "gunfire", "crash", "skidding", "vehicle", "aircraft", "water", "alarm",
                "music", "animal", "cheering"]
LEXICON_SOUNDS = {"police": ["siren", "skidding"], "crash": ["crash", "skidding"], "explosion": ["explosion"],
                  "drive": ["skidding"], "boat": ["water"], "plane": ["aircraft"], "fight": ["gunfire", "explosion"]}

GENERIC_EXCLUDE = ["reading donations or thanking chat", "menu or loading screens", "talking about unrelated real-life topics"]
GENERIC_ENTERTAINMENT = ["an unexpected outcome", "a big genuine reaction", "a clear setup and payoff", "something absurd"]


def understand_topic(raw: str, llm: LLM, direction: str = "") -> TopicSpec:
    raw = (raw or "").strip()
    if not raw:
        raw = "the most entertaining moments"
    req = parse_request(raw)
    try:
        p = PROMPT.format(raw=raw, sound_groups=", ".join(TOPIC_SOUNDS))
        if direction:
            p = (f"The creator approved this production brief for the request (follow it; the request's own words "
                 f"still decide what counts):\n{direction[:3000]}\n\n" + p)
        d = llm.complete_json(SYSTEM, p, max_tokens=1100)
        spec = TopicSpec(
            raw=raw,
            summary=str(d.get("summary") or raw),
            sub_topics=_strs(d.get("sub_topics"))[:5] or [raw],
            visual_positive=_strs(d.get("visual_positive"))[:10],
            visual_negative=_strs(d.get("visual_negative"))[:6],
            speech_cues=_strs(d.get("speech_cues"))[:15],
            keywords=_strs(d.get("keywords"))[:15],
            entertainment_criteria=_strs(d.get("entertainment_criteria"))[:6] or GENERIC_ENTERTAINMENT,
            exclude=_strs(d.get("exclude"))[:8] or GENERIC_EXCLUDE,
            needs_visual=bool(d.get("needs_visual", True)),
            needs_speech=bool(d.get("needs_speech", True)),
            sounds=[x for x in _strs(d.get("sounds")) if x in TOPIC_SOUNDS][:4],
        )
        if spec.visual_positive or spec.speech_cues:
            _apply_request(spec, req, d)
            _merge_lexicon(spec)  # adds proven phrasings the model may have missed
            return spec
    except ProviderUnavailable:
        pass
    return rule_topic(raw)


def rule_topic(raw: str) -> TopicSpec:
    req = parse_request(raw)
    q = req["search"] or raw                    # search with the subject, not the instructions
    spec = TopicSpec(raw=raw, summary=raw)
    _apply_request(spec, req, {})
    parts = [p.strip() for p in re.split(r",|;| and | or |\n", q) if len(p.strip()) > 3]
    spec.sub_topics = parts[:5] or [q]
    spec.keywords = [w for w in re.findall(r"[a-zA-Z']+", q.lower()) if len(w) > 3 and w not in _FILLER][:15]
    spec.entertainment_criteria = GENERIC_ENTERTAINMENT
    spec.exclude = GENERIC_EXCLUDE
    if spec.open:   # no subject: look for what makes any moment entertaining
        for keys, entry in LEXICON:
            if keys[0] in QUALITY_GROUPS:
                spec.visual_positive += [v for v in entry["visual"] if v not in spec.visual_positive]
                spec.speech_cues += [v for v in entry["speech"] if v not in spec.speech_cues]
        spec.summary = f"the {spec.superlative or 'most entertaining'} moments of the stream"
    _merge_lexicon(spec)
    if not spec.visual_positive:
        spec.visual_positive = [f"a video game scene showing {p}" for p in spec.sub_topics]
    if not spec.speech_cues:
        spec.speech_cues = spec.sub_topics
    words = set(re.findall(r"[a-z]+", q.lower()))
    speech_only = {"say", "says", "said", "quote", "quotes", "rant", "story", "talks", "conversation"}
    spec.needs_speech = True
    spec.needs_visual = not (words & speech_only and not any(words & set(k) for k, _ in LEXICON))
    return spec


# ---------------------------------------------------------------- how the Short should be told
# Read from the request without a language model too, so "describe the four coolest things" works
# either way: how many moments, ranked or not, and whether the narration should describe each one.

_NUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
        "ten": 10, "a couple of": 2, "a couple": 2, "a few": 3}
_NUM_RE = r"(\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)"
_UNITS = {"seconds", "secs", "minutes", "mins", "hours", "hrs", "words", "frames", "fps", "times", "lines",
          "sentences", "percent", "years", "days"}
_SUPER = re.compile(r"\b(best|worst|top|greatest|biggest|craziest|coolest|funniest|wildest|scariest|"
                    r"dumbest|smartest|weirdest|insanest|most\s+\w+|\w{3,}iest|\w{3,}est)\b", re.I)
_DESCRIBE = re.compile(r"\b(describ\w*|explain\w*|tell\s+(?:me|us|people|the\s+viewers?)|talk\s+(?:about|through)|"
                       r"narrat\w*|commentat\w*|break(?:s|ing)?\s+(?:it\s+)?down|breakdown|in\s+detail|detailed|"
                       r"walk\s+(?:me|us|them)?\s*through|say\s+what|what\s+happens|why\s+(?:it|they|each)|"
                       r"go\s+over|review|recap)\b", re.I)
_NO_VOICE = re.compile(r"\b(no|without)\s+(narration|narrator|voice[- ]?over|voice|talking)\b", re.I)
_STORY = re.compile(r"\b(in\s+order|chronological\w*|tell\s+the\s+story|what\s+happened\s+(?:in|during)|"
                    r"from\s+start\s+to\s+finish)\b", re.I)
_RANK = re.compile(r"\b(count\s*down|countdown|rank\w*|number\s+one|#\s*1|from\s+worst\s+to\s+best)\b", re.I)
_LEAD = re.compile(r"^\s*(?:please\s+)?(?:(?:can|could)\s+you\s+)?(?:make|create|build|do|give\s+me|i\s+want)\s+"
                   r"(?:me\s+)?(?:a|an|the|my)?\s*(?:youtube\s+)?(?:video|short|clip|compilation|montage|countdown|ranking|"
                   r"list|rundown)?\s*"
                   r"(?:about|on|of|showing|with|for)?\s*", re.I)
_FILLER = {"make", "video", "short", "want", "describe", "explain", "things", "thing", "this", "that", "about",
           "what", "coolest", "best", "the", "four", "three", "five", "please", "them", "each", "talk", "tell"}


def _strip_counts(text: str) -> str:
    """Remove the count ("top 5", "the four coolest") but keep durations ("in 30 seconds")."""
    units = "|".join(sorted(_UNITS))
    return re.sub(r"\b(?:top\s+)?" + _NUM_RE + r"\b(?!\s+(?:" + units + r")\b)(?:\s+of)?\s*", "", text, flags=re.I)


def parse_request(raw: str) -> dict:
    """{"count", "format", "detail", "instructions", "search", "superlative"} read from the request."""
    text = " ".join((raw or "").split())
    low = text.lower()
    out = {"count": 0, "format": "", "detail": "", "instructions": "", "search": text, "superlative": ""}
    # how many: "top 5", "the four coolest things", "3 best clips", "a few funny moments"
    m = re.search(r"\btop\s+" + _NUM_RE + r"\b", low)
    n = 0
    if m:
        n = int(m.group(1)) if m.group(1).isdigit() else _NUM[m.group(1)]
    else:
        for m in re.finditer(r"\b(a\s+couple(?:\s+of)?|a\s+few|" + _NUM_RE[1:-1] + r")\s+((?:[a-z'-]+\s+){0,3}?)"
                             r"([a-z'-]+s)\b", low):
            word, mid, noun = m.group(1), m.group(2), m.group(3)
            if noun in _UNITS or (word == "one" and mid.strip().startswith("of")):   # "one of the best…"
                continue
            n = int(word) if word.isdigit() else _NUM.get(" ".join(word.split()), 0)
            if n:
                break
    if 1 <= n <= 10:
        out["count"] = n
    sups = [x.group(1).lower() for x in _SUPER.finditer(low)
            if x.group(1).lower() not in {"test", "interest", "rest", "chest", "forest", "guest", "latest", "request",
                                         "contest", "honest", "modest", "suggest", "digest", "invest"}]
    if sups:   # the adjective itself ("funniest") rather than "top"
        out["superlative"] = next((x for x in sups if x not in ("top", "best")), sups[0])
    # how to tell it
    if _NO_VOICE.search(low):
        out["detail"] = "none"
    elif _DESCRIBE.search(low):
        out["detail"] = "detailed"
    if _STORY.search(low):
        out["format"] = "story"
    elif _RANK.search(low) or re.search(r"\btop\s+" + _NUM_RE, low) or (out["count"] >= 2 and out["superlative"]):
        out["format"] = "countdown"
    elif out["count"] >= 2:
        out["format"] = "list"
    # the instructions (from the first "describe / explain / tell …" on) and the subject (the rest)
    search = _NO_VOICE.sub("", text) if out["detail"] == "none" else text
    d = _DESCRIBE.search(search) if out["detail"] != "none" else None
    if d:
        start = d.start()
        joiner = re.search(r"(?:,|\.|;|\band\b|\bthen\b)?\s*(?:i\s+want\s+(?:you\s+)?(?:to\s+)?|please\s+|"
                           r"also\s+|and\s+)*$", text[:start], re.I)
        cut = joiner.start() if joiner else start
        out["instructions"] = search[start:].strip(" .")
        search = search[:cut]
    search = _LEAD.sub("", search)
    search = _STORY.sub("", re.sub(r"\btell\s+(?:me\s+)?the\s+story\s+of\b", "", search, flags=re.I))
    search = _strip_counts(search)
    search = re.sub(r"\s+", " ", search).strip(" ,.;")
    if search.lower() in {"", "this", "it", "this video", "the video", "this stream", "the stream"}:
        # "make the video about this and describe the four coolest things": the subject IS the ranking
        search = re.sub(r"^(?:what\s+)?(?:the\s+)?", "", out["instructions"].split(" ", 1)[-1], flags=re.I) \
            if out["instructions"] else text
        search = re.sub(r"\b(are|is|were|was)\b.*$", "", search).strip(" ,.") or text
        search = _strip_counts(search).strip()
    out["search"] = search
    return out


_GENERIC = {"things", "thing", "moments", "moment", "clips", "clip", "parts", "part", "stuff", "highlights",
            "highlight", "plays", "play", "scenes", "scene", "ones", "one", "bits", "times", "events", "video",
            "videos", "stream", "streams", "vod", "short", "shorts", "find", "show", "get", "give", "me", "the", "a",
            "an", "of", "from", "in", "this", "that", "all", "some", "most", "top", "best", "worst", "greatest",
            "entertaining", "interesting", "exciting", "good", "great", "cool", "fun", "epic", "crazy", "wild",
            "insane", "awesome", "amazing", "funny", "hilarious", "happened", "happen", "happens", "what", "were",
            "are", "is", "be", "it", "its", "his", "her", "their", "my", "our", "your", "and", "or", "to", "for",
            "make", "want", "you", "i", "please", "about", "on", "with", "whole", "entire"}


def is_open_request(search: str) -> bool:
    """True when the request names no subject, only how good the moments should be."""
    words = re.findall(r"[a-z']+", (search or "").lower())
    content = [w for w in words if w not in _GENERIC and not re.fullmatch(r"\w+(iest|est)", w)
               and w not in _NUM]
    return not content


def _apply_request(spec: TopicSpec, req: dict, llm: dict) -> None:
    """Fill the how-to-tell-it fields: the language model's reading when it gave one, the rule-based
    reading otherwise (a number written in the request always wins: it is unambiguous)."""
    try:
        n = int(llm.get("count") or 0)
    except (TypeError, ValueError):
        n = 0
    spec.count = req["count"] or (n if 1 <= n <= 10 else 0)
    f = str(llm.get("format") or "").lower()
    spec.format = req["format"] if req["format"] else (f if f in ("countdown", "list", "story") else "")
    if spec.count >= 2 and spec.format == "" and req["superlative"]:
        spec.format = "countdown"
    dl = str(llm.get("detail") or "").lower()
    spec.detail = req["detail"] or (dl if dl in ("detailed", "none") else "")
    spec.instructions = req["instructions"] or str(llm.get("instructions") or "")[:300]
    spec.search = str(llm.get("search") or "").strip() or req["search"]
    spec.superlative = req["superlative"]
    spec.open = is_open_request(req["search"])


# Groups that describe a QUALITY of a moment (funny, surprising) rather than its subject.
# When the topic also names a subject ("funny NPC interactions"), their reaction phrases are
# evidence of entertainment, not of the topic, so they must not make an off-subject clip look on-topic.
QUALITY_GROUPS = {"funny", "surprise"}


def _merge_lexicon(spec: TopicSpec) -> None:
    words = set(re.findall(r"[a-z]+", (spec.raw + " " + " ".join(spec.keywords)).lower()))
    matched = [(keys, entry) for keys, entry in LEXICON if words & set(keys)]
    has_subject = any(keys[0] not in QUALITY_GROUPS for keys, _ in matched)
    for keys, entry in matched:
        if has_subject and keys[0] in QUALITY_GROUPS:
            spec.entertainment_criteria = list(dict.fromkeys(
                spec.entertainment_criteria + [f'reactions like "{c}"' for c in entry["speech"][:4]]))[:10]
            spec.visual_positive += [v for v in entry["visual"] if v not in spec.visual_positive]
            continue
        if True:
            spec.visual_positive += [v for v in entry["visual"] if v not in spec.visual_positive]
            spec.visual_negative += [v for v in entry["neg"] if v not in spec.visual_negative]
            spec.speech_cues += [v for v in entry["speech"] if v not in spec.speech_cues]
            spec.keywords += [k for k in keys if k not in spec.keywords]
            spec.sounds += [x for x in LEXICON_SOUNDS.get(keys[0], []) if x not in spec.sounds]
    spec.sounds = spec.sounds[:5]
    spec.visual_positive = spec.visual_positive[:14]
    spec.visual_negative = spec.visual_negative[:8]
    spec.speech_cues = spec.speech_cues[:24]
    spec.keywords = spec.keywords[:24]


def _strs(v) -> list[str]:
    if isinstance(v, str):
        return [v]
    if not isinstance(v, list):
        return []
    return [str(x).strip() for x in v if str(x).strip()]
