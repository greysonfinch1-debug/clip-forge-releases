"""Pass 2 – precision: verify and grade each candidate with all available evidence.

For every proposed candidate an *evidence dossier* is built: the exact transcript with
timestamps (plus what was said just before and after), the visual concepts CLIP sees over
time, optional keyframe descriptions from a vision-language model, and audio facts. The
language model then grades topic match, entertainment value for a stranger, context
completeness and hook potential, may tighten or extend the cut, and must reject anything
whose evidence does not actually show the requested topic.
"""
from __future__ import annotations

import json
from typing import Callable, Optional

import numpy as np

from ..analysis.audio import AudioFeatures
from ..analysis.visual import VisualFeatures, concept_labels
from ..core.ffmpeg import extract_frames_at
from ..core.models import Candidate, Evidence, TopicSpec, Transcript, clamp
from ..providers.base import MalformedResponse, LLM, FrameCaptioner, ProviderUnavailable
from .proposals import HOUSEKEEPING, TopicTimeline, snap_to_words

VERSION = 27  # bump when proposal/judging logic changes (invalidates cached candidates)

GENERIC_CONCEPTS = ["a car driving on a road", "police cars with flashing lights", "a car crash", "an explosion",
                    "people walking on a sidewalk", "a character on foot", "a menu or map screen", "a loading screen",
                    "a shootout", "an aircraft", "a boat on water", "a building interior", "a dark night street",
                    "a streamer's webcam face"]


# ----------------------------------------------------------------------------- evidence

def build_evidence(c: Candidate, spec: TopicSpec, transcript: Transcript, audio: AudioFeatures,
                   visual: Optional[VisualFeatures], vision, proxy_path: str, keyframe_dir: str,
                   captioner: Optional[FrameCaptioner], use_captioner: bool, keyframes: int = 3,
                   sounds=None) -> Evidence:
    ev = Evidence()
    lines = []
    inside = transcript.sentences_between(c.start, c.end)
    multi = len({s.speaker for s in inside if s.speaker}) > 1
    for s in inside:
        who = f"{s.speaker}: " if multi and s.speaker else ""
        lines.append(f"[{s.start - c.start:+.1f}s] {who}{s.text}")
    ev.transcript = "\n".join(lines) or "(no speech)"
    before = transcript.sentences_between(max(0, c.start - 12), c.start - 0.01)
    ev.transcript_before = "\n".join(f"[{s.start - c.start:+.1f}s] {s.text}" for s in before[-3:]) or "(nothing)"
    after = transcript.sentences_between(c.end + 0.01, c.end + 8)
    ev.transcript_after = "\n".join(f"[+{s.start - c.end:.1f}s after end] {s.text}" for s in after[:2]) or "(nothing)"
    a = audio.summary(c.start, c.end)
    if sounds is not None and len(sounds.times):
        heard = sounds.summary(c.start, c.end)
        ev.audio_summary = (f"peak excitement {a['peak_excitement']:.2f} at {a.get('peak_time', c.start) - c.start:+.1f}s, "
                            f"silent {a['silence_fraction'] * 100:.0f}% of the time; sounds detected: "
                            + (", ".join(f"{g} {p:.2f}" for g, p in heard) if heard else "nothing notable"))
    else:
        ev.audio_summary = (f"peak excitement {a['peak_excitement']:.2f} at {a.get('peak_time', c.start) - c.start:+.1f}s, "
                            f"laughter-like audio {a['laughter']:.2f}, silent {a['silence_fraction'] * 100:.0f}% of the time")
    if visual is not None and vision is not None and visual.emb is not None:
        concepts = list(dict.fromkeys(spec.visual_positive + spec.visual_negative + GENERIC_CONCEPTS))
        ev.visual_labels = concept_labels(visual, vision, concepts, c.start, c.end, k=2)
    # keyframes: start of the action, the reaction peak, near the end
    peak = float(a.get("peak_time", (c.start + c.end) / 2))
    times = sorted({round(c.start + min(1.5, c.duration * 0.15), 2), round(min(max(peak, c.start + 0.5), c.end - 0.5), 2),
                    round(c.end - min(1.5, c.duration * 0.15), 2)})[:keyframes]
    ev.keyframe_times = times
    if use_captioner and captioner is not None:
        paths = extract_frames_at(proxy_path, times, keyframe_dir, height=360)
        if paths:
            try:
                desc = captioner.describe(paths, (
                    "These are frames from a gameplay livestream, in time order. In 2-3 short factual sentences, "
                    "describe what is visibly happening (vehicles, police, crashes, characters, location). "
                    f"Then say whether it shows: {spec.summary}. Do not guess beyond what is visible."))
                ev.frame_captions = [desc]
            except ProviderUnavailable:
                pass
    return ev


# ----------------------------------------------------------------------------- LLM judge

SYSTEM = """You are a senior short-form video editor selecting clips from a gameplay livestream for a YouTube Short.
You judge each candidate ONLY from its evidence (transcript, visual labels, frame descriptions, audio facts).
Hard rules:
- If the evidence does not clearly show the requested topic, give topic_match <= 3 and set reject=true. Loudness or excitement alone never proves the topic.
- Reject donation reading, menu/loading screens, and off-topic conversation.
- Never invent events, dialogue or details that are not in the evidence.
- "entertainment" means: would a stranger who has never seen this streamer enjoy it?
- A clip needs its setup (what is happening) and its payoff/reaction. If the setup is in the 'said before' text or the reaction is in the 'said after' text, extend the cut to include it.
Reply with JSON only."""

PROMPT = """Requested topic: {topic}
Topic details: {details}
What makes it entertaining: {criteria}
Must exclude: {exclude}

Candidates (times are seconds relative to the candidate's start):
{blocks}

Return JSON: {{"results": [ one object per candidate with keys:
 "id": candidate id,
 "topic_match": 0-10, "entertainment": 0-10, "context_completeness": 0-10, "hook_potential": 0-10,
 "confidence": 0.0-1.0,
 "description": one factual sentence (max 25 words) of what happens, using only the evidence,
 "why_matches": short reason it fits (or doesn't fit) the topic,
 "start_adjust": seconds to move the start (negative = earlier, max -10, positive = later),
 "end_adjust": seconds to move the end (positive = later, max +6, negative = earlier),
 "best_moment": seconds from start of the single most striking instant,
 "context_text": optional 3-7 word on-screen caption giving needed context, or "",
 "reject": true/false, "reject_reason": "" ]}}"""


def _block(c: Candidate) -> str:
    ev = c.evidence
    parts = [f"### id={c.cid}  duration={c.duration:.1f}s",
             f"Said before the clip:\n{ev.transcript_before}",
             f"Transcript in the clip:\n{ev.transcript}",
             f"Said right after:\n{ev.transcript_after}",
             f"Audio: {ev.audio_summary}"]
    if ev.visual_labels:
        parts.append("Visual concepts over time (CLIP, approximate):\n" + "\n".join(ev.visual_labels))
    if ev.frame_captions:
        parts.append("Frame descriptions:\n" + "\n".join(ev.frame_captions))
    return "\n".join(parts)


def judge_candidates(cands: list[Candidate], spec: TopicSpec, llm: LLM, transcript: Transcript,
                     visual: Optional[VisualFeatures], audio: AudioFeatures, tl: TopicTimeline,
                     batch_size: int = 4, progress: Optional[Callable[[float, str], None]] = None,
                     cancel=None) -> str:
    """Grades candidates in place. Returns the judge actually used ("llm" or "rules")."""
    used = "llm"
    llm_failed = False
    for i in range(0, len(cands), batch_size):
        if cancel and cancel():
            raise RuntimeError("Cancelled")
        batch = cands[i:i + batch_size]
        if not llm_failed:
            try:
                prompt = PROMPT.format(topic=spec.summary, details="; ".join(spec.sub_topics),
                                       criteria="; ".join(spec.entertainment_criteria), exclude="; ".join(spec.exclude),
                                       blocks="\n\n".join(_block(c) for c in batch))
                data = llm.complete_json(SYSTEM, prompt, max_tokens=450 * len(batch) + 200)
                results = data.get("results") or data.get("items") or []
                by_id = {str(r.get("id")): r for r in results if isinstance(r, dict)}
                for c in batch:
                    r = by_id.get(c.cid)
                    if r is None:
                        _rules_judge(c, spec, transcript, visual, audio, tl)
                        c.judged_by = "rules (model skipped this one)"
                    else:
                        _apply(c, r, transcript)
            except MalformedResponse:
                for c in batch:  # only this batch falls back; keep using the model for the rest
                    _rules_judge(c, spec, transcript, visual, audio, tl)
                    c.judged_by = "rules (model reply unusable)"
            except ProviderUnavailable:
                llm_failed = True
                used = "rules"
        if llm_failed:
            for c in batch:
                _rules_judge(c, spec, transcript, visual, audio, tl)
        for c in batch:
            if not (c.start <= c.best_moment <= c.end):  # model gave no key moment: strongest on-topic instant
                c.best_moment = _strongest_instant(c, tl, audio)
            _protect_key_moment(c, transcript, tl)
            _quality(c, visual, audio)
            c.final_score = final_score(c)
        if progress:
            progress(min(1.0, (i + len(batch)) / max(1, len(cands))), f"Judging candidates ({used})")
    return used


def _num(v, lo, hi, default=0.0) -> float:
    try:
        return float(clamp(float(v), lo, hi))
    except (TypeError, ValueError):
        return default


def _apply(c: Candidate, r: dict, transcript: Transcript) -> None:
    c.topic_match = _num(r.get("topic_match"), 0, 10)
    c.entertainment = _num(r.get("entertainment"), 0, 10)
    c.context_completeness = _num(r.get("context_completeness"), 0, 10, 5)
    c.hook_potential = _num(r.get("hook_potential"), 0, 10)
    c.confidence = _num(r.get("confidence"), 0, 1, 0.6)
    c.description = str(r.get("description") or "")[:240]
    c.why_matches = str(r.get("why_matches") or "")[:240]
    if bool(r.get("reject")):
        c.topic_match = min(c.topic_match, 2.0)
        c.why_matches = ("Rejected: " + str(r.get("reject_reason") or c.why_matches))[:240]
    sa = _num(r.get("start_adjust"), -10, 8, 0)
    ea = _num(r.get("end_adjust"), -8, 6, 0)
    new_s, new_e = max(0.0, c.start + sa), c.end + ea
    if new_e - new_s >= 3.0:
        c.start, c.end = snap_to_words(new_s, new_e, transcript)
    bm = r.get("best_moment")
    if bm is not None:
        c.best_moment = min(max(c.start + _num(bm, -12, c.duration + 8, 0), c.start), c.end)
    ctx = str(r.get("context_text") or "").strip()
    if ctx:
        c.reasons = [r_ for r_ in c.reasons if not r_.startswith("context:")] + [f"context:{ctx[:60]}"]
    c.judged_by = "llm"


def _rules_judge(c: Candidate, spec: TopicSpec, transcript: Transcript, visual, audio: AudioFeatures,
                 tl: TopicTimeline) -> None:
    sig = sorted([c.visual_relevance, c.speech_relevance, 0.8 * c.sound_relevance], reverse=True)
    rel, both = sig[0], sig[1]
    c.topic_match = round(10 * clamp(0.85 * rel + 0.3 * both), 1)
    summ = audio.summary(c.start, c.end)
    sents = transcript.sentences_between(c.start, c.end)
    text = " ".join(s.text for s in sents)
    exclaims = text.count("!") + sum(text.lower().count(k) for k in ("no way", "oh my god", "wait", "insane", "dying"))
    c.entertainment = round(10 * clamp(0.5 * c.excitement + 0.3 * summ["laughter"] + 0.08 * exclaims + 0.1), 1)
    if getattr(spec, "open", False):
        # "the coolest things": no subject to match, so how entertaining a moment is IS the match
        c.topic_match = max(c.topic_match, round(5.0 + 5.0 * clamp(c.entertainment / 10 + 0.3 * c.excitement), 1))
    starts_clean = not sents or sents[0].start >= c.start - 0.2
    ends_clean = not sents or sents[-1].end <= c.end + 0.2
    c.context_completeness = 8.0 if (starts_clean and ends_clean and c.duration >= 6) else 5.0
    c.hook_potential = round(10 * clamp(0.6 * c.excitement + 0.4 * rel), 1)
    c.confidence = 0.4
    c.best_moment = _strongest_instant(c, tl, audio)
    lead = max(sents, key=lambda s: tl.sentence_rel.get(s.idx, 0)).text if sents else ""
    c.description = (f'Streamer says: "{lead}"' if lead else "Gameplay moment without speech")[:240]
    c.why_matches = ", ".join(c.reasons)
    house = sum(1 for s in sents if HOUSEKEEPING.search(s.text))
    if sents and house >= max(1, len(sents) // 2):
        c.topic_match = min(c.topic_match, 2.0)
        c.why_matches = "Rejected: stream housekeeping (donations/subs/thanks), not the topic"
    c.judged_by = "rules"


SETUP_MIN, REACTION_MIN = 2.5, 2.5


def _strongest_instant(c: Candidate, tl, audio: AudioFeatures) -> float:
    """The key moment = where topic relevance AND entertainment peak together (the strongest
    on-topic instant), not simply the loudest point, which can fall on unrelated chatter."""
    score = getattr(tl, "score", None)
    if score is not None and len(score):
        a, b = int(c.start / 0.5), min(len(score), int(c.end / 0.5) + 1)
        if b > a:
            return float(min(max((a + int(np.argmax(score[a:b])) + 0.5) * 0.5, c.start), c.end))
    pk = audio.summary(c.start, c.end).get("peak_time", (c.start + c.end) / 2)
    return float(min(max(pk, c.start), c.end))


def _protect_key_moment(c: Candidate, transcript: Transcript, tl=None) -> None:
    """A key moment at the very edge of a clip has no setup (or no reaction): widen the cut so
    a viewer sees what leads up to it and how it lands — but never into unrelated talk."""
    start, end = c.start, c.end
    rel = getattr(tl, "sentence_rel", {}) if tl is not None else {}
    if c.best_moment - start < SETUP_MIN:
        start = max(0.0, c.best_moment - SETUP_MIN - 0.5)
        for s_ in transcript.sentences_between(start, c.start):
            if s_.end <= c.start + 0.1 and rel.get(s_.idx, 1.0) < 0.2:
                start = max(start, s_.end + 0.1)
    if end - c.best_moment < REACTION_MIN:
        end = c.best_moment + REACTION_MIN + 0.5
        for s_ in transcript.sentences_between(c.end, end):
            if s_.start >= c.end - 0.1 and rel.get(s_.idx, 1.0) < 0.2:
                end = min(end, s_.start - 0.1)
                break
    if (start, end) != (c.start, c.end):
        c.start, c.end = snap_to_words(start, end, transcript)


def _quality(c: Candidate, visual: Optional[VisualFeatures], audio: AudioFeatures) -> None:
    s = audio.summary(c.start, c.end)
    loud = s["loudness_db"]
    c.audio_quality = round(10 * clamp(1 - s["silence_fraction"] * 0.8) * clamp((loud + 60) / 35), 1)
    if visual is not None and len(visual.times):
        idx = visual.idx(c.start, c.end)
        if len(idx):
            sharp = float(np.mean(visual.sharp[idx]))
            bright = float(np.mean(visual.bright[idx]))
            dark_pen = 0.0 if bright > 0.12 else (0.12 - bright) * 6
            c.visual_quality = round(10 * clamp(0.4 + 0.6 * sharp - dark_pen), 1)
            return
    c.visual_quality = 6.0


def final_score(c: Candidate) -> float:
    """Topic match gates the score; entertainment drives ranking among on-topic clips."""
    if c.topic_match < 4.5:
        gate = 0.25
    elif c.topic_match < 6:
        gate = 0.7
    else:
        gate = 1.0
    base = (0.42 * c.topic_match + 0.33 * c.entertainment + 0.12 * c.context_completeness +
            0.07 * c.audio_quality + 0.06 * c.visual_quality) / 10.0
    conf = 0.75 + 0.25 * c.confidence
    return round(100 * base * gate * conf, 1)


def dossier_json(c: Candidate) -> str:
    return json.dumps(c.evidence.to_dict(), indent=1)
