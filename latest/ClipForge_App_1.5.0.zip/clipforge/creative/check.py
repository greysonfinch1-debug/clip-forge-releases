"""clipforge-cli creativecheck — narration-driven, hybrid and clip-driven videos on this PC, with its
real AI models (the part that can't be tested without them: the language model writing the script).

    clipforge-cli creativecheck "D:\\Videos\\my stream.mp4" --rights own
    clipforge-cli creativecheck "D:\\Videos\\stream.mp4" --rights permission --creator "Their channel"
                                [--library "D:\\Videos\\broll.mp4" ...] [--quick]

Works in a temporary data folder that is deleted afterwards: your projects, settings and models are
not touched. Report, scripts, footage choices and the exported videos:
%APPDATA%\\ClipForge\\checks\\creative_<date>\\ (report.md, results.json, *.mp4).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import tempfile
import time
from dataclasses import asdict
from pathlib import Path

# (name, prompt, seconds, export?)  — written to work with any recording
PROMPTS = [
    ("about the video", "Explain what happens in this stream and what makes it worth watching. Informative, use "
                        "the footage as background.", 35, True),
    ("general knowledge", "Make a short documentary-style video about the history of livestreaming. Use my footage "
                          "as b-roll.", 35, False),
    ("hybrid", "Open with the most exciting real moment, then explain why moments like this work so well on "
               "stream, and include the real reactions.", 45, True),
    ("tips, fast", "Fast-paced and entertaining: three tips for new streamers, footage in the background.", 30,
     False),
    ("clip-driven (as before)", "find the funniest moments", 40, False),
]
BANNED = re.compile(r"\b(as you can see|here we see|in this clip|in this video|let'?s dive in|like and subscribe)\b",
                    re.I)


def main(argv=None) -> int:
    from ..config import Settings, app_dir
    from .cli import run_spec
    from .narration import WORDS_PER_SECOND

    ap = argparse.ArgumentParser(prog="clipforge-cli creativecheck", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--rights", required=True, choices=["own", "permission", "licence"])
    ap.add_argument("--creator", default="")
    ap.add_argument("--library", nargs="*", default=[], help="more videos (same permission as --rights)")
    ap.add_argument("--quick", action="store_true", help="plans only, no exports")
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)
    video = Path(a.video).expanduser().resolve()
    if not video.is_file():
        print(f"File not found: {video}")
        return 2
    real = Settings.load()                      # read only: the models folder and AI choices
    base = asdict(real)
    base.update(first_run_done=True, check_updates=False, auto_install_updates=False)
    out = Path(a.out) if a.out else app_dir() / "checks" / time.strftime("creative_%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="cf_creative_"))
    base["output_dir"] = str(work / "exports")
    (work / "settings.json").write_text(json.dumps(base, indent=1), encoding="utf-8")
    old_home = os.environ.get("CLIPFORGE_HOME")
    os.environ["CLIPFORGE_HOME"] = str(work)
    rights = {"basis": a.rights, "creator": a.creator or "(not given)", "commercial_use": False}
    res = {"video": str(video), "llm": f"{real.llm.backend} / {real.llm.model}",
           "vision": f"{real.vision.backend} / {real.vision.clip_model}", "runs": [], "checks": []}
    print(f"ClipForge creative check → {out}\n(temporary data folder {work}; your projects are not touched)\n"
          "The first run analyses the video (speech, sound, pictures): that takes the longest.\n")

    def add(name, status, detail):
        res["checks"].append({"check": name, "result": status, "detail": detail})
        print(f"{status:5s} {name}: {detail}", flush=True)
        _report(out, res)

    try:
        from ..config import Settings as _S
        from ..services import Services

        if not Services(_S.load()).llm_available():
            print("NOTE: the AI language model isn't reachable (is Ollama running, with "
                  f"{real.llm.model} pulled?). The narrated prompts will fail; the clip-driven one still runs.\n")
        for k, (name, prompt, secs, export) in enumerate(PROMPTS):
            spec = {"name": f"creative check {k + 1}", "main": {"path": str(video), "rights": rights},
                    "library": [{"path": p, "role": "broll", "rights": rights} for p in a.library],
                    "prompt": prompt, "seconds": secs, "export": export and not a.quick,
                    "out": str(work / "exports")}
            t0 = time.time()
            print(f"--- {k + 1}/{len(PROMPTS)} {name}: {prompt}", flush=True)
            try:
                rep = run_spec(spec, quiet=True)
            except Exception as e:  # noqa: BLE001
                add(f"{name}: made a plan", "FAIL", f"{type(e).__name__}: {str(e)[:300]}")
                res["runs"].append({"name": name, "prompt": prompt, "error": str(e)[:1000]})
                continue
            rep["name"], rep["took_s"] = name, round(time.time() - t0, 1)
            if rep.get("export"):
                dst = out / f"{k + 1:02d}_{Path(rep['export']).name}"
                shutil.copy2(rep["export"], dst)
                rep["export"] = str(dst)
            res["runs"].append(rep)
            narrated = [s for s in rep["sections"] if s.get("kind") == "narration"]
            if rep["mode"] == "clip":
                add(f"{name}: clip-driven video", "PASS" if rep.get("clip_driven", {}).get("clips") else "FAIL",
                    f"{len(rep.get('clip_driven', {}).get('clips', []))} clips")
                continue
            add(f"{name}: language model wrote the narration", "PASS" if rep.get("script_by") == "llm" else "FAIL",
                f"written by: {rep.get('script_by')} (the language model must be running: start Ollama)")
            words = sum(len(s["text"].split()) for s in narrated)
            moment_s = sum((s["end"] - s["start"]) for s in rep["sections"] if s.get("kind") == "moment"
                           and s.get("end") is not None)
            want = max(1.0, (secs - moment_s) * WORDS_PER_SECOND)
            add(f"{name}: narration length fits", "PASS" if 0.6 * want <= words <= 1.4 * want else "WARN",
                f"{words} words for about {want:.0f}")
            bad = [s["text"] for s in narrated if BANNED.search(s["text"])]
            add(f"{name}: no filler or 'as you can see'", "PASS" if not bad else "FAIL", "; ".join(bad)[:200] or "ok")
            empty = [i + 1 for i, s in enumerate(rep["sections"]) if s.get("kind") == "narration" and not s["shots"]]
            add(f"{name}: every part has footage", "PASS" if not empty else "FAIL", f"parts without: {empty}" if empty
                else f"{sum(len(s['shots']) for s in narrated)} shots")
            marked = [i + 1 for i, s in enumerate(rep["sections"]) if s.get("claims")]
            add(f"{name}: facts marked", "INFO", f"parts marked: {marked or 'none'}; {rep.get('sources_note', '')}"[:300])
            if rep["mode"] == "hybrid":
                add(f"{name}: real moments included", "PASS" if any(s.get("kind") == "moment"
                                                                   for s in rep["sections"]) else "FAIL", "")
            if "qc_passed" in rep:
                add(f"{name}: export quality checks", "PASS" if rep["qc_passed"] else "FAIL",
                    "; ".join(f"{n}: {d}" for n, d in rep.get("qc_failed", []))[:300] or "all passed")
    finally:
        if old_home is None:
            os.environ.pop("CLIPFORGE_HOME", None)
        else:
            os.environ["CLIPFORGE_HOME"] = old_home
        _report(out, res)
        shutil.rmtree(work, ignore_errors=True)
    print(f"\nReport: {out / 'report.md'}")
    return 0 if not any(c["result"] == "FAIL" for c in res["checks"]) else 1


def _report(out: Path, res: dict) -> None:
    (out / "results.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    lines = ["# ClipForge creative check", "", f"Video: {res['video']}  ", f"Language model: {res['llm']}  ",
             f"Picture model: {res['vision']}", "", "| Result | Check | Detail |", "|---|---|---|"]
    lines += [f"| {c['result']} | {c['check']} | {c['detail']} |" for c in res["checks"]]
    for r in res["runs"]:
        lines += ["", f"## {r.get('name')}: {r.get('prompt')}", ""]
        if r.get("error"):
            lines.append(f"Error: {r['error']}")
            continue
        lines.append(f"Type {r.get('mode')} ({r.get('mode_reason')}), style {r.get('style')}, pacing {r.get('pacing')}, "
                     f"script by {r.get('script_by')}, took {r.get('took_s')} s" + (f", export {r['export']}"
                                                                                    if r.get("export") else ""))
        for i, s in enumerate(r.get("sections", [])):
            if s.get("kind") == "moment":
                lines.append(f"{i + 1}. **real moment** {s.get('start')}–{s.get('end')} s")
                continue
            lines.append(f"{i + 1}. *{s.get('role')}* {s.get('text')}" + (f" _({s['claims']})_" if s.get("claims") else ""))
            for sh in s.get("shots", []):
                lines.append(f"   - {sh.get('title', '')[:30]} {sh.get('start', 0):.1f}–{sh.get('end', 0):.1f} s: {sh.get('why')}")
    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
