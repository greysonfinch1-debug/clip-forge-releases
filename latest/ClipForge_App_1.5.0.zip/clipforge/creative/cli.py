"""clipforge-cli create — make any kind of video from a prompt, from the command line.

    clipforge-cli create --spec video.json
    clipforge-cli create --file main.mp4 --rights own --prompt "Explain why..." [--library extra.mp4 ...]
                         [--mode auto|clip|narration|hybrid] [--script my_script.txt] [--seconds 45]

A spec file (JSON) can say everything, including the permission for each video:
    {"main": {"path": "D:/stream.mp4", "rights": {"basis": "own", "creator": "me"}},
     "library": [{"path": "D:/broll.mp4", "role": "broll",
                  "rights": {"basis": "licence", "creator": "Blender Foundation (CC BY 3.0)"}}],
     "prompt": "...", "mode": "auto", "style": "", "pacing": "", "seconds": 45,
     "script": "optional: your own narration", "use_my_script": false,
     "notes": "optional facts", "source_urls": [], "out": "D:/exports", "name": "my video",
     "voice": "optional voice name (e.g. af_heart)",
     "expand": false}      (true: AI prompt expansion first; "required": stop if it isn't possible)
Prints the plan (sections, footage picked and why) and the quality checks; with "report" in the
spec, writes them as JSON too.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path


def _rights(d: dict):
    from ..core.models import RightsRecord

    basis = {"permission": "written_permission", "license": "licence"}.get(d.get("basis", ""), d.get("basis", ""))
    return RightsRecord(basis=basis, creator=d.get("creator", ""), commercial_use=bool(d.get("commercial_use", False)),
                        game_publisher_ok=bool(d.get("game_publisher_ok", False)), notes=d.get("notes", ""),
                        confirmed=bool(basis))


def run_spec(spec: dict, quiet: bool = False) -> dict:
    from ..config import Settings
    from ..pipeline import Pipeline
    from . import workflow

    say = (lambda *a: None) if quiet else print
    st = Settings.load()
    if spec.get("voice"):
        st.voice.voice = str(spec["voice"])
    p = Pipeline(st)
    t0 = time.time()
    last = {"msg": ""}

    def progress(stage, frac, msg):
        if msg != last["msg"] and not quiet:
            last["msg"] = msg
            print(f"  [{time.time() - t0:5.0f}s] {stage:<9} {msg[:80]}", flush=True)
    if spec.get("name"):
        p.new_project(spec["name"])
    main = spec.get("main") or {}
    p.ingest(path=main.get("path", ""), url=main.get("url", ""), progress=progress)
    r = _rights(main.get("rights") or {})
    if r.confirmed:
        p.project.source.rights = r
        p.save_rights()
    for item in spec.get("library") or []:
        workflow.add_library_video(p, path=item.get("path", ""), url=item.get("url", ""), role=item.get("role", "broll"),
                                   rights=_rights(item.get("rights") or {}), progress=progress)
    production, exp = None, {}
    if spec.get("expand"):        # AI prompt expansion first (as the window does), auto-approved
        from . import expand as ex

        t1 = time.time()
        try:
            production = p.expand_prompt(spec["prompt"], float(spec.get("seconds", 45)), spec.get("mode", "auto"),
                                         spec.get("style", ""), spec.get("script", "") if spec.get("use_my_script")
                                         else "", spec.get("notes", ""), progress=progress)
            production.approved = True
            exp = {"status": production.status, "seconds": round(time.time() - t1, 1), "text": production.text}
            say("\nProduction brief:\n" + production.text + "\n")
        except ex.ExpansionUnavailable as e:
            if spec.get("expand") == "required":
                raise
            production = ex.not_expanded(spec["prompt"], f"could not be expanded: {e}")
            exp = {"status": "not_expanded", "reason": str(e)}
            say(f"\nPrompt not expanded: {e}\n")
    res = p.create(spec["prompt"], float(spec.get("seconds", 45)), spec.get("mode", "auto"), spec.get("style", ""),
                   spec.get("pacing", ""), spec.get("script", ""), spec.get("notes", ""), spec.get("source_urls"),
                   bool(spec.get("use_my_script", False)), int(spec.get("clips", 0)), progress, production=production)
    if isinstance(res, list):          # clip-driven: pick clips, story, hooks and script as the window does
        p.select(progress)
    plan = p.project.plan
    rep = {"prompt": spec["prompt"], "mode": plan.brief.mode, "mode_reason": plan.brief.mode_reason,
           "style": plan.brief.style, "pacing": plan.brief.pacing, "script_by": p.used.get("script"),
           "visual_match": p.used.get("visual_match"), "title": plan.title, "sections": [],
           "match_notes": p.project.meta.get("match_notes") or [], "sources_note": plan.sources_note,
           "original_prompt": plan.original_prompt, "expansion": exp, "plan_seconds": round(time.time() - t0, 1)}
    say(f"\nType: {plan.brief.mode} ({plan.brief.mode_reason}) · style {plan.brief.style or '-'} · pacing "
        f"{plan.brief.pacing} · script by {p.used.get('script')} · footage matched with {p.used.get('visual_match')}")
    for n in rep["match_notes"]:
        say(f"Note: {n}")
    titles = {it.source_id: it.title for it in p.project.library}
    if p.project.source:
        titles[p.project.source.source_id] = p.project.source.title
    for i, s in enumerate(plan.sections):
        if s.kind == "moment":
            c = next((c for c in p.project.candidates if c.cid == s.cid), None)
            line = f"{i + 1}. [real moment] {c.start:.1f}-{c.end:.1f}s: {c.description[:70]}" if c else f"{i + 1}. [moment]"
            say(line)
            rep["sections"].append({"kind": "moment", "cid": s.cid, "start": c.start if c else None,
                                    "end": c.end if c else None})
            continue
        say(f"{i + 1}. [{s.role}] {s.text}")
        say(f"     show: {'; '.join(s.visuals)}" + (f"   ({s.claims})" if s.claims else ""))
        for sh in s.shots:
            say(f"     → {titles.get(sh.source_id, sh.source_id)[:28]} {sh.start:6.1f}-{sh.end:6.1f}s  {sh.why}")
        rep["sections"].append({"kind": "narration", "role": s.role, "text": s.text, "visuals": s.visuals,
                                "claims": s.claims, "shots": [sh.to_dict() | {"title": titles.get(sh.source_id, "")}
                                                              for sh in s.shots]})
    if isinstance(res, list):
        rep["clip_driven"] = {"clips": [(it.start, it.end) for it in plan.story],
                              "narration": [ln.text for ln in plan.narration], "script_by": p.used.get("script")}
        say("\nClip-driven: " + ", ".join(f"{it.start:.1f}-{it.end:.1f}s" for it in plan.story))
        for ln in plan.narration:
            say(f"  narration: {ln.text}")
    if spec.get("export", True):
        out = spec.get("out") or ""
        (path, qc), = p.export(out_dir=out, progress=progress)
        rep["export"] = str(path)
        rep["qc_passed"] = qc.passed
        rep["qc_failed"] = [(c.name, c.detail) for c in qc.checks if not c.ok]
        rep["duration"] = p.edit_timeline.duration if p.edit_timeline else None
        tl = p.edit_timeline
        if tl is not None:
            rep["timeline"] = [{"kind": g.kind, "part": g.item_index, "out_start": round(g.out_start, 2),
                                "out_end": round(g.out_end, 2), "source_start": round(g.source_start, 2),
                                "unit": g.unit, "layout": g.layout, "gain_db": g.gain_db} for g in tl.segments]
            rep["narration"] = [{"part": pl.line.item_index, "start": round(pl.out_start, 2),
                                 "duration": round(pl.line.duration, 2), "text": pl.line.text} for pl in tl.narration]
            rep["captions"] = len(plan.captions)
        say(f"\nExported {path}\nQC: {'passed' if qc.passed else 'FAILED'}"
            + "".join(f"\n  {'FAIL' if c.severity == 'error' else 'WARN'} {c.name}: {c.detail}" for c in qc.checks
                      if not c.ok))
    rep["seconds"] = round(time.time() - t0, 1)
    if spec.get("report"):
        Path(spec["report"]).write_text(json.dumps(rep, indent=1, default=str), encoding="utf-8")
    return rep


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="clipforge-cli create", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--spec", help="JSON spec file (see above)")
    ap.add_argument("--file", help="main video file")
    ap.add_argument("--url", help="main video link (public, with permission)")
    ap.add_argument("--rights", choices=["own", "permission", "licence"])
    ap.add_argument("--creator", default="")
    ap.add_argument("--library", nargs="*", default=[], help="more video files (same permission as --rights)")
    ap.add_argument("--role", default="broll", choices=["main", "broll", "reaction", "atmosphere"])
    ap.add_argument("--prompt")
    ap.add_argument("--mode", default="auto", choices=["auto", "clip", "narration", "hybrid"])
    ap.add_argument("--style", default="")
    ap.add_argument("--pacing", default="", choices=["", "slow", "normal", "fast"])
    ap.add_argument("--script", help="text file with your own narration")
    ap.add_argument("--notes", help="text file with facts / notes the narration may use")
    ap.add_argument("--source-url", nargs="*", default=[])
    ap.add_argument("--seconds", type=float, default=45)
    ap.add_argument("--out", default="")
    ap.add_argument("--no-export", action="store_true")
    ap.add_argument("--expand", action="store_true",
                    help="expand the prompt into a production brief with the language model first (used as written)")
    a = ap.parse_args(argv)
    if a.spec:
        spec = json.loads(Path(a.spec).read_text(encoding="utf-8"))
    else:
        if not a.prompt or not (a.file or a.url):
            ap.error("give --spec, or --file/--url and --prompt")
        rights = {"basis": a.rights or "", "creator": a.creator}
        spec = {"main": {"path": a.file or "", "url": a.url or "", "rights": rights},
                "library": [{"path": f, "role": a.role, "rights": rights} for f in a.library],
                "prompt": a.prompt, "mode": a.mode, "style": a.style, "pacing": a.pacing, "seconds": a.seconds,
                "script": Path(a.script).read_text(encoding="utf-8") if a.script else "",
                "use_my_script": bool(a.script), "notes": Path(a.notes).read_text(encoding="utf-8") if a.notes else "",
                "source_urls": a.source_url, "out": a.out, "export": not a.no_export, "expand": a.expand}
    rep = run_spec(spec)
    return 0 if rep.get("qc_passed", True) else 1
