"""The footage library: every video a narration-driven or hybrid Short may draw pictures from.

The project's main video is always in it; the user can add more (local files, links, or videos
already analysed in other projects) and say what each is for: main story footage, supporting
background footage (b-roll), reaction footage or general atmosphere. Each video is analysed once
and cached exactly like the main video (speech, loudness, a CLIP picture embedding per second),
so adding a video to a second project costs nothing.

``FootageIndex`` turns the library into per-second arrays the matcher scores: CLIP embeddings,
movement, brightness, whether someone is talking, scene changes, and which source/role each
second belongs to. A video only joins the index when its permission to use is recorded.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from ..core.cache import SourceCache
from ..core.models import LibraryItem, RightsRecord, Transcript, VideoSource

ROLES = {"main": "Main story footage", "broll": "Supporting background footage (b-roll)",
         "reaction": "Reaction footage", "atmosphere": "General atmosphere footage"}
SCENE_CUT = 0.85          # per-second scene-change strength treated as a cut between shots


@dataclass
class SourceFootage:
    """One analysed video in the library."""
    src: VideoSource
    role: str
    transcript: Optional[Transcript]
    audio: object                     # AudioFeatures
    visual: object                    # VisualFeatures
    rights_ok: bool = True
    rights_problems: list[str] = field(default_factory=list)

    @property
    def source_id(self) -> str:
        return self.src.source_id


@dataclass
class FootageIndex:
    """Per-second features of every usable library video, concatenated."""
    sources: dict[str, SourceFootage]
    src_of: np.ndarray            # (n,) index into source_ids
    source_ids: list[str]
    t: np.ndarray                 # (n,) time inside its source (s)
    emb: Optional[np.ndarray]     # (n, d) unit CLIP embeddings, or None without a vision model
    motion: np.ndarray
    bright: np.ndarray
    speech: np.ndarray            # 1 where someone is talking
    cut_after: np.ndarray         # 1 where a scene change follows this second
    role: np.ndarray              # (n,) role name per second
    vision_model: str = ""
    height: Optional[np.ndarray] = None   # (n,) picture height of the source (0 = unknown)

    def __len__(self) -> int:
        return len(self.t)

    def frames_of(self, source_id: str) -> np.ndarray:
        return np.where(self.src_of == self.source_ids.index(source_id))[0]


def analyse_source(src: VideoSource, services, settings, progress: Optional[Callable] = None,
                   cancel: Optional[Callable] = None) -> SourceFootage:
    """Speech, loudness and pictures of one library video (cached per video; reused everywhere)."""
    from ..analysis.audio import analyze_audio
    from ..analysis.transcript import get_transcript
    from ..analysis.visual import analyze_visual

    cache = SourceCache(src.source_id)
    pr = (lambda st: (lambda f, m: progress(st, f, m))) if progress else (lambda st: None)
    transcript = get_transcript(src.audio_path, cache, lambda: services.transcriber(pr("models")), pr("transcript"),
                                cancel)
    audio = analyze_audio(src.audio_path, cache, pr("audio"), cancel)
    visual = analyze_visual(src.proxy_path, cache, settings.vision.sample_every_seconds, services.vision(),
                            settings.vision.analysis_height, pr("visual"), cancel)
    rights = src.rights if src.rights else RightsRecord()
    cached = cache.load_json("rights.json")
    if cached and not (rights and rights.confirmed):
        rights = RightsRecord.from_dict(cached)
    probs = rights.problems(False)
    return SourceFootage(src=src, role="main", transcript=transcript, audio=audio, visual=visual,
                         rights_ok=not probs, rights_problems=probs)


def build_index(footage: list[SourceFootage]) -> FootageIndex:
    """Concatenate the usable videos' per-second features (videos without recorded permission are
    left out: their pictures are never offered)."""
    usable = [f for f in footage if f.rights_ok and f.visual is not None and len(f.visual.times)]
    ids, src_of, ts, embs, mot, bri, sp, cut, role, hs = [], [], [], [], [], [], [], [], [], []
    model = ""
    have_emb = all(f.visual.emb is not None for f in usable) and bool(usable)
    if have_emb and len({f.visual.emb_model for f in usable}) > 1:
        have_emb = False          # different picture models can't be compared
    for k, f in enumerate(usable):
        v = f.visual
        n = len(v.times)
        ids.append(f.source_id)
        src_of.append(np.full(n, k))
        ts.append(np.asarray(v.times, np.float32))
        mot.append(np.asarray(v.motion, np.float32))
        bri.append(np.asarray(v.bright, np.float32))
        s = np.zeros(n, np.float32)
        if f.transcript is not None:
            for sen in f.transcript.sentences:
                for w in sen.words or []:
                    a, b = np.searchsorted(v.times, w.start - 0.25), np.searchsorted(v.times, w.end + 0.25)
                    s[a:b] = 1.0
        sp.append(s)
        sc = np.asarray(v.scene, np.float32)
        c = np.zeros(n, np.float32)
        c[:-1] = (sc[1:] >= SCENE_CUT).astype(np.float32)
        c[-1] = 1.0                                  # a source's end is a boundary too
        cut.append(c)
        role.append(np.array([f.role] * n))
        hs.append(np.full(n, float(f.src.height or 0), np.float32))
        if have_emb:
            e = np.asarray(v.emb, np.float32)
            embs.append(e / (np.linalg.norm(e, axis=1, keepdims=True) + 1e-9))
            model = v.emb_model
    cat = lambda xs, dt=np.float32: np.concatenate(xs).astype(dt) if xs else np.zeros(0, dt)
    return FootageIndex(sources={f.source_id: f for f in usable}, src_of=cat(src_of, np.int32), source_ids=ids,
                        t=cat(ts), emb=np.concatenate(embs) if have_emb else None, motion=cat(mot), bright=cat(bri),
                        speech=cat(sp), cut_after=cat(cut), role=np.concatenate(role) if role else np.zeros(0, str),
                        vision_model=model, height=cat(hs))


# what the library shows, in words the script writer can use (and the user can read)
VOCAB = ["driving a car on a city street", "a car chase with police cars", "a city skyline", "tall buildings",
         "pedestrians walking on a sidewalk", "busy traffic", "a highway", "the countryside", "a beach or the ocean",
         "a sunset", "night time city lights", "rain or stormy weather", "an explosion or fire", "a shootout",
         "a helicopter or plane in the air", "a boat on the water", "a character close-up", "people talking",
         "the inside of a building", "a shop or store", "a menu or loading screen", "a map", "a webcam of a person",
         "a motorcycle", "a crash", "mountains", "a forest", "an airport", "a gas station", "a crowd of people"]


def describe_library(index: FootageIndex, vision, top: int = 8) -> dict[str, list[str]]:
    """For each video: the things most often on screen (for the script writer's footage summary)."""
    if index.emb is None or vision is None or not len(index):
        return {}
    txt = vision.encode_texts([f"a screenshot of {v}" for v in VOCAB])
    txt = txt / (np.linalg.norm(txt, axis=1, keepdims=True) + 1e-9)
    sims = index.emb @ txt.T                                   # (n, vocab)
    z = (sims - sims.mean(axis=0)) / (sims.std(axis=0) + 1e-6)
    out: dict[str, list[str]] = {}
    for k, sid in enumerate(index.source_ids):
        rows = z[index.src_of == k]
        if not len(rows):
            continue
        share = (rows.argmax(axis=1)[:, None] == np.arange(len(VOCAB))[None, :]).mean(axis=0)
        strength = np.clip(rows, 0, None).mean(axis=0)
        order = np.argsort(-(share + 0.3 * strength))
        out[sid] = [VOCAB[i] for i in order[:top] if share[i] > 0.01]
    return out


def library_items_from_sources(srcs: list[tuple[VideoSource, str]]) -> list[LibraryItem]:
    return [LibraryItem(source_id=s.source_id, path=s.path or "", url=s.url or "", title=s.title or "",
                        role=role, duration=s.duration) for s, role in srcs]
