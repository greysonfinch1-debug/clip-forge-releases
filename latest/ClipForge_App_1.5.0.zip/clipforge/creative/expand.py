"""AI prompt expansion: the user's prompt → a detailed production brief.

The prompt the user typed is never changed. The language model reads it (with what ClipForge knows
about the video and the footage) and writes a production brief beside it: intent, subject, purpose,
audience, the kind of video, structure (hook, parts with talking points and what to show, ending),
footage needs, editing, narration and caption pacing, and which facts are known, which must be
checked and which choices are its own assumptions.

The brief then steers every stage (``workflow.create_plan`` and ``Pipeline.create``): the video
type, style and pacing; the script writer (structure, hook, points, ending); the footage matcher
(subject and the footage named); editing (shot length, transitions), the voice speed and caption
chunking; and, for clip-driven videos, the moment search and the script.

Without a language model there is no expansion. That is reported plainly (``ExpansionUnavailable``)
and the user decides whether to continue with the original prompt; nothing is paraphrased by rules
and presented as an expansion.
"""
from __future__ import annotations

import json
import re
import time
from typing import Callable, Optional

from ..cancel import Cancelled
from ..core.models import ProductionBrief
from ..providers.base import LLM, ProviderUnavailable

VERSION = 1
MODES = ("clip", "narration", "hybrid")
STYLES = ("informative", "documentary", "educational", "entertaining", "dramatic", "conversational",
          "storytelling", "commentary", "news")


class ExpansionUnavailable(RuntimeError):
    """The prompt can't be expanded (no language model, or it didn't answer usefully)."""


SYSTEM = """You are the producer of a YouTube Shorts channel. A creator gives you a short request; you turn it into a complete production brief that an editor and a scriptwriter could follow without asking anything.

Rules:
- Stay faithful to the request: same subject, same intent. Never add unrelated topics.
- Make sensible creative decisions where the request is silent (structure, hook, tone, pacing, what to show) and list them as assumptions.
- FACTS: never state facts you are not sure of. Facts the request or the supplied material states go in "facts_known". Anything else a video on this subject would need to say goes in "facts_to_check" (phrased as something to verify, e.g. "the release date — check an official source"). For unreleased or future things (unreleased games, rumours, upcoming events) everything is speculation unless the sources say otherwise.
- The footage illustrates; it never proves anything. Describe footage needs as things visible on screen.
- Choose the kind of video: "clip" = built from moments found in the creator's own footage (highlights, funniest/craziest moments, reactions, compilations, countdowns of moments); "narration" = a narrator explains/tells/informs and footage is chosen to go with it (explainers, facts, history, news, reviews, tips, stories, poems); "hybrid" = real moments with their original sound AND narrated parts.
- Ask a question only when an answer would really change the video and you cannot reasonably decide yourself.
Reply with JSON only."""

PROMPT = """Creator's request (exact words): "{prompt}"

What ClipForge knows:
{context}

Return JSON:
{{"intent": "what the creator actually wants, one sentence",
  "subject": "the subject in a few words",
  "purpose": "what the viewer should come away with",
  "audience": "who it is for",
  "mode": "clip|narration|hybrid", "mode_reason": "why, briefly",
  "style": one of {styles},
  "tone": "a few words",
  "pacing": "slow|normal|fast",
  "length_seconds": number (15-90; follow the request or the creator's setting),
  "points": number of talking points or moments the request asks for (0 if none),
  "hook": "the opening line or moment that stops the scroll",
  "parts": [{{"title": "short name", "purpose": "what this part does",
             "points": ["what is said or shown, concretely"],
             "visuals": ["2-3 things visible on screen during this part"]}}],
  "ending": "how it ends",
  "footage": "what the footage should show overall",
  "footage_kind": "a kind of footage the request names (e.g. gameplay, cartoon) or empty",
  "footage_avoid": "what not to show, or empty",
  "editing": "cut rhythm, transitions, text on screen",
  "transitions": "quick|none",
  "narration": "voice style and pace (or 'none' if the request wants no narration)",
  "voice_speed": number between 0.9 and 1.15 (1.0 = normal),
  "captions": "caption style and chunking",
  "music": "music the request asks for, 'none', or empty",
  "facts_known": ["..."], "facts_to_check": ["..."], "assumptions": ["..."], "questions": ["..."]}}
Use 3-6 parts for narrated videos and one part per moment for clip-driven ones."""


def context_text(title: str = "", duration: float = 0.0, transcript_sample: str = "", library: str = "",
                 target_seconds: float = 0.0, forced_mode: str = "", forced_style: str = "", notes: str = "",
                 has_script: bool = False) -> str:
    lines = []
    if title:
        lines.append(f"- The creator's video: \"{title}\" ({duration / 60:.0f} min)" if duration else
                     f"- The creator's video: \"{title}\"")
    if transcript_sample:
        lines.append(f"- Some of what is said in it: {transcript_sample[:700]}")
    if library:
        lines.append(f"- Footage available (most common things on screen): {library[:400]}")
    if target_seconds:
        lines.append(f"- Length chosen in the app: about {target_seconds:.0f} seconds")
    if forced_mode and forced_mode != "auto":
        lines.append(f"- The creator chose the video type: {forced_mode} (use it)")
    if forced_style:
        lines.append(f"- The creator chose the style: {forced_style} (use it)")
    if has_script:
        lines.append("- The creator supplied their own narration script (it will be used word for word)")
    if notes:
        lines.append(f"- Facts / sources the creator supplied:\n{notes[:2000]}")
    return "\n".join(lines) or "- nothing beyond the request"


def expand(prompt: str, llm: LLM, context: str = "", on_text: Optional[Callable[[str], None]] = None,
           model_name: str = "") -> ProductionBrief:
    """Ask the language model for the production brief. ``prompt`` is used exactly as given and
    copied unchanged into ``original_prompt``. Raises ExpansionUnavailable without a model."""
    t0 = time.time()
    old = getattr(llm, "on_text", None)
    try:
        if on_text is not None:
            llm.on_text = on_text
        d = llm.complete_json(SYSTEM, PROMPT.format(prompt=prompt, context=context or "- nothing beyond the request",
                                                    styles=list(STYLES)), max_tokens=1800)
    except ProviderUnavailable as e:
        raise ExpansionUnavailable(str(e)) from e
    except Cancelled:
        raise
    except Exception as e:  # noqa: BLE001  (malformed answers after retries)
        if "Cancelled" in str(e):
            raise
        raise ExpansionUnavailable(f"The language model didn't return a usable brief ({e})") from e
    finally:
        try:
            llm.on_text = old
        except Exception:  # noqa: BLE001
            pass
    b = from_dict(d, prompt)
    if not (b.subject or b.intent) or not b.parts:
        raise ExpansionUnavailable("The language model's brief was empty or incomplete")
    b.status, b.model, b.seconds = "expanded", model_name, round(time.time() - t0, 1)
    b.text = render(b)
    return b


def not_expanded(prompt: str, reason: str) -> ProductionBrief:
    """The record kept when no expansion happened (shown as such, never as an expansion)."""
    return ProductionBrief(original_prompt=prompt, status="not_expanded", reason=reason)


# ------------------------------------------------------------------ reading the model's answer
def _s(v, n: int = 400) -> str:
    return " ".join(str(v or "").split())[:n]


def _list(v, n: int = 12) -> list[str]:
    if isinstance(v, str):
        v = [x for x in re.split(r"\s*;\s*|\n+", v) if x.strip()]
    return [_s(x, 300) for x in (v if isinstance(v, (list, tuple)) else []) if _s(x)][:n]


def _num(v, lo: float, hi: float, default: float = 0.0) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    return min(hi, max(lo, x))


def from_dict(d: dict, prompt: str) -> ProductionBrief:
    if not isinstance(d, dict):
        d = {}
    parts = []
    for p in d.get("parts") or []:
        if isinstance(p, dict):
            parts.append({"title": _s(p.get("title"), 80), "purpose": _s(p.get("purpose"), 200),
                          "points": _list(p.get("points"), 6), "visuals": _list(p.get("visuals"), 4)})
        elif isinstance(p, str) and p.strip():
            parts.append({"title": _s(p, 80), "purpose": "", "points": [], "visuals": []})
    mode = str(d.get("mode") or "").lower().strip()
    style = str(d.get("style") or "").lower().strip().replace("news-style", "news")
    pacing = str(d.get("pacing") or "").lower().strip()
    trans = str(d.get("transitions") or "").lower().strip()
    return ProductionBrief(
        original_prompt=prompt, intent=_s(d.get("intent")), subject=_s(d.get("subject"), 160),
        purpose=_s(d.get("purpose")), audience=_s(d.get("audience"), 200),
        mode=mode if mode in MODES else "", mode_reason=_s(d.get("mode_reason"), 200),
        style=style if style in STYLES else "", tone=_s(d.get("tone"), 80),
        pacing=pacing if pacing in ("slow", "normal", "fast") else "",
        length_seconds=_num(d.get("length_seconds"), 10, 180, 0.0), points=int(_num(d.get("points"), 0, 10, 0)),
        hook=_s(d.get("hook"), 300), parts=parts[:8], ending=_s(d.get("ending"), 300),
        footage=_s(d.get("footage"), 300), footage_kind=_s(d.get("footage_kind"), 40).lower(),
        footage_avoid=_s(d.get("footage_avoid"), 200), editing=_s(d.get("editing"), 300),
        transitions=trans if trans in ("quick", "none") else "", narration=_s(d.get("narration"), 200),
        voice_speed=_num(d.get("voice_speed"), 0.9, 1.15, 0.0), captions=_s(d.get("captions"), 200),
        music=_s(d.get("music"), 60), facts_known=_list(d.get("facts_known")),
        facts_to_check=_list(d.get("facts_to_check")), assumptions=_list(d.get("assumptions")),
        questions=_list(d.get("questions"), 5))


# ------------------------------------------------------------------ the brief as text (shown and editable)
LABELS = [("intent", "Intent"), ("subject", "Subject"), ("purpose", "Purpose"), ("audience", "Audience"),
          ("mode", "Video type"), ("style", "Style"), ("tone", "Tone"), ("pacing", "Pacing"),
          ("length_seconds", "Length (seconds)"), ("hook", "Hook"), ("ending", "Ending"),
          ("footage", "Footage"), ("footage_kind", "Footage to use"), ("footage_avoid", "Avoid showing"),
          ("editing", "Editing"), ("transitions", "Transitions"), ("narration", "Narration"),
          ("voice_speed", "Voice speed"), ("captions", "Captions"), ("music", "Music")]
LISTS = [("facts_known", "Facts stated in the request or sources"), ("facts_to_check", "Facts to check before stating"),
         ("assumptions", "Creative decisions made"), ("questions", "Open questions")]


def render(b: ProductionBrief) -> str:
    out = []
    for key, lab in LABELS:
        v = getattr(b, key)
        if key == "mode" and v:
            v = {"clip": "clip-driven", "narration": "narration-driven", "hybrid": "hybrid"}.get(v, v)
            if b.mode_reason:
                v += f" ({b.mode_reason})"
        if isinstance(v, float):
            v = "" if not v else (f"{v:.0f}" if key == "length_seconds" else f"{v:.2f}")
        if v not in ("", None):
            out.append(f"{lab}: {v}")
    if b.parts:
        out.append("Structure:")
        for k, p in enumerate(b.parts, 1):
            out.append(f"  Part {k}: {p.get('title') or ''}" + (f" — {p['purpose']}" if p.get("purpose") else ""))
            for pt in p.get("points") or []:
                out.append(f"    - {pt}")
            if p.get("visuals"):
                out.append(f"    Show: {'; '.join(p['visuals'])}")
    for key, lab in LISTS:
        items = getattr(b, key)
        if items:
            out.append(f"{lab}:")
            out += [f"  - {x}" for x in items]
    return "\n".join(out)


_LAB = {lab.lower(): key for key, lab in LABELS}
_LISTLAB = {lab.lower(): key for key, lab in LISTS}


def parse_edited(text: str, base: ProductionBrief) -> ProductionBrief:
    """The user's edit of the brief text back into the brief (fields they removed are cleared;
    the original prompt is never touched)."""
    b = ProductionBrief.from_dict(base.to_dict())
    for key, _ in LABELS:
        setattr(b, key, 0.0 if isinstance(getattr(b, key), float) else "")
    for key, _ in LISTS:
        setattr(b, key, [])
    b.mode_reason = ""
    parts: list[dict] = []
    cur_list: Optional[str] = None
    in_structure = False
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        m = re.match(r"^\s*Part\s+\d+\s*:\s*(.*)$", line, re.I)
        if in_structure and m:
            title, _, purpose = m.group(1).partition(" — ")
            parts.append({"title": title.strip(), "purpose": purpose.strip(), "points": [], "visuals": []})
            continue
        m = re.match(r"^\s*Show\s*:\s*(.*)$", line, re.I)
        if in_structure and parts and m:
            parts[-1]["visuals"] = [x.strip() for x in m.group(1).split(";") if x.strip()]
            continue
        m = re.match(r"^\s*[-•*]\s+(.*)$", line)
        if m:
            if cur_list:
                getattr(b, cur_list).append(m.group(1).strip())
            elif in_structure and parts:
                parts[-1]["points"].append(m.group(1).strip())
            continue
        m = re.match(r"^\s*([A-Za-z][A-Za-z ()/]+?)\s*:\s*(.*)$", line)
        if not m:
            continue
        lab, val = m.group(1).strip().lower(), m.group(2).strip()
        cur_list = None
        if lab == "structure":
            in_structure = True
            continue
        in_structure = False
        if lab in _LISTLAB:
            cur_list = _LISTLAB[lab]
            continue
        key = _LAB.get(lab)
        if key is None:
            continue
        if key == "mode":
            mm = re.match(r"\s*(clip|narration|hybrid)", val, re.I)
            b.mode = mm.group(1).lower() if mm else ""
            r = re.search(r"\((.*)\)\s*$", val)
            b.mode_reason = r.group(1) if r else ""
        elif key in ("length_seconds", "voice_speed"):
            n = re.search(r"\d+(?:\.\d+)?", val)
            setattr(b, key, float(n.group(0)) if n else 0.0)
        elif key == "style":
            v = val.lower().replace("news-style", "news")
            b.style = v if v in STYLES else ""
        elif key == "pacing":
            v = val.lower()
            b.pacing = v if v in ("slow", "normal", "fast") else ""
        elif key == "transitions":
            v = val.lower()
            b.transitions = v if v in ("quick", "none") else ""
        else:
            setattr(b, key, val)
    b.parts = parts
    b.text = text
    b.status = "edited"
    return b


def for_writer(b: ProductionBrief) -> str:
    """The brief as instructions for the scriptwriter / moment finder (empty without expansion)."""
    if b.status not in ("expanded", "edited") or not b.text.strip():
        return ""
    return b.text.strip()[:5000]


def cache_key(prompt: str, model: str, context: str) -> str:
    from ..core.cache import stable_id

    return "expand_" + stable_id(prompt, model, context, str(VERSION))


def to_json(b: ProductionBrief) -> str:
    return json.dumps(b.to_dict(), ensure_ascii=False)
