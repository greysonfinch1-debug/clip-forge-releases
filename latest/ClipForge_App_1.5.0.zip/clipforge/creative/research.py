"""Source material for the narration: notes the user pasted and the text of links they supplied.

When sources are supplied the script writer may use only the facts in them (and the Short's
description lists them). ClipForge only reads public pages the user points it to, like a browser
would, and keeps nothing but the page text for this project; it never signs in or gets around
paywalls.
"""
from __future__ import annotations

import html
import re
from html.parser import HTMLParser

MAX_CHARS_PER_SOURCE = 5000


class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "nav", "footer", "header", "aside", "form", "svg", "button", "select"}

    def __init__(self):
        super().__init__()
        self.out, self.skip, self.title = [], 0, ""
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag == "title":
            self._in_title = True
        if tag in ("p", "br", "li", "h1", "h2", "h3", "h4", "tr", "div"):
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif not self.skip:
            self.out.append(data)


def page_text(raw: str) -> tuple[str, str]:
    p = _Text()
    p.feed(raw)
    text = html.unescape("".join(p.out))
    lines = [" ".join(ln.split()) for ln in text.splitlines()]
    lines = [ln for ln in lines if len(ln) > 40 or (ln and ln[-1:] in ".!?:")]   # drop menus and buttons
    return " ".join(p.title.split()), "\n".join(lines)


def fetch_sources(urls: list[str], timeout: float = 20.0) -> tuple[str, list[str]]:
    """Text of each public page (best effort). Returns (combined text, problems)."""
    import requests

    parts, problems = [], []
    for u in urls:
        u = u.strip()
        if not re.match(r"^https?://", u):
            continue
        try:
            r = requests.get(u, timeout=timeout, headers={"User-Agent": "Mozilla/5.0 (ClipForge source reader)"})
            if r.status_code in (401, 402, 403):
                problems.append(f"{u}: the site refused access ({r.status_code}); ClipForge doesn't sign in or "
                                "get around paywalls. Paste the facts as notes instead.")
                continue
            r.raise_for_status()
            if "html" not in r.headers.get("content-type", "html"):
                text, title = r.text, u
            else:
                title, text = page_text(r.text)
            text = text.strip()[:MAX_CHARS_PER_SOURCE]
            if len(text) < 200:
                problems.append(f"{u}: almost no readable text on the page")
                continue
            parts.append(f"[Source: {title or u} — {u}]\n{text}")
        except Exception as e:  # noqa: BLE001
            problems.append(f"{u}: couldn't read it ({type(e).__name__})")
    return "\n\n".join(parts), problems


def source_material(notes: str, urls: list[str]) -> tuple[str, list[str]]:
    text, problems = fetch_sources(urls) if urls else ("", [])
    if notes.strip():
        text = (f"[Source: the creator's own notes]\n{notes.strip()[:MAX_CHARS_PER_SOURCE]}\n\n" + text).strip()
    return text, problems
