"""The shared narration-to-visual timeline.

Each section becomes one "unit" of the video:
  narration section  its shots back to back (hard cuts inside the section), the narration voiced
                     over them; the footage's own sound stays underneath, lower when someone is
                     talking in it. Shot changes are moved onto the narration's word gaps so the
                     picture changes between words, not in the middle of one.
  moment             the original clip with its own sound and dialogue captions (hybrid videos)
Units are joined with the edit's short cross-dissolve, like clip-driven Shorts. The result is
the same ``Timeline`` the renderer, captions and quality checks already use.
"""
from __future__ import annotations

from typing import Optional

from ..core.models import Candidate, NarrationLine, Section, Shot, Transcript, Word
from ..render.timeline import Placement, Segment, Timeline

PAD_BEFORE = 0.15        # picture before the narration starts
PAD_AFTER = 0.40         # picture after it ends (a breath before the next section)
BROLL_DB = -12.0         # footage sound under narration
BROLL_SPEECH_DB = -24.0  # …when someone talks in that footage (never competes with the narrator)
SNAP = 0.45              # how far a shot change may move to land between two words


def fit_shots(shots: list[Shot], total: float, source_len: dict[str, float]) -> list[Shot]:
    """Scale the section's shots to exactly ``total`` seconds (the narration's real length),
    keeping each shot inside its video."""
    if not shots or total <= 0:
        return shots
    have = sum(s.duration for s in shots) or 1.0
    out, acc = [], 0.0
    for k, s in enumerate(shots):
        d = total - acc if k == len(shots) - 1 else s.duration * total / have
        d = max(0.5, d)
        start = s.start
        end_max = source_len.get(s.source_id, start + d)
        if start + d > end_max:
            start = max(0.0, end_max - d)
        out.append(Shot(source_id=s.source_id, start=round(start, 3), end=round(start + d, 3), score=s.score,
                        why=s.why, locked=s.locked))
        acc += d
    return out


def snap_cuts(durations: list[float], words: list[Word], offset: float) -> list[float]:
    """Move shot changes inside a section onto gaps between narration words (``words`` relative to
    the narration start, which begins ``offset`` seconds into the section). The end of a sentence
    is preferred, from further away, so the picture changes when the narration moves on."""
    if len(durations) < 2 or not words:
        return durations
    sent = [offset + w.end + 0.05 for w in words[:-1] if w.text.rstrip().endswith((".", "!", "?"))]
    gaps = [offset + (a.end + b.start) / 2 for a, b in zip(words, words[1:]) if b.start - a.end > 0.04]
    gaps += [offset + w.end + 0.05 for w in words if w.text.rstrip().endswith((",", ";", ":"))] + sent
    if not gaps:
        return durations
    total = sum(durations)
    reach = max(SNAP, 0.4 * total / len(durations))
    cuts, t, last = [], 0.0, 0.0
    for d in durations[:-1]:
        t += d
        near_sent = [g for g in sent if abs(g - t) <= reach and g - last >= 1.0 and total - g >= 1.0]
        near = [g for g in gaps if abs(g - t) <= SNAP and g - last >= 0.6]
        c = min(near_sent, key=lambda g: abs(g - t)) if near_sent else (min(near, key=lambda g: abs(g - t)) if near
                                                                         else t)
        if c in cuts:
            c = t
        cuts.append(c)
        last = c
    cuts = sorted(cuts)
    bounds = [0.0] + cuts + [total]
    out = [max(0.6, b - a) for a, b in zip(bounds, bounds[1:])]
    out[-1] = max(0.6, total - sum(out[:-1]))
    return out


def build(sections: list[Section], lines: dict[int, NarrationLine], words: dict[int, list[Word]],
          files: dict[str, list[tuple[str, float, float]]], transcripts: dict[str, Optional[Transcript]],
          moments: dict[str, Candidate], main_source: str, layouts: dict[str, tuple[str, Optional[list]]],
          transition: float = 0.18) -> Timeline:
    """``files[source_id]`` = [(file, offset, end)]: local media covering source time offset..end.
    ``layouts[source_id]`` = (crop mode, webcam box) for that video's pictures."""
    tl = Timeline(transition=transition)
    t = 0.0
    last_seg, last_src = None, ""
    for i, sec in enumerate(sections):
        # "same shot as the previous part": the footage keeps running across the boundary, so no
        # transition and the same unit (hard cut onto the very next frame = no visible cut)
        cont = (sec.kind != "moment" and sec.continue_visual and last_seg is not None and bool(sec.shots)
                and sec.shots[0].source_id == last_src)
        if i > 0 and transition and not cont:
            t -= transition
        unit_start = t
        lead = transition if i > 0 and transition and not cont else 0.0
        if sec.kind == "moment":
            last_seg, last_src = None, ""
            c = moments.get(sec.cid)
            if c is None:
                continue
            f, f0, _ = _file_for(files, main_source, c.start, c.end)
            mode, fc = layouts.get(main_source, ("", None))
            # real moments use the normal Short layout (webcam stacking etc.), unless the video is shown
            # whole (low resolution, or "wide shots" asked for)
            seg = Segment("clip", i, f, c.start - f0, c.end - f0, c.start, t, t + (c.end - c.start), unit=i,
                          layout="blur-fill" if mode == "blur-fill" else "", facecam=None)
            tl.segments.append(seg)
            tl.item_spans.append((seg.out_start, seg.out_end))
            tr = transcripts.get(main_source)
            if tr is not None:
                for w in tr.words_between(c.start, c.end):
                    ws, we = seg.out_start + (w.start - c.start), seg.out_start + (w.end - c.start)
                    if ws >= seg.out_start - 0.05 and we <= seg.out_end + 0.3:
                        tl.dialogue_words.append((Word(w.text, ws, min(we, seg.out_end), speaker=w.speaker), i))
            t = seg.out_end
            continue
        ln = lines.get(i)
        dur = ln.duration if ln is not None else 0.0
        total = lead + PAD_BEFORE + dur + PAD_AFTER
        shots = sec.shots or []
        if not shots:
            continue
        lens = snap_cuts([s.duration for s in shots], words.get(i, []), lead + PAD_BEFORE)
        scale = total / max(1e-6, sum(lens))
        lens = [d * scale for d in lens]
        first = None
        unit = last_seg.unit if cont else i
        for k, (s, d) in enumerate(zip(shots, lens)):
            start = s.start
            if cont and k == 0:
                start = last_seg.source_start + (last_seg.src_out - last_seg.src_in)
            f, f0, f_end = _file_for(files, s.source_id, start, start + d)
            if start + d > f_end - 0.05:          # the shot got longer when fitted: never run past the video
                start = max(f0, f_end - 0.05 - d)
            mode, fc = layouts.get(s.source_id, ("", None))
            talk = _talking(transcripts.get(s.source_id), start, start + d)
            seg = Segment("broll", i, f, start - f0, start - f0 + d, start, t, t + d, unit=unit,
                          gain_db=BROLL_SPEECH_DB if talk else BROLL_DB, layout=mode or "zoom-fit", facecam=fc)
            tl.segments.append(seg)
            first = first or seg
            last_seg, last_src = seg, s.source_id
            t += d
        tl.item_spans.append((first.out_start, t))
        if ln is not None:
            nt = unit_start + lead + PAD_BEFORE
            tl.narration.append(Placement(ln, nt))
            ln.t_start = nt
    tl.duration = t
    return tl


def _file_for(files: dict, source_id: str, a: float, b: float) -> tuple[str, float, float]:
    """(file, source time where it starts, source time where it ends) covering a..b."""
    opts = files.get(source_id) or []
    for f, off, end in opts:
        if off - 0.05 <= a and b <= end + 0.05:
            return f, off, end
    if opts:      # the closest covering file (shot slightly longer than the fetched piece)
        f, off, end = min(opts, key=lambda x: abs(x[1] - a))
        return f, off, end
    raise FileNotFoundError(f"No footage file for {source_id} at {a:.1f}s")


def _talking(tr: Optional[Transcript], a: float, b: float) -> bool:
    if tr is None:
        return False
    return sum(min(b, w.end) - max(a, w.start) for w in tr.words_between(a, b)) > 0.25 * (b - a)
