"""clipforge-cli expandcheck — AI prompt expansion with this PC's REAL language model.

    clipforge-cli expandcheck                                  (32 prompts, briefs only)
    clipforge-cli expandcheck --video "D:\\Videos\\mine.mp4" --rights own      (+ full videos)
    clipforge-cli expandcheck --video ... --rights own --full 3 --no-export

Every brief here is written by the language model set in Settings (normally Ollama). Nothing is
simulated: if the model isn't running, the check says so and stops.

Per prompt it checks: the original prompt is unchanged; the brief is more detailed than the prompt;
the video type is a sensible one for the request; the brief stays on the request's subject; no
fact is stated as known unless the request or the supplied notes contain it (a word-overlap test:
flagged lines are listed for you to read); specific numbers the brief adds are listed for review;
editing the brief's text round-trips; the brief reaches the video's plan; asking again with the
same prompt reuses the brief instead of calling the model.

With --video (one you own or have permission to use): full videos made from expanded prompts
(clip-driven, narration-driven, hybrid), exported, with the same prompt made WITHOUT expansion
beside each for comparison.

Works in a temporary data folder that is deleted afterwards: your projects, settings and models are
not touched. Report: %APPDATA%\\ClipForge\\checks\\expand_<date>\\report.md (+ results.json, videos).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import tempfile
import time
from dataclasses import asdict
from pathlib import Path

# (category, prompt, acceptable video types, subject words (any one must appear), notes, use_my_script)
PROMPTS = [
    ("short", "funny moments", {"clip"}, ["funny", "funniest", "humor", "humour", "laugh"], "", ""),
    ("short", "gta 6", {"clip", "narration", "hybrid"}, ["gta", "grand theft"], "", ""),
    ("short", "explain redstone", {"narration"}, ["redstone"], "", ""),
    ("short", "top 5 fails", {"clip"}, ["fail"], "", ""),
    ("detailed", "Make a 45 second educational video explaining how airplanes stay in the air. Start with a "
                 "surprising question, cover lift, thrust and drag in three clear points, use calm narration with "
                 "gameplay footage in the background, and end by asking viewers what they want explained next.",
     {"narration"}, ["airplane", "lift", "flight", "plane"], "", ""),
    ("detailed", "Find the 4 craziest police chases in the stream, count them down from 4 to 1, describe what "
                 "happens in each one in a sentence, keep the original audio of the chases and make it fast-paced.",
     {"clip", "hybrid"}, ["chase", "police"], "", ""),
    ("ambiguous", "make something cool from this", {"clip", "narration", "hybrid"}, ["cool", "best", "highlight",
                                                                                   "moment", "video", "stream"], "", ""),
    ("ambiguous", "a video about this stream", {"clip", "narration", "hybrid"}, ["stream"], "", ""),
    ("ambiguous", "speed", {"clip", "narration", "hybrid"}, ["speed"], "", ""),
    ("gaming", "5 things that make GTA 6 feel realistic, use gameplay as background footage",
     {"narration"}, ["gta", "realistic", "realism"], "", ""),
    ("gaming", "Show the best clutch plays and explain why each one worked",
     {"hybrid", "clip"}, ["clutch"], "", ""),
    ("gaming", "the history of Fortnite's map changes, documentary style", {"narration"}, ["fortnite", "map"], "", ""),
    ("history", "The history of the Roman Empire in 60 seconds, documentary style", {"narration"},
     ["roman", "rome"], "", ""),
    ("history", "how the printing press changed the world", {"narration"}, ["printing"], "", ""),
    ("history", "the history of livestreaming, use my footage as b-roll", {"narration"},
     ["livestream", "streaming"], "Justin.tv launched in 2007. Twitch was spun off from Justin.tv in 2011.", ""),
    ("educational", "explain how black holes form, in simple words for kids", {"narration"}, ["black hole"], "", ""),
    ("educational", "teach three tips to improve your aim in shooters", {"narration", "hybrid"}, ["aim"], "", ""),
    ("narration", "Tell a short story about a lonely robot who finds a friend. Calm narration over the footage.",
     {"narration"}, ["robot"], "", ""),
    ("narration", "write a poem about rainy cities and use the footage as background", {"narration"},
     ["rain", "city", "cities"], "", ""),
    ("narration", "narrate my script over the gameplay", {"narration"}, ["script", "narrat", "gameplay", "morning"],
     "", "Every morning the city wakes up slowly.\n\nThen the traffic starts.\n\nAnd nobody looks up."),
    ("clip", "the 4 craziest police chases, describe each one", {"clip"}, ["chase", "police"], "", ""),
    ("clip", "his best reactions, no narration", {"clip"}, ["reaction"], "", ""),
    ("clip", "countdown of the top 3 rage moments", {"clip"}, ["rage"], "", ""),
    ("hybrid", "Open with his funniest moment, then explain why the AI in this game is so chaotic",
     {"hybrid"}, ["ai", "chaotic", "chaos", "funn"], "", ""),
    ("hybrid", "show the real reactions and explain what was happening in between", {"hybrid"},
     ["reaction"], "", ""),
    ("creative", "make it feel like a nature documentary about a gamer in his natural habitat",
     {"narration", "hybrid"}, ["nature", "gamer", "habitat", "documentary"], "", ""),
    ("creative", "a fake movie trailer for this stream", {"hybrid", "narration", "clip"}, ["trailer"], "", ""),
    ("creative", "a motivational speech over the gameplay", {"narration"}, ["motivat"], "", ""),
    ("news", "News-style report: what has been announced about GTA 6 so far", {"narration"}, ["gta"], "", ""),
    ("news", "is the new iPhone worth it?", {"narration"}, ["iphone"], "", ""),
    ("style words", "No music, slow pacing: explain how volcanoes erupt", {"narration"}, ["volcan"], "", ""),
    ("style words", "funny and fast-paced: the dumbest deaths in the stream", {"clip", "hybrid"},
     ["death", "die", "dumb"], "", ""),
]
# full videos: (name, prompt, seconds)
FULL = [("clip-driven", "find the funniest moments and say why each one is funny", 40),
        ("narration-driven", "Explain what makes livestreams fun to watch, use my footage as background", 35),
        ("hybrid", "Open with the most exciting real moment, then explain why moments like this work so well on "
                   "stream", 45)]
STOP = set("a an the of in on at to for and or with about from by is are was be this that it its as into than "
           "then so very more most can could will would should do does did not no your my his her their our they "
           "them we you i video short footage".split())


def _words(s: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9']+", (s or "").lower()) if w not in STOP and len(w) > 2}


def _numbers(s: str) -> set[str]:
    return set(re.findall(r"\b\d{2,}(?:[.,]\d+)?\b", s or ""))


def check_prompt(p, prompt: str, modes: set, keys: list, notes: str, script: str, secs: float = 45) -> dict:
    from . import expand as ex
    from .brief import brief_from_production

    r = {"prompt": prompt, "checks": []}

    def add(name, ok, detail=""):
        r["checks"].append({"check": name, "result": ok if isinstance(ok, str) else ("PASS" if ok else "FAIL"),
                            "detail": str(detail)[:400]})
    t0 = time.time()
    try:
        b = p.expand_prompt(prompt, secs, "auto", "", script, notes)
    except ex.ExpansionUnavailable as e:
        add("expanded by the language model", False, e)
        return r
    r["seconds"] = round(time.time() - t0, 1)
    r["brief"] = b.to_dict()
    add("expanded by the language model", b.status == "expanded", f"{b.model}, {r['seconds']} s")
    add("original prompt unchanged", b.original_prompt == prompt and b.original_prompt is not None, repr(b.original_prompt))
    detail = len(b.text) >= 3 * len(prompt) and len(b.parts) >= 2 and bool(b.hook) and bool(b.ending)
    add("more detailed than the prompt", detail, f"{len(b.text)} vs {len(prompt)} characters, {len(b.parts)} parts, "
        f"hook {'yes' if b.hook else 'no'}, ending {'yes' if b.ending else 'no'}")
    add("sensible video type", b.mode in modes, f"{b.mode} ({b.mode_reason}); acceptable: {sorted(modes)}")
    blob = " ".join([b.subject, b.intent, b.text]).lower()
    add("stays on the request's subject", any(k in blob for k in keys), f"subject: {b.subject}")
    allowed = _words(prompt + " " + notes + " " + script)
    flagged = [f for f in b.facts_known if len(_words(f)) and len(_words(f) & allowed) / len(_words(f)) < 0.5]
    add("no fact stated as known beyond the request / notes", not flagged,
        "flagged: " + " | ".join(flagged) if flagged else f"{len(b.facts_known)} known, {len(b.facts_to_check)} to check")
    said = "\n".join(ln for ln in b.text.splitlines() if not ln.startswith(("Voice speed:", "Length (seconds):")))
    extra_nums = sorted(_numbers(said) - _numbers(prompt + " " + notes + " " + script))
    add("specific numbers the brief added (review)", "INFO" if extra_nums else "PASS",
        ", ".join(extra_nums) or "none")
    if notes:
        add("facts from the notes are recognised as known", bool(b.facts_known), "; ".join(b.facts_known)[:300])
    if re.search(r"announced|new iphone|news|so far|worth it", prompt, re.I):
        add("current topic: facts to check listed", bool(b.facts_to_check), "; ".join(b.facts_to_check)[:300])
    same = ex.parse_edited(b.text, b)
    rt = all(getattr(same, k) == getattr(b, k) for k in ("subject", "mode", "style", "pacing", "hook", "ending")) \
        and same.parts == b.parts
    edited = ex.parse_edited(b.text.replace(f"Hook: {b.hook}", "Hook: my own opening line"), b)
    add("edit round-trips and edits apply", rt and edited.hook == "my own opening line"
        and edited.original_prompt == prompt)
    cb = brief_from_production(prompt, b)
    add("brief reaches the video plan", cb.subject == (b.subject or cb.subject)[:200]
        and (cb.mode == b.mode or not b.mode), f"video type {cb.mode}, style {cb.style}, pacing {cb.pacing}")
    calls = {"n": 0}
    llm = p.services.llm()
    orig = llm.complete_json

    def counted(*a, **k):
        calls["n"] += 1
        return orig(*a, **k)
    llm.complete_json = counted
    try:
        t1 = time.time()
        again = p.expand_prompt(prompt, secs, "auto", "", script, notes)
        add("same prompt again reuses the brief (no model call)", calls["n"] == 0 and again.text == b.text,
            f"{time.time() - t1:.2f} s")
    finally:
        llm.complete_json = orig
    return r


def main(argv=None) -> int:
    from ..config import Settings, app_dir
    from ..model_manager import ollama_status

    ap = argparse.ArgumentParser(prog="clipforge-cli expandcheck", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", default="", help="a video you own or have permission to use (for full videos)")
    ap.add_argument("--rights", choices=["own", "permission", "licence"])
    ap.add_argument("--creator", default="")
    ap.add_argument("--full", type=int, default=3, help="how many full videos (0-3)")
    ap.add_argument("--no-export", action="store_true", help="full videos: plans only")
    ap.add_argument("--only", type=int, default=0, help="first N prompts only")
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)
    real = Settings.load()
    out = Path(a.out) if a.out else app_dir() / "checks" / time.strftime("expand_%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    res = {"kind": "REAL AI (no simulated replies)", "llm": f"{real.llm.backend} / {real.llm.model}",
           "started": time.strftime("%Y-%m-%d %H:%M:%S"), "preflight": {}, "prompts": [], "full": []}
    print(f"ClipForge prompt-expansion check (real AI) → {out}")
    if real.llm.backend == "ollama":
        st = ollama_status(real.llm.base_url, [real.llm.model])
        res["preflight"] = st
        if not st.get("running"):
            msg = (f"Ollama is not running at {real.llm.base_url}. Start the Ollama app, then run this check again. "
                   f"({st.get('error', '')[:200]})")
            res["stopped"] = msg
            _report(out, res)
            print(msg)
            return 2
        if not all(st["models"].values()):
            msg = (f"The model {real.llm.model} isn't downloaded in Ollama. Run:  ollama pull {real.llm.model}  "
                   "(or AI Models → Download missing Ollama models), then run this check again.")
            res["stopped"] = msg
            _report(out, res)
            print(msg)
            return 2
    elif real.llm.backend == "rules":
        res["stopped"] = "No AI language model is set up (Settings → Language model): there is nothing to test."
        _report(out, res)
        print(res["stopped"])
        return 2
    video = Path(a.video).expanduser().resolve() if a.video else None
    if video is not None and (not video.is_file() or not a.rights):
        print("--video needs an existing file and --rights (own / permission / licence)")
        return 2
    base = asdict(real)
    base.update(first_run_done=True, check_updates=False, auto_install_updates=False, expand_prompts=True)
    work = Path(tempfile.mkdtemp(prefix="cf_expand_"))
    base["output_dir"] = str(work / "exports")
    (work / "settings.json").write_text(json.dumps(base, indent=1), encoding="utf-8")
    old_home = os.environ.get("CLIPFORGE_HOME")
    os.environ["CLIPFORGE_HOME"] = str(work)
    try:
        from ..pipeline import Pipeline

        p = Pipeline(Settings.load())
        t_warm = time.time()
        warm = getattr(p.services.llm(), "warm_up", None)
        if warm:
            warm()
        res["model_load_seconds"] = round(time.time() - t_warm, 1)
        print(f"Model loaded in {res['model_load_seconds']} s\n")
        todo = PROMPTS[: a.only] if a.only else PROMPTS
        for k, (cat, prompt, modes, keys, notes, script) in enumerate(todo):
            print(f"--- {k + 1}/{len(todo)} [{cat}] {prompt[:90]}", flush=True)
            try:
                r = check_prompt(p, prompt, modes, keys, notes, script)
            except Exception as e:  # noqa: BLE001
                r = {"prompt": prompt, "checks": [{"check": "ran", "result": "FAIL",
                                                   "detail": f"{type(e).__name__}: {e}"[:400]}]}
            r["category"] = cat
            res["prompts"].append(r)
            for c in r["checks"]:
                print(f"   {c['result']:5s} {c['check']}: {c['detail'][:110]}", flush=True)
            _report(out, res)
        if video is not None and a.full > 0:
            _full(a, video, res, out, work)
    finally:
        if old_home is None:
            os.environ.pop("CLIPFORGE_HOME", None)
        else:
            os.environ["CLIPFORGE_HOME"] = old_home
        res["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
        _report(out, res)
        shutil.rmtree(work, ignore_errors=True)
    print(f"\nReport: {out / 'report.md'}")
    fails = [c for r in res["prompts"] + res["full"] for c in r.get("checks", []) if c["result"] == "FAIL"]
    return 1 if fails else 0


def _full(a, video: Path, res: dict, out: Path, work: Path) -> None:
    from .cli import run_spec

    rights = {"basis": a.rights, "creator": a.creator or "(not given)", "commercial_use": False}
    for k, (name, prompt, secs) in enumerate(FULL[: a.full]):
        print(f"\n=== full video {k + 1}: {name}: {prompt}", flush=True)
        r = {"name": name, "prompt": prompt, "checks": []}

        def add(n, ok, d=""):
            r["checks"].append({"check": n, "result": ok if isinstance(ok, str) else ("PASS" if ok else "FAIL"),
                                "detail": str(d)[:400]})
        spec = {"name": f"expand check {k + 1}", "main": {"path": str(video), "rights": rights}, "prompt": prompt,
                "seconds": secs, "export": not a.no_export, "out": str(work / "exports"), "expand": "required"}
        try:
            t0 = time.time()
            with_b = run_spec(spec, quiet=True)
            r["with_brief"] = with_b
            r["seconds"] = round(time.time() - t0, 1)
            t1 = time.time()
            without = run_spec(dict(spec, expand=False, export=False, name=f"expand check {k + 1} (no brief)"),
                               quiet=True)
            r["without_brief"] = without
            r["seconds_without"] = round(time.time() - t1, 1)
        except Exception as e:  # noqa: BLE001
            add("made the video", False, f"{type(e).__name__}: {e}")
            res["full"].append(r)
            _report(out, res)
            continue
        ex_ = with_b.get("expansion") or {}
        add("expanded by the language model", ex_.get("status") == "expanded", f"{ex_.get('seconds')} s")
        add("original prompt kept exactly", with_b.get("original_prompt") == prompt)
        add("video type follows the brief", True if not ex_.get("text") else
            (with_b["mode"] in ex_["text"].split("Video type: ", 1)[-1][:20]),
            f"{with_b['mode']} ({with_b['mode_reason']})")
        if with_b["mode"] != "clip":
            add("the language model wrote the script", with_b.get("script_by") == "llm", with_b.get("script_by"))
        brief_words = _words(ex_.get("text", "")) - _words(prompt)
        script = " ".join(s.get("text", "") for s in with_b.get("sections", [])) + " " + \
            " ".join((with_b.get("clip_driven") or {}).get("narration", []))
        add("the script uses the brief (shared words beyond the prompt)", "INFO",
            f"{len(_words(script) & brief_words)} of the brief's own words appear in the script")
        if "qc_passed" in with_b:
            add("export quality checks", with_b["qc_passed"], "; ".join(f"{n}: {d}" for n, d in with_b["qc_failed"])
                or "all passed")
            dst = out / f"full{k + 1}_{name}.mp4"
            shutil.copy2(with_b["export"], dst)
            r["video"] = str(dst)
        res["full"].append(r)
        _report(out, res)


def _report(out: Path, res: dict) -> None:
    (out / "results.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    L = ["# ClipForge prompt-expansion check — REAL AI", "",
         f"Language model: {res['llm']}  ", f"Started {res['started']}" +
         (f", finished {res['finished']}" if res.get("finished") else " (running)"), "",
         "Every brief below was written by the language model on this PC. No simulated replies.", ""]
    if res.get("stopped"):
        L += [f"**Not run:** {res['stopped']}", ""]
    if res.get("model_load_seconds") is not None:
        L.append(f"Model load / warm-up: {res['model_load_seconds']} s  ")
    rows = res["prompts"]
    if rows:
        n_fail = sum(any(c["result"] == "FAIL" for c in r["checks"]) for r in rows)
        secs = [r["seconds"] for r in rows if r.get("seconds")]
        L += [f"Prompts: {len(rows)}, with any FAIL: {n_fail}" + (f"; expansion time median "
              f"{sorted(secs)[len(secs) // 2]} s, max {max(secs)} s" if secs else ""), "",
              "| # | Category | Prompt | Type | Time | Result |", "|---|---|---|---|---|---|"]
        for i, r in enumerate(rows, 1):
            bad = [c["check"] for c in r["checks"] if c["result"] == "FAIL"]
            L.append(f"| {i} | {r.get('category', '')} | {r['prompt'][:70]} | {(r.get('brief') or {}).get('mode', '')} "
                     f"| {r.get('seconds', '')} s | {'FAIL: ' + ', '.join(bad) if bad else 'PASS'} |")
        for i, r in enumerate(rows, 1):
            L += ["", f"## {i}. {r['prompt']}", ""]
            L += [f"- {c['result']} {c['check']}: {c['detail']}" for c in r["checks"]]
            if r.get("brief"):
                L += ["", "```", r["brief"].get("text", ""), "```"]
    for r in res["full"]:
        L += ["", f"## Full video: {r['name']} — {r['prompt']}", ""]
        L += [f"- {c['result']} {c['check']}: {c['detail']}" for c in r["checks"]]
        for key, lab in (("with_brief", "With the expanded brief"), ("without_brief", "Original prompt only")):
            rep = r.get(key)
            if not rep:
                continue
            L += ["", f"**{lab}** — type {rep.get('mode')}, script by {rep.get('script_by')}, title “{rep.get('title')}”"]
            for s in rep.get("sections", []):
                L.append(f"- {'[real moment]' if s.get('kind') == 'moment' else s.get('text', '')}")
            for t in (rep.get("clip_driven") or {}).get("narration", []):
                L.append(f"- {t}")
        if r.get("video"):
            L.append(f"\nVideo: {r['video']}")
    (out / "report.md").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
