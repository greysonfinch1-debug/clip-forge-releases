"""Creative modes: narration-driven and hybrid videos.

ClipForge started as clip-driven: find moments, then narrate around them. These modules add two
more ways of making a video, sharing the same projects, rendering, captions and export:

  brief.py      what the user asked for: mode (clip / narration / hybrid), style, pacing, points…
  narration.py  narration intelligence: the script, split into sections, each with what should
                be on screen (written by the language model, or taken from the user's own script)
  research.py   optional source material the narration may use (pasted notes, fetched links)
  library.py    the footage library: every authorised video, analysed once and cut into shots
  matcher.py    visual selection: which shots best match each section's meaning (CLIP), with
                variety, quality, pacing and no unrelated scenes
  timeline.py   the shared narration-to-visual timeline the renderer turns into the video

The two intelligences only meet in the timeline: the narration never has to describe the
footage, and the footage never dictates the narration.
"""
