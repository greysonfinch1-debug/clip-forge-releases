"""Narration audio: synthesis (cached per line) and word timing for captions."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import numpy as np

from ..core.cache import SourceCache, stable_id
from ..core.models import NarrationLine, Word


def tts_text(text: str) -> str:
    """Light normalisation so the voice reads naturally (numbers, symbols, all-caps)."""
    t = text.replace("&", " and ").replace("%", " percent").replace("$", " dollars ")
    t = re.sub(r"\b([A-Z]{3,})\b", lambda m: m.group(1).capitalize(), t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def synthesize_lines(lines: list[NarrationLine], tts, voice: str, speed: float, volume_db: float,
                     cache: SourceCache, progress=None) -> None:
    import soundfile as sf

    out_dir = cache.subdir("narration")
    gain = 10 ** (volume_db / 20)
    from .. import cancel

    for i, ln in enumerate(lines):
        cancel.check()
        key = stable_id(ln.text, voice, f"{speed:.3f}", f"{volume_db:.1f}", tts.name)
        p = out_dir / f"n_{key}.wav"
        if not p.exists():
            samples, sr = tts.synthesize(tts_text(ln.text), voice, speed)
            samples = _trim_silence(samples, sr)
            peak = float(np.max(np.abs(samples))) or 1.0
            samples = samples / peak * 0.89 * gain
            fade = int(0.01 * sr)
            if len(samples) > 2 * fade:
                samples[:fade] *= np.linspace(0, 1, fade)
                samples[-fade:] *= np.linspace(1, 0, fade)
            tmp = p.with_name(p.stem + ".partial.wav")
            sf.write(tmp, samples.astype(np.float32), sr)
            tmp.replace(p)
        info = sf.info(str(p))
        ln.audio_path = str(p)
        ln.duration = float(info.duration)
        if progress:
            progress((i + 1) / max(1, len(lines)), f"Voicing line {i + 1}/{len(lines)}")


def _trim_silence(x: np.ndarray, sr: int, thr: float = 0.01) -> np.ndarray:
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(0.03 * sr))
    b = min(len(x), idx[-1] + int(0.08 * sr))
    return x[a:b]


def narration_word_times(line: NarrationLine, transcriber=None) -> list[Word]:
    """Word timings inside a narration clip. Uses the speech recogniser for exact timings when
    available (it is already loaded), otherwise distributes time by syllable estimate."""
    words = line.text.split()
    if not words:
        return []
    if transcriber is not None and getattr(transcriber, "name", "") == "parakeet":
        try:
            import soundfile as sf

            audio, sr = sf.read(line.audio_path, dtype="float32")
            if sr != 16000:
                n = int(len(audio) * 16000 / sr)
                audio = np.interp(np.linspace(0, len(audio), n, endpoint=False), np.arange(len(audio)), audio
                                  ).astype(np.float32)
            rec_words = transcriber._decode(audio, 0.0)
            if rec_words and abs(len(rec_words) - len(words)) <= max(2, len(words) // 4):
                return _align(words, rec_words, line.duration)
        except Exception:
            pass
    return _estimate(words, line.duration)


def _syllables(w: str) -> int:
    w = re.sub(r"[^a-z]", "", w.lower())
    if not w:
        return 1
    return max(1, len(re.findall(r"[aeiouy]+", w)) - (1 if w.endswith("e") and len(w) > 3 else 0))


def _estimate(words: list[str], dur: float) -> list[Word]:
    weights = np.array([_syllables(w) + (0.6 if re.search(r"[,.!?]$", w) else 0) for w in words], float)
    t = np.concatenate([[0], np.cumsum(weights)]) / weights.sum() * dur
    return [Word(w, float(t[i]), float(t[i + 1])) for i, w in enumerate(words)]


def _align(script_words: list[str], rec: list[Word], dur: float) -> list[Word]:
    """Use the script's spelling with the recogniser's timings (sequence alignment by position)."""
    import difflib

    a = [re.sub(r"[^a-z0-9]", "", w.lower()) for w in script_words]
    b = [re.sub(r"[^a-z0-9]", "", w.text.lower()) for w in rec]
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    times: list[Optional[tuple[float, float]]] = [None] * len(a)
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            r = rec[blk.b + k]
            times[blk.a + k] = (r.start, r.end)
    # fill gaps by interpolation
    est = _estimate(script_words, dur)
    out = []
    for i, w in enumerate(script_words):
        if times[i] is not None:
            out.append(Word(w, *times[i]))
        else:
            prev_end = out[-1].end if out else 0.0
            nxt = next((times[j][0] for j in range(i + 1, len(a)) if times[j] is not None), dur)
            span = max(0.12, (nxt - prev_end))
            missing = next((j for j in range(i + 1, len(a)) if times[j] is not None), len(a)) - i
            out.append(Word(w, prev_end, prev_end + span / max(1, missing)))
    for i in range(len(out) - 1):
        out[i].end = min(max(out[i].end, out[i].start + 0.08), out[i + 1].start + 0.02)
    _ = est
    return out
