"""Speaker identification in a helper process.

sherpa-onnx's diarizer holds Python's global interpreter lock for the whole call (3-6 s per
window measured here), so while it ran, ClipForge's window couldn't redraw or react. In 1.2.12
and earlier the window therefore froze again and again during "Identifying speakers". The
diarizer now runs in a separate Python process: same model, same settings, same results
(checked), the window stays responsive, and Cancel stops it at once by ending the helper.

The helper is started with the bundled Python directly (never through the launcher, which could
apply a downloaded update), with the running app's own import paths. It is tracked like FFmpeg:
lower priority in Balanced / Low, and ended by Windows if ClipForge crashes.
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

import numpy as np

TAG = "@@CF "
BOOT = ("import os, sys, json; cfg = json.loads(sys.argv[1]); sys.path[:0] = cfg['paths']\n"
        "for d in cfg.get('dll_dirs', []):\n"
        "    try: os.add_dll_directory(d)\n"
        "    except Exception: pass\n"
        "from clipforge.providers.speaker_worker import serve; serve(cfg)")


def _python() -> str:
    p = os.environ.get("CLIPFORGE_PYTHON")
    if p and Path(p).exists():
        return p
    inst = os.environ.get("CLIPFORGE_INSTALL_DIR")
    if inst and (Path(inst) / "runtime" / "python.exe").exists():
        return str(Path(inst) / "runtime" / "python.exe")
    return sys.executable


def _tmp_dir() -> Path:
    """%TEMP%\\ClipForge\\speakers_<pid>; folders left by ClipForge sessions that ended are removed."""
    import shutil

    root = Path(tempfile.gettempdir()) / "ClipForge"
    root.mkdir(parents=True, exist_ok=True)
    for d in root.glob("speakers_*"):
        try:
            pid = int(d.name.split("_", 1)[1])
            from ..projects import _pid_alive

            if pid != os.getpid() and not _pid_alive(pid):
                shutil.rmtree(d, ignore_errors=True)
        except (ValueError, OSError):
            pass
    d = root / f"speakers_{os.getpid()}"
    d.mkdir(exist_ok=True)
    return d


class WorkerFailed(RuntimeError):
    pass


class SpeakerWorker:
    """Runs PyannoteDiarizer.diarize in a helper process; start() loads the models there."""

    def __init__(self, models_dir: str, threads: int, threshold: float, start_timeout: float = 300.0):
        dll = []
        if sys.platform == "win32" and os.environ.get("CLIPFORGE_INSTALL_DIR"):
            dll.append(str(Path(os.environ["CLIPFORGE_INSTALL_DIR"]) / "runtime"))
        self.cfg = {"models_dir": models_dir, "threads": threads, "threshold": threshold,
                    "paths": [p for p in sys.path if p], "dll_dirs": dll}
        self.start_timeout = start_timeout
        self.proc: Optional[subprocess.Popen] = None
        self.lines: "queue.Queue[str]" = queue.Queue()
        self.sample_rate = 16000
        self._tmp = _tmp_dir()

    # ---- lifecycle
    def start(self) -> None:
        from .. import resources

        self.lines = queue.Queue()
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.proc = resources.popen([_python(), "-c", BOOT, json.dumps(self.cfg)], stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8",
                                    bufsize=1, creationflags=flags)
        out = self.proc.stdout

        def reader():
            for ln in out:
                if ln.startswith(TAG):
                    self.lines.put(ln[len(TAG):].strip())
            self.lines.put('{"eof": true}')
        threading.Thread(target=reader, daemon=True).start()
        msg = self._reply(self.start_timeout, "starting the speaker model")
        if not msg.get("ready"):
            self.close()
            raise WorkerFailed(msg.get("error") or "the speaker helper didn't start")
        self.sample_rate = int(msg.get("sample_rate") or 16000)

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def close(self, now: bool = False) -> None:
        """End the helper: politely when it's idle, at once when ``now`` (Cancel: it may be busy)."""
        from .. import resources

        p, self.proc = self.proc, None
        if p is not None:
            try:
                if p.poll() is None and not now:
                    p.stdin.write(json.dumps({"quit": True}) + "\n")
                    p.stdin.flush()
                    p.wait(2)
            except Exception:  # noqa: BLE001
                pass
            if p.poll() is None:
                p.kill()
                try:
                    p.wait(5)
                except Exception:  # noqa: BLE001
                    pass
            resources.forget(p)
        for f in self._tmp.glob("*"):
            f.unlink(missing_ok=True)

    def __del__(self):
        try:
            self.close()
        except Exception:  # noqa: BLE001
            pass

    # ---- work
    def _reply(self, timeout: Optional[float], what: str) -> dict:
        from .. import cancel

        t0 = time.time()
        while True:
            try:
                ln = self.lines.get(timeout=0.1)
                return json.loads(ln)
            except queue.Empty:
                pass
            if cancel.requested():
                self.close(now=True)           # ends the helper at once; it restarts next time
                raise cancel.Cancelled("Cancelled")
            if self.proc is None or self.proc.poll() is not None:
                if self.lines.empty():
                    raise WorkerFailed(f"the speaker helper stopped while {what}")
            if timeout and time.time() - t0 > timeout:
                self.close(now=True)
                raise WorkerFailed(f"the speaker helper didn't answer within {timeout:.0f} s while {what}")

    def diarize(self, samples: np.ndarray, sr: int, progress=None) -> list[tuple[float, float, int]]:
        if not self.alive():
            self.start()
        f = self._tmp / "chunk.npy"
        np.save(f, samples.astype(np.float32))
        self.proc.stdin.write(json.dumps({"npy": str(f), "sr": sr}) + "\n")
        self.proc.stdin.flush()
        while True:
            msg = self._reply(None, "identifying speakers")
            if "p" in msg:
                if progress:
                    progress(float(msg["p"]), "Identifying speakers")
                continue
            if "error" in msg:
                raise WorkerFailed(msg["error"])
            if msg.get("eof"):
                raise WorkerFailed("the speaker helper stopped while identifying speakers")
            return [(float(a), float(b), int(c)) for a, b, c in msg["segs"]]


def serve(cfg: dict) -> None:
    """The helper process: load the diarizer, then answer one request per line."""
    def say(obj):
        sys.stdout.write(TAG + json.dumps(obj) + "\n")
        sys.stdout.flush()
    try:
        from .audio_ai import PyannoteDiarizer

        dz = PyannoteDiarizer(cfg["models_dir"], threads=cfg.get("threads", 0), threshold=cfg["threshold"],
                              in_process=True)
    except Exception as e:  # noqa: BLE001
        say({"ready": False, "error": f"{type(e).__name__}: {e}"})
        return
    say({"ready": True, "sample_rate": dz.sd.sample_rate})
    for ln in sys.stdin:
        try:
            req = json.loads(ln)
        except ValueError:
            continue
        if req.get("quit"):
            break
        try:
            x = np.load(req["npy"])
            last = [0.0]

            def prog(f, _m):
                if f - last[0] >= 0.1:
                    last[0] = f
                    say({"p": round(f, 3)})
            segs = dz.diarize(x, int(req["sr"]), prog)
            say({"segs": segs})
        except Exception as e:  # noqa: BLE001
            say({"error": f"{type(e).__name__}: {e}"})
