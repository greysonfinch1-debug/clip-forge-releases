"""Language-model backends (structured JSON output).

* ``ollama`` – local model through Ollama (free). Uses JSON mode.
* ``openai`` – any OpenAI-compatible chat API (OpenAI, Groq, OpenRouter, LM Studio, vLLM...).
* ``rules``  – no model. Raises ProviderUnavailable so every caller falls back to its
  deterministic heuristic implementation.
"""
from __future__ import annotations

import json
import re

from .base import LLM, MalformedResponse, ProviderUnavailable, register


def parse_json_loose(text: str) -> dict:
    """Parse model output into a dict, tolerating code fences and trailing commentary."""
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t, flags=re.S)
    try:
        v = json.loads(t)
        return v if isinstance(v, dict) else {"items": v}
    except Exception:
        pass
    start = min([i for i in (t.find("{"), t.find("[")) if i >= 0], default=-1)
    if start < 0:
        raise ValueError("No JSON object in model output")
    depth, in_str, esc = 0, False, False
    opener = t[start]
    closer = "}" if opener == "{" else "]"
    for i in range(start, len(t)):
        c = t[i]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
        elif c == opener:
            depth += 1
        elif c == closer:
            depth -= 1
            if depth == 0:
                frag = re.sub(r",\s*([}\]])", r"\1", t[start:i + 1])
                v = json.loads(frag)
                return v if isinstance(v, dict) else {"items": v}
    raise ValueError("Unterminated JSON in model output")


# Keep the model loaded between requests (Ollama's default unloads it after 5 idle minutes, and
# every reload of a 7B model costs seconds to tens of seconds). The context size must be the same in
# every request: Ollama reloads the model whenever it changes.
KEEP_ALIVE = "30m"
NUM_CTX = 16384


def ollama_has_model(names: set, model: str) -> bool:
    if model in names or model + ":latest" in names:
        return True
    return ":" not in model and any(n.startswith(model + ":") for n in names)


class _JSONRetryMixin:
    def _complete_json(self, call, system: str, user: str, max_tokens: int) -> dict:
        last = None
        for attempt in range(3):
            prompt = user if attempt == 0 else (
                user + "\n\nYour previous reply was not valid JSON. Reply with ONE valid JSON object only.")
            try:
                return parse_json_loose(call(system, prompt, max_tokens))
            except ProviderUnavailable:
                raise
            except Exception as e:  # malformed JSON -> retry
                last = e
        raise MalformedResponse(f"Model did not return valid JSON: {last}")


@register("llm", "ollama")
class OllamaLLM(LLM, _JSONRetryMixin):
    def __init__(self, model: str = "qwen2.5:7b-instruct", base_url: str = "http://localhost:11434",
                 temperature: float = 0.3, timeout_seconds: int = 240, **_):
        import requests

        self.model, self.base = model, base_url.rstrip("/")
        self.temperature, self.timeout = temperature, timeout_seconds
        self.s = requests.Session()
        try:
            r = self.s.get(self.base + "/api/tags", timeout=10)
            r.raise_for_status()
            names = {m.get("name", "") for m in r.json().get("models", [])}
        except Exception as e:
            raise ProviderUnavailable(f"Ollama is not running at {self.base} ({e}). Start Ollama or change the "
                                      f"language model in Settings.") from e
        if not ollama_has_model(names, model):
            raise ProviderUnavailable(f"Model '{model}' is not pulled in Ollama. Run: ollama pull {model}")
        self.on_text = None          # optional: called with the answer so far while it streams in

    def warm_up(self) -> None:
        """Load the model into memory now (in the background) so the first real request doesn't
        wait for it; it then stays loaded between requests (KEEP_ALIVE)."""
        try:
            self.s.post(self.base + "/api/generate", json={"model": self.model, "keep_alive": KEEP_ALIVE,
                                                           "options": {"num_ctx": NUM_CTX}}, timeout=300)
        except Exception:  # noqa: BLE001
            pass

    def _call(self, system: str, user: str, max_tokens: int) -> str:
        """Streamed, so Cancel takes effect within a moment: closing the connection makes Ollama
        stop generating (it doesn't keep the GPU/CPU busy for an answer nobody wants)."""
        import json as _json
        import time as _time

        from .. import cancel

        cancel.check()
        body = {"model": self.model, "stream": True, "format": "json", "keep_alive": KEEP_ALIVE,
                "options": {"temperature": self.temperature, "num_predict": max_tokens, "num_ctx": NUM_CTX},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        try:
            r = self.s.post(self.base + "/api/chat", json=body, timeout=(10, 60), stream=True)
        except Exception as e:
            raise ProviderUnavailable(f"Ollama request failed: {e}") from e
        if r.status_code >= 400:
            raise ProviderUnavailable(f"Ollama error {r.status_code}: {r.text[:300]}")
        parts, t0 = [], _time.time()
        try:
            for line in r.iter_lines():
                if cancel.requested():
                    raise cancel.Cancelled()
                if _time.time() - t0 > self.timeout:
                    raise ProviderUnavailable(f"Ollama took longer than {self.timeout} s")
                if not line:
                    continue
                try:
                    msg = _json.loads(line)
                except ValueError:
                    continue
                if msg.get("error"):
                    raise ProviderUnavailable(f"Ollama error: {msg['error']}")
                parts.append((msg.get("message") or {}).get("content", ""))
                if self.on_text is not None:
                    try:
                        self.on_text("".join(parts))
                    except Exception:  # noqa: BLE001  (a display callback must never stop the model)
                        pass
                if msg.get("done"):
                    break
        except cancel.Cancelled:
            raise
        except ProviderUnavailable:
            raise
        except Exception as e:  # noqa: BLE001
            raise ProviderUnavailable(f"Ollama request failed: {e}") from e
        finally:
            r.close()
        return "".join(parts)

    def complete_json(self, system: str, user: str, max_tokens: int = 1500) -> dict:
        return self._complete_json(self._call, system, user, max_tokens)


@register("llm", "openai")
class OpenAICompatibleLLM(LLM, _JSONRetryMixin):
    def __init__(self, model: str = "gpt-4o-mini", base_url: str = "https://api.openai.com/v1", api_key: str = "",
                 temperature: float = 0.3, timeout_seconds: int = 120, **_):
        import requests

        if not api_key and "localhost" not in base_url and "127.0.0.1" not in base_url:
            raise ProviderUnavailable("No API key set for the OpenAI-compatible language model")
        self.model, self.base, self.key = model, base_url.rstrip("/"), api_key
        self.temperature, self.timeout = temperature, timeout_seconds
        self.s = requests.Session()

    def _call(self, system: str, user: str, max_tokens: int) -> str:
        body = {"model": self.model, "temperature": self.temperature, "max_tokens": max_tokens,
                "response_format": {"type": "json_object"},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        headers = {"Authorization": f"Bearer {self.key}"} if self.key else {}
        try:
            r = self.s.post(self.base + "/chat/completions", json=body, headers=headers, timeout=self.timeout)
        except Exception as e:
            raise ProviderUnavailable(f"API request failed: {e}") from e
        if r.status_code == 400 and "response_format" in r.text:
            body.pop("response_format")
            r = self.s.post(self.base + "/chat/completions", json=body, headers=headers, timeout=self.timeout)
        if r.status_code >= 400:
            raise ProviderUnavailable(f"API error {r.status_code}: {r.text[:300]}")
        return r.json()["choices"][0]["message"]["content"]

    def complete_json(self, system: str, user: str, max_tokens: int = 1500) -> dict:
        return self._complete_json(self._call, system, user, max_tokens)


@register("llm", "rules")
class RulesOnly(LLM):
    def __init__(self, **_):
        pass

    def complete_json(self, system: str, user: str, max_tokens: int = 1500) -> dict:
        raise ProviderUnavailable("Rule-based mode (no language model selected)")
