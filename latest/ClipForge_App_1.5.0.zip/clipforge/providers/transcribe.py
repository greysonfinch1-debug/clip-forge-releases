"""Transcription backends.

* ``parakeet``  – NVIDIA Parakeet TDT 0.6B (int8) through sherpa-onnx. English, punctuated,
  token timestamps, fast on CPU. Speech regions are found with Silero VAD first, so music
  and silence in long streams are skipped and memory stays flat.
* ``faster-whisper`` – OpenAI Whisper via CTranslate2. Multilingual, word timestamps,
  best with an NVIDIA GPU. Audio is fed in chunks so multi-hour files never load fully.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import numpy as np

from ..core.ffmpeg import iter_wav_chunks
from ..core.models import Sentence, Transcript, Word
from .base import (CancelFn, ProgressFn, ProviderUnavailable, Transcriber, download_file, extract_tar,
                   register)

SHERPA_RELEASE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
PARAKEET_DIR = "sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8"


# ----------------------------------------------------------------------------- sentence building

_END = re.compile(r"[.!?]+[\"')\]]*$")


def words_to_sentences(words: list[Word], max_words: int = 28, pause: float = 0.85) -> list[Sentence]:
    sentences: list[Sentence] = []
    cur: list[Word] = []

    def flush():
        if cur:
            text = " ".join(w.text for w in cur).strip()
            text = re.sub(r"\s+([,.!?;:])", r"\1", text)
            sentences.append(Sentence(idx=len(sentences), start=cur[0].start, end=cur[-1].end, text=text,
                                      words=list(cur)))
            cur.clear()

    for i, w in enumerate(words):
        if cur and (w.start - cur[-1].end) > pause:
            flush()
        cur.append(w)
        if _END.search(w.text) or len(cur) >= max_words:
            flush()
    flush()
    return sentences


def dedupe_words(words: list[Word]) -> list[Word]:
    """Remove words decoded twice where padded speech segments overlap."""
    out: list[Word] = []
    for w in words:
        dup = False
        for p in out[-4:]:
            if abs(p.start - w.start) < 0.3 and p.text.lower().strip(".,!?") == w.text.lower().strip(".,!?"):
                dup = True
                break
        if not dup:
            out.append(w)
    return out


# ----------------------------------------------------------------------------- Parakeet

@register("transcriber", "parakeet")
class ParakeetTranscriber(Transcriber):
    def __init__(self, models_dir: str, threads: int = 0, progress: ProgressFn = None, **_):
        try:
            import sherpa_onnx  # noqa: F401
        except ImportError as e:
            raise ProviderUnavailable("sherpa-onnx is not installed") from e
        self.models_dir = Path(models_dir)
        self.threads = threads or max(1, min(8, (os.cpu_count() or 2)))
        self._ensure_models(progress)
        import sherpa_onnx

        d = self.models_dir / PARAKEET_DIR
        self.rec = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=str(d / "encoder.int8.onnx"), decoder=str(d / "decoder.int8.onnx"),
            joiner=str(d / "joiner.int8.onnx"), tokens=str(d / "tokens.txt"),
            model_type="nemo_transducer", num_threads=self.threads)
        cfg = sherpa_onnx.VadModelConfig()
        cfg.silero_vad.model = str(self.models_dir / "silero_vad.onnx")
        cfg.silero_vad.min_silence_duration = 0.35
        cfg.silero_vad.min_speech_duration = 0.2
        cfg.silero_vad.max_speech_duration = 25.0
        cfg.silero_vad.threshold = 0.45
        cfg.sample_rate = 16000
        cfg.num_threads = 1
        self._vad_cfg = cfg

    def _ensure_models(self, progress: ProgressFn):
        from ..model_manager import ModelError, ensure

        try:
            ensure("parakeet", self.models_dir, progress)
            ensure("vad", self.models_dir, progress)
        except ModelError as e:
            raise ProviderUnavailable(str(e)) from e

    def transcribe(self, wav_path: str, progress: ProgressFn = None, cancel: CancelFn = None) -> Transcript:
        import sherpa_onnx
        import soundfile as sf

        total = sf.info(wav_path).duration or 1.0
        vad = sherpa_onnx.VoiceActivityDetector(self._vad_cfg, buffer_size_in_seconds=120)
        words: list[Word] = []
        window = self._vad_cfg.silero_vad.window_size

        from ..core.ffmpeg import read_wav_segment

        def drain():
            while not vad.empty():
                if cancel and cancel():          # stop within one sentence, not one minute of audio
                    raise ProviderUnavailable("Cancelled")
                seg = vad.front
                start = seg.start / 16000.0
                dur = len(seg.samples) / 16000.0
                vad.pop()
                # VAD trims speech onsets slightly; re-read with padding so first words aren't lost
                a = max(0.0, start - 0.35)
                samples, _sr = read_wav_segment(wav_path, a, start + dur + 0.25)
                words.extend(self._decode(samples, a))

        for t0, chunk in iter_wav_chunks(wav_path, 60.0):
            if cancel and cancel():
                raise ProviderUnavailable("Cancelled")
            for i in range(0, len(chunk) - window + 1, window):
                vad.accept_waveform(chunk[i:i + window])
            drain()
            if progress:
                progress(min(0.99, (t0 + 60.0) / total), "Transcribing speech")
        vad.flush()
        drain()
        words.sort(key=lambda w: w.start)
        return Transcript(language="en", sentences=words_to_sentences(dedupe_words(words)), backend="parakeet")

    def _decode(self, samples: np.ndarray, offset: float) -> list[Word]:
        if len(samples) < 1600:
            return []
        s = self.rec.create_stream()
        s.accept_waveform(16000, samples)
        self.rec.decode_stream(s)
        r = s.result
        toks, ts = list(r.tokens), list(r.timestamps)
        seg_end = offset + len(samples) / 16000.0
        words: list[Word] = []
        cur_text, cur_start, cur_last = "", None, None
        for i, (tok, t) in enumerate(zip(toks, ts)):
            t_abs = offset + float(t)
            starts_word = tok.startswith(" ") or tok.startswith("▁") or cur_start is None
            piece = tok.replace("▁", " ")
            if starts_word and cur_text.strip():
                words.append(Word(cur_text.strip(), cur_start, t_abs))
                cur_text, cur_start = "", None
            if cur_start is None:
                cur_start = t_abs
            cur_text += piece
            cur_last = t_abs
        if cur_text.strip():
            end = min(seg_end, (cur_last or cur_start) + 0.45)
            words.append(Word(cur_text.strip(), cur_start, max(end, cur_start + 0.08)))
        # tighten each word's end to at most ~0.6 s so pauses remain visible
        for w in words:
            w.end = min(w.end, w.start + 0.9)
        return words


# ----------------------------------------------------------------------------- faster-whisper

@register("transcriber", "faster-whisper")
class FasterWhisperTranscriber(Transcriber):
    def __init__(self, model: str = "small", device: str = "auto", language: str = "en",
                 chunk_seconds: int = 300, threads: int = 0, models_dir: str = "", **_):
        try:
            from faster_whisper import WhisperModel  # type: ignore
        except ImportError as e:
            raise ProviderUnavailable("faster-whisper is not installed (pip install faster-whisper)") from e
        if device == "auto":
            device = "cuda" if _cuda_available() else "cpu"
        compute = "float16" if device == "cuda" else "int8"
        try:
            self.model = WhisperModel(model, device=device, compute_type=compute, cpu_threads=threads or 0,
                                      download_root=os.path.join(models_dir, "whisper") if models_dir else None)
        except Exception as e:
            raise ProviderUnavailable(f"Could not load Whisper model '{model}': {e}") from e
        self.language = language or None
        self.chunk = chunk_seconds

    def transcribe(self, wav_path: str, progress: ProgressFn = None, cancel: CancelFn = None) -> Transcript:
        import soundfile as sf

        total = sf.info(wav_path).duration or 1.0
        overlap = 2.0
        words: list[Word] = []
        for t0, chunk in iter_wav_chunks(wav_path, self.chunk, overlap):
            if cancel and cancel():
                raise ProviderUnavailable("Cancelled")
            segs, _info = self.model.transcribe(chunk, language=self.language, word_timestamps=True,
                                                vad_filter=True, beam_size=5, condition_on_previous_text=False)
            keep_from = t0 + (overlap if t0 > 0 else 0.0)
            for seg in segs:
                for w in seg.words or []:
                    ws, we = t0 + w.start, t0 + w.end
                    if ws < keep_from - 1e-3:
                        continue  # overlap region already covered by the previous chunk
                    words.append(Word(w.word.strip(), ws, we, float(w.probability)))
            if progress:
                progress(min(0.99, (t0 + self.chunk) / total), "Transcribing speech")
        words.sort(key=lambda w: w.start)
        return Transcript(language=self.language or "auto", sentences=words_to_sentences(words),
                          backend="faster-whisper")


def _cuda_available() -> bool:
    try:
        import ctranslate2  # type: ignore

        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False
