"""Visual understanding backends.

* ``clip`` (VisionEncoder) – open_clip image/text embeddings. Every sampled frame is
  embedded once and cached; any future topic is matched against those cached embeddings
  without touching the video again.
* ``ollama`` (FrameCaptioner) – a local vision-language model (e.g. Qwen2.5-VL, LLaVA,
  Gemma 3) that describes the keyframes of the top candidates in words, so the language
  model can judge what actually happens on screen.
"""
from __future__ import annotations

import base64
import os
from pathlib import Path

import numpy as np

from .base import FrameCaptioner, ProviderUnavailable, VisionEncoder, register


def _online() -> None:
    os.environ.pop("HF_HUB_OFFLINE", None)
    try:
        import huggingface_hub.constants as c  # type: ignore

        c.HF_HUB_OFFLINE = False
    except Exception:  # noqa: BLE001
        pass


def clip_model_id(model: str, pretrained: str) -> str:
    """The id ClipEncoder reports, known without loading it (cached analysis is keyed by it)."""
    return f"clip:{model}:{None if pretrained in ('', 'none') else pretrained}"


def _hf_cached(models_dir: str) -> bool:
    d = Path(models_dir) / "clip" if models_dir else None
    return bool(d and d.is_dir() and any(d.glob("models--*/snapshots/*/*")))


@register("vision", "clip")
class ClipEncoder(VisionEncoder):
    def __init__(self, model: str = "ViT-B-32", pretrained: str = "laion2b_s34b_b79k", device: str = "auto",
                 models_dir: str = "", **_):
        # weights already downloaded: load them without asking HuggingFace first (each start-up
        # otherwise made several network requests, seconds on a slow connection; see the PC's log)
        offline = _hf_cached(models_dir) and "HF_HUB_OFFLINE" not in os.environ
        if offline:
            os.environ["HF_HUB_OFFLINE"] = "1"
            try:      # already imported by another model: its constant was read at import time
                import huggingface_hub.constants as _c  # type: ignore

                _c.HF_HUB_OFFLINE = True
            except Exception:  # noqa: BLE001
                pass
        try:
            import open_clip  # type: ignore
            import torch  # type: ignore
        except ImportError as e:
            raise ProviderUnavailable("open_clip_torch / torch are not installed") from e
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
            if device == "cuda":
                # don't fill a GPU that's nearly full (a game, Ollama…): CLIP needs ~1.5 GB
                try:
                    free, _total = torch.cuda.mem_get_info()
                    if free < 1500 * 2**20:
                        device = "cpu"
                except Exception:  # noqa: BLE001
                    pass
        if device == "cuda":
            try:
                torch.set_num_threads(max(1, torch.get_num_threads()))
            except Exception:  # noqa: BLE001
                pass
        else:
            from ..resources import ai_threads

            torch.set_num_threads(ai_threads())
        if pretrained in ("", "none"):  # untrained weights: only for speed benchmarks / tests
            pretrained = None
        self.device = device
        def _load():
            return open_clip.create_model_and_transforms(model, pretrained=pretrained, device=device,
                                                         cache_dir=(models_dir + "/clip") if models_dir else None)
        try:
            try:
                self.model, _, self.preprocess = _load()
            except Exception:
                if not offline:
                    raise
                _online()                     # something was missing locally: allow the download
                self.model, _, self.preprocess = _load()
        except Exception as e:
            raise ProviderUnavailable(f"Could not load CLIP model {model}/{pretrained}: {e}") from e
        finally:
            if offline:
                _online()
        self.model.eval()
        self.tokenizer = open_clip.get_tokenizer(model)
        self._id = f"clip:{model}:{pretrained}"
        self.torch = torch

    @property
    def model_id(self) -> str:
        return self._id

    def encode_images(self, images: list[np.ndarray]) -> np.ndarray:
        from PIL import Image

        torch = self.torch
        if not images:
            return np.zeros((0, 512), np.float32)
        batch = torch.stack([self.preprocess(Image.fromarray(im)) for im in images]).to(self.device)
        with torch.no_grad():
            feats = self.model.encode_image(batch)
            feats = feats / feats.norm(dim=-1, keepdim=True)
        return feats.float().cpu().numpy()

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        """Text embeddings; each text is encoded once per session (the same descriptions come back
        when a part is re-matched, a plan is redone or a topic is searched again)."""
        cache = self.__dict__.setdefault("_text_cache", {})
        todo = list(dict.fromkeys(t for t in texts if t not in cache))
        if todo:
            torch = self.torch
            toks = self.tokenizer(todo).to(self.device)
            with torch.no_grad():
                feats = self.model.encode_text(toks)
                feats = feats / feats.norm(dim=-1, keepdim=True)
            for t, f in zip(todo, feats.float().cpu().numpy()):
                cache[t] = f
            if len(cache) > 20000:          # bounded: drop the oldest
                for k in list(cache)[:5000]:
                    cache.pop(k, None)
        if not texts:
            return np.zeros((0, 512), np.float32)
        return np.stack([cache[t] for t in texts]).astype(np.float32)


@register("captioner", "ollama")
class OllamaCaptioner(FrameCaptioner):
    def __init__(self, model: str = "qwen2.5vl:7b", base_url: str = "http://localhost:11434", timeout: int = 240, **_):
        import requests

        self.model, self.base, self.timeout = model, base_url.rstrip("/"), timeout
        self.s = requests.Session()
        try:
            r = self.s.get(self.base + "/api/tags", timeout=10)
            r.raise_for_status()
            names = {m.get("name", "") for m in r.json().get("models", [])}
            from .llm import ollama_has_model

            if not ollama_has_model(names, model):
                raise ProviderUnavailable(f"Vision model '{model}' is not pulled in Ollama. Run: ollama pull {model}")
        except ProviderUnavailable:
            raise
        except Exception as e:
            raise ProviderUnavailable(f"Ollama is not running at {self.base}: {e}") from e

    def describe(self, image_paths: list[str], instruction: str) -> str:
        imgs = []
        for p in image_paths:
            with open(p, "rb") as f:
                imgs.append(base64.b64encode(f.read()).decode())
        from .llm import KEEP_ALIVE

        body = {"model": self.model, "stream": False, "keep_alive": KEEP_ALIVE,
                "options": {"temperature": 0.1, "num_predict": 160},
                "messages": [{"role": "user", "content": instruction, "images": imgs}]}
        r = self.s.post(self.base + "/api/chat", json=body, timeout=self.timeout)
        if r.status_code >= 400:
            raise ProviderUnavailable(f"Vision model error {r.status_code}: {r.text[:200]}")
        return (r.json().get("message", {}).get("content") or "").strip()
