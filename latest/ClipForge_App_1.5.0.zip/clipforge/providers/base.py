"""Interfaces for every replaceable AI component, plus a small registry.

To upgrade a component later (a better transcriber, a stronger vision model, a different
LLM or voice), write a class implementing the matching interface, register it with
``@register("kind", "name")`` and choose it in Settings. Nothing else changes.
"""
from __future__ import annotations

import os
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, Optional

import numpy as np

ProgressFn = Optional[Callable[[float, str], None]]
CancelFn = Optional[Callable[[], bool]]


class ProviderUnavailable(RuntimeError):
    """Raised when a provider cannot run (missing package, model, server, key)."""


class MalformedResponse(ProviderUnavailable):
    """The model answered, but not with usable JSON (only this request falls back)."""


# ----------------------------------------------------------------------------- interfaces

class Transcriber(ABC):
    name = "base"

    @abstractmethod
    def transcribe(self, wav_path: str, progress: ProgressFn = None, cancel: CancelFn = None):
        """Return clipforge.core.models.Transcript with word timestamps."""


class TextEmbedder(ABC):
    name = "base"

    @abstractmethod
    def embed(self, texts: list[str]) -> np.ndarray:
        """L2-normalised embeddings, shape (n, d)."""


class VisionEncoder(ABC):
    """Joint image/text embedding model (CLIP-style) used to match frames to the topic."""
    name = "base"

    @abstractmethod
    def encode_images(self, images: list[np.ndarray]) -> np.ndarray:
        """RGB uint8 arrays -> L2-normalised embeddings (n, d)."""

    @abstractmethod
    def encode_texts(self, texts: list[str]) -> np.ndarray:
        """Text prompts -> L2-normalised embeddings in the same space (n, d)."""

    @property
    def model_id(self) -> str:
        return self.name


class FrameCaptioner(ABC):
    """Vision-language model that describes keyframes in words (used on top candidates only)."""
    name = "base"

    @abstractmethod
    def describe(self, image_paths: list[str], instruction: str) -> str:
        ...


class AudioTagger(ABC):
    """Sound-event model (AudioSet classes): laughter, screams, sirens, explosions, music…"""
    name = "base"

    @property
    def model_id(self) -> str:
        return self.name

    @abstractmethod
    def labels(self) -> list[str]:
        ...

    @abstractmethod
    def tag(self, samples: np.ndarray, sr: int) -> np.ndarray:
        """Probabilities for every label for one short window (float32, len(labels()))."""


class Diarizer(ABC):
    """Who-spoke-when: returns [(start, end, speaker_index)]."""
    name = "base"

    @property
    def model_id(self) -> str:
        return self.name

    @abstractmethod
    def diarize(self, samples: np.ndarray, sr: int, progress=None) -> list[tuple[float, float, int]]:
        ...


class LLM(ABC):
    name = "base"
    on_text = None            # optional callback: the answer so far, while it streams in (Ollama)

    def warm_up(self) -> None:
        """Load the model ahead of the first request (no-op where that doesn't apply)."""

    @abstractmethod
    def complete_json(self, system: str, user: str, max_tokens: int = 1500) -> dict:
        """Return a parsed JSON object. Raise ProviderUnavailable if the model cannot be reached."""


class TTS(ABC):
    name = "base"

    @abstractmethod
    def voices(self) -> list[str]:
        ...

    @abstractmethod
    def synthesize(self, text: str, voice: str, speed: float = 1.0) -> tuple[np.ndarray, int]:
        ...


# ----------------------------------------------------------------------------- registry

_REGISTRY: dict[str, dict[str, type]] = {}


def register(kind: str, name: str):
    def deco(cls):
        _REGISTRY.setdefault(kind, {})[name] = cls
        cls.name = name
        return cls
    return deco


def available(kind: str) -> list[str]:
    return sorted(_REGISTRY.get(kind, {}).keys())


def create(kind: str, name: str, **kwargs):
    try:
        cls = _REGISTRY[kind][name]
    except KeyError as e:
        raise ProviderUnavailable(f"Unknown {kind} provider '{name}'. Options: {available(kind)}") from e
    return cls(**kwargs)


# ----------------------------------------------------------------------------- model files

def download_file(url: str, dst: Path, progress: ProgressFn = None, label: str = "Downloading model") -> Path:
    """Download once into the models folder (atomic)."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    tmp = dst.with_suffix(dst.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "ClipForge/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                buf = r.read(1 << 20)
                if not buf:
                    break
                f.write(buf)
                done += len(buf)
                if progress and total:
                    progress(done / total, f"{label} ({done >> 20} / {total >> 20} MB)")
    except Exception as e:
        if tmp.exists():
            tmp.unlink()
        raise ProviderUnavailable(f"Could not download {url}: {e}") from e
    os.replace(tmp, dst)
    return dst


def extract_tar(archive: Path, dest_dir: Path) -> None:
    import tarfile

    with tarfile.open(archive) as t:
        root = dest_dir.resolve()
        for m in t.getmembers():
            target = (dest_dir / m.name).resolve()
            if not str(target).startswith(str(root)):
                raise ProviderUnavailable("Unsafe path in model archive")
        t.extractall(dest_dir)
