"""The production-brief window (AI prompt expansion).

Shows the user's prompt exactly as typed (read-only, never changed) and, beside it, the
production brief the language model is writing - live while it streams in. The user can edit the
brief, ask for a different one, approve it, or make the video from the original prompt alone.
When no language model is available it says why and how to fix it, and offers to continue with
the original prompt; it never shows a rule-based paraphrase as an expansion.
"""
from __future__ import annotations

import json
import re

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QVBoxLayout)

from ..core.models import ProductionBrief
from ..creative import expand as ex


class Streamer(QObject):
    """Carries the brief's text from the worker thread to the window while it's being written."""
    text = Signal(str)


def readable_partial(raw: str) -> str:
    """The half-written JSON as readable lines ("Hook: …") while it streams in."""
    s = raw.strip()
    try:
        return ex.render(ex.from_dict(json.loads(s), ""))
    except Exception:  # noqa: BLE001  (incomplete: show what's there so far)
        pass
    out = []
    for m in re.finditer(r'"([a-z_]+)"\s*:\s*("(?:[^"\\]|\\.)*"?|\d+(?:\.\d+)?)', s):
        key, val = m.group(1), m.group(2).strip('"')
        lab = dict(ex.LABELS).get(key) or dict(ex.LISTS).get(key) or key.replace("_", " ").capitalize()
        out.append(f"{lab}: {val}")
    for m in re.finditer(r'"(points|visuals|facts_known|facts_to_check|assumptions)"\s*:\s*\[([^\]]*)', s):
        items = [x.strip().strip('"') for x in re.findall(r'"(?:[^"\\]|\\.)*"', m.group(2))]
        if items:
            out.append(f"{m.group(1).replace('_', ' ').capitalize()}: " + "; ".join(items))
    return "\n".join(out)


class BriefDialog(QDialog):
    APPROVE, REGENERATE, ORIGINAL, RETRY = "approve", "regenerate", "original", "retry"

    def __init__(self, parent, prompt: str, model: str):
        super().__init__(parent)
        self.setWindowTitle("Production brief")
        self.resize(820, 680)
        self.prompt, self.model = prompt, model
        self.choice = ""
        self.brief: ProductionBrief | None = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>Your prompt</b> (kept exactly as you typed it - it is never changed):"))
        self.orig = QPlainTextEdit(prompt)
        self.orig.setReadOnly(True)
        self.orig.setMaximumHeight(70)
        self.orig.setObjectName("originalPrompt")
        lay.addWidget(self.orig)
        self.status = QLabel(f"{model} is writing a production brief from your prompt…")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setObjectName("expandedBrief")
        lay.addWidget(self.text, 1)
        self.note = QLabel("")
        self.note.setWordWrap(True)
        self.note.setObjectName("hint")
        lay.addWidget(self.note)
        row = QHBoxLayout()
        self.b_approve = QPushButton("Approve and make the video")
        self.b_regen = QPushButton("Write a different brief")
        self.b_orig = QPushButton("Use my original prompt only")
        self.b_retry = QPushButton("Try again")
        self.b_cancel = QPushButton("Cancel")
        for b in (self.b_approve, self.b_regen, self.b_retry, self.b_orig):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.b_cancel)
        lay.addLayout(row)
        self.b_approve.clicked.connect(lambda: self._done(self.APPROVE))
        self.b_regen.clicked.connect(lambda: self._done(self.REGENERATE))
        self.b_orig.clicked.connect(lambda: self._done(self.ORIGINAL))
        self.b_retry.clicked.connect(lambda: self._done(self.RETRY))
        self.b_cancel.clicked.connect(self.reject)
        self.streamer = Streamer()
        self.streamer.text.connect(self.on_text)
        self._buttons(writing=True)

    def _buttons(self, writing=False, ok=False, failed=False):
        self.b_approve.setVisible(ok)
        self.b_regen.setVisible(ok)
        self.b_retry.setVisible(failed)
        self.b_orig.setVisible(ok or failed)
        self.b_cancel.setText("Stop" if writing else "Cancel")

    def on_text(self, raw: str):
        self.text.setPlainText(readable_partial(raw))
        self.text.verticalScrollBar().setValue(self.text.verticalScrollBar().maximum())

    def show_brief(self, b: ProductionBrief):
        self.brief = b
        self.text.setPlainText(b.text)
        self.text.setReadOnly(False)
        self.status.setText(f"Production brief written by {b.model or self.model}" +
                            (" earlier (reused: same prompt, video and model - click “Write a different brief” "
                             "for a new one)" if getattr(b, "reused", False) else f" in {b.seconds:.0f} s") +
                            ". Edit anything below, then approve. Your prompt above stays as you typed it.")
        self.note.setText("“Facts to check” are things the video must not state as fact unless your notes or "
                          "sources confirm them. “Creative decisions made” are the AI's choices where your prompt "
                          "didn't say - change them freely.")
        self._buttons(ok=True)

    def show_unavailable(self, reason: str, model: str):
        self.text.setReadOnly(True)
        self.status.setText("<b>Your prompt could not be expanded.</b> No expansion was made - nothing below "
                            "is AI output.")
        how = []
        r = reason.lower()
        if "not running" in r or "connection" in r or "refused" in r:
            how.append("Start Ollama (open the Ollama app from the Start menu, or run  ollama serve  in a "
                       "terminal), then click Try again.")
        if "not pulled" in r or "ollama pull" in r:
            how.append(f"Download the model: open a terminal (Windows key, type  cmd, Enter) and run\n"
                       f"    ollama pull {model}\nor use AI Models → Download missing Ollama models. Then click "
                       f"Try again.")
        if "rule-based" in r or "no ai language model" in r:
            how.append("Choose Ollama as the language model in Settings, then click Try again.")
        if "longer than" in r:
            how.append("The model took too long. Close other heavy programs, or pick a smaller model in "
                       "Settings, then click Try again.")
        if not how:
            how.append("Check that Ollama is running and the model is downloaded (AI Models page), then click "
                       "Try again.")
        self.text.setPlainText(f"Why: {reason}\n\nHow to fix it:\n" + "\n\n".join(how) +
                               "\n\nOr click “Use my original prompt only”: the video is then made from your prompt "
                               "as typed, without an expanded brief.")
        self._buttons(failed=True)

    def edited(self) -> ProductionBrief:
        """The approved brief, with the user's edits (the original prompt is untouched)."""
        assert self.brief is not None
        txt = self.text.toPlainText()
        b = self.brief if txt.strip() == (self.brief.text or "").strip() else ex.parse_edited(txt, self.brief)
        b.approved = True
        b.original_prompt = self.prompt
        return b

    def _done(self, choice: str):
        self.choice = choice
        self.accept()
