"""Screens for narration-driven and hybrid videos.

  CreativeOptions  page 1: video type, style, pacing, your script / notes / source links, and the
                   footage library (extra videos, what each is for, and its permission)
  PlanPage         step 2 for these videos: "Script & Visuals" — every part of the narration, what
                   should be on screen, the footage picked (with thumbnails) and why; rewrite one
                   part, find different footage for one part or one shot, change pacing or style,
                   keep (lock) footage you like. Other parts are never touched.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit,
                               QMessageBox, QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QToolButton,
                               QVBoxLayout, QWidget)

from ..core.models import RIGHTS_BASES, RightsRecord, Section
from ..creative import workflow
from ..creative.brief import MODES, STYLE_LABELS
from ..creative.library import ROLES


def _hint(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("hint")
    lb.setWordWrap(True)
    return lb


# ====================================================================== page 1 options
class CreativeOptions(QWidget):
    """Type / style / pacing row, plus a collapsible 'script, sources and more footage' panel."""

    def __init__(self, page):
        super().__init__()
        self.page, self.win = page, page.win
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        row.addWidget(QLabel("Video type"))
        self.mode = QComboBox()
        for k, lab in MODES.items():
            self.mode.addItem(lab, k)
        self.mode.setToolTip("Automatic reads your prompt: \"explain…\", \"use gameplay as background\" → "
                             "narration-driven; \"the funniest moments\" → clip-driven; both → hybrid.")
        row.addWidget(self.mode, 2)
        row.addSpacing(10)
        row.addWidget(QLabel("Narration style"))
        self.style = QComboBox()
        for k, lab in STYLE_LABELS.items():
            self.style.addItem(lab, k)
        row.addWidget(self.style, 1)
        row.addSpacing(10)
        row.addWidget(QLabel("Pacing"))
        self.pacing = QComboBox()
        for k, lab in (("", "Automatic"), ("slow", "Slow (longer shots)"), ("normal", "Normal"),
                       ("fast", "Fast (quick cuts)")):
            self.pacing.addItem(lab, k)
        row.addWidget(self.pacing, 1)
        v.addLayout(row)
        self.more_btn = QToolButton()
        self.more_btn.setText("▸ Your script, sources and more footage (optional)")
        self.more_btn.setCheckable(True)
        self.more_btn.setStyleSheet("QToolButton{border:none;color:#9ab;padding:2px 0;}")
        self.more_btn.toggled.connect(self._toggle)
        v.addWidget(self.more_btn)
        self.more = QWidget()
        m = QVBoxLayout(self.more)
        m.setContentsMargins(12, 0, 0, 0)
        self.script = QPlainTextEdit()
        self.script.setPlaceholderText("Paste your own narration script here (one paragraph per part), or notes and "
                                       "facts the narration should use. Leave empty to let the AI write it.")
        self.script.setFixedHeight(90)
        m.addWidget(self.script)
        self.use_script = QCheckBox("Use this as the narration, word for word (otherwise it's treated as notes/facts "
                                    "for the AI)")
        m.addWidget(self.use_script)
        self.urls = QLineEdit()
        self.urls.setPlaceholderText("Source links the narration may use (optional): https://… https://…")
        m.addWidget(self.urls)
        m.addWidget(_hint("With sources, the AI uses only their facts and the description credits them. Without, "
                          "facts come from the AI's general knowledge and are marked \"check before publishing\"; "
                          "anything unconfirmed (an unreleased game, rumours) is marked speculation."))
        lib = QGroupBox("Footage library — extra videos the narration-driven parts can use")
        lv = QVBoxLayout(lib)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Video", "Used as", "Permission"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setFixedHeight(120)
        lv.addWidget(self.table)
        br = QHBoxLayout()
        b = QPushButton("Add video files…")
        b.clicked.connect(self.add_files)
        br.addWidget(b)
        b = QPushButton("Remove selected")
        b.clicked.connect(self.remove)
        br.addWidget(b)
        br.addStretch(1)
        lv.addLayout(br)
        lv.addWidget(_hint("The main video (above) is always in the library. Only videos whose permission is "
                           "recorded are ever shown. Being publicly visible online doesn't make a video free to "
                           "reuse."))
        m.addWidget(lib)
        self.more.hide()
        v.addWidget(self.more)

    def _toggle(self, on: bool):
        self.more.setVisible(on)
        self.more_btn.setText(("▾ " if on else "▸ ") + "Your script, sources and more footage (optional)")

    def values(self) -> dict:
        return {"mode": self.mode.currentData(), "style": self.style.currentData(),
                "pacing": self.pacing.currentData(), "script": self.script.toPlainText(),
                "use_my_script": self.use_script.isChecked(),
                "urls": [u for u in self.urls.text().replace(",", " ").split() if u.startswith("http")]}

    def clear(self):
        self.mode.setCurrentIndex(0)
        self.style.setCurrentIndex(0)
        self.pacing.setCurrentIndex(0)
        self.script.clear()
        self.use_script.setChecked(False)
        self.urls.clear()
        self.table.setRowCount(0)

    def refresh(self):
        pr = self.page.p.project
        b = pr.plan.brief
        if b.user_script:
            self.script.setPlainText(b.user_script)
            self.use_script.setChecked(True)
        self.table.setRowCount(len(pr.library))
        for r, it in enumerate(pr.library):
            self.table.setItem(r, 0, QTableWidgetItem(it.title or it.path or it.url))
            cb = QComboBox()
            for k, lab in ROLES.items():
                cb.addItem(lab, k)
            cb.setCurrentIndex(max(0, cb.findData(it.role)))
            cb.currentIndexChanged.connect(lambda _i, it=it, cb=cb: self._set_role(it, cb.currentData()))
            self.table.setCellWidget(r, 1, cb)
            from ..core.cache import SourceCache

            rd = SourceCache(it.source_id).load_json("rights.json") or {}
            ok = bool(rd.get("confirmed") and rd.get("basis"))
            self.table.setItem(r, 2, QTableWidgetItem(f"{RIGHTS_BASES.get(rd.get('basis'), '?')[:40]}" if ok
                                                      else "NOT RECORDED — won't be used"))

    def _set_role(self, it, role: str):
        it.role = role
        self.page.p._footage = self.page.p._index = None      # the next footage choice uses the new role
        self.win.schedule_save()

    def add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Add videos to the footage library", str(Path.home()),
                                                "Video (*.mp4 *.mkv *.mov *.webm *.avi *.m4v)")
        if not paths:
            return
        dlg = RightsDialog(self, len(paths))
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        rights, role = dlg.result_rights(), dlg.role.currentData()
        p = self.page.p

        def job(progress=None):
            for k, path in enumerate(paths):
                workflow.add_library_video(p, path=path, role=role, rights=rights, progress=progress)
            workflow.footage(p, progress)          # analyse them now (cached for every later use)
            return len(paths)
        self.win.run(job, lambda n: (self.refresh(), self.win.save_project(),
                                     self.win.statusBar().showMessage(f"Added {n} video(s) to the library", 6000)),
                     title="Adding footage", steps=["ingest", "transcript", "audio", "visual"])

    def remove(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        pr = self.page.p.project
        for r in rows:
            if 0 <= r < len(pr.library):
                del pr.library[r]
        self.page.p._footage = self.page.p._index = None
        self.refresh()


class RightsDialog(QDialog):
    """Permission for videos added to the library (the same record the main video needs)."""

    def __init__(self, parent, n: int):
        super().__init__(parent)
        self.setWindowTitle("Permission for the added videos")
        f = QFormLayout(self)
        f.addRow(QLabel(f"How may you use {'this video' if n == 1 else f'these {n} videos'}?"))
        self.basis = QComboBox()
        self.basis.addItem("— choose —", "")
        for k, lab in RIGHTS_BASES.items():
            self.basis.addItem(lab, k)
        f.addRow("Permission", self.basis)
        self.creator = QLineEdit()
        self.creator.setPlaceholderText("Creator / owner (and licence, e.g. CC BY 3.0)")
        f.addRow("Creator", self.creator)
        self.role = QComboBox()
        for k, lab in ROLES.items():
            self.role.addItem(lab, k)
        self.role.setCurrentIndex(1)
        f.addRow("Use as", self.role)
        self.commercial = QCheckBox("The permission covers monetized use")
        f.addRow("", self.commercial)
        self.publisher = QCheckBox("Not game footage, or I checked the game publisher's video policy")
        self.publisher.setToolTip("Only matters for monetized videos, like for the main video")
        f.addRow("", self.publisher)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _ok(self):
        if not self.basis.currentData():
            QMessageBox.information(self, "ClipForge", "Choose how you have permission to use these videos. "
                                    "Videos without a recorded permission are never used.")
            return
        self.accept()

    def result_rights(self) -> RightsRecord:
        return RightsRecord(basis=self.basis.currentData(), creator=self.creator.text().strip(),
                            commercial_use=self.commercial.isChecked(),
                            game_publisher_ok=self.publisher.isChecked(), confirmed=True)


# ====================================================================== step 2: script & visuals
class PlanPage(QWidget):
    COLS = ["#", "Part", "Narration (edit freely)", "What to show (edit, ';' between)", "Footage chosen", "Keep"]

    def __init__(self, win):
        super().__init__()
        self.setObjectName("page")
        self.win = win
        self.p = win.pipeline
        v = QVBoxLayout(self)
        t = QLabel("2 · Script & Visuals")
        t.setObjectName("h1")
        v.addWidget(t)
        self.info = _hint("")
        v.addWidget(self.info)
        self.warn = QLabel("")
        self.warn.setWordWrap(True)
        self.warn.setStyleSheet("background:#3a2e0a;color:#fbbf24;border:1px solid #6b5310;border-radius:6px;"
                                "padding:6px 10px;")
        self.warn.hide()
        v.addWidget(self.warn)
        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for c, w in ((0, 34), (1, 90), (3, 230), (4, 300), (5, 46)):
            self.table.setColumnWidth(c, w)
        self.table.verticalHeader().setVisible(False)
        self.table.setWordWrap(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.itemSelectionChanged.connect(self.show_thumbs)
        v.addWidget(self.table, 3)
        self.thumbs = QHBoxLayout()
        tw = QWidget()
        tw.setLayout(self.thumbs)
        tw.setFixedHeight(150)
        v.addWidget(tw)
        row = QHBoxLayout()
        for text, fn in (("Rewrite this part with AI…", self.rewrite), ("Find different footage", self.refind),
                         ("Replace one shot…", self.replace_shot), ("Same shot as previous part", self.same_shot),
                         ("Move up", lambda: self.move(-1)),
                         ("Move down", lambda: self.move(1)), ("Add part", self.add_part), ("Delete part", self.delete)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(QLabel("Pacing"))
        self.pacing = QComboBox()
        for k, lab in (("slow", "Slow (longer shots)"), ("normal", "Normal"), ("fast", "Fast (quick cuts)")):
            self.pacing.addItem(lab, k)
        row.addWidget(self.pacing)
        b = QPushButton("Re-pick footage at this pacing")
        b.clicked.connect(self.apply_pacing)
        row.addWidget(b)
        row.addSpacing(16)
        row.addWidget(QLabel("Style"))
        self.style = QComboBox()
        for k, lab in STYLE_LABELS.items():
            if k:
                self.style.addItem(lab, k)
        row.addWidget(self.style)
        b = QPushButton("Rewrite in this style (AI)")
        b.clicked.connect(self.apply_style)
        row.addWidget(b)
        row.addStretch(1)
        nxt = QPushButton("Save → Voice")
        nxt.setObjectName("primary")
        nxt.clicked.connect(lambda: self.win.goto(3))
        row.addWidget(nxt)
        v.addLayout(row)

    # ---- show
    def refresh(self):
        plan = self.p.project.plan
        b = plan.brief
        mode = {"narration": "Narration-driven", "hybrid": "Hybrid"}.get(b.mode, b.mode)
        by = {"llm": "written by the AI", "user": "your script"}.get(self.p.used.get("script"), "-")
        self.info.setText(f"<b>{mode}</b> video ({b.mode_reason}). Style: {b.style or '-'} · pacing: {b.pacing} · "
                          f"narration: {by}. Footage is matched to what each part says; it doesn't have to show the "
                          f"exact thing being said. Edit any part — the others are kept.")
        notes = list(self.p.project.meta.get("match_notes") or [])
        if plan.sources_note and "general knowledge" in plan.sources_note:
            notes.append(plan.sources_note)
        risky = [i + 1 for i, s in enumerate(plan.sections) if "speculation" in s.claims or "general" in s.claims]
        if risky:
            notes.append(f"Parts {', '.join(map(str, risky))} contain facts to check (general knowledge or speculation).")
        self.warn.setText("\n".join("⚠ " + n for n in notes))
        self.warn.setVisible(bool(notes))
        self.pacing.setCurrentIndex(max(0, self.pacing.findData(b.pacing)))
        self.style.setCurrentIndex(max(0, self.style.findData(b.style)))
        titles = self._titles()
        cands = {c.cid: c for c in self.p.project.candidates}
        self.table.blockSignals(True)
        self.table.setRowCount(len(plan.sections))
        for r, s in enumerate(plan.sections):
            def item(text, edit=False):
                it = QTableWidgetItem(text)
                if not edit:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                return it
            self.table.setItem(r, 0, item(str(r + 1)))
            self.table.setItem(r, 1, item(("real moment" if s.kind == "moment" else s.role)
                                          + (f"\n{s.claims}" if s.claims else "")))
            if s.kind == "moment":
                c = cands.get(s.cid)
                said = self.p.transcript.text_between(c.start, c.end)[:160] if (c and self.p.transcript) else ""
                self.table.setItem(r, 2, item(f"[original sound] {said}"))
                self.table.setItem(r, 3, item("—"))
                self.table.setItem(r, 4, item(f"{c.start:.1f}–{c.end:.1f}s of the main video" if c else "?"))
            else:
                self.table.setItem(r, 2, item(s.text, True))
                self.table.setItem(r, 3, item("; ".join(s.visuals), True))
                self.table.setItem(r, 4, item("\n".join(f"{titles.get(sh.source_id, '?')[:22]} {sh.start:.1f}–"
                                                       f"{sh.end:.1f}s · {sh.why}" for sh in s.shots) or "none"))
            keep = QTableWidgetItem("")
            keep.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            keep.setCheckState(Qt.CheckState.Checked if s.shots and all(x.locked for x in s.shots)
                               else Qt.CheckState.Unchecked)
            keep.setToolTip("Keep this footage when footage is picked again (pacing, other parts)")
            self.table.setItem(r, 5, keep)
        self.table.resizeRowsToContents()
        self.table.blockSignals(False)
        if plan.sections and not self.table.selectedIndexes():
            self.table.selectRow(0)

    def _titles(self) -> dict:
        pr = self.p.project
        t = {it.source_id: it.title for it in pr.library}
        if pr.source:
            t[pr.source.source_id] = pr.source.title or "main video"
        return t

    def show_thumbs(self):
        while self.thumbs.count():
            w = self.thumbs.takeAt(0).widget()
            if w:
                w.hide()
                w.deleteLater()
        r = self._row()
        plan = self.p.project.plan
        if r < 0 or r >= len(plan.sections):
            return
        sec = plan.sections[r]
        fl = {f.source_id: f for f in (self.p._footage or [])}
        for k, sh in enumerate(sec.shots[:6]):
            f = fl.get(sh.source_id)
            img = self._thumb(f, sh) if f is not None else None
            lb = QLabel()
            if img:
                lb.setPixmap(QPixmap(img).scaledToHeight(110, Qt.TransformationMode.SmoothTransformation))
            else:
                lb.setText("(no preview)")
            cap = QLabel(f"shot {k + 1}: {sh.duration:.1f}s")
            cap.setObjectName("hint")
            w = QWidget()
            wl = QVBoxLayout(w)
            wl.setContentsMargins(0, 0, 0, 0)
            wl.addWidget(lb)
            wl.addWidget(cap)
            self.thumbs.addWidget(w)
        self.thumbs.addStretch(1)

    def _thumb(self, f, sh) -> str:
        from ..core import ffmpeg as ff
        from ..core.cache import SourceCache

        d = SourceCache(sh.source_id).subdir("thumbs")
        out = d / f"t_{int((sh.start + sh.end) / 2 * 10)}.jpg"
        if not out.exists():
            src = f.src.proxy_path or f.src.path
            try:
                subprocess.run([ff.ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{(sh.start + sh.end) / 2:.2f}", "-i", src,
                                "-frames:v", "1", "-vf", "scale=-2:180", str(out)], timeout=20,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:  # noqa: BLE001
                return ""
        return str(out) if out.exists() else ""

    # ---- edits
    def _row(self) -> int:
        rows = {i.row() for i in self.table.selectedIndexes()}
        return min(rows) if rows else -1

    def commit(self):
        """Keep the table's edits: narration words, what to show, kept footage."""
        plan = self.p.project.plan
        for r, s in enumerate(plan.sections):
            if r >= self.table.rowCount():
                break
            if s.kind == "narration":
                t = (self.table.item(r, 2).text() if self.table.item(r, 2) else s.text).strip()
                if t and t != s.text:
                    s.text, s.edited, s.audio_path, s.duration = t, True, "", 0.0
                vis = self.table.item(r, 3).text() if self.table.item(r, 3) else ""
                new_vis = [x.strip() for x in vis.split(";") if x.strip()]
                if new_vis and new_vis != s.visuals:
                    s.visuals = new_vis
            keep = self.table.item(r, 5)
            lock = keep is not None and keep.checkState() == Qt.CheckState.Checked
            for sh in s.shots:
                sh.locked = lock
        workflow.sync_narration(self.p)

    def _run(self, fn, title):
        self.commit()
        self.win.run(lambda progress=None: fn(), lambda _: (self.refresh(), self.win.save_project()), title=title)

    def rewrite(self):
        r = self._row()
        plan = self.p.project.plan
        if r < 0 or plan.sections[r].kind != "narration":
            QMessageBox.information(self, "ClipForge", "Select a narrated part first.")
            return
        text, ok = QInputDialog.getText(self, "Rewrite this part",
                                        "What should change? (e.g. 'punchier', 'mention the weather', or leave empty)")
        if ok:
            self._run(lambda: workflow.rewrite_section(self.p, r, text.strip()), "Rewriting a part")

    def refind(self):
        r = self._row()
        if r < 0 or self.p.project.plan.sections[r].kind != "narration":
            QMessageBox.information(self, "ClipForge", "Select a narrated part first.")
            return
        self._run(lambda: workflow.find_different_footage(self.p, r), "Finding different footage")

    def replace_shot(self):
        r = self._row()
        plan = self.p.project.plan
        if r < 0 or not plan.sections[r].shots:
            return
        n = len(plan.sections[r].shots)
        k, ok = QInputDialog.getInt(self, "Replace one shot", f"Which shot (1-{n})?", 1, 1, n)
        if ok:
            self._run(lambda: workflow.find_different_footage(self.p, r, k - 1), "Replacing a shot")

    def same_shot(self):
        """Toggle: keep the previous part's picture running through this part (one visual, two parts)."""
        r = self._row()
        secs = self.p.project.plan.sections
        if r <= 0 or secs[r].kind != "narration" or secs[r - 1].kind != "narration" or not secs[r - 1].shots:
            QMessageBox.information(self, "ClipForge", "Select a narrated part that follows another narrated part.")
            return
        secs[r].continue_visual = not secs[r].continue_visual
        title = "Carrying the previous shot on" if secs[r].continue_visual else "Finding footage for this part"
        self._run(lambda: workflow.find_different_footage(self.p, r), title)

    def move(self, d: int):
        self.commit()
        r = self._row()
        secs = self.p.project.plan.sections
        j = r + d
        if 0 <= r < len(secs) and 0 <= j < len(secs):
            secs[r], secs[j] = secs[j], secs[r]
            workflow.sync_narration(self.p)
            self.refresh()
            self.table.selectRow(j)

    def add_part(self):
        self.commit()
        r = self._row()
        secs = self.p.project.plan.sections
        text, ok = QInputDialog.getMultiLineText(self, "Add a part", "Narration for the new part:")
        if not ok or not text.strip():
            return
        from ..creative.narration import visuals_from_text

        s = Section(sid=f"u{len(secs) + 1}", role="point", text=text.strip(), visuals=visuals_from_text(text),
                    edited=True)
        secs.insert(r + 1 if r >= 0 else len(secs), s)
        i = secs.index(s)
        self._run(lambda: workflow.find_different_footage(self.p, i), "Finding footage for the new part")

    def delete(self):
        r = self._row()
        secs = self.p.project.plan.sections
        if 0 <= r < len(secs) and QMessageBox.question(self, "Delete part", f"Delete part {r + 1}?") == \
                QMessageBox.StandardButton.Yes:
            del secs[r]
            workflow.sync_narration(self.p)
            self.refresh()

    def apply_pacing(self):
        pace = self.pacing.currentData()
        self._run(lambda: workflow.change_pacing(self.p, pace), "Re-picking footage")

    def apply_style(self):
        st = self.style.currentData()
        self._run(lambda: workflow.change_tone(self.p, st), "Rewriting the narration")
