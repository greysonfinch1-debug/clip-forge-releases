"""Projects: the project list (open / new / rename / delete), Restart project, crash recovery
and the structured error message."""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout,
                               QHeaderView, QInputDialog, QLabel, QMessageBox, QPushButton, QRadioButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout)

from .. import projects as P
from ..core.storage import human


def _when(t: float) -> str:
    if not t:
        return ""
    d = time.time() - t
    if d < 60:
        return "just now"
    if d < 3600:
        return f"{int(d // 60)} min ago"
    if time.strftime("%Y%m%d", time.localtime(t)) == time.strftime("%Y%m%d"):
        return time.strftime("today %H:%M", time.localtime(t))
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t))


def _status_text(s: str) -> str:
    if s.startswith("running"):
        return "interrupted (" + s.split(":", 1)[-1].strip() + ")"
    return s


class ProjectsDialog(QDialog):
    COLS = ["Name", "Source video", "Topic", "Stage", "Last modified", "Status"]

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("Projects")
        self.resize(1080, 520)
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Your projects. Double-click one to open it. Projects are saved automatically "
                           "every time you move between steps."))
        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hh.setStretchLastSection(True)
        for i, w in enumerate((220, 260, 200, 150, 130)):
            self.table.setColumnWidth(i, w)
        self.table.doubleClicked.connect(self.open_selected)
        v.addWidget(self.table, 1)
        row = QHBoxLayout()
        self.b_new = QPushButton("New project")
        self.b_new.clicked.connect(self.new)
        self.b_open = QPushButton("Open")
        self.b_open.setObjectName("primary")
        self.b_open.clicked.connect(self.open_selected)
        self.b_rename = QPushButton("Rename…")
        self.b_rename.clicked.connect(self.rename)
        self.b_delete = QPushButton("Delete…")
        self.b_delete.clicked.connect(self.delete)
        for b in (self.b_new, self.b_open, self.b_rename, self.b_delete):
            row.addWidget(b)
        row.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        v.addLayout(row)
        self.refresh()

    def refresh(self):
        self.items = P.list_projects()
        cur = self.win.pipeline.project.project_id
        self.table.setRowCount(len(self.items))
        for r, it in enumerate(self.items):
            src = it.source
            if len(src) > 60:
                src = "…" + src[-58:]
            status = _status_text(it.status)
            if it.project_id == cur:
                status = "open now · " + status
            vals = [it.name, src, it.topic, it.stage_name, _when(it.modified), status]
            for c, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                item.setToolTip(it.source if c == 1 else str(val))
                if it.project_id == cur:
                    f = item.font()
                    f.setBold(True)
                    item.setFont(f)
                self.table.setItem(r, c, item)
        if self.items:
            self.table.selectRow(0)
        has = bool(self.items)
        for b in (self.b_open, self.b_rename, self.b_delete):
            b.setEnabled(has)

    def _sel(self):
        r = self.table.currentRow()
        return self.items[r] if 0 <= r < len(self.items) else None

    def new(self):
        name, ok = QInputDialog.getText(self, "New project", "Name for the new project (optional):")
        if not ok:
            return
        self.win.new_project(name.strip())
        self.accept()

    def open_selected(self, *_):
        it = self._sel()
        if it is None:
            return
        if it.project_id == self.win.pipeline.project.project_id:
            self.accept()
            return
        self.accept()
        self.win.open_project_path(str(it.path))

    def rename(self):
        it = self._sel()
        if it is None:
            return
        name, ok = QInputDialog.getText(self, "Rename project", "New name:", text=it.name)
        if not ok or not name.strip():
            return
        pr = self.win.pipeline.project
        if it.project_id == pr.project_id:
            pr.meta["name"] = name.strip()
            pr.save()
            self.win.update_project_label()
        else:
            data, _ = P.load_project_dict(it.path)
            data.setdefault("meta", {})["name"] = name.strip()
            P.save_project_dict(it.project_id, data)
        self.refresh()

    def delete(self):
        it = self._sel()
        if it is None:
            return
        if delete_project_flow(self, self.win, it):
            self.refresh()


def delete_project_flow(parent, win, it: "P.ProjectInfo") -> bool:
    shared = P.source_in_use(it.source_id, it.project_id) if it.source_id else []
    size = P.cache_size(it.source_id) if it.source_id and not shared else 0
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("Delete project")
    box.setText(f"Delete the project <b>{it.name}</b>?")
    box.setInformativeText("This removes the project and its saved checkpoints. It can't be undone.\n\n"
                           "Not affected: your exported Shorts, your settings, AI models and other projects.")
    cb = QCheckBox(f"Also delete its downloaded video and analysis ({human(size)})" if not shared else
                   f"Its downloaded video and analysis are kept (used by {len(shared)} other project"
                   f"{'s' if len(shared) > 1 else ''})")
    cb.setChecked(bool(size) and not shared)
    cb.setEnabled(bool(size) and not shared)
    box.setCheckBox(cb)
    yes = box.addButton("Delete project", QMessageBox.ButtonRole.DestructiveRole)
    box.addButton(QMessageBox.StandardButton.Cancel)
    box.exec()
    if box.clickedButton() is not yes:
        return False
    current = it.project_id == win.pipeline.project.project_id
    res = P.delete_project(it.project_id, cb.isChecked())
    if current:
        win.new_project("", save_current=False)
    msg = "Project deleted."
    if res.get("source_data_mb"):
        msg += f" Freed {res['source_data_mb']:.0f} MB of downloaded video and analysis."
    win.statusBar().showMessage(msg, 8000)
    return True


class RestartDialog(QDialog):
    """Start the current project over from step 1, choosing what to keep."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        pr = win.pipeline.project
        self.setWindowTitle("Restart project")
        v = QVBoxLayout(self)
        v.addWidget(QLabel(f"<b>Start “{pr.name}” over from step 1</b>"))
        self.keep = QRadioButton("Keep the video and its analysis (recommended: finding moments again takes "
                                 "seconds)")
        self.scratch = QRadioButton("Start completely from scratch: also remove the video from this project and "
                                    "delete its downloaded copy and analysis")
        grp = QButtonGroup(self)
        grp.addButton(self.keep)
        grp.addButton(self.scratch)
        self.keep.setChecked(True)
        if pr.source is None:
            self.keep.setEnabled(False)
            self.scratch.setChecked(True)
        v.addWidget(self.keep)
        v.addWidget(self.scratch)
        self.size = QLabel("")
        self.size.setWordWrap(True)
        v.addWidget(self.size)
        v.addWidget(QLabel("Cleared either way: topic, chosen clips, story and hooks, script and voice, "
                           "edit and captions.\nNever touched: your exported Shorts, settings, AI models and "
                           "other projects."))
        bb = QDialogButtonBox()
        self.ok = bb.addButton("Restart project", QDialogButtonBox.ButtonRole.DestructiveRole)
        bb.addButton(QDialogButtonBox.StandardButton.Cancel)
        self.ok.clicked.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self.scratch.toggled.connect(self._size)
        self._size()

    def _size(self):
        pr = self.win.pipeline.project
        if pr.source is None or not self.scratch.isChecked():
            self.size.setText("")
            return
        shared = P.source_in_use(pr.source.source_id, pr.project_id)
        if shared:
            self.size.setText(f"The downloaded video and analysis are also used by {len(shared)} other "
                              f"project(s), so they will be kept.")
        else:
            self.size.setText(f"Frees {human(P.cache_size(pr.source.source_id))}.")


def recovery_prompt(win, previous: dict) -> None:
    """ClipForge didn't close properly last time: say what's safe and offer to continue."""
    started = previous.get("started")
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(started)) if started else "earlier"
    path = previous.get("project_path") or ""
    task = previous.get("task") or ""
    info = None
    if path and Path(path).exists():
        info = next((p for p in P.list_projects() if str(p.path) == str(Path(path))), None)
    box = QMessageBox(win)
    box.setIcon(QMessageBox.Icon.Information)
    box.setWindowTitle("ClipForge recovered")
    lines = [f"ClipForge didn't close normally last time (session started {when}). It may have crashed, been "
             f"force-closed, or Windows shut down."]
    if info is not None:
        lines.append(f"\nYour project “{info.name}” is safe: it was saved {_when(info.modified)} at "
                     f"step {info.stage_name}.")
        if task:
            lines.append(f"It was busy with “{task}” — that step will simply run again when you continue. "
                         f"Finished downloads and analysis are kept and reused.")
    else:
        lines.append("\nNo open project was affected.")
    lines.append("\nA crash report was saved in the logs folder (Settings → Diagnostics).")
    box.setText("\n".join(lines))
    reopen = box.addButton("Reopen project", QMessageBox.ButtonRole.AcceptRole) if info is not None else None
    box.addButton("Start fresh" if info is not None else "OK", QMessageBox.ButtonRole.RejectRole)
    box.exec()
    if reopen is not None and box.clickedButton() is reopen:
        win.open_project_path(str(info.path))


def explain_failure(win, title: str, msg: str, retry=None) -> None:
    """What failed, why, whether the project is safe, whether to retry, and which step to redo."""
    first = (msg or "Unknown error").strip()
    pr = win.pipeline.project
    saved = pr.meta.get("modified")
    safe = (f"Your project is safe — last saved {time.strftime('%H:%M:%S', time.localtime(saved))}. Everything "
            f"finished before this step is kept." if saved else "Your project wasn't changed.")
    hint = {"Finding moments": "Step 1 → Find moments", "Getting the video": "Step 1 → Load the video again",
            "Making your Short": "Step 5 → Build edit", "Rendering the preview": "Step 5 → Render quick preview",
            "Exporting": "Step 6 → Export", "Applying your changes": "Step 5 → Make these changes"}.get(title, "")
    box = QMessageBox(win)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("ClipForge")
    box.setText(f"<b>{title} didn't finish.</b>")
    why = first.split("\n\nDetails were saved")[0]
    body = f"Why: {why[:1500]}\n\n{safe}"
    if hint:
        body += f"\n\nTo try again: {hint}" + (" (or click Try again)." if retry else ".")
    box.setInformativeText(body)
    if "Details were saved" in first:
        box.setDetailedText(first[first.index("Details were saved"):][:6000])
    again = box.addButton("Try again", QMessageBox.ButtonRole.AcceptRole) if retry else None
    box.addButton("Close", QMessageBox.ButtonRole.RejectRole)
    box.exec()
    if again is not None and box.clickedButton() is again:
        retry()
