"""Orchestrates every stage. The GUI and tests drive the app only through this module.

Stages (each cached, each reports progress, each can be cancelled):
  ingest → transcribe → audio analysis → visual analysis → topic understanding →
  proposals → evidence → judging → selection → story → hooks → script → voice → render → QC
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from .analysis.audio import AudioFeatures, analyze_audio
from .analysis.transcript import get_transcript
from .analysis.visual import VisualFeatures, analyze_visual
from .config import Settings
from .core import ffmpeg as ff
from .core.cache import SourceCache, stable_id
from .core.ingest import Ingestor
from .core.models import Candidate, LibraryItem, NarrationLine, Plan, StoryItem, TopicSpec, Transcript, VideoSource
from .intelligence import judge as judge_mod
from .intelligence.proposals import build_timeline, propose
from .intelligence.selection import select_clips
from .intelligence.story import make_hooks, order_story, write_script
from .intelligence import topic as topic_mod
from .intelligence.topic import understand_topic
from .providers.base import ProviderUnavailable
from .services import Services

Progress = Callable[[str, float, str], None]  # (stage, fraction, message)


@dataclass
class Project:
    source: Optional[VideoSource] = None
    plan: Plan = field(default_factory=Plan)
    candidates: list[Candidate] = field(default_factory=list)
    log: list[str] = field(default_factory=list)
    used: dict = field(default_factory=dict)       # which engine actually did each stage
    last_export: str = ""
    project_id: str = ""
    # name, created, modified, stage (page 1-6 the user is on), status, fp (what each stage's
    # results were made from: used to tell which later stages are out of date)
    meta: dict = field(default_factory=dict)
    # extra footage for narration-driven / hybrid videos (the main video is ``source``)
    library: list[LibraryItem] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"source": self.source.to_dict() if self.source else None, "plan": self.plan.to_dict(),
                "candidates": [c.to_dict() for c in self.candidates], "log": self.log[-300:], "used": self.used,
                "last_export": self.last_export, "project_id": self.project_id, "meta": self.meta,
                "library": [x.to_dict() for x in self.library]}

    @classmethod
    def from_dict(cls, d: dict) -> "Project":
        return cls(source=VideoSource.from_dict(d["source"]) if d.get("source") else None,
                   plan=Plan.from_dict(d.get("plan") or {}),
                   candidates=[Candidate.from_dict(c) for c in d.get("candidates") or []],
                   log=d.get("log") or [], used=d.get("used") or {}, last_export=d.get("last_export", ""),
                   project_id=d.get("project_id", ""), meta=dict(d.get("meta") or {}),
                   library=[LibraryItem.from_dict(x) for x in d.get("library") or []])

    @property
    def name(self) -> str:
        return self.meta.get("name") or (self.source.title if self.source else "") or "Untitled project"

    def save(self) -> Path:
        """Atomic save + checkpoint (see projects.py): a crash never leaves a half-written project."""
        from .projects import save_project_dict

        if not self.project_id:
            from .projects import new_project_id

            self.project_id = new_project_id()
            self.meta.setdefault("created", time.time())
        self.meta["modified"] = time.time()
        if not self.meta.get("name") and self.source is not None:
            self.meta["name"] = self.source.title or "Untitled project"
        return save_project_dict(self.project_id, self.to_dict())

    def candidate(self, cid: str) -> Optional[Candidate]:
        return next((c for c in self.candidates if c.cid == cid), None)


class Pipeline:
    def __init__(self, settings: Optional[Settings] = None, services: Optional[Services] = None):
        from . import resources

        self.settings = settings or Settings.load()
        resources.set_mode(self.settings.performance or resources.recommended_mode())
        self.services = services or Services(self.settings)
        self.project = Project()
        self._cancel = False
        # analysis results kept in memory for the current source
        self.transcript: Optional[Transcript] = None
        self.audio: Optional[AudioFeatures] = None
        self.visual: Optional[VisualFeatures] = None
        self.timeline = None
        self.sounds = None
        # narration-driven / hybrid videos: analysed footage library, its index, crop profiles
        self._footage = None
        self._index = None
        self._creative_profiles: dict = {}

    def is_creative(self) -> bool:
        """True when the plan is narration-driven or hybrid (the narration leads)."""
        plan = self.project.plan
        return plan.brief.mode in ("narration", "hybrid") and bool(plan.sections)

    # -------------------------------------------------------------- 3b. any kind of video from a prompt
    def create(self, prompt: str, target_seconds: float, mode: str = "auto", style: str = "", pacing: str = "",
               script: str = "", notes: str = "", urls: Optional[list] = None, use_my_script: bool = False,
               desired_clips: int = 0, progress: Optional[Progress] = None, production=None):
        """Read the prompt and make the right kind of video plan: clip-driven (find moments),
        narration-driven (narration first, footage chosen to accompany it) or hybrid.

        ``prompt`` is used exactly as the user typed it. ``production`` is the approved production
        brief (AI prompt expansion, ``creative.expand``) when there is one: it then steers every
        stage. Both are kept in the plan, separately."""
        from .core.models import ProductionBrief
        from .creative import expand as expand_mod
        from .creative import workflow

        production = production if production is not None else ProductionBrief(original_prompt=prompt,
                                                                                 status="not_requested")
        direction = expand_mod.for_writer(production)
        self._wait_background(progress)       # analysis started while the brief was written
        if self.transcript is None and self.project.source is not None:
            # sound events and speakers are only needed to find moments (clip-driven and hybrid);
            # find_moments adds them when it runs
            self.analyze_signals(progress, with_sounds=False)
        self.reset_cancel()
        brief = workflow.create_plan(self, prompt, target_seconds, mode, style, pacing, script, notes, urls,
                                     use_my_script, progress, production=production)
        if brief.mode == "clip":
            cands = self.find_moments(prompt, target_seconds, desired_clips, progress, direction=direction)
            self.project.plan.brief = brief
        self.project.plan.original_prompt = prompt
        self.project.plan.production = production
        self.project.save()
        return cands if brief.mode == "clip" else self.project.plan

    # -------------------------------------------------------------- 3a. AI prompt expansion
    def expand_prompt(self, prompt: str, target_seconds: float = 0.0, mode: str = "auto", style: str = "",
                      script: str = "", notes: str = "", on_text=None, regenerate: bool = False,
                      progress: Optional[Progress] = None):
        """The production brief for ``prompt`` (which is never changed). Uses the language model;
        raises ``creative.expand.ExpansionUnavailable`` with the reason when it can't. The same
        prompt with the same video, settings and model comes back from the cache instantly
        (``regenerate`` asks the model again)."""
        import random

        from .core.models import ProductionBrief
        from .creative import expand as ex

        if self._start_background_analysis():      # meanwhile (and while the user reads the brief)
            self.log("Analysing the video while the production brief is written")
        self.services.retry_llm()
        llm = self.services.llm()
        st = self.services.status["llm"]
        if st.active == "rules":
            raise ex.ExpansionUnavailable(st.message or "No AI language model is set up (Settings > AI models).")
        src = self.project.source
        sample = ""
        if self.transcript is not None and self.transcript.sentences:
            sens = [x.text.strip() for x in self.transcript.sentences if len(x.text.split()) >= 5]
            sample = " | ".join(sens[:: max(1, len(sens) // 8)][:8])
        ctx = ex.context_text(title=src.title if src else "", duration=src.duration if src else 0.0,
                              transcript_sample=sample, target_seconds=target_seconds, forced_mode=mode,
                              forced_style=style, notes=notes, has_script=bool(script.strip()))
        model = f"{self.settings.llm.backend}:{self.settings.llm.model}"
        cache = SourceCache("_expansions")
        # the same prompt, video, options and model reuse the brief (whether or not the video's speech
        # had been analysed yet when it was written)
        key_ctx = ex.context_text(title=src.title if src else "", target_seconds=target_seconds, forced_mode=mode,
                                  forced_style=style, notes=notes, has_script=bool(script.strip()))
        key = ex.cache_key(prompt, model, key_ctx + (src.source_id if src else ""))
        if not regenerate:
            d = cache.load_json(key + ".json")
            if d:
                b = ProductionBrief.from_dict(d)
                if b.original_prompt == prompt and b.status == "expanded":
                    self.log("Production brief: reused (same prompt, video and model)")
                    b.reused = True               # (not saved: only for showing it)
                    return b
        old_t = getattr(llm, "temperature", None)
        if progress:
            progress("expand", 0.02, f"Asking {self.settings.llm.model} to expand your prompt")

        def text(t: str):
            if progress:     # the brief is roughly 2,500 characters of JSON
                progress("expand", min(0.95, 0.05 + len(t) / 2600), "Writing the production brief")
            if on_text:
                on_text(t)
        self.reset_cancel()
        try:
            if regenerate and old_t is not None:          # a different take, still on topic
                llm.temperature = min(0.9, (old_t or 0.3) + 0.3 + random.random() * 0.1)
            b = ex.expand(prompt, llm, ctx, on_text=text, model_name=model)
        finally:
            if old_t is not None:
                llm.temperature = old_t
        cache.save_json(key + ".json", b.to_dict())
        self.log(f"Production brief written by {model} in {b.seconds:.0f}s")
        return b

    # -------------------------------------------------------------- utilities
    def cancel(self):
        from . import cancel as _c

        self._cancel = True
        _c.request()

    def reset_cancel(self):
        from . import cancel as _c

        self._cancel = False
        _c.reset()

    def _cancelled(self) -> bool:
        from . import cancel as _c

        return self._cancel or _c.requested()

    def log(self, msg: str):
        self.project.log.append(f"{time.strftime('%H:%M:%S')}  {msg}")

    @property
    def cache(self) -> SourceCache:
        assert self.project.source is not None
        return SourceCache(self.project.source.source_id)

    # -------------------------------------------------------------- 1. ingest
    def ingest(self, url: str = "", path: str = "", progress: Optional[Progress] = None) -> VideoSource:
        self._stop_background()
        self.reset_cancel()
        p = (lambda f, m: progress("ingest", f, m)) if progress else None
        ing = Ingestor(progress=p, cancel=self._cancelled, analysis_height=self.settings.vision.analysis_height)
        src = ing.from_url(url) if url else ing.from_file(path)
        cached = SourceCache(src.source_id).load_json("rights.json")
        if cached:
            from .core.models import RightsRecord
            src.rights = RightsRecord.from_dict(cached)
        old = self.project
        # the video belongs to the open project: keep its id and name (a new video in a project
        # replaces the old one and everything made from it)
        meta = {k: v for k, v in old.meta.items() if k in ("name", "created")}
        if old.source is not None and meta.get("name") == old.source.title:
            meta.pop("name")          # the name was just the old video's title: follow the new one
        self.project = Project(source=src, project_id=old.project_id, meta=meta | {"stage": 1},
                               library=[x for x in old.library if x.source_id != src.source_id])
        self.transcript = self.audio = self.visual = self.timeline = self.sounds = self.edit_timeline = None
        self._best_src = {}
        self.log(f"Loaded '{src.title}' ({src.duration / 60:.1f} min) from {src.platform}")
        return src

    def open_project(self, path: str, progress: Optional[Progress] = None) -> Project:
        """Resume a saved project; analysis comes back from the cache in seconds. A damaged
        project file is recovered from its newest checkpoint (``self.recovered_note`` says so)."""
        from .projects import load_project_dict

        data, self.recovered_note = load_project_dict(Path(path))
        proj = Project.from_dict(data)
        self._stop_background()
        if proj.source is not None and proj.source.kind == "file" and not Path(proj.source.path).exists():
            raise FileNotFoundError(f"The video file has moved or was deleted: {proj.source.path}")
        self.reset_cancel()
        self.project = proj
        self.transcript = self.audio = self.visual = self.timeline = self.edit_timeline = self.sounds = None
        self._best_src = {}
        if proj.source is not None and (proj.candidates or proj.meta.get("analysed")):
            self.analyze_signals(progress)
        return proj

    recovered_note = ""

    # -------------------------------------------------------------- projects: new / restart
    # -------------------------------------------------------------- analysis while the brief is written
    def _start_background_analysis(self) -> bool:
        """Analyse the video (speech, pictures) while the language model writes the production brief
        and while the user reads it: the two don't depend on each other. Only the first time, and
        only when the PC has the memory and cores for both (``resources.parallel_analysis``)."""
        import threading

        from . import resources as _res

        src = self.project.source
        if src is None or self.transcript is not None or not src.audio_path or not _res.parallel_analysis():
            return False
        if getattr(self, "_bg", None) is not None and self._bg.is_alive():
            return True

        def run():
            try:
                self.analyze_signals(None, with_sounds=False)
                self.log("Analysis finished while the brief was being written")
            except BaseException as e:  # noqa: BLE001  (redone, with its error shown, when it's needed)
                self.transcript = None
                self.log(f"Background analysis stopped ({type(e).__name__}); it runs again when needed")
        self._bg = threading.Thread(target=run, name="analysis-during-brief", daemon=True)
        self._bg.start()
        return True

    def _wait_background(self, progress: Optional[Progress] = None) -> bool:
        """Wait for the analysis started during prompt expansion (never from that thread itself)."""
        import threading

        bg = getattr(self, "_bg", None)
        if bg is None or bg is threading.current_thread():
            return False
        if bg.is_alive():
            if progress:
                progress("transcript", 0.5, "Finishing the analysis started while the brief was written")
            while bg.is_alive():
                bg.join(0.2)
            if self._cancelled():               # Cancel pressed while waiting: stop here too
                self._bg = None
                from .cancel import Cancelled
                raise Cancelled()
        self._bg = None
        return True

    def _stop_background(self):
        """Another video / project / restart: stop the background analysis first."""
        bg = getattr(self, "_bg", None)
        if bg is not None and bg.is_alive():
            self.cancel()
            bg.join(60)
        self._bg = None

    def new_project(self, name: str = "") -> Project:
        """An empty project (the current one should be saved first)."""
        self._stop_background()
        self.reset_cancel()
        self.project = Project(meta={"name": name, "created": time.time(), "stage": 1, "status": "new"})
        self.transcript = self.audio = self.visual = self.timeline = self.edit_timeline = self.sounds = None
        self._best_src = {}
        return self.project

    def restart(self, keep_source: bool) -> dict:
        """Start this project over from page 1.

        keep_source=True: keep the downloaded video, its rights record and its analysis (finding
        moments again takes seconds); everything made from it — topic, picks, story, hooks,
        script, voice, edit — is cleared.
        keep_source=False: also clear the video from the project and delete its downloaded copy
        and analysis, unless another project uses the same video.
        Exported Shorts on disk, settings, AI models and other projects are never touched."""
        from .projects import cache_size, source_in_use, _safe_rmtree_cache

        self._stop_background()
        old = self.project
        src = old.source
        meta = {"name": old.meta.get("name") or (src.title if src else ""), "created": old.meta.get("created"),
                "stage": 1, "status": "restarted"}
        removed = {"cleared": True, "source_data_mb": 0.0, "kept_shared": False}
        self.reset_cancel()
        if keep_source and src is not None:
            self.project = Project(source=src, project_id=old.project_id, meta=meta | {"analysed": True})
            self.edit_timeline = self.timeline = None
        else:
            if src is not None:
                if source_in_use(src.source_id, old.project_id):
                    removed["kept_shared"] = True
                else:
                    removed["source_data_mb"] = round(cache_size(src.source_id) / 2**20, 1)
                    _safe_rmtree_cache(src.source_id)
            self.project = Project(project_id=old.project_id, meta=meta)
            self.transcript = self.audio = self.visual = self.timeline = self.edit_timeline = self.sounds = None
        self._best_src = {}
        self.project.log.append(f"{time.strftime('%H:%M:%S')}  Project restarted "
                                f"({'kept the video and its analysis' if keep_source else 'from scratch'})")
        if self.project.project_id:
            self.project.save()
        return removed

    # -------------------------------------------------------------- stage dependencies
    def _fp(self, *parts) -> str:
        import hashlib

        return hashlib.sha1(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()[:16]

    def stage_inputs(self) -> dict[str, str]:
        """What each stage's results depend on, right now. Compared with what they were made from."""
        pr, plan = self.project, self.project.plan
        es = self.settings.edit
        topic = (plan.topic.raw or plan.topic.summary or "").strip().lower()
        picks = sorted((c.cid, c.included, c.excluded, c.locked) for c in pr.candidates)
        story = [(it.cid, round(it.start, 2), round(it.end, 2)) for it in plan.story]
        # narration-driven / hybrid: the sections and the footage picked for them shape the edit
        story += [(s.kind, s.cid, s.text, [(sh.source_id, round(sh.start, 2), round(sh.end, 2)) for sh in s.shots])
                  for s in plan.sections]
        narr = [(ln.text, ln.item_index, ln.position) for ln in plan.narration]
        v = self.voice_settings()
        import dataclasses

        # settings that change the edit's timing/content (style-only settings just re-render)
        edit_settings = {k: getattr(es, k) for k in ("crop_mode", "transitions", "transition_seconds",
                                                     "flash_forward_hook", "tighten_pauses",
                                                     "show_original_dialogue_captions", "caption_words_per_line",
                                                     "end_message")}
        all_settings = dataclasses.asdict(es)
        return {"candidates": self._fp(pr.source.source_id if pr.source else "", topic, plan.target_seconds,
                                       plan.desired_clips),
                "story": self._fp(picks),
                "script": self._fp([it.cid for it in plan.story], plan.chosen_hook),
                "edit": self._fp(story, narr, (v.voice, v.speed), plan.chosen_hook, edit_settings),
                "export": self._fp(story, narr, (v.voice, v.speed), plan.chosen_hook, all_settings,
                                   [o.to_dict() for o in plan.overlays], [c.to_dict() for c in plan.captions])}

    def mark_made(self, *stages: str) -> None:
        cur = self.stage_inputs()
        fp = self.project.meta.setdefault("fp", {})
        for st in stages:
            fp[st] = cur[st]

    def stale(self) -> dict[str, bool]:
        """Which stages have results that were made from something that has changed since."""
        fp = self.project.meta.get("fp") or {}
        cur = self.stage_inputs()
        has = {"candidates": bool(self.project.candidates), "story": bool(self.project.plan.story),
               "script": bool(self.project.plan.narration) or bool(self.project.plan.story),
               "edit": bool(self.project.plan.captions) or self.edit_timeline is not None,
               "export": bool(self.project.last_export)}
        return {st: bool(has[st] and st in fp and fp[st] != cur[st]) for st in cur}

    def save_rights(self):
        if self.project.source:
            self.cache.save_json("rights.json", self.project.source.rights.to_dict())

    # -------------------------------------------------------------- 2. analyse (whole-video signals)
    def analyze_signals(self, progress: Optional[Progress] = None, with_sounds: bool = True):
        """Speech, loudness and pictures; with ``with_sounds`` also sound events and the speaker
        model (needed only to find moments: a narration-driven video skips them).

        Speech (the speech model) and pictures (video decoding + CLIP) don't depend on each other,
        so the first analysis of a video runs them side by side when the PC has the cores for it."""
        import threading

        from . import resources as _res

        src = self.project.source
        assert src is not None
        self._wait_background(progress)              # started while the brief was being written
        self.reset_cancel()
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        failed: list[BaseException] = []
        stop = lambda: self._cancelled() or bool(failed)          # one side failing stops the other

        def speech():
            t0 = time.time()
            self.transcript = get_transcript(src.audio_path, self.cache,
                                             lambda: self.services.transcriber(pr("models")), pr("transcript"), stop)
            self.used["transcription"] = self.transcript.backend
            if _res.release_models_between_stages():
                self.services.release("transcriber")  # ~1 GB; reloaded only if needed for caption timing
            self.log(f"Transcript: {len(self.transcript.sentences)} sentences ({self.transcript.backend}) "
                     f"[{time.time() - t0:.0f}s]")

        def pictures():
            t0 = time.time()
            self.audio = analyze_audio(src.audio_path, self.cache, pr("audio"), stop)
            self.log(f"Audio analysed [{time.time() - t0:.0f}s]")
            t0 = time.time()
            vision = self.services.vision()
            every, height = self.settings.vision.sample_every_seconds, self.settings.vision.analysis_height
            try:
                self.visual = analyze_visual(src.proxy_path, self.cache, every, vision, height, pr("visual"), stop)
            except ProviderUnavailable:
                if self._cancelled():
                    raise
                # the picture model couldn't load after all: analyse without it (as before)
                self.visual = analyze_visual(src.proxy_path, self.cache, every, None, height, pr("visual"), stop)
            self.used["vision"] = self.visual.emb_model or "none (no visual model)"
            self.log(f"Visuals analysed: {len(self.visual.times)} frames, model={self.used['vision']} "
                     f"[{time.time() - t0:.0f}s]")

        def guarded(fn):
            def run():
                try:
                    fn()
                except BaseException as e:  # noqa: BLE001  (re-raised below, in this thread)
                    failed.append(e)
            return run

        fresh = not (self.cache.has("transcript.json") and self.cache.has("visual_features.npz"))
        if fresh and _res.parallel_analysis():
            side = threading.Thread(target=guarded(pictures), name="analysis-pictures", daemon=True)
            side.start()
            guarded(speech)()
            side.join()
            if failed:
                cancelled = [e for e in failed if "ancel" in str(e)]
                raise (cancelled or failed)[0]
        else:
            speech()
            pictures()
        self._sounds_done = False
        if with_sounds:
            self.analyze_sounds(progress)

    def analyze_sounds(self, progress: Optional[Progress] = None):
        src = self.project.source
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        # real sound-event model (laughter, sirens, crashes…) and speaker identification
        t0 = time.time()
        from .analysis.sound_events import analyze_sound_events

        try:
            self.sounds = analyze_sound_events(src.audio_path, src.duration, self.cache,
                                               self.services.sound_tagger(pr("models")), pr("sounds"), self._cancelled)
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001  (a model failure must never stop the analysis)
            self.sounds = None
            self.log(f"Sound-event model failed ({e}); using loudness-based cues")
        self.used["sound_events"] = self.sounds.model_id if self.sounds is not None else "none"
        # speakers are identified later, only around candidate moments (much faster on long streams)
        dz = self.services.diarizer(pr("models"))
        self.used["speakers"] = dz.model_id if dz is not None else "none"
        self.log(f"Sounds analysed: {self.used['sound_events']}; speaker model: {self.used['speakers']} "
                 f"[{time.time() - t0:.0f}s]")
        self._sounds_done = True

    @property
    def used(self) -> dict:
        return self.project.used

    # -------------------------------------------------------------- 3. find & judge moments for a topic
    def find_moments(self, topic: str, target_seconds: float, desired_clips: int = 0,
                     progress: Optional[Progress] = None, direction: str = "") -> list[Candidate]:
        self._wait_background(progress)
        if self.transcript is None:
            self.analyze_signals(progress)
        elif not getattr(self, "_sounds_done", True):
            self.analyze_sounds(progress)
        self.reset_cancel()
        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        self.services.retry_llm()
        llm = self.services.llm()
        self.used["llm"] = self.services.status["llm"].active
        spec_key = "topic_" + stable_id(topic.strip().lower(), self.used["llm"], self.settings.llm.model,
                                         str(topic_mod.VERSION), *([direction] if direction else []))
        spec_d = self.cache.load_json(spec_key + ".json")
        spec = TopicSpec.from_dict(spec_d) if spec_d else understand_topic(topic, llm, direction)
        spec.direction = direction
        self.cache.save_json(spec_key + ".json", spec.to_dict())
        self.log("Topic understood: " + spec.summary)
        embedder = self.services.embedder()
        self.used["embedder"] = self.services.status["embedder"].active
        vision = self.services.vision()
        self.timeline = build_timeline(spec, self.transcript, self.audio, self.visual, embedder, vision,
                                       getattr(self, "sounds", None))
        max_len = min(40.0, max(10.0, target_seconds * 0.8))
        cand_key = spec_key + "_" + stable_id(str(max_len), self.used["embedder"], self.used.get("vision", ""),
                                              self.settings.vision.captioner, str(judge_mod.VERSION),
                                              self.used.get("sound_events", ""), self.used.get("speakers", ""))
        cached = self.cache.load_json(f"cands_{cand_key}.json")
        if cached:
            cands = [Candidate.from_dict(c) for c in cached["candidates"]]
            self.used["judge"] = cached.get("judge", "?")
            self.log(f"Loaded {len(cands)} judged candidates from cache")
            self._label_speakers(cands, progress)
        else:
            n_judge = self.settings.llm.max_candidates_to_judge
            cands = propose(self.timeline, self.transcript, self.audio, max_candidates=n_judge, max_len=max_len)
            self.log(f"Proposed {len(cands)} candidate moments")
            self._label_speakers(cands, progress)
            captioner = self.services.captioner() if self.used["llm"] != "rules" else None
            kf_dir = str(self.cache.subdir("keyframes"))
            n_cap = 15  # vision-LLM descriptions only for the strongest proposals (speed)
            for i, c in enumerate(cands):
                c.evidence = judge_mod.build_evidence(c, spec, self.transcript, self.audio, self.visual, vision,
                                                      self.project.source.proxy_path, kf_dir, captioner, i < n_cap,
                                                      self.settings.vision.keyframes_per_candidate,
                                                      getattr(self, "sounds", None))
                if progress:
                    progress("evidence", (i + 1) / max(1, len(cands)), "Gathering evidence for each moment")
                if self._cancelled():
                    raise RuntimeError("Cancelled")
            self.used["captioner"] = (self.services.status.get("captioner").active
                                      if self.services.status.get("captioner") else "none")
            self.used["judge"] = judge_mod.judge_candidates(cands, spec, llm, self.transcript, self.visual, self.audio,
                                                            self.timeline, batch_size=4, progress=pr("judge"),
                                                            cancel=self._cancelled)
            self.cache.save_json(f"cands_{cand_key}.json", {"candidates": [c.to_dict() for c in cands],
                                                            "judge": self.used["judge"]})
        if not desired_clips and spec.count:      # "the four coolest things" = 4 clips
            desired_clips = spec.count
            self.log(f"The request asks for {spec.count} moments"
                     + (" as a countdown" if spec.format == "countdown" else "")
                     + (", each one described" if spec.detail == "detailed" else ""))
        self.project.plan = Plan(topic=spec, target_seconds=target_seconds, desired_clips=desired_clips)
        self.project.plan.topic.raw = self.project.plan.topic.raw or topic
        self.project.candidates = cands
        self.project.meta["analysed"] = True
        self.select(progress)
        self.mark_made("candidates", "story", "script")
        self.project.save()
        self._release_after("find")
        return cands

    def _release_after(self, stage: str) -> None:
        """Free AI models the next steps don't need (not in Performance mode). They reload on
        demand, which costs a few seconds but keeps memory free for the rest of the PC."""
        from . import resources

        if not resources.release_models_between_stages():
            return
        if stage == "find":
            self.services.release("vision", "captioner", "sound_events", "diarizer", "transcriber")
        elif stage == "edit" and resources.mode() == "low":
            self.services.release("tts", "transcriber")
        elif stage == "export":
            self.services.release("tts", "transcriber")

    def _label_speakers(self, cands, progress=None):
        """Who-spoke-when around the candidate moments (cached; only new windows are processed)."""
        from .analysis.speakers import get_speakers

        src = self.project.source
        pr = (lambda f, m: progress("speakers", f, m)) if progress else None
        t0 = time.time()
        try:
            n = get_speakers(src.audio_path, src.duration, self.cache, self.transcript, self.services.diarizer(),
                             [(c.start, c.end) for c in cands], pr, self._cancelled)
            if self.services.diarizer() is not None:
                self.log(f"Speakers identified around {len(cands)} moments: {n} voice(s) [{time.time() - t0:.0f}s]")
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001  (never stops the analysis)
            self.log(f"Speaker identification failed ({e})")

    # -------------------------------------------------------------- 4. select + story + script
    def select(self, progress: Optional[Progress] = None):
        plan = self.project.plan
        # a described / counted-down Short needs more narration time, so the clips leave room for it
        share = {"detailed": 0.35, "none": 0.0}.get(plan.topic.detail, 0.15)
        if plan.topic.format == "countdown" and plan.topic.detail != "none":
            share = max(share, 0.25)
        chosen = select_clips(self.project.candidates, self.transcript, plan.target_seconds, plan.desired_clips,
                              self.services.embedder(), narration_share=share)
        if plan.topic.count and len(chosen) < plan.topic.count:
            self.log(f"Only {len(chosen)} moment(s) matched well enough; the request asked for {plan.topic.count}")
        self.log(f"Selected {len(chosen)} clips: " + ", ".join(f"{c.cid} ({c.duration:.0f}s)" for c in chosen))
        self.build_story(progress)

    def build_story(self, progress: Optional[Progress] = None):
        plan = self.project.plan
        chosen = [c for c in self.project.candidates if c.included]
        llm = self.services.llm()
        story, how = order_story(chosen, plan.topic, llm)
        plan.story = story
        self.used["story"] = how
        by_id = {c.cid: c for c in self.project.candidates}
        hooks, how_h = make_hooks(story, by_id, plan.topic, llm, self.settings.hook_variants)
        plan.hooks, plan.chosen_hook = hooks, 0
        self.used["hooks"] = how_h
        self.write_script()
        self.mark_made("story", "script")
        if progress:
            progress("story", 1.0, "Story, hooks and script ready")

    def write_script(self):
        plan = self.project.plan
        by_id = {c.cid: c for c in self.project.candidates}
        self.services.retry_llm()               # "Rewrite script with AI" after starting Ollama
        hook = plan.hooks[plan.chosen_hook] if plan.hooks else None
        lines, extras, how = write_script(plan.story, by_id, plan.topic, hook, self.services.llm(), self.transcript,
                                          plan.target_seconds)
        plan.narration = lines
        self.edit_timeline = None
        self.used["script"] = how
        ctx = extras.get("context_texts") or {}
        for i, it in enumerate(plan.story):
            t = ctx.get(str(i + 1)) or ctx.get(i + 1)
            c = by_id[it.cid]
            if not t:
                t = next((r.split(":", 1)[1] for r in c.reasons if r.startswith("context:")), "")
            it.context_text = str(t or "")[:60]
        plan.title = extras.get("title") or (hook.headline.title() if hook else plan.topic.summary[:60])
        if extras.get("description"):
            plan.description = extras["description"]
        else:  # fallback: a clean sentence, not the raw search request
            from .intelligence.story import _short_topic

            plan.description = f"The best {_short_topic(plan.topic)} from the stream."
        self.log(f"Script: {len(lines)} narration lines ({how})")
        self.project.meta["script_edited"] = False
        self.mark_made("script")

    # -------------------------------------------------------------- re-selection after user edits
    def set_choices(self, include: set[str]):
        """Apply the user's ticks on the candidates page: ticked = locked in, unticked = excluded."""
        for c in self.project.candidates:
            was = c.included
            c.included = c.cid in include
            c.locked = c.included
            c.excluded = (not c.included) and (was or c.excluded)
        self.edit_timeline = None
        self.build_story()

    def replace_clip(self, cid: str):
        """Remove one clip and let the selector pick the best remaining alternative."""
        c = self.project.candidate(cid)
        if c is None:
            return
        c.excluded, c.locked, c.included = True, False, False
        for x in self.project.candidates:
            x.locked = x.included
        self.select()

    def auto_select(self):
        for x in self.project.candidates:
            x.locked = False
        self.select()

    def render_preview(self, progress: Optional[Progress] = None) -> Path:
        """Fast low-resolution preview of the current edit (not checked for rights: stays on this PC)."""
        import dataclasses

        from .render.render import RenderJob, render

        if self.edit_timeline is None:
            self.prepare_edit(progress)
        es = dataclasses.replace(self.edit_settings(), width=540, height=960, crf=30, preset="ultrafast")
        work = self.cache.subdir("render") / "preview"
        out = self.cache.subdir("render") / "preview.mp4"
        job = RenderJob(self.edit_timeline, self.project.plan.captions, self.project.plan.overlays, es, work, out,
                        getattr(self, "_best_src", {}), self.visual,
                        self.visual.facecam if self.visual is not None else None, self.project.source.source_id,
                        visual_profiles=self._creative_profiles if self.is_creative() else None)
        path = render(job, (lambda f, m: progress("preview", f, m)) if progress else None, self._cancelled)
        shutil.rmtree(work, ignore_errors=True)
        return path

    def edit_settings(self):
        """The edit settings for this video: the user's settings, with the prompt's music request
        applied ("no music" turns it off; "calm music" prefers a file in the music folder whose
        name has that word). ClipForge ships no music: it only uses the user's own files."""
        import dataclasses

        es = self.settings.edit
        pb = self.project.plan.production
        if pb.status in ("expanded", "edited") and pb.transitions in ("quick", "none") \
                and pb.transitions != es.transitions:
            es = dataclasses.replace(es, transitions=pb.transitions)   # the approved brief's editing direction
        want = (self.project.plan.brief.music or "").strip().lower()
        if want == "none":
            return dataclasses.replace(es, music_path="")
        if want and es.music_path and Path(es.music_path).is_dir():
            from .render.render import MUSIC_EXT

            files = sorted(f for f in Path(es.music_path).iterdir() if f.suffix.lower() in MUSIC_EXT)
            hit = [f for f in files if any(w in f.stem.lower() for w in want.split() if len(w) > 2)]
            if hit:
                return dataclasses.replace(es, music_path=str(hit[0]))
        return es

    def voice_settings(self):
        """The voice settings for this video: the user's, with the approved production brief's
        narration speed when it gives one (it only nudges: 0.9-1.15 of normal)."""
        import dataclasses

        v = self.settings.voice
        pb = self.project.plan.production
        if pb.status in ("expanded", "edited") and 0.9 <= pb.voice_speed <= 1.15:
            # the user's own speed setting is the baseline; the brief scales it a little
            return dataclasses.replace(v, speed=round(min(1.3, max(0.8, v.speed * pb.voice_speed)), 3))
        return v

    def story_candidates(self) -> list[tuple[StoryItem, Candidate]]:
        by_id = {c.cid: c for c in self.project.candidates}
        return [(it, by_id[it.cid]) for it in self.project.plan.story if it.cid in by_id]

    def move_story_item(self, index: int, delta: int):
        st = self.project.plan.story
        j = index + delta
        if 0 <= index < len(st) and 0 <= j < len(st):
            st[index], st[j] = st[j], st[index]
            for ln in self.project.plan.narration:  # narration follows its clip
                if ln.item_index == index:
                    ln.item_index = j
                elif ln.item_index == j:
                    ln.item_index = index
            self.edit_timeline = None

    def choose_hook(self, index: int):
        """Switch the hook: headline overlay + opening narration line (rest of the script kept)."""
        plan = self.project.plan
        if not (0 <= index < len(plan.hooks)):
            return
        plan.chosen_hook = index
        h = plan.hooks[index]
        first = next((ln for ln in plan.narration if ln.item_index == 0 and ln.position != "after"), None)
        if first is not None and h.opening_line:
            first.text, first.audio_path, first.duration = h.opening_line, "", 0.0
        elif h.opening_line:
            plan.narration.insert(0, NarrationLine(text=h.opening_line, item_index=0))
        for o in plan.overlays:
            if o.kind == "headline":
                o.text = h.headline
        self.edit_timeline = None

    # -------------------------------------------------------------- "Any changes?" (typed revisions)
    def revise(self, request: str, progress: Optional[Progress] = None, render: bool = True) -> dict:
        """Apply a typed change request ("drop clip 3, make the hook funnier") and re-render the preview.
        Returns {done, skipped, reply, how, undo, preview}."""
        from .intelligence.revise import apply_changes, plan_changes, snapshot

        if progress:
            progress("revise", 0.05, "Understanding your request…")
        undo = snapshot(self)
        ops, how, reply = plan_changes(request, self)
        done, skipped = apply_changes(self, ops)
        self.log(f"Revision ({how}): {request!r} -> {len(done)} changes, {len(skipped)} skipped")
        preview = None
        if done:
            self.project.save()
            if render:
                sub = (lambda st, f, m: progress(st, 0.1 + 0.9 * f, m)) if progress else None
                preview = self.render_preview(sub)
        return {"done": done, "skipped": skipped, "reply": reply, "how": how, "undo": undo,
                "preview": str(preview) if preview else ""}

    def undo_revision(self, snap: dict, progress: Optional[Progress] = None) -> str:
        from .intelligence.revise import restore

        restore(self, snap)
        self.project.save()
        return str(self.render_preview(progress))

    # -------------------------------------------------------------- 5. voice + edit plan (captions, overlays)
    edit_timeline = None

    def prepare_edit(self, progress: Optional[Progress] = None, keep_overlays: bool = True):
        """Fetch full-quality clip sections, voice the script, lay out the timeline, and build
        captions + overlays (stored in the plan so they can be corrected before export)."""
        if self.is_creative():
            from .creative import workflow

            return workflow.prepare_edit(self, progress)
        from .render.captions import build_captions, default_overlays
        from .render.timeline import build_timeline as build_out_timeline
        from .render.timeline import find_dead_air, refine_cut_points
        from .render.voice import narration_word_times, synthesize_lines

        src, plan = self.project.source, self.project.plan
        assert src is not None and plan.story, "Nothing to edit yet"
        from . import cancel as _cancel

        pr = lambda stage: (lambda f, m: progress(stage, f, m)) if progress else None
        es = self.settings.edit
        # full-quality footage for the chosen clips only
        if src.kind == "file" and src.path and Path(src.path).exists():
            sections = {i: (src.path, 0.0) for i in range(len(plan.story))}
        else:
            ranges = [(max(0.0, it.start - 6.0), it.end + 1.5) for it in plan.story]  # lead-in room
            ing = Ingestor(progress=pr("download"), cancel=self._cancelled)
            got = ing.fetch_sections(src, ranges, fps=es.fps)
            sections = {i: (got[r], r[0]) for i, r in enumerate(ranges)}
        # analysis models aren't needed for editing: free their memory before loading the voice
        # (only when memory is short: they'd have to be loaded again for the next video)
        from . import resources as _res

        if _res.release_models_between_stages():
            self.services.release("vision", "captioner", "sound_events", "diarizer")
        # voice
        v = self.voice_settings()
        tts = self.services.tts(pr("models"))
        _cancel.check()
        synthesize_lines(plan.narration, tts, v.voice, v.speed, v.volume_db, self.cache, pr("voice"))
        self.used["voice"] = f"{tts.name}:{v.voice}"
        _cancel.check()
        # exact narration word timings for captions (speech model), estimated if it can't load
        try:
            trans = self.services.transcriber() if plan.narration else None
        except Exception:  # noqa: BLE001
            trans = None
        if progress and plan.narration:
            progress("voice", 0.95, "Timing the narration captions…")
        word_times = []
        for ln in plan.narration:
            _cancel.check()
            word_times.append(narration_word_times(ln, trans))
        if _res.release_models_between_stages():
            self.services.release("transcriber")
        # timeline
        T = es.transition_seconds if es.transitions != "none" else 0.0
        by_id = {c.cid: c for c in self.project.candidates}
        self._best_src = {}
        for i, it in enumerate(plan.story):
            c = by_id.get(it.cid)
            if c is not None and it.start <= c.best_moment <= it.end:
                self._best_src[i] = c.best_moment
        if progress:
            progress("edit", 0.2, "Finding scene changes…")
        # cut points: never open or end a clip on a few frames of a different scene, and know
        # where the scene changes are so lead-in / flash-forward footage never crosses one
        _cancel.check()
        cuts = self._scene_cuts(sections)
        _cancel.check()
        notes = refine_cut_points(plan.story, cuts, self.transcript)
        if notes:
            self.log("Cut points moved to scene changes: " + "; ".join(notes))
        self._best_src = {i: bm for i, bm in self._best_src.items() if plan.story[i].start <= bm <= plan.story[i].end}
        # the quiet opening of a clip where a narration line will play must not be trimmed away
        need: dict[int, float] = {}
        last_i = len(plan.story) - 1
        for ln in plan.narration:
            j = ln.item_index if ln.position != "after" else (ln.item_index + 1 if ln.item_index < last_i else None)
            if j is not None:
                need[j] = need.get(j, 0.0) + ln.duration + 0.15
        trims = find_dead_air(plan.story, self.transcript, self.audio, self.visual, self._best_src,
                              protect={j: v + 0.4 for j, v in need.items()}) \
            if getattr(es, "tighten_pauses", True) else {}
        tl = build_out_timeline(plan.story, sections, plan.narration, self.transcript, T, self._best_src,
                                teaser=es.flash_forward_hook, cuts=cuts, trims=trims)
        if trims:
            self.log("Tightened pauses: " + ", ".join(f"clip {i + 1}: {sum(b - a for a, b in v):.1f}s"
                                                     for i, v in trims.items()))
        by_line = {id(ln): wt for ln, wt in zip(plan.narration, word_times)}
        best_out = [o for o in (tl.to_output(i, bm) for i, bm in self._best_src.items() if i < len(tl.item_spans))
                    if o is not None]
        old_edits = {(c.kind, round(c.start, 1)): c for c in plan.captions if c.edited}
        chunks = build_captions(tl, [by_line[id(p.line)] for p in tl.narration], es, best_out)
        for c in chunks:
            e = old_edits.get((c.kind, round(c.start, 1)))
            if e is not None:
                c.words, c.edited = e.words, True
        plan.captions = chunks
        defaults = default_overlays(plan, tl, es)
        if keep_overlays and plan.overlays:
            # keep the user's text edits, re-time to the new edit
            kinds: dict = {}
            for o in defaults:
                k = kinds[o.kind] = kinds.get(o.kind, -1) + 1
                prev = [x for x in plan.overlays if x.kind == o.kind]
                if k < len(prev) and prev[k].text.strip():
                    o.text = prev[k].text
            defaults += [o for o in plan.overlays if o.kind == "emphasis"]
        plan.overlays = defaults
        self.edit_timeline = tl
        self.mark_made("edit")
        self.project.meta["fp"]["edit_story"] = self._fp([(it.cid, round(it.start, 2), round(it.end, 2))
                                                          for it in plan.story])
        self._release_after("edit")
        self.log(f"Edit ready: {tl.duration:.1f}s, {len(tl.narration)} narration lines, {len(chunks)} caption groups")
        return tl

    def _scene_cuts(self, sections: dict) -> dict[int, list[float]]:
        """Scene changes near each clip's start, end and best moment (source time), cached."""
        plan = self.project.plan
        store = self.cache.load_json("scene_cuts.json") or {}
        out: dict[int, list[float]] = {}
        changed = False
        for i, it in enumerate(plan.story):
            f, f0 = sections[i]
            spans = [(it.start - 6.5, it.start + 3.6), (it.end - 3.6, it.end + 1.5)]
            bm = getattr(self, "_best_src", {}).get(i)
            if bm is not None:
                spans.append((bm - 3.0, bm + 3.0))
            found: set[float] = set()
            for a, b in spans:
                a, b = max(f0, a), b
                key = f"{Path(f).name}|{a - f0:.2f}|{b - f0:.2f}"
                if key not in store:
                    try:
                        store[key] = [round(c + f0, 3) for c in ff.detect_cuts(f, a - f0, b - f0)]
                    except Exception:  # noqa: BLE001  (cut detection is a refinement, never a failure)
                        store[key] = []
                    changed = True
                found.update(store[key])
            out[i] = sorted(found)
        if changed:
            self.cache.save_json("scene_cuts.json", store)
        return out

    def _credits(self) -> list[str]:
        """'Footage: creator - link' for every video whose pictures or sound are used."""
        fl = {f.source_id: f for f in (self._footage or [])}
        used = {sh.source_id for s in self.project.plan.sections for sh in s.shots}
        if any(s.kind == "moment" for s in self.project.plan.sections) and self.project.source is not None:
            used.add(self.project.source.source_id)
        out = []
        for sid in sorted(used):
            f = fl.get(sid)
            if f is None:
                continue
            s, r = f.src, f.src.rights
            out.append(f"Footage: {s.uploader or r.creator or s.title or 'source creator'}"
                       + (f" - {s.url}" if s.url else (f" ({s.title})" if s.title else "")))
        return out

    # -------------------------------------------------------------- 6. export
    def export(self, hook_indices: Optional[list[int]] = None, progress: Optional[Progress] = None,
               out_dir: str = "") -> list[tuple[Path, "object"]]:
        from .render.qc import run_qc
        from .render.render import RenderJob, render

        src, plan = self.project.source, self.project.plan
        assert src is not None
        problems = src.rights.problems(plan.monetized)
        if self.is_creative():
            from .creative import workflow

            # every video whose pictures or sound appear must have its permission recorded
            problems = workflow.rights_problems(self)
            if any(s.kind == "moment" for s in plan.sections) or any(
                    sh.source_id == src.source_id for s in plan.sections for sh in s.shots):
                problems = src.rights.problems(plan.monetized) + problems
        if problems:
            raise PermissionError("Export blocked until footage rights are recorded:\n- " + "\n- ".join(problems))
        hook_indices = hook_indices if hook_indices else [plan.chosen_hook]
        original_hook = plan.chosen_hook
        out_root = Path(out_dir or self.settings.output_dir)
        out_root.mkdir(parents=True, exist_ok=True)
        from .core.storage import check_space

        # a 1080x1920 Short is ~5-15 MB per 10 s; renders also need room for working files
        check_space(out_root, 60e6 * len(hook_indices), "exporting this Short")
        check_space(self.cache.dir, 300e6, "rendering this Short")
        results = []
        base = _safe_name(plan.title or plan.topic.summary or "short")
        stamp = time.strftime("%Y%m%d-%H%M")
        for n, h in enumerate(hook_indices):
            if h != plan.chosen_hook or self.edit_timeline is None:
                if h != plan.chosen_hook:
                    self.choose_hook(h)
                self.prepare_edit(progress)
            tl = self.edit_timeline
            suffix = f"_hook{h + 1}" if len(hook_indices) > 1 else ""
            out = out_root / f"{base}_{stamp}{suffix}.mp4"
            job = RenderJob(timeline=tl, chunks=plan.captions, overlays=plan.overlays, edit=self.edit_settings(),
                            workdir=self.cache.subdir("render") / f"{stamp}_{h}", out_path=out,
                            best_moments=getattr(self, "_best_src", {}), visual_profile=self.visual,
                            facecam=self.visual.facecam if self.visual is not None else None,
                            seed=src.source_id + str(h),
                            visual_profiles=self._creative_profiles if self.is_creative() else None)
            sub = (lambda f, m, n=n: progress("render", (n + f) / len(hook_indices), m)) if progress else None
            path = render(job, sub, self._cancelled)
            rep = run_qc(str(path), self.settings.edit, tl.duration, plan.captions, plan.target_seconds, tl)
            try:
                from .story_eval import evaluate_plan

                self.story_quality = evaluate_plan(plan, self.project.candidates, self.transcript, self.timeline, tl)
            except Exception:  # noqa: BLE001  (informational only)
                self.story_quality = None
            _write_sidecar(path, plan, src, rep, self.used, self._credits() if self.is_creative() else None)
            self.log(f"Exported {path.name}: QC {'passed' if rep.passed else 'FAILED'}")
            results.append((path, rep))
            shutil.rmtree(job.workdir, ignore_errors=True)
        if plan.chosen_hook != original_hook:
            self.choose_hook(original_hook)
            self.edit_timeline = None
        self.project.last_export = str(results[-1][0]) if results else ""
        self.mark_made("export")
        self.project.meta["status"] = "exported"
        self.project.save()
        self._release_after("export")
        return results


def _safe_name(s: str) -> str:
    import re as _re

    s = _re.sub(r"[^\w\- ]+", "", s).strip().replace(" ", "_")
    return (s or "short")[:60]


def _write_sidecar(path: Path, plan: Plan, src: VideoSource, rep, used: dict, credits: Optional[list] = None) -> None:
    """Upload helper text: title, description with source credit, rights record, QC result."""
    r = src.rights
    footage = credits or [f"Footage: {src.uploader or r.creator or 'source creator'}" + (f" - {src.url}" if src.url else "")]
    lines = [f"TITLE: {plan.title}", "", "DESCRIPTION:", plan.description, "", *footage,
             *([plan.sources_note] if plan.sources_note else []),
             "", "---- for your records (not for upload) ----",
             f"Rights basis: {r.basis} | creator: {r.creator} | commercial use: {r.commercial_use} | "
             f"publisher policy checked: {r.game_publisher_ok} | monetized: {plan.monetized}",
             f"Notes: {r.notes}", f"Engines used: {used}", "", "QC:", rep.summary()]
    path.with_suffix(".txt").write_text("\n".join(lines), encoding="utf-8")
