"""ClipForge's script writer (1.7.0). See ``engine`` for how it works and why.

``research`` finds the facts, ``Writer.write`` plans, hooks, drafts, reviews and rewrites, and
``to_sections`` turns a passed script into the sections the rest of the pipeline already uses
(footage matching, voice, captions are unchanged).
"""
from __future__ import annotations

from typing import Callable, Optional

from ..core.models import Section
from .engine import (AREAS, THRESHOLDS, ScriptRejected, ScriptResult, Writer, classify, game_note,  # noqa: F401
                     requested_count, requested_ending, word_range)


def research(prompt: str, subject: str, category: str, llm, log: Optional[Callable[[str], None]] = None,
             opener=None) -> tuple[list, list[dict]]:
    """Look the topic up (GTA Wiki + Wikipedia), asking the model which wiki pages to read first.
    Returns (sources, facts)."""
    from ..creative import factfind
    from . import prompts as P

    import copy
    import re

    queries: list[str] = []
    if llm is not None and hasattr(llm, "temperature"):      # looking things up is not a creative job
        llm = copy.copy(llm)
        llm.temperature = 0.2

    game = any(re.search(pat, (subject + " " + prompt).lower()) for pat, _api, _site in factfind.GAME_WIKIS)
    if llm is not None and game:
        try:
            d = llm.complete_json(P.SEARCH_SYSTEM, P.SEARCH_PROMPT.format(prompt=prompt[:600]), max_tokens=300)
            queries = [str(x).strip() for x in (d.get("pages") or []) + (d.get("searches") or [])
                       if str(x).strip()][:6]
        except Exception:  # noqa: BLE001
            queries = []
    secrets = bool(re.search(r"secret|easter egg|hidden|cheat", prompt or "", re.I))
    queries = list(dict.fromkeys(queries + factfind.default_queries(subject or prompt, prompt,
                                                                     "gaming" if secrets else "")))
    srcs = factfind.find_sources(prompt, subject or prompt, category or "gaming", queries=queries[:8], opener=opener,
                                 log=log)
    facts = factfind.extract_facts(prompt, srcs, llm, n=14) if (srcs and llm is not None) else []
    return srcs, facts


def to_sections(lines: list[str], claims: str = "") -> list[Section]:
    from ..creative.narration import clean_line, visuals_from_text

    secs = []
    for k, t in enumerate(lines):
        t = clean_line(t)
        if not t:
            continue
        role = "hook" if k == 0 else ("conclusion" if k == len(lines) - 1 and len(lines) > 2 else "point")
        secs.append(Section(sid=f"s{k + 1}", role=role, text=t, visuals=visuals_from_text(t), claims=claims))
    return secs
