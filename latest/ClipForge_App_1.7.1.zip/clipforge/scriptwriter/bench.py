"""``clipforge-cli scriptbench``: write scripts for 10+ GTA topics with THIS PC's real language model
and keep everything: research, plan, hooks, every draft, its scores and problems, and whether it
passed. Nothing is simulated. The report is written after every topic to
%APPDATA%\\ClipForge\\logs\\scriptbench-<time>.txt (and .json), so a partial run is readable.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

# (format, request) - GTA 5 / GTA Online, the seven formats the creator asked to test, plus their channel intro
TOPICS = [
    ("one specific tip", "One GTA 5 tip: the fastest way to lose a wanted level"),
    ("hidden mechanic", "A GTA 5 mechanic most players don't understand: how the police search cone works when "
                        "your wanted stars are flashing"),
    ("money-making", "How the Nightclub makes passive money in GTA Online"),
    ("money-making", "Is the Acid Lab worth buying in GTA Online? Explain how it makes money"),
    ("mistake players make", "A common mistake GTA Online players make with their Bunker"),
    ("GTA Online feature", "Explain what the Agency and the Dr. Dre contract are in GTA Online"),
    ("mission strategy", "Cayo Perico Heist: a strategy for the finale"),
    ("interesting discovery", "The UFO on Mount Chiliad in GTA 5"),
    ("vehicle", "Why the Oppressor Mk II is the most hated vehicle in GTA Online"),
    ("money-making (Story Mode)", "Using Lester's assassination missions to make money on the stock market in GTA 5 "
                                  "Story Mode"),
    ("channel intro", "45-second intro for my YouTube channel Vice Intel, before GTA 6 releases. Tell viewers what "
                      "the channel is: one Short every day from launch, with secrets, fastest money methods, how to "
                      "lose the cops, and small details most players miss. Fast, excited, talking straight to the "
                      "viewer. End with \"Follow so you don't miss launch day.\""),
]


def run_one(request: str, llm, seconds: float = 40.0, research: bool = True, log=print) -> dict:
    from . import Writer, classify
    from . import research as do_research
    from ..creative.brief import rule_brief
    from ..creative import factfind

    b = rule_brief(request)
    kind = classify(request, b.category)
    t0 = time.time()
    srcs, facts = ([], [])
    if research and kind == "facts":
        srcs, facts = do_research(request, b.subject or request, b.category or "", llm, log=log)
    t_research = time.time() - t0
    res = Writer(llm, log=log).write(request, kind, facts, factfind.as_text(srcs) if srcs else "", seconds,
                                     b.category or "")
    d = res.to_dict()
    d.update({"request": request, "sources": [{"title": s.title, "url": s.url, "site": s.site} for s in srcs],
              "research_seconds": round(t_research, 1)})
    return d


def text_report(rows: list[dict], model: str) -> str:
    out = [f"ClipForge script benchmark — model: {model} — {time.strftime('%Y-%m-%d %H:%M')}",
           f"{sum(1 for r in rows if r.get('ok'))}/{len(rows)} passed the quality check", ""]
    for k, r in enumerate(rows, 1):
        out.append("=" * 100)
        out.append(f"{k}. [{r.get('format', '')}] {r['request']}")
        out.append(f"   kind: {r.get('kind')}   result: {'PASSED' if r.get('ok') else 'REJECTED'}   "
                   f"time: research {r.get('research_seconds', 0)} s + writing {r.get('seconds', 0)} s")
        if r.get("error"):
            out.append(f"   ERROR: {r['error']}")
            continue
        out.append(f"   sources: " + ("; ".join(s["title"] for s in r.get("sources", [])) or "none"))
        for i, f in enumerate(r.get("facts") or [], 1):
            out.append(f"     F{i}. {f['fact']} [{f.get('source', '')}]")
        p = r.get("plan") or {}
        if p:
            out.append(f"   PLAN: {p.get('understanding', '')}")
            out.append(f"     learns: {p.get('takeaway', '')}")
            out.append(f"     angle: {p.get('angle', '')}   game: {p.get('game_version', '')}")
            for j, bt in enumerate(p.get("beats") or [], 1):
                out.append(f"     beat {j} ({bt.get('role')}): {bt.get('says')} {bt.get('facts') or ''}")
        if r.get("hooks"):
            out.append("   HOOKS (ranked):")
            for h in r["hooks"][:6]:
                out.append(f"     {h.get('score', '')}  {h['text']}  ({h.get('technique', '')})")
        for a in r.get("attempts") or []:
            out.append(f"   --- {a['label']}: {'PASSED' if a['passed'] else 'failed'}  ({a['seconds']} s)")
            out.append("     scores: " + ", ".join(f"{k2} {v}" for k2, v in a["scores"].items()))
            out.append("     script: " + " ".join(a["lines"]))
            for pr in a["problems"][:10]:
                out.append(f"       - {pr}")
        if not r.get("ok"):
            out.append(f"   REJECTED BECAUSE: {r.get('reason', '')}")
        out.append("")
    return "\n".join(out)


def main(argv=None) -> int:
    from ..config import Settings, app_dir
    from ..services import Services

    ap = argparse.ArgumentParser(prog="clipforge-cli scriptbench",
                                 description="Write scripts for GTA topics with this PC's real language model and "
                                             "save a full report (research, plan, hooks, drafts, scores).")
    ap.add_argument("--topic", action="append", default=[], help="your own request (repeatable); default: 11 built-in")
    ap.add_argument("--seconds", type=float, default=40)
    ap.add_argument("--no-research", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args(argv)
    sv = Services(Settings.load())
    if not sv.llm_available():
        print("No language model: start Ollama (and download the model in AI Models), then try again.")
        return 2
    llm = sv.writer_llm()
    model = getattr(llm, "model", getattr(llm, "name", "?"))
    topics = [("your topic", t) for t in a.topic] or TOPICS
    if a.limit:
        topics = topics[: a.limit]
    d = app_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M")
    txt, js = d / f"scriptbench-{stamp}.txt", d / f"scriptbench-{stamp}.json"
    rows = []
    print(f"Model: {model}. Writing {len(topics)} scripts; report: {txt}")
    for k, (fmt, req) in enumerate(topics, 1):
        print(f"\n[{k}/{len(topics)}] {req[:90]}")
        try:
            r = run_one(req, llm, a.seconds, not a.no_research, log=lambda m: print("   " + m))
        except Exception as e:  # noqa: BLE001  (one topic failing must not lose the others)
            r = {"request": req, "ok": False, "error": f"{type(e).__name__}: {e}"}
        r["format"] = fmt
        rows.append(r)
        print("   -> " + ("PASSED" if r.get("ok") else "REJECTED: " + str(r.get("reason") or r.get("error"))[:200]))
        if r.get("lines"):
            print("   " + " ".join(r["lines"]))
        Path(js).write_text(json.dumps({"model": model, "rows": rows}, indent=1, ensure_ascii=False), encoding="utf-8")
        Path(txt).write_text(text_report(rows, model), encoding="utf-8")
    print(f"\nDone: {sum(1 for r in rows if r.get('ok'))}/{len(rows)} passed. Full report: {txt}")
    return 0
