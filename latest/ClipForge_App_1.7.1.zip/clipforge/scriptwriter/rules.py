"""Checks that need no language model. They can only LOWER a score the reviewer gave, never raise
one (a small model grading its own script tends to be generous, so these are the floor of honesty).

Each finding names the sentence it is about, so a rewrite can be told exactly what to fix.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# openers the creator called weak when they don't add a specific reason to watch
GENERIC_OPENERS = re.compile(
    r"^\s*(?:did you know|here (?:are|is|'s a list)|today,? (?:we|i)|in this video|you won'?t believe|"
    r"most (?:gta )?players (?:don'?t|do not|never) know|hey|hi|welcome|what'?s up|let'?s (?:talk|dive|look)|"
    r"have you ever|ever wondered|so,? |okay,? |alright,? )", re.I)
FILLER = re.compile(r"\b(hidden features?|cool (?:facts|details|stuff|things)|every trick counts|truly special|"
                    r"so much more|and more|stay ahead of (?:the game|everyone)|level up|game[- ]changing|"
                    r"mind[- ]blowing|insane|crazy good|amazing|incredible|epic|next level|don'?t miss out|"
                    r"make sure (?:to|you) (?:use|try) (?:these|this)|lots of ways|many ways|there are (?:lots|many)|"
                    r"some are better than others|in today'?s video|let'?s dive in|without further ado|"
                    r"smash that like|like and subscribe)\b", re.I)
HYPE = re.compile(r"!{2,}|\b(insane|crazy|epic|amazing|incredible|unbelievable|mind[- ]blowing|game[- ]changing)\b", re.I)
CONJ = re.compile(r"\b(and|but|so|or|because|then|while|if|when|which|that|since|until|before|after|once|where)\b",
                  re.I)

# a word list good enough to tell a sentence from a fragment ("Hidden tricks, daily from launch.")
_VERBS = set("""
be am is are was were been being do does did done have has had having can could will would shall should may might
must need needs let lets get gets got getting go goes went going come comes came make makes made take takes took
give gives gave keep keeps kept put puts run runs ran use uses used find finds found buy buys bought sell sells sold
earn earns pay pays paid cost costs spend spends save saves stop stops start starts try tries tried want wants know
knows knew think thinks see sees saw look looks watch watches drive drives drove fly flies flew shoot shoots shot
kill kills hit hits lose loses lost win wins won miss misses move moves turn turns open opens close closes call calls
park parks steal steals rob robs hide hides avoid avoids leave leaves stay stays wait waits head heads skip skips
grab grabs pick picks press presses hold holds switch switches upgrade upgrades unlock unlocks own owns assign assigns
build builds generate generates produce produces fill fills sit sits work works works play plays finish finishes
complete completes do does deliver delivers sell source sources resupply resupplies spawn spawns respawn appear
appears happen happens matter matters mean means show shows tell tells say says said explain explains notice notices
check checks follow follows join joins post posts drop drops launch launches release releases help helps waste wastes
double doubles boost boosts beat beats escape escapes crash crashes ram rams block blocks lure lures chase chases
lock locks track tracks spot spots reach reaches set sets add adds remove removes change changes cut cuts count counts
feel feels seem seems become becomes became give gave land lands jump jumps climb climbs swim swims dive dives
store stores stack stacks collect collects deposit deposits withdraw withdraws invest invests sit sits wait gets
cover covers hold covers carry carries load loads rack racks trigger triggers fail fails pass passes beat
guess guesses learn learns teach teaches remember remembers forget forgets ignore ignores overlook overlooks
discover explore spot catch master grind farm level rank craft equip aim reload crouch sprint sneak dodge flee
evade outrun outsmart bail eject respawn customize customise tune modify repair fix rent hire fire recruit invite
host plan prepare scout gather prep set setup sign subscribe watch notice uncover reveal unlock find search hunt
""".split())
# words a noun phrase starts with; a verbless sentence that starts like this is a fragment,
# while an unknown first word is probably an imperative verb we don't list ("Discover the…")
_NP_START = set("""a an the this that these those my your our their his her its every each some any all no one two
three four five six seven eight nine ten new old hidden small big huge fastest best worst easiest hardest quickest
secret secrets daily more most less few many fresh top bonus extra free real true""".split())
_SUBJ_AUX = re.compile(r"\b(i|you|we|they|he|she|it|this|that|there|which|who)(?:'(?:re|ll|ve|d|s|m))\b|"
                       r"\b(?:isn'?t|aren'?t|wasn'?t|don'?t|doesn'?t|didn'?t|can'?t|won'?t|shouldn'?t|"
                       r"couldn'?t|wouldn'?t|here'?s|there'?s|that'?s|what'?s|it'?s|let'?s)\b", re.I)


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+(?=[\"'A-Z0-9$])", " ".join((text or "").split()))
    return [p.strip() for p in parts if p.strip()]


def words(s: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9$%']+", s or "")


def has_verb(s: str) -> bool:
    if _SUBJ_AUX.search(s):
        return True
    for w in words(s.lower()):
        w = w.strip("'")
        if w in _VERBS:
            return True
        if len(w) > 4 and (w.endswith("ing") or w.endswith("ed")) and w[:-3] in _VERBS | {x + "e" for x in _VERBS}:
            return True
        if len(w) > 3 and w.endswith("s") and w[:-1] in _VERBS:
            return True
    return False


def is_fragment(s: str) -> str:
    """'' or why the sentence won't make sense spoken on its own."""
    ws = words(s)
    if len(ws) <= 2:
        return ""                       # "Here's how." / "Not anymore." are fine spoken
    first = ws[0].lower()
    np_start = first in _NP_START or first.endswith("est") or first[:1].isdigit()
    if not has_verb(s) and np_start and not (s.rstrip().endswith("?") and len(ws) <= 8):  # "Five stars and still alive?"
        return "it has no verb, so it isn't a sentence"
    # "Block roadways with trash truck, lose cops." - two clipped clauses glued by a comma
    if "," in s and len(ws) <= 9 and not CONJ.search(s) and not s.rstrip().endswith("?"):
        left, right = s.split(",", 1)
        if len(words(left)) <= 5 and len(words(right)) <= 5:
            return "two clipped phrases joined by a comma (telegraph style)"
    return ""


@dataclass
class Finding:
    area: str          # hook / information / logic / accuracy / natural / clarity / pacing
    sentence: int      # 1-based sentence number, 0 = whole script
    message: str
    penalty: float


# names that need no source in a GTA video (they're the game's own basic vocabulary)
COMMON_NAMES = set("""gta grand theft auto online story mode los santos blaine county rockstar rockstar games michael
franklin trevor lester lamar vice city leonida lucia jason liberty city san andreas police lspd cops wanted level
stars maze bank fleeca pacific standard ammu-nation los santos customs benny's paleto bay sandy shores mount chiliad
vinewood ps5 ps4 xbox pc series x gta+ shark card shark cards contact missions heists heist ceo mc vip i you we""".split())

_NUM = re.compile(r"\$\s?[\d,.]+(?:\s?(?:k|m|million|thousand))?|\b\d[\d,.]*\s?%|\b\d[\d,.]*\b", re.I)
_SPELLED_NUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
                "ten": 10}


def numbers(s: str) -> list[str]:
    out = []
    for m in _NUM.finditer(s or ""):
        v = m.group(0).strip()
        digits = re.sub(r"[^\d]", "", v)
        if not digits:
            continue
        if not any(c in v for c in "$%") and int(digits[:6] or 0) <= 10 and len(digits) <= 2:
            continue                    # "two ways", "5 stars": counts, not claims
        out.append(v)
    return out


def _norm_num(v: str) -> str:
    return re.sub(r"[^\d]", "", v)


def check(lines: list[str], hook: str, evidence: str, request: str, min_words: int, max_words: int,
          kind: str, ending: str = "") -> list[Finding]:
    """Deterministic findings for a script (lines = the narration in order, hook = its first line)."""
    out: list[Finding] = []
    text = " ".join(lines)
    sents = sentences(text)
    ev = (evidence + " " + request).lower()
    ev_nums = {_norm_num(v) for v in numbers(ev)}
    # ---- hook
    hw = len(words(hook))
    if GENERIC_OPENERS.search(hook):
        out.append(Finding("hook", 1, f"the hook opens with a generic phrase (\"{hook[:40]}…\")", 4.0))
    if hw > 16:
        out.append(Finding("hook", 1, f"the hook is {hw} words; it has to land in 2-3 seconds (16 words max)", 2.5))
    elif hw < 5:
        out.append(Finding("hook", 1, f"the hook is only {hw} words; it doesn't say what the video is about", 2.0))
    fr = is_fragment(hook)
    if fr:
        out.append(Finding("hook", 1, f"the hook isn't a real sentence: {fr}", 3.0))
    # ---- sentences
    seen: list[set] = []
    for k, s in enumerate(sents, 1):
        fr = is_fragment(s)
        if fr and k > 1:
            out.append(Finding("natural", k, f"\"{s}\": {fr}", 2.0))
        f = FILLER.search(s)
        if f:
            out.append(Finding("information", k, f"\"{f.group(0)}\" is filler: it tells the viewer nothing", 1.5))
        if HYPE.search(s):
            out.append(Finding("natural", k, f"\"{s[:50]}\" uses artificial hype", 1.0))
        if len(words(s)) > 28:
            out.append(Finding("clarity", k, f"sentence {k} is {len(words(s))} words; too long to follow by ear", 1.5))
        cw = {w.lower() for w in words(s) if len(w) > 3}
        for j, o in enumerate(seen, 1):
            if cw and o and len(cw & o) / min(len(cw), len(o)) >= 0.75 and min(len(cw), len(o)) >= 3:
                out.append(Finding("natural", k, f"sentence {k} repeats sentence {j}", 2.0))
                break
        seen.append(cw)
        # ---- accuracy: numbers / money / percentages nobody supplied
        if kind != "promo":
            for v in numbers(s):
                if _norm_num(v) not in ev_nums:
                    out.append(Finding("accuracy", k, f"\"{v}\" isn't in the facts or the request (unverified number)",
                                       3.0))
    # ---- length
    n = len(words(text))
    if n > max_words * 1.15:
        out.append(Finding("pacing", 0, f"{n} words is too long for this Short (max about {max_words})",
                           min(4.0, (n - max_words) / max(1, max_words) * 10)))
    elif n < min_words * 0.8:
        out.append(Finding("pacing", 0, f"only {n} words: too thin to deliver the point (about {min_words}+)",
                           min(4.0, (min_words - n) / max(1, min_words) * 10)))
    if ending and ending.lower().strip(" .!") not in text.lower():
        out.append(Finding("logic", len(sents), f"the creator's ending \"{ending}\" is missing", 1.0))
    return out
