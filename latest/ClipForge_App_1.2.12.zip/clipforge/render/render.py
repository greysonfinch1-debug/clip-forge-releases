"""Final video assembly.

1. Each story unit (optional hold frame + clip [+ closing hold]) is rendered to a vertical
   1080x1920 intermediate with its layout and zoom accents.
2. Units are joined with short cross-dissolves (or hard cuts).
3. One last pass mixes narration / ducked original audio / music / SFX, normalises loudness
   (two-pass loudnorm, -14 LUFS) and burns captions + overlays (ASS via libass).
Output: H.264 High, yuv420p, 30 fps, AAC 48 kHz stereo, +faststart — the format YouTube
recommends for Shorts.
"""
from __future__ import annotations

import subprocess

import random
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from ..config import ASSETS_DIR, EditSettings
from ..core import ffmpeg as ff
from ..core.models import CaptionChunk, Overlay
from . import audio as au
from .captions import write_ass
from .layout import action_center, layout_filter, punch_filter
from .timeline import Segment, Timeline

MUSIC_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus"}


@dataclass
class RenderJob:
    timeline: Timeline
    chunks: list[CaptionChunk]
    overlays: list[Overlay]
    edit: EditSettings
    workdir: Path
    out_path: Path
    best_moments: dict[int, float]          # story item index -> absolute source time of key moment
    visual_profile: object = None          # VisualFeatures (for action-centred crops) or None
    facecam: Optional[list] = None
    seed: str = ""


def _music_file(path: str, seed: str) -> Optional[str]:
    if not path:
        return None
    p = Path(path)
    if p.is_file() and p.suffix.lower() in MUSIC_EXT:
        return str(p)
    if p.is_dir():
        files = sorted(f for f in p.iterdir() if f.suffix.lower() in MUSIC_EXT)
        if files:
            return str(random.Random(seed).choice(files))
    return None


def _src_info(path: str, cache: dict) -> dict:
    if path not in cache:
        cache[path] = ff.media_info(path)
    return cache[path]


def render(job: RenderJob, progress: Optional[Callable[[float, str], None]] = None,
           cancel: Optional[Callable[[], bool]] = None) -> Path:
    es, tl = job.edit, job.timeline
    W, H, fps = es.width, es.height, es.fps
    work = Path(job.workdir).resolve()
    work.mkdir(parents=True, exist_ok=True)
    infos: dict = {}
    vf = job.visual_profile
    units: dict[int, list[Segment]] = {}
    for s in tl.segments:
        units.setdefault(s.unit, []).append(s)
    unit_ids = sorted(units)
    total_est = sum(s.out_end - s.out_start for s in tl.segments) + 1
    done = 0.0

    def sub(lo, hi, label):
        return (lambda f, m=None: progress(lo + (hi - lo) * f, label)) if progress else None

    # ---- 1. units
    unit_files: list[tuple[str, float]] = []
    for ui in unit_ids:
        segs = units[ui]
        inputs: list[str] = []
        fparts: list[str] = []
        vlabels, alabels = [], []
        for k, s in enumerate(segs):
            info = _src_info(s.src_file, infos)
            ax = action_center(getattr(vf, "profile", None), getattr(vf, "times", None),
                               s.source_start, s.source_start + max(1.0, s.duration if s.kind == "clip" else 3))
            idx = _count_inputs(inputs)
            if s.kind == "hold":
                png = work / f"hold_{ui}_{k}.png"
                ff.run(["-ss", f"{max(0.0, s.src_in):.3f}", "-i", s.src_file, "-frames:v", "1", "-update", "1",
                        str(png)], label="Hold frame")
                inputs += ["-loop", "1", "-framerate", str(fps), "-t", f"{s.duration:.3f}", "-i", str(png)]
                fparts.append(f"[{idx}:v]fps={fps},setsar=1[r{k}]")
                fparts.append(layout_filter(f"r{k}", f"l{k}", info["width"], info["height"], W, H, es.crop_mode, ax,
                                            job.facecam))
                fparts.append(punch_filter(f"l{k}", f"v{k}", W, H, fps, None, True, s.duration))
                fparts.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{s.duration:.3f}[a{k}]")
            else:
                dur = s.src_out - s.src_in
                inputs += ["-ss", f"{max(0.0, s.src_in):.3f}", "-t", f"{dur:.3f}", "-i", s.src_file]
                fparts.append(f"[{idx}:v]fps={fps},setsar=1,trim=0:{dur:.3f},setpts=PTS-STARTPTS[r{k}]")
                fparts.append(layout_filter(f"r{k}", f"l{k}", info["width"], info["height"], W, H, es.crop_mode, ax,
                                            job.facecam))
                bm = job.best_moments.get(s.item_index) if s.kind == "clip" else None
                at = (bm - s.source_start) if bm is not None and bm >= 0 else None
                fparts.append(punch_filter(f"l{k}", f"v{k}", W, H, fps, at, False, dur))
                if info["has_audio"]:
                    fparts.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:{dur:.3f},"
                                  f"asetpts=PTS-STARTPTS,apad=whole_dur={dur:.3f}[a{k}]")
                else:
                    fparts.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f}[a{k}]")
            vlabels.append(f"[v{k}]")
            alabels.append(f"[a{k}]")
        n = len(segs)
        cat = "".join(v + a for v, a in zip(vlabels, alabels))
        fparts.append(f"{cat}concat=n={n}:v=1:a=1[vout][aout]")
        upath = work / f"unit_{ui:02d}.mp4"
        udur = sum(s.duration for s in segs)
        ff.run(inputs + ["-filter_complex", ";".join(fparts), "-map", "[vout]", "-map", "[aout]",
                         "-c:v", "libx264", "-preset", es.preset, "-crf", str(max(10, es.crf - 2)), "-pix_fmt", "yuv420p",
                         "-r", str(fps), "-c:a", "pcm_s16le", "-ar", "48000", str(upath.with_suffix(".mkv"))],
               sub(done / total_est * 0.6, (done + udur) / total_est * 0.6, f"Editing clip {ui + 1}/{len(unit_ids)}"),
               udur, f"Editing clip {ui + 1}", cancel)
        done += udur
        real = ff.media_info(str(upath.with_suffix(".mkv")))["duration"]
        unit_files.append((str(upath.with_suffix(".mkv")), real))

    # ---- 2. join
    joined = work / "joined.mkv"
    T = tl.transition if es.transitions != "none" else 0.0
    if len(unit_files) == 1:
        shutil.copyfile(unit_files[0][0], joined)
    elif T > 0:
        ins, parts = [], []
        for f, _ in unit_files:
            ins += ["-i", f]
        acc_v, acc_a, offset = "[0:v]", "[0:a]", 0.0
        for k in range(1, len(unit_files)):
            offset += unit_files[k - 1][1] - T
            parts.append(f"{acc_v}[{k}:v]xfade=transition=fade:duration={T:.3f}:offset={offset:.3f}[xv{k}]")
            parts.append(f"{acc_a}[{k}:a]acrossfade=d={T:.3f}:c1=tri:c2=tri[xa{k}]")
            acc_v, acc_a = f"[xv{k}]", f"[xa{k}]"
        ff.run(ins + ["-filter_complex", ";".join(parts), "-map", acc_v, "-map", acc_a, "-c:v", "libx264",
                      "-preset", es.preset, "-crf", str(max(10, es.crf - 2)), "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le",
                      str(joined)], sub(0.6, 0.75, "Joining clips"), tl.duration, "Joining clips", cancel)
    else:
        lst = work / "concat.txt"
        lst.write_text("".join(f"file '{Path(f).as_posix()}'\n" for f, _ in unit_files), encoding="utf-8")
        ff.run(["-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(joined)], label="Joining clips")
    jdur = ff.media_info(str(joined))["duration"]

    # ---- 3. final mix + captions
    ass = write_ass(work / "captions.ass", job.chunks, job.overlays, es)
    inputs = ["-i", str(joined)]
    narr = [p for p in tl.narration if p.line.audio_path]
    for p in narr:
        inputs += ["-i", p.line.audio_path]
    nxt = 1 + len(narr)
    music = _music_file(es.music_path, job.seed)
    music_idx = None
    if music:
        inputs += ["-stream_loop", "-1", "-i", music]
        music_idx = nxt
        nxt += 1
    sfx_list: list[tuple[int, float, float]] = []
    if es.sfx_enabled:
        fx = au.make_sfx(work.parent / "_sfx")
        cut_times = [tl.item_spans[i][0] for i in range(1, len(tl.item_spans))]
        cut_times = [max(0.0, t - 0.2) for t in cut_times]
        if cut_times:
            inputs += ["-i", fx["whoosh"]]
            w_idx = nxt
            nxt += 1
            # an input can only be consumed once: reuse via asplit
            sfx_list += [(w_idx, t, -14.0) for t in cut_times]
        if any(o.kind == "headline" for o in job.overlays):
            inputs += ["-i", fx["pop"]]
            sfx_list.append((nxt, 0.05, -12.0))
            nxt += 1
    spans = [(p.out_start, p.out_start + p.line.duration) for p in narr]
    graph = au.build_mix_graph(len(narr), [p.out_start for p in narr], spans, jdur, es.original_audio_db,
                               es.narration_duck_db, music_idx, es.music_db, [], nxt)
    graph = _add_sfx(graph, sfx_list)
    if progress:
        progress(0.78, "Balancing audio")
    meas = au.measure_loudness(inputs, graph)
    # The subtitle filter takes file paths inside the filter text, where an apostrophe, bracket,
    # comma or colon in a folder name (C:\\Users\\Zoë O'Neil\\...) breaks FFmpeg's parsing. So the
    # final render runs inside the work folder and refers to plain relative names only.
    fonts_dir = work / "fonts"
    fonts_dir.mkdir(exist_ok=True)
    for f in (ASSETS_DIR / "fonts").glob("*.[ot]tf"):
        if not (fonts_dir / f.name).exists():
            shutil.copyfile(f, fonts_dir / f.name)
    # loudness normalisation, then a gentle true-peak safety limiter (AAC encoding adds overshoot)
    full = (graph + f";[amix]{au.loudnorm_filter(meas)},aresample=48000,"
            f"alimiter=limit=0.79:attack=5:release=60:level=0,asplit=2[aout][apcm]"
            f";[0:v]ass={ass.name}:fontsdir=fonts,format=yuv420p[vout]")
    out = Path(job.out_path).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.stem + ".part.mp4")
    pcm = work / "final_audio.wav"     # the finished mix before AAC encoding (for a peak correction)
    ff.run(inputs + ["-filter_complex", full, "-map", "[vout]", "-map", "[aout]", "-t", f"{jdur:.3f}",
                     "-c:v", "libx264", "-profile:v", "high", "-preset", es.preset, "-crf", str(es.crf),
                     "-pix_fmt", "yuv420p", "-r", str(fps), "-g", str(fps * 2), "-c:a", "aac", "-b:a", "192k",
                     "-ar", "48000", "-ac", "2", "-movflags", "+faststart", str(tmp),
                     "-map", "[apcm]", "-t", f"{jdur:.3f}", "-c:a", "pcm_s16le", str(pcm)],
           sub(0.8, 0.97, "Final render"), jdur, "Final render", cancel, cwd=str(work))
    _fix_true_peak(tmp, pcm, sub(0.97, 1.0, "Checking audio peaks"))
    tmp.replace(out)
    return out


TP_CEILING = -1.0   # dBTP after AAC encoding (platforms clip above 0; QC requires <= -0.5)


def _true_peak(path: Path) -> float | None:
    import re as _re

    r = subprocess.run([ff.ffmpeg_bin(), "-hide_banner", "-nostdin", "-i", str(path), "-map", "0:a",
                        "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", creationflags=ff._NO_WINDOW)
    tp = _re.findall(r"Peak:\s+(-?[\d.]+|-inf) dBFS", r.stderr)
    if not tp:
        return None
    return float(tp[-1]) if tp[-1] != "-inf" else -99.0


def _fix_true_peak(video: Path, pcm: Path, progress=None) -> None:
    """The AAC encoder can overshoot the limiter by 1-2 dB (more with some FFmpeg versions). If the
    encoded file's true peak is too high, re-encode only the audio, from the lossless mix, slightly
    quieter. The video stream is copied untouched."""
    try:
        for _ in range(2):
            tp = _true_peak(video)
            if tp is None or tp <= TP_CEILING or not pcm.exists():
                return
            gain = TP_CEILING - 0.3 - tp
            fixed = video.with_name(video.stem + ".tp.mp4")
            ff.run(["-i", str(video), "-i", str(pcm), "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                    "-af", f"volume={gain:.2f}dB", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
                    "-shortest", "-movflags", "+faststart", str(fixed)], progress, 0, "Audio peak correction")
            fixed.replace(video)
            pcm_gain = pcm.with_name("final_audio_g.wav")
            ff.run(["-i", str(pcm), "-af", f"volume={gain:.2f}dB", "-c:a", "pcm_s16le", str(pcm_gain)])
            pcm_gain.replace(pcm)
    finally:
        pcm.unlink(missing_ok=True)


def _count_inputs(args: list[str]) -> int:
    return sum(1 for a in args if a == "-i")


def _add_sfx(graph: str, sfx: list[tuple[int, float, float]]) -> str:
    """Insert SFX into the mix; one input file may be used several times (asplit)."""
    if not sfx:
        return graph
    by_idx: dict[int, list[tuple[float, float]]] = {}
    for idx, t, g in sfx:
        by_idx.setdefault(idx, []).append((t, g))
    pre, labels = [], []
    j = 0
    for idx, uses in by_idx.items():
        names = [f"sx{idx}_{u}" for u in range(len(uses))]
        if len(uses) > 1:
            pre.append(f"[{idx}:a]asplit={len(uses)}" + "".join(f"[{n}]" for n in names))
            srcs = [f"[{n}]" for n in names]
        else:
            srcs = [f"[{idx}:a]"]
        for src, (t, g) in zip(srcs, uses):
            ms = int(round(max(0.0, t) * 1000))
            pre.append(f"{src}aresample=48000,aformat=channel_layouts=stereo,volume={g}dB,adelay={ms}|{ms}[sf{j}]")
            labels.append(f"[sf{j}]")
            j += 1
    head, mix = graph.rsplit(";", 1)
    ins = mix.split("amix=inputs=")[0]
    n = int(mix.split("amix=inputs=")[1].split(":")[0])
    mix = mix.replace(f"{ins}amix=inputs={n}", f"{ins}{''.join(labels)}amix=inputs={n + len(labels)}", 1)
    return ";".join([head] + pre + [mix])
