"""Captions and text overlays, written as one ASS subtitle file burned in by libass.

* Narration and original dialogue use different styles, so viewers can tell the voice-over
  from what the streamer actually said.
* Word-by-word highlight with a small "pop" when each group appears.
* The line at each clip's strongest moment is shown in a larger "emphasis" style (quoted
  from the transcript, never invented).
* Everything stays inside the Shorts safe area (clear of the top bar, the right-hand
  buttons and the bottom description area) and chunks never overlap in time.
"""
from __future__ import annotations

import re
from pathlib import Path

from ..config import EditSettings
from ..core.models import CaptionChunk, Overlay, Plan, Word
from .timeline import Timeline

# Shorts UI safe area on a 1080x1920 canvas
SAFE_LEFT, SAFE_RIGHT, SAFE_TOP, SAFE_BOTTOM = 70, 150, 200, 420
PUNCT_BREAK = re.compile(r"[.!?,;:]$")


# ----------------------------------------------------------------------------- chunks

def group_words(words: list[Word], kind: str, per_line: int, max_gap: float = 0.55) -> list[CaptionChunk]:
    chunks: list[CaptionChunk] = []
    cur: list[Word] = []
    for w in words:
        if cur and (len(cur) >= per_line or w.start - cur[-1].end > max_gap or PUNCT_BREAK.search(cur[-1].text)
                    or w.speaker != cur[-1].speaker):          # never mix two speakers in one caption
            chunks.append(CaptionChunk(kind, cur[0].start, cur[-1].end, cur, speaker=cur[0].speaker))
            cur = []
        cur.append(Word(w.text, w.start, w.end, speaker=w.speaker))
    if cur:
        chunks.append(CaptionChunk(kind, cur[0].start, cur[-1].end, cur, speaker=cur[0].speaker))
    return chunks


# dialogue colour per speaker (S1 = main voice keeps the default colour)
SPEAKER_COLORS = ["#E8F4FF", "#B9F5C9", "#FFD0E1", "#FFE2A8", "#C9D4FF"]


def speaker_color(speaker: str) -> str:
    try:
        return SPEAKER_COLORS[(int(speaker.lstrip("S")) - 1) % len(SPEAKER_COLORS)]
    except ValueError:
        return SPEAKER_COLORS[0]


def build_captions(tl: Timeline, narration_words: list[list[Word]], es: EditSettings,
                   best_moments_out: list[float]) -> list[CaptionChunk]:
    """narration_words[k] are word timings *inside* narration line k (relative to its start)."""
    per = max(1, es.caption_words_per_line)
    chunks: list[CaptionChunk] = []
    narr_spans = []
    for pl, words in zip(tl.narration, narration_words):
        abs_words = [Word(w.text, pl.out_start + w.start, pl.out_start + w.end) for w in words]
        chunks += group_words(abs_words, "narration", per)
        narr_spans.append((pl.out_start - 0.05, pl.out_start + pl.line.duration + 0.05))
    if es.show_original_dialogue_captions:
        dwords = [w for w, _ in tl.dialogue_words
                  if not any(a < (w.start + w.end) / 2 < b for a, b in narr_spans)]
        dchunks = group_words(dwords, "dialogue", per)
        for bm in best_moments_out:  # the chunk containing / nearest after the key moment becomes emphasis
            near = [c for c in dchunks if c.end >= bm - 0.3 and c.start <= bm + 1.5]
            if near:
                near[0].kind = "emphasis"
        chunks += dchunks
    out = resolve_overlaps(chunks)
    for c in out:  # nothing may linger past the end of the video
        c.end = min(c.end, tl.duration - 0.05)
    return [c for c in out if c.end - c.start >= 0.1]


def resolve_overlaps(chunks: list[CaptionChunk]) -> list[CaptionChunk]:
    """Each chunk stays up until the next one starts (max +0.6 s) and never overlaps it.
    Narration wins when a narration chunk and a dialogue chunk collide."""
    chunks = sorted(chunks, key=lambda c: (c.start, 0 if c.kind == "narration" else 1))
    out: list[CaptionChunk] = []
    for c in chunks:
        if out and c.start < out[-1].end - 0.02:
            prev = out[-1]
            if prev.kind == "narration" and c.kind != "narration":
                if c.end <= prev.end + 0.15:
                    continue  # dialogue fully under narration: skip
                c.start = prev.end
            else:
                prev.end = max(prev.start + 0.2, c.start)
        out.append(c)
    for a, b in zip(out, out[1:]):
        a.end = min(max(a.end, a.start + 0.35) + 0.25, b.start)  # linger briefly, never into the next chunk
    if out:
        out[-1].end += 0.4
    return out


def retime_edited(chunk: CaptionChunk, new_text: str) -> None:
    """User corrected a caption: keep its time span, spread new words over it."""
    words = new_text.split()
    if not words:
        chunk.words = []
        return
    old = [w.text for w in chunk.words]
    if len(words) == len(old):
        for w, t in zip(chunk.words, words):
            w.text = t
    else:
        span = chunk.end - chunk.start
        weights = [max(1, len(w)) for w in words]
        tot = sum(weights)
        t, ws = chunk.start, []
        for w, k in zip(words, weights):
            d = span * k / tot
            ws.append(Word(w, t, t + d))
            t += d
        chunk.words = ws
    chunk.edited = True


# ----------------------------------------------------------------------------- overlays

def default_overlays(plan: Plan, tl: Timeline, es: EditSettings) -> list[Overlay]:
    ovs: list[Overlay] = []
    hook = plan.hooks[plan.chosen_hook] if plan.hooks else None
    first_end = tl.item_spans[0][1] if tl.item_spans else 3.0
    if hook and hook.headline:
        ovs.append(Overlay(hook.headline, "headline", 0.0, min(first_end, max(3.0, min(6.0, first_end)))))
    for i, it in enumerate(plan.story):
        if it.context_text and i < len(tl.item_spans):
            s = tl.item_spans[i][0] + (0.25 if i else 0.0)
            ovs.append(Overlay(it.context_text, "context", s + (6.0 if i == 0 and hook else 0.0),
                               s + (6.0 if i == 0 and hook else 0.0) + 2.6))
    if es.end_message:
        ovs.append(Overlay(es.end_message, "end", max(0.0, tl.duration - 2.2), tl.duration))
    return [o for o in ovs if o.t_end > o.t_start]


# ----------------------------------------------------------------------------- ASS writer

def _ass_color(hex_rgb: str, alpha: int | None = None) -> str:
    h = hex_rgb.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    a = alpha if alpha is not None else (255 - int(h[6:8], 16) if len(h) >= 8 else 0)
    return f"&H{a:02X}{b}{g}{r}".upper()


def _t(sec: float) -> str:
    sec = max(0.0, sec)
    cs = int(round(sec * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _esc(text: str) -> str:
    return text.replace("\\", "/").replace("{", "(").replace("}", ")").replace("\n", " ")


_FONT_CACHE: dict = {}


def text_width(text: str, font_name: str, size: int) -> float:
    """Rendered width in pixels (the bundled font when available, otherwise an estimate)."""
    key = (font_name, size)
    if key not in _FONT_CACHE:
        font = None
        try:
            from PIL import ImageFont

            from ..config import ASSETS_DIR

            f = ASSETS_DIR / "fonts" / f"{font_name}-Bold.ttf"
            font = ImageFont.truetype(str(f), size) if f.exists() else None
        except Exception:  # noqa: BLE001
            font = None
        _FONT_CACHE[key] = font
    font = _FONT_CACHE[key]
    if font is not None:
        return float(font.getlength(text))
    return 0.62 * size * len(text)


def fit_size(text: str, font_name: str, size: int, max_width: float, floor: float = 0.72) -> int:
    """Shrink a caption that wouldn't fit on one line (down to ``floor`` x; longer ones wrap)."""
    w = text_width(text, font_name, size) * 1.04 + size * 0.2   # + outline
    if w <= max_width:
        return size
    return max(int(size * floor), int(size * max_width / w))


def write_ass(path: str | Path, chunks: list[CaptionChunk], overlays: list[Overlay], es: EditSettings) -> Path:
    W, H = es.width, es.height
    sx, sy = W / 1080, H / 1920
    cap_y = int(min(es.caption_position * H, H - SAFE_BOTTOM * sy))
    head_y = int(max(es.headline_position * H, SAFE_TOP * sy))
    ml, mr = int(SAFE_LEFT * sx), int(SAFE_RIGHT * sx)
    white, hi, outline = _ass_color(es.caption_color), _ass_color(es.caption_highlight), _ass_color(es.caption_outline)
    box = _ass_color(es.headline_box[:7], 255 - int(es.headline_box[7:9], 16) if len(es.headline_box) >= 9 else 0x60)
    cs = int(es.caption_size * sx)
    styles = [
        # Name, Font, Size, Primary, Secondary, Outline, Back, Bold, Italic, Underline, Strike, ScaleX, ScaleY,
        # Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
        f"Style: Narration,{es.caption_font},{cs},{white},{hi},{outline},&H80000000,-1,0,0,0,100,100,0,0,1,"
        f"{max(3, cs // 14)},2,5,{ml},{mr},0,1",
        f"Style: Dialogue,{es.caption_font},{int(cs * 0.9)},{_ass_color('#E8F4FF')},{hi},{outline},&H80000000,-1,-1,0,0,"
        f"100,100,0,0,1,{max(3, cs // 16)},2,5,{ml},{mr},0,1",
        f"Style: Emphasis,{es.caption_font},{int(cs * 1.12)},{hi},{white},{outline},&H80000000,-1,0,0,0,100,100,0,0,1,"
        f"{max(4, cs // 12)},3,5,{ml},{mr},0,1",
        f"Style: Headline,{es.headline_font},{int(es.headline_size * sx)},{_ass_color(es.headline_color)},{white},"
        f"{box},{box},-1,0,0,0,100,100,0,0,3,18,0,8,{ml},{mr},{head_y},1",
        f"Style: Context,{es.caption_font},{int(cs * 0.6)},{_ass_color('#FFFFFF')},{white},&H40000000,&H40000000,"
        f"0,0,0,0,100,100,0,0,3,12,0,8,{ml},{mr},{head_y + int(es.headline_size * sx * 2.6)},1",
        f"Style: End,{es.headline_font},{int(es.headline_size * sx)},{hi},{white},{outline},&H80000000,-1,0,0,0,"
        f"100,100,0,0,1,5,2,5,{ml},{mr},0,1",
    ]
    events: list[str] = []
    cx = (ml + (W - mr)) // 2
    for c in chunks:
        if not c.words or c.end <= c.start:
            continue
        style = {"narration": "Narration", "dialogue": "Dialogue", "emphasis": "Emphasis"}.get(c.kind, "Dialogue")
        y = cap_y if c.kind != "emphasis" else cap_y - int(40 * sy)
        pop = r"\fscx82\fscy82\t(0,90,\fscx100\fscy100)" if c.kind != "emphasis" else \
              r"\fscx60\fscy60\t(0,120,\fscx112\fscy112)\t(120,220,\fscx100\fscy100)"
        words = c.words
        plain = " ".join(w.text for w in words)
        size = {"narration": cs, "dialogue": int(cs * 0.9), "emphasis": int(cs * 1.12)}.get(c.kind, int(cs * 0.9))
        fitted = fit_size(plain.upper() if c.kind != "dialogue" else plain, es.caption_font, size, W - ml - mr)
        fs = f"\\fs{fitted}" if fitted != size else ""
        if c.kind == "emphasis":
            text = _esc(plain).upper()
            events.append(f"Dialogue: 2,{_t(c.start)},{_t(c.end)},{style},,0,0,0,,{{\\an5\\pos({cx},{y}){fs}{pop}}}{text}")
            continue
        # one event per active word so the current word is highlighted (karaoke style)
        bounds = [max(c.start, w.start) for w in words] + [c.end]
        bounds[0] = c.start
        for k, w in enumerate(words):
            a, b = bounds[k], bounds[k + 1]
            if b - a < 0.02:
                continue
            parts = []
            base = white if c.kind == "narration" else _ass_color(speaker_color(c.speaker))
            for j, ww in enumerate(words):
                t = _esc(ww.text)
                if c.kind == "narration":
                    t = t.upper()
                parts.append(f"{{\\c{hi}}}{t}{{\\c{base}}}" if j == k else t)
            col = "" if c.kind == "narration" else f"\\c{base}"
            tag = f"{{\\an5\\pos({cx},{y}){fs}{col}{pop if k == 0 else ''}}}"
            events.append(f"Dialogue: 1,{_t(a)},{_t(b)},{style},,0,0,0,,{tag}{' '.join(parts)}")
    for o in overlays:
        if o.t_end <= o.t_start or not o.text.strip():
            continue
        txt = _esc(o.text.strip())
        if o.kind == "headline":
            y = int(o.position * H) if o.position >= 0 else head_y
            tag = f"{{\\an8\\pos({cx},{y})\\fad(120,200)\\fscx70\\fscy70\\t(0,140,\\fscx100\\fscy100)}}"
            events.append(f"Dialogue: 3,{_t(o.t_start)},{_t(o.t_end)},Headline,,0,0,0,,{tag}{txt.upper()}")
        elif o.kind == "context":
            y = int(o.position * H) if o.position >= 0 else head_y + int(es.headline_size * sx * 2.6)
            events.append(f"Dialogue: 3,{_t(o.t_start)},{_t(o.t_end)},Context,,0,0,0,,"
                          f"{{\\an8\\pos({cx},{y})\\fad(150,150)}}{txt}")
        elif o.kind == "end":
            y = int(o.position * H) if o.position >= 0 else int(H * 0.45)
            events.append(f"Dialogue: 3,{_t(o.t_start)},{_t(o.t_end)},End,,0,0,0,,"
                          f"{{\\an5\\pos({cx},{y})\\fad(200,0)\\fscx80\\fscy80\\t(0,200,\\fscx100\\fscy100)}}{txt.upper()}")
        else:  # emphasis overlay added manually by the user
            y = int(o.position * H) if o.position >= 0 else int(H * 0.5)
            events.append(f"Dialogue: 3,{_t(o.t_start)},{_t(o.t_end)},Emphasis,,0,0,0,,"
                          f"{{\\an5\\pos({cx},{y})\\fscx60\\fscy60\\t(0,120,\\fscx100\\fscy100)}}{txt.upper()}")
    head = (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {W}\nPlayResY: {H}\nWrapStyle: 0\n"
            f"ScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
            "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
            "MarginL, MarginR, MarginV, Encoding\n" + "\n".join(styles) +
            "\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
    p = Path(path)
    p.write_text(head + "\n".join(events) + "\n", encoding="utf-8")
    return p
