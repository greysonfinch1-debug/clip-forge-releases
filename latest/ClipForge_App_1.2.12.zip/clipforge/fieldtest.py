"""Field test: run ClipForge end to end on a list of real recordings and keep every result.

    clipforge-cli fieldtest <list.txt> [--out ClipForge_Test_Results] [--seconds 45] [--hooks 1] [--skip-validate]

list.txt, one recording per line (lines starting with # are ignored):
    <link or file path> | <topic> | <creator who gave permission> [| <seconds>] [| <rights: permission/own>]

Only use recordings you own or have the creator's permission to edit and publish.

Output (ClipForge_Test_Results/):
    00_model_validation/   every AI model run on known inputs (+ Ollama status), with timings
    01_source_info/        per recording: platform, duration, resolution, download/decode checks, timings
    02_selected_clips/     per recording: all judged candidates (json) + a preview of each chosen clip
    03_final_shorts/       the exported Shorts (+ their .txt sidecars)
    04_qc_reports/         QC report, objective review (json), 1-frame-per-second contact sheet, loudness plot
    05_failed_tests/       anything that failed, with the full error
    06_before_after/       (filled when a Short is re-rendered after a fix)
    summary.json / summary.md
Each recording runs in its own process so memory figures are per recording and one crash
can't stop the rest.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

DIRS = ["00_model_validation", "01_source_info", "02_selected_clips", "03_final_shorts", "04_qc_reports",
        "05_failed_tests", "06_before_after"]


# ----------------------------------------------------------------------------- resources
def peak_rss_mb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                            ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaNonPagedPoolUsage", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t),
                            ("PeakPagefileUsage", ctypes.c_size_t)]
            pmc = PMC()
            pmc.cb = ctypes.sizeof(PMC)
            k32 = ctypes.WinDLL("kernel32")
            k32.GetCurrentProcess.restype = wintypes.HANDLE      # 64-bit handle, not a C int
            fn = getattr(k32, "K32GetProcessMemoryInfo", None) or ctypes.WinDLL("psapi").GetProcessMemoryInfo
            fn.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
            fn.restype = wintypes.BOOL
            if not fn(k32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb):
                return -1.0
            return round(pmc.PeakWorkingSetSize / 2**20, 1)
        import resource

        return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
    except Exception:  # noqa: BLE001
        return -1.0


class GpuSampler(threading.Thread):
    """Peak GPU memory / utilisation via nvidia-smi (if there is an NVIDIA GPU)."""

    def __init__(self):
        super().__init__(daemon=True)
        self.exe = shutil.which("nvidia-smi")
        self.peak_mem = 0
        self.peak_util = 0
        self.stop = threading.Event()

    def run(self):
        while self.exe and not self.stop.is_set():
            try:
                out = subprocess.run([self.exe, "--query-gpu=memory.used,utilization.gpu", "--format=csv,noheader,nounits"],
                                     capture_output=True, text=True, timeout=10,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
                mem, util = [int(x) for x in out.strip().splitlines()[0].split(",")]
                self.peak_mem, self.peak_util = max(self.peak_mem, mem), max(self.peak_util, util)
            except Exception:  # noqa: BLE001
                pass
            self.stop.wait(2.0)


class StageClock:
    def __init__(self):
        self.t0 = time.time()
        self.first: dict[str, float] = {}
        self.last: dict[str, float] = {}
        self.order: list[str] = []
        self.messages: dict[str, str] = {}

    def __call__(self, stage: str, frac: float, msg: str):
        now = time.time() - self.t0
        if stage not in self.first:
            self.first[stage] = now
            self.order.append(stage)
        self.last[stage] = now
        step = int(frac * 10)
        if msg != self.messages.get(stage) or step != getattr(self, "_step", -1):
            self._step = step
            print(f"  [{now:6.0f}s] {stage:<10} {frac * 100:5.1f}%  {msg[:70]}", flush=True)
        self.messages[stage] = msg

    def table(self) -> dict:
        return {s: round(self.last[s] - self.first[s], 1) for s in self.order}


def slug(s: str, n: int = 40) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")[:n] or "video"


# ----------------------------------------------------------------------------- one recording (own process)
def run_one(spec: dict, out: Path) -> dict:
    from .config import Settings
    from .core import ffmpeg as ff
    from .pipeline import Pipeline
    from .review import review

    name = spec["name"]
    res: dict = {"name": name, "source": spec["source"], "topic": spec["topic"], "ok": False}
    gpu = GpuSampler()
    gpu.start()
    clock = StageClock()
    t_start = time.time()
    try:
        p = Pipeline(Settings.load())
        is_url = bool(re.match(r"https?://", spec["source"]))
        t = time.time()
        src = p.ingest(url=spec["source"] if is_url else "", path="" if is_url else spec["source"], progress=clock)
        res["ingest_s"] = round(time.time() - t, 1)
        # source information + "was the whole recording obtained and decodable?"
        info = {k: getattr(src, k) for k in ("platform", "title", "uploader", "duration", "width", "height", "fps",
                                              "url", "path", "proxy_path", "audio_path")}
        checks = {}
        for label, path in (("analysis_video", src.proxy_path), ("analysis_audio", src.audio_path),
                            ("full_file", src.path)):
            if path and Path(path).exists():
                try:
                    d = float(ff.media_info(path)["duration"])
                except Exception:  # noqa: BLE001
                    d = 0.0
                checks[label] = {"duration": round(d, 1), "covers_source": abs(d - src.duration) < max(3.0, 0.01 * src.duration),
                                 "size_mb": round(Path(path).stat().st_size / 2**20, 1)}
        info["completeness"] = checks
        res["source_duration_s"] = round(src.duration, 1)
        r = src.rights
        basis = {"permission": "written_permission", "own": "own"}.get(spec.get("rights", "permission"),
                                                                        spec.get("rights", "permission"))
        r.basis, r.creator, r.confirmed = basis, spec.get("creator") or src.uploader, True
        r.notes = "field test: the user stated they own this footage or the creator gave permission"
        p.save_rights()   # monetized stays off, so no commercial / publisher permission is claimed
        t = time.time()
        p.find_moments(spec["topic"], float(spec.get("seconds") or 45), 0, clock)
        res["find_moments_s"] = round(time.time() - t, 1)
        res["engines"] = dict(p.used)
        (out / "01_source_info" / f"{name}.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
        # candidates and chosen clips
        cand = [{"cid": c.cid, "start": round(c.start, 2), "end": round(c.end, 2), "score": round(c.final_score, 2),
                 "topic_match": c.topic_match, "entertainment": c.entertainment, "context": c.context_completeness,
                 "confidence": c.confidence, "judged_by": c.judged_by, "included": c.included,
                 "description": c.description, "why": c.why_matches, "reasons": c.reasons[:8]}
                for c in sorted(p.project.candidates, key=lambda c: -c.final_score)]
        clip_dir = out / "02_selected_clips" / name
        clip_dir.mkdir(parents=True, exist_ok=True)
        (clip_dir / "candidates.json").write_text(json.dumps(cand, indent=1), encoding="utf-8")
        plan = p.project.plan
        story = [{"order": i + 1, "cid": it.cid, "role": it.role, "start": round(it.start, 2), "end": round(it.end, 2),
                  "context_text": it.context_text,
                  # what is actually said in the clip: narration must not contradict or invent it
                  "dialogue": (p.transcript.text_between(it.start, it.end) if p.transcript else "")[:600]}
                 for i, it in enumerate(plan.story)]
        res["story"] = story
        res["hooks"] = [{"headline": h.headline, "opening_line": h.opening_line} for h in plan.hooks]
        res["narration"] = [{"clip": ln.item_index + 1, "position": ln.position, "text": ln.text} for ln in plan.narration]
        res["title"] = plan.title
        # export + QC + objective review
        t = time.time()
        nh = int(spec.get("hooks") or 1)
        results = p.export(None if nh <= 1 else list(range(min(nh, max(1, len(plan.hooks))))), clock,
                           out_dir=str(out / "03_final_shorts"))
        res["export_s"] = round(time.time() - t, 1)
        res["shorts"] = []
        tl = p.edit_timeline or p.prepare_edit(clock)
        story = [dict(st, start=round(it.start, 2), end=round(it.end, 2)) for st, it in zip(story, plan.story)]
        res["story"] = story
        for seg in [g for g in tl.segments if g.kind == "clip"]:
            # each chosen clip with up to 3 s before / 1.5 s after, to check the cut points
            st = story[seg.item_index]
            a0 = max(0.0, seg.src_in - 3.0)
            dur = (seg.src_out - a0) + 1.5
            dst = clip_dir / f"{st['order']:02d}_{st['role'] or 'clip'}_{int(st['start'])}-{int(st['end'])}s.mp4"
            try:
                ff.run(["-ss", f"{a0:.2f}", "-i", seg.src_file, "-t", f"{dur:.2f}", "-vf", "scale=-2:540",
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-c:a", "aac", "-y", str(dst)],
                       label="clip preview")
            except Exception as e:  # noqa: BLE001
                res.setdefault("warnings", []).append(f"clip preview {st['order']}: {e}"[:300])
        holds = [(s.out_start, s.out_end) for s in tl.segments if s.kind == "hold"] if tl else []
        for path, rep in results:
            qc_txt = out / "04_qc_reports" / f"{Path(path).stem}_qc.txt"
            qc_txt.write_text(rep.summary(), encoding="utf-8")
            rv = review(str(path), str(out / "04_qc_reports"), plan.to_dict(), holds)
            res["shorts"].append({"file": Path(path).name, "qc_passed": rep.passed, "review_flags": rv["flags"],
                                  "duration": rv["duration"], "lufs": rv["integrated_lufs"],
                                  "true_peak": rv["true_peak_db"]})
        try:
            sq = getattr(p, "story_quality", None)
            res["story_quality"] = sq if isinstance(sq, (dict, list, str, int, float)) else str(sq)
        except Exception:  # noqa: BLE001
            pass
        res["edit_log"] = [ln for ln in p.project.log if "Tightened" in ln or "scene changes" in ln
                           or "Edit ready" in ln][-6:]
        p.project.save()
        res["project"] = p.project.project_id
        res["ok"] = True
    except Exception as e:  # noqa: BLE001
        res["error"] = f"{type(e).__name__}: {e}"
        (out / "05_failed_tests" / f"{name}.txt").write_text(
            f"{spec}\n\n{traceback.format_exc()}\n\nlast stage messages: {json.dumps(clock.messages, indent=1)}",
            encoding="utf-8")
    finally:
        gpu.stop.set()
    res["stage_seconds"] = clock.table()
    res["total_s"] = round(time.time() - t_start, 1)
    res["peak_ram_mb"] = peak_rss_mb()
    res["peak_gpu_mem_mb"] = gpu.peak_mem if gpu.exe else None
    res["peak_gpu_util"] = gpu.peak_util if gpu.exe else None
    print()
    return res


def parse_list(text: str) -> list[dict]:
    specs = []
    for k, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) < 3:
            raise SystemExit(f"line {k}: need '<link or file> | <topic> | <creator who gave permission>'")
        spec = {"source": parts[0], "topic": parts[1], "creator": parts[2],
                "seconds": parts[3] if len(parts) > 3 and parts[3] else 45,
                "rights": parts[4] if len(parts) > 4 and parts[4] else "permission"}
        spec["name"] = f"{len(specs) + 1:02d}_{slug(spec['topic'], 24)}"
        specs.append(spec)
    return specs


def validate_models(out: Path) -> dict:
    from .config import Settings
    from .model_manager import ollama_status
    from .validate_models import run_all

    t = time.time()
    rep = run_all(progress=lambda st, f, m: print(f"\r{m[:80]:<80}", end="", flush=True))
    print()
    s = Settings.load()
    oll = ollama_status(s.llm.base_url, [s.llm.model, s.embedding.model, s.vision.captioner_model])
    text = rep.text() + f"\n\nOllama: {json.dumps(oll)}\nTotal {time.time() - t:.0f} s\n"
    (out / "00_model_validation" / "model_validation.txt").write_text(text, encoding="utf-8")
    return {"results": [{"name": r.name, "status": r.status, "detail": getattr(r, "detail", "")[:200]}
                        for r in rep.results], "ollama": oll}


def environment() -> dict:
    from . import __version__

    env = {"clipforge": __version__, "python": sys.version.split()[0], "os": platform.platform(),
           "cpu": platform.processor(), "cores": os.cpu_count(), "time": time.strftime("%Y-%m-%d %H:%M")}
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                        ("avail", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong),
                        ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
        if sys.platform == "win32":
            m = MS()
            m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            env["ram_gb"] = round(m.total / 2**30, 1)
    except Exception:  # noqa: BLE001
        pass
    gpu = shutil.which("nvidia-smi")
    if gpu:
        env["gpu"] = subprocess.run([gpu, "--query-gpu=name,memory.total", "--format=csv,noheader"],
                                    capture_output=True, text=True).stdout.strip()
    return env


def write_summary(out: Path, env: dict, models: dict | None, results: list[dict]) -> None:
    (out / "summary.json").write_text(json.dumps({"environment": env, "models": models, "recordings": results},
                                                 indent=1, default=str), encoding="utf-8")
    lines = [f"# ClipForge field test — {env.get('time')}", "",
             f"ClipForge {env.get('clipforge')} · {env.get('os')} · {env.get('cores')} cores · "
             f"{env.get('ram_gb', '?')} GB RAM · GPU: {env.get('gpu', 'none')}", "",
             "| # | Recording | Source length | Ingest | Analyse+select | Export | Peak RAM | QC | Review flags |",
             "|---|---|---|---|---|---|---|---|---|"]
    for r in results:
        sh = r.get("shorts") or []
        qc = "FAILED: " + r.get("error", "")[:60] if not r.get("ok") else \
            ", ".join("PASS" if s["qc_passed"] else "FAIL" for s in sh)
        flags = "; ".join(f for s in sh for f in s["review_flags"])[:120] or "none"
        lines.append(f"| {r['name']} | {r['source'][:50]} | {r.get('source_duration_s', '?')} s | {r.get('ingest_s', '?')} s"
                     f" | {r.get('find_moments_s', '?')} s | {r.get('export_s', '?')} s | {r.get('peak_ram_mb')} MB"
                     f" | {qc} | {flags} |")
    (out / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv=None) -> int:
    import argparse

    ap = argparse.ArgumentParser(prog="clipforge-cli fieldtest")
    ap.add_argument("list")
    ap.add_argument("--out", default=str(Path.home() / "Videos" / "ClipForge_Test_Results"))
    ap.add_argument("--hooks", type=int, default=1)
    ap.add_argument("--skip-validate", action="store_true")
    ap.add_argument("--only", default="", help="run only recordings whose number or name contains this")
    a = ap.parse_args(argv)
    out = Path(a.out)
    for d in DIRS:
        (out / d).mkdir(parents=True, exist_ok=True)
    specs = parse_list(Path(a.list).read_text(encoding="utf-8"))
    if a.only:
        specs = [s for s in specs if a.only in s["name"]]
    env = environment()
    models = None if a.skip_validate else validate_models(out)
    results = []
    prev = out / "summary.json"
    if prev.exists():   # keep earlier recordings' results when re-running some of them
        try:
            results = [r for r in json.loads(prev.read_text(encoding="utf-8"))["recordings"]
                       if r["name"] not in {s["name"] for s in specs}]
        except (OSError, ValueError, KeyError):
            results = []
    for spec in specs:
        spec["hooks"] = a.hooks
        print(f"\n=== {spec['name']}: {spec['source']}  —  {spec['topic']}")
        res_file = out / "05_failed_tests" / f".{spec['name']}.result.json"
        spec_file = out / "05_failed_tests" / f".{spec['name']}.spec.json"
        spec_file.write_text(json.dumps(spec), encoding="utf-8")   # no quoting problems on Windows
        cmd = _self_command() + ["fieldtest-one", str(spec_file), str(out), str(res_file)]
        t = time.time()
        rc = subprocess.run(cmd).returncode
        try:
            res = json.loads(res_file.read_text(encoding="utf-8"))
            res_file.unlink()
            spec_file.unlink()
        except (OSError, ValueError):
            res = {"name": spec["name"], "source": spec["source"], "topic": spec["topic"], "ok": False,
                   "error": f"process ended with code {rc} after {time.time() - t:.0f} s (crash?)"}
            (out / "05_failed_tests" / f"{spec['name']}.txt").write_text(res["error"], encoding="utf-8")
        results.append(res)
        results.sort(key=lambda r: r["name"])
        write_summary(out, env, models, results)
    print(f"\nDone. Results: {out}\n{(out / 'summary.md').read_text(encoding='utf-8')}")
    return 0


def _self_command() -> list[str]:
    inst = os.environ.get("CLIPFORGE_INSTALL_DIR")
    if inst and (Path(inst) / "clipforge-cli.exe").exists():
        return [str(Path(inst) / "clipforge-cli.exe"), "cli"]
    return [sys.executable, "-m", "clipforge.cli"]


def main_one(argv) -> int:
    spec, out, res_file = json.loads(Path(argv[0]).read_text(encoding="utf-8")), Path(argv[1]), Path(argv[2])
    res = run_one(spec, out)
    res_file.write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    return 0 if res.get("ok") else 1
