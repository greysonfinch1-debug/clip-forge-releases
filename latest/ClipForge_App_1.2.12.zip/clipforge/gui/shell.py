"""Desktop-application parts of the interface: app icon, AI model manager, About, the built-in
updater (check at start-up in the background → banner → one-click update → restart), the
first-launch welcome, and messages left by the launcher (e.g. an automatic rollback).

The six workflow pages are unchanged; these open from the sidebar or appear when needed.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QGroupBox, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit,
                               QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QTableWidget,
                               QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from .. import __version__, model_manager as mm, updater
from ..config import ASSETS_DIR, app_dir, data_dir

BRAND = ASSETS_DIR / "brand"
CLIP_EXTRA = ["open_clip_torch>=2.24"]


def app_icon() -> QIcon:
    ico = QIcon()
    for name in ("clipforge.ico", "clipforge_256.png", "clipforge_64.png"):
        p = BRAND / name
        if p.exists():
            ico.addFile(str(p))
    return ico


def _hint(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("hint")
    l.setWordWrap(True)
    return l


def open_folder(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


class Job(QThread):
    """Runs fn(progress, cancel) in the background for a dialog (with its own progress bar)."""
    progress = Signal(float, str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self._cancel = threading.Event()

    def cancel(self):
        self._cancel.set()

    def run(self):
        try:
            self.done.emit(self.fn(lambda f, m="": self.progress.emit(float(f), m or ""), self._cancel.is_set))
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e) or type(e).__name__)


# =============================================================================== AI models
class ModelsDialog(QDialog):
    """Which AI components are installed, and one-click downloads for the missing ones."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.s = win.pipeline.settings
        self.job: Job | None = None
        self.setWindowTitle("AI Models")
        self.resize(900, 620)
        lay = QVBoxLayout(self)
        lay.addWidget(_hint("ClipForge's AI models run on this computer. They are downloaded once, checked "
                            "against a known fingerprint (SHA-256), and kept when ClipForge is updated. "
                            f"Folder: {self.s.models_dir}"))
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["", "Model", "What it does", "Size / status"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        lay.addWidget(self.table, 1)
        row = QHBoxLayout()
        self.dl = QPushButton("Download missing models")
        self.dl.setObjectName("primary")
        self.dl.clicked.connect(self.download_missing)
        row.addWidget(self.dl)
        self.verify_btn = QPushButton("Verify installed models")
        self.verify_btn.clicked.connect(self.verify)
        row.addWidget(self.verify_btn)
        b = QPushButton("Open models folder")
        b.clicked.connect(lambda: open_folder(Path(self.s.models_dir)))
        row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        g = QGroupBox("Language model (Ollama, free, runs locally)")
        gl = QVBoxLayout(g)
        self.oll = QLabel("Checking…")
        self.oll.setWordWrap(True)
        gl.addWidget(self.oll)
        orow = QHBoxLayout()
        self.pull = QPushButton("Download missing Ollama models")
        self.pull.clicked.connect(self.pull_ollama)
        orow.addWidget(self.pull)
        b = QPushButton("Get Ollama (ollama.com)")
        b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://ollama.com/download")))
        orow.addWidget(b)
        orow.addStretch(1)
        gl.addLayout(orow)
        lay.addWidget(g)

        g = QGroupBox("Visual understanding (CLIP + PyTorch, optional, about 2 GB)")
        gl = QVBoxLayout(g)
        self.vis = QLabel("")
        self.vis.setWordWrap(True)
        gl.addWidget(self.vis)
        vrow = QHBoxLayout()
        self.vis_btn = QPushButton("Install visual understanding")
        self.vis_btn.clicked.connect(self.install_vision)
        vrow.addWidget(self.vis_btn)
        vrow.addStretch(1)
        gl.addLayout(vrow)
        lay.addWidget(g)

        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.msg = QLabel("")
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(lambda: self.job and self.job.cancel())
        prow = QHBoxLayout()
        prow.addWidget(self.bar, 1)
        prow.addWidget(self.cancel_btn)
        lay.addWidget(self.msg)
        lay.addLayout(prow)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.refresh()

    # ---- state
    def refresh(self):
        st = mm.status(self.s.models_dir)
        self.table.setRowCount(len(st))
        for r, m in enumerate(st):
            icon = "✅" if m["installed"] else "⬇"
            state = ("installed, verified" if m["verified"] else "installed") if m["installed"] else \
                f"not downloaded ({m['download_mb']} MB)"
            for c, v in enumerate((icon, m["name"], m["purpose"], state)):
                self.table.setItem(r, c, QTableWidgetItem(v))
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        missing = [m for m in st if not m["installed"]]
        self.dl.setEnabled(bool(missing) and not self._busy())
        self.dl.setText(f"Download missing models ({sum(m['download_mb'] for m in missing)} MB)" if missing
                        else "All models installed")
        threading.Thread(target=self._ollama_state, daemon=True).start()
        self._vision_state()

    def _wanted_ollama(self) -> list[str]:
        s = self.s
        w = []
        if s.llm.backend == "ollama":
            w.append(s.llm.model)
        if s.embedding.backend == "ollama":
            w.append(s.embedding.model)
        if s.vision.captioner == "ollama":
            w.append(s.vision.captioner_model)
        return [x for x in w if x]

    def _ollama_state(self):
        wanted = self._wanted_ollama()
        st = mm.ollama_status(self.s.llm.base_url, wanted) if wanted else {"running": None, "models": {}}
        QTimer.singleShot(0, self, lambda: self._show_ollama(st))

    def _show_ollama(self, st):
        self._oll = st
        if st["running"] is None:
            self.oll.setText("Ollama isn't used with your current Settings.")
            self.pull.setEnabled(False)
        elif not st["running"]:
            self.oll.setText("Ollama is not running. Install it from ollama.com (free) and start it; ClipForge then "
                             "uses it for judging clips and writing scripts. Without it, a rule-based mode is used "
                             "(less accurate).")
            self.pull.setEnabled(False)
        else:
            parts = [f"{'✅' if ok else '⬇'} {name}" for name, ok in st["models"].items()]
            self.oll.setText("Ollama is running.  " + "   ".join(parts))
            self.pull.setEnabled(not all(st["models"].values()) and not self._busy())

    def _vision_state(self):
        import importlib.util

        have = importlib.util.find_spec("torch") is not None and importlib.util.find_spec("open_clip") is not None
        can_install = bool(os.environ.get("CLIPFORGE_PYTHON")) and Path(os.environ["CLIPFORGE_PYTHON"]).exists()
        if have:
            self.vis.setText("✅ Installed. ClipForge recognises what's on screen (cars, police, crashes, menus…).")
        elif can_install:
            self.vis.setText("Not installed. This is the biggest accuracy gain for visual topics. It downloads "
                             "PyTorch (GPU build if an NVIDIA card is found) into your ClipForge data folder; "
                             "updates keep it.")
        else:
            self.vis.setText("Not installed. In the source version, run install.bat and choose the vision option.")
        self.vis_btn.setEnabled(not have and can_install and not self._busy())

    def _busy(self) -> bool:
        return self.job is not None and self.job.isRunning()

    def _start(self, fn, on_done, label):
        self.msg.setText(label)
        self.bar.setValue(0)
        for b in (self.dl, self.pull, self.vis_btn, self.verify_btn):
            b.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.job = Job(fn)
        self.job.progress.connect(lambda f, m: (self.bar.setValue(int(f * 1000)), self.msg.setText(m)))
        self.job.done.connect(lambda r: self._end(on_done, r, None))
        self.job.failed.connect(lambda e: self._end(None, None, e))
        self.job.start()

    def _end(self, on_done, r, err):
        self.cancel_btn.setEnabled(False)
        self.verify_btn.setEnabled(True)
        if err:
            self.msg.setText("Stopped: " + err.splitlines()[0][:200])
            if "Cancelled" not in err:
                QMessageBox.warning(self, "AI Models", err[:2000] + "\n\nAnything already downloaded is kept; "
                                    "clicking the button again resumes where it stopped.")
        else:
            self.bar.setValue(1000)
            if on_done:
                on_done(r)
        self.win.reset_services()
        self.refresh()

    # ---- actions
    def download_missing(self):
        md = self.s.models_dir
        self._start(lambda progress, cancel: mm.ensure_all(md, None, progress, cancel),
                    lambda done: self.msg.setText(f"Downloaded and verified: {', '.join(done) or 'nothing needed'}"),
                    "Downloading…")

    def verify(self):
        md = self.s.models_dir

        def job(progress, cancel):
            bad = []
            st = [m for m in mm.status(md) if m["installed"]]
            for i, m in enumerate(st):
                progress(i / max(1, len(st)), f"Checking {m['name']}…")
                try:
                    mm.ensure(m["key"], md, None, cancel, reverify=True)
                except mm.ModelError as e:
                    bad.append(f"{m['name']}: {e}")
            return bad
        self._start(job, lambda bad: QMessageBox.information(
            self, "AI Models", "All installed models passed verification." if not bad else
            "Problems found (re-downloaded where possible):\n" + "\n".join(bad)), "Verifying…")

    def pull_ollama(self):
        st = getattr(self, "_oll", {"models": {}})
        todo = [m for m, ok in st.get("models", {}).items() if not ok]
        url = self.s.llm.base_url

        def job(progress, cancel):
            for i, m in enumerate(todo):
                mm.ollama_pull(url, m, lambda f, msg, i=i: progress((i + f) / len(todo), msg), cancel)
            return todo
        self._start(job, lambda d: self.msg.setText("Ollama models ready: " + ", ".join(d)), "Asking Ollama…")

    def install_vision(self):
        py = os.environ["CLIPFORGE_PYTHON"]
        target = data_dir() / "packages"
        if QMessageBox.question(self, "Visual understanding",
                                "Download and install PyTorch and CLIP (about 2 GB, a few minutes)?\n\n"
                                f"They go into {target} and are kept when ClipForge updates.") \
                != QMessageBox.StandardButton.Yes:
            return
        gpu = shutil.which("nvidia-smi") is not None
        index = "https://download.pytorch.org/whl/cu124" if gpu else "https://download.pytorch.org/whl/cpu"

        def job(progress, cancel):
            staging = target.with_name("packages.new")
            shutil.rmtree(staging, ignore_errors=True)
            steps = [[py, "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location",
                      "--target", str(staging), "torch", "torchvision", *CLIP_EXTRA,
                      "--index-url", index, "--extra-index-url", "https://pypi.org/simple"]]
            log = []
            for i, cmd in enumerate(steps):
                progress(0.01, "Installing PyTorch (GPU build) and CLIP…" if gpu else "Installing PyTorch and CLIP…")
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                for line in p.stdout:
                    log.append(line)
                    if cancel():
                        p.kill()
                        raise RuntimeError("Cancelled")
                    if line.startswith(("Collecting", "Downloading", "Installing")):
                        progress(min(0.95, 0.02 + len(log) / 400), line.strip()[:90])
                if p.wait() != 0:
                    shutil.rmtree(staging, ignore_errors=True)
                    raise RuntimeError("pip failed:\n" + "".join(log[-25:]))
            # drop duplicates of packages ClipForge already ships (the bundled versions are the tested ones)
            for dup in ("numpy", "PIL", "requests", "urllib3", "certifi", "idna", "charset_normalizer",
                        "typing_extensions.py", "packaging"):
                for p in staging.glob(dup + "*"):
                    shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
            if target.exists():
                old = target.with_name("packages.old")
                shutil.rmtree(old, ignore_errors=True)
                os.replace(target, old)
                shutil.rmtree(old, ignore_errors=True)
            os.replace(staging, target)
            return True
        self._start(job, lambda _: QMessageBox.information(
            self, "Visual understanding", "Installed. Restart ClipForge to start using it."), "Installing…")

    def reject(self):
        if self._busy():
            if QMessageBox.question(self, "AI Models", "A download is running. Stop it? (It resumes next time.)") \
                    != QMessageBox.StandardButton.Yes:
                return
            self.job.cancel()
            self.job.wait(10000)
        super().reject()


# =============================================================================== About
class AboutDialog(QDialog):
    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("About ClipForge")
        self.resize(660, 580)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        pic = QLabel()
        pm = QPixmap(str(BRAND / "clipforge_256.png"))
        if not pm.isNull():
            pic.setPixmap(pm.scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation))
        top.addWidget(pic)
        t = QLabel(f"<div style='font-size:20pt;font-weight:700'>ClipForge</div>"
                   f"<div>Version <b>{__version__}</b></div>"
                   f"<div style='color:#9aa0ab'>AI Shorts from long videos — runs on your computer</div>")
        top.addWidget(t, 1)
        lay.addLayout(top)
        inst = updater.install_dir()
        info = [("Program folder", str(inst) if inst else str(Path(__file__).resolve().parents[2]) + " (source)"),
                ("Built-in runtime", updater.runtime_version() or f"Python {sys.version.split()[0]} (system)"),
                ("Settings & projects", str(app_dir())),
                ("Models & cache", str(data_dir()))]
        txt = QLabel("<table>" + "".join(f"<tr><td style='padding-right:12px;color:#9aa0ab'>{k}</td><td>{v}</td></tr>"
                                         for k, v in info) + "</table>")
        txt.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        txt.setWordWrap(True)
        lay.addWidget(txt)
        row = QHBoxLayout()
        for label, path in (("Open settings folder", app_dir()), ("Open models folder", data_dir())):
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, p=path: open_folder(p))
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        g = QGroupBox("Updates")
        gl = QVBoxLayout(g)
        self.auto = QCheckBox("Check for updates when ClipForge starts")
        self.auto.setChecked(win.pipeline.settings.check_updates)
        self.auto.toggled.connect(self._toggle)
        gl.addWidget(self.auto)
        self.auto_inst = QCheckBox("Install updates automatically (downloaded in the background, installed the "
                                   "next time ClipForge opens)")
        self.auto_inst.setChecked(win.pipeline.settings.auto_install_updates)
        self.auto_inst.toggled.connect(self._toggle_inst)
        gl.addWidget(self.auto_inst)
        cfg = updater.update_config()
        srow = QHBoxLayout()
        srow.addWidget(QLabel("Update source (GitHub):"))
        self.repo = QLineEdit(cfg.get("github_repo", ""))
        self.repo.setPlaceholderText("owner/name  (where ClipForge releases are published)")
        srow.addWidget(self.repo, 1)
        b = QPushButton("Save")
        b.clicked.connect(self._save_repo)
        srow.addWidget(b)
        gl.addLayout(srow)
        if cfg.get("base_url"):
            gl.addWidget(_hint(f"(Testing/mirror override active: {cfg['base_url']})"))
        gl.addWidget(_hint("Every update is checked against ClipForge's release signature and SHA-256 before "
                           "anything is installed, so only genuine ClipForge releases can be installed. Your "
                           "settings, projects, models and cache are never touched by an update."))
        self.status = QLabel(self._last_checked())
        self.status.setWordWrap(True)
        gl.addWidget(self.status)
        b = QPushButton("Check for updates now")
        b.clicked.connect(self.check_now)
        gl.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(g)
        lay.addStretch(1)
        lic = QPushButton("Third-party licences")
        lic.clicked.connect(self._licences)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.addButton(lic, QDialogButtonBox.ButtonRole.HelpRole)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _save_repo(self):
        try:
            updater.set_github_repo(self.repo.text())
            self.status.setText("Saved. Checking…")
            self.check_now()
        except updater.UpdateError as e:
            self.status.setText(str(e))

    @staticmethod
    def _last_checked() -> str:
        import time as _t

        try:
            st = json.loads((app_dir() / "update_state.json").read_text(encoding="utf-8"))
            when = _t.strftime("%b %d at %I:%M %p", _t.localtime(st["last_check"])).replace(" 0", " ")
            return f"Last checked {when}. You're on {__version__}."
        except (OSError, ValueError, KeyError):
            return ""

    def _toggle_inst(self, on):
        s = self.win.pipeline.settings
        s.auto_install_updates = bool(on)
        s.save()

    def _toggle(self, on):
        s = self.win.pipeline.settings
        s.check_updates = bool(on)
        s.save()

    def check_now(self):
        self.status.setText("Checking…")
        self.win.updates.check(force=True, quiet=False, on_result=self._result)

    def _result(self, info, err):
        if err:
            self.status.setText("Could not check: " + err)
        elif info is None:
            self.status.setText(f"✅ ClipForge {__version__} is the latest version.")
        else:
            self.status.setText(f"ClipForge {info.version} is available.")

    def _licences(self):
        root = Path(__file__).resolve().parents[2]
        for cand in (root / "THIRD_PARTY.md", (updater.install_dir() or root) / "THIRD_PARTY.md"):
            if cand.exists():
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(cand)))
                return


# =============================================================================== updates
class _CheckThread(QThread):
    result = Signal(object, str)

    def __init__(self, force):
        super().__init__()
        self.force = force

    def run(self):
        try:
            self.result.emit(updater.check(force=self.force), "")
        except Exception as e:  # noqa: BLE001
            self.result.emit(None, str(e) or type(e).__name__)


class UpdateDialog(QDialog):
    def __init__(self, win, info: "updater.UpdateInfo"):
        super().__init__(win)
        self.win, self.info = win, info
        self.job: Job | None = None
        self.setWindowTitle("Update ClipForge")
        self.resize(620, 520)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"<div style='font-size:15pt;font-weight:700'>ClipForge {info.version} is available"
                             f"</div><div style='color:#9aa0ab'>You have {__version__}. Download: about "
                             f"{max(1, round(info.download_mb))} MB.</div>"))
        notes = QTextBrowser()
        notes.setOpenExternalLinks(True)
        notes.setMarkdown(info.notes or "Improvements and fixes.")
        lay.addWidget(notes, 1)
        lay.addWidget(_hint("Your settings, projects, AI models, cache and exports are kept. The update is "
                            "verified before installing; if the new version can't start, ClipForge goes back to "
                            "this version automatically."))
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.hide()
        self.msg = QLabel("")
        lay.addWidget(self.msg)
        lay.addWidget(self.bar)
        row = QHBoxLayout()
        row.addStretch(1)
        self.later = QPushButton("Later")
        self.later.clicked.connect(self.reject)
        row.addWidget(self.later)
        self.go = QPushButton("Update and restart")
        self.go.setObjectName("primary")
        self.go.setDefault(True)
        self.later.setAutoDefault(False)
        self.go.clicked.connect(self.start)
        row.addWidget(self.go)
        lay.addLayout(row)

    def start(self):
        if self.win.worker is not None and self.win.worker.isRunning():
            QMessageBox.information(self, "Update", "ClipForge is busy (analysing or exporting). Update when it has "
                                    "finished — nothing is lost by waiting.")
            return
        self.go.setEnabled(False)
        self.later.setText("Cancel")
        self.bar.show()
        self.job = Job(lambda progress, cancel: updater.prepare(self.info, progress, cancel))
        self.job.progress.connect(lambda f, m: (self.bar.setValue(int(f * 1000)), self.msg.setText(m)))
        self.job.done.connect(self._ready)
        self.job.failed.connect(self._failed)
        self.job.start()

    def _ready(self, staged):
        self.bar.setValue(1000)
        self.msg.setText("Verified. Restarting ClipForge…")
        try:
            if self.win.pipeline.project.source is not None:
                self.win.pipeline.project.save()
        except Exception:  # noqa: BLE001
            pass
        try:
            updater.finish(staged)
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Update", f"The update is downloaded and verified but could not restart "
                                f"ClipForge automatically ({e}). Close and reopen ClipForge to finish.")
            self.accept()
            return
        self.win._quitting_for_update = True
        QTimer.singleShot(300, self.win.close)
        self.accept()

    def _failed(self, err):
        self.bar.hide()
        self.go.setEnabled(True)
        self.later.setText("Later")
        if "Cancelled" in err:
            self.msg.setText("Cancelled. Nothing was changed.")
            return
        self.msg.setText("The update did not install. Nothing was changed.")
        QMessageBox.warning(self, "Update", f"{err}\n\nYour current version keeps working. You can try again "
                            "later, or download ClipForge_Setup.exe from the releases page and run it "
                            "(it keeps your data).")

    def reject(self):
        if self.job is not None and self.job.isRunning():
            self.job.cancel()
            self.job.wait(10000)
        super().reject()


class UpdateController(QObject):
    """Background check at start-up (never delays the window) + a banner in the status bar."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.thread: _CheckThread | None = None
        self.info = None
        self.banner = QPushButton("")
        self.banner.setObjectName("primary")
        self.banner.hide()
        self.banner.clicked.connect(self.show_dialog)
        win.statusBar().addPermanentWidget(self.banner)

    def start(self):
        if self.win.pipeline.settings.check_updates and not os.environ.get("CLIPFORGE_NO_UPDATE_CHECK"):
            QTimer.singleShot(1500, lambda: self.check(force=False, quiet=True))

    def check(self, force: bool, quiet: bool, on_result=None):
        if self.thread is not None and self.thread.isRunning():
            return
        self.thread = _CheckThread(force)
        self.thread.result.connect(lambda info, err: self._result(info, err, quiet, on_result))
        self.thread.start()

    def _result(self, info, err, quiet, on_result):
        if on_result:
            on_result(info, err)
        if err:
            if not quiet:
                QMessageBox.information(self.win, "Updates", f"Could not check for updates: {err}")
            return
        self.info = info
        self.staged = None
        if info is None:
            return
        auto = self.win.pipeline.settings.auto_install_updates and not info.needs_full_installer
        if auto:
            # fully automatic: download + verify quietly now; it switches over at the next start
            self.banner.setText(f"  Downloading ClipForge {info.version}…  ")
            self.banner.setEnabled(False)
            self.banner.show()
            self.job = Job(lambda progress, cancel: updater.prepare(info, None, cancel))
            self.job.done.connect(self._staged)
            self.job.failed.connect(self._stage_failed)
            self.job.start()
            return
        self.banner.setText(f"  ClipForge {info.version} is available — Update  ")
        self.banner.show()
        if not quiet:
            self.show_dialog()

    def _staged(self, staged):
        self.staged = staged
        self.banner.setEnabled(True)
        self.banner.setText(f"  ClipForge {self.info.version} is ready — Restart to finish  ")
        self.banner.setToolTip("Installs the next time ClipForge opens. Click to restart now.")

    def _stage_failed(self, err):
        self.banner.setEnabled(True)
        self.banner.setText(f"  ClipForge {self.info.version} is available — Update  ")
        self.banner.setToolTip(f"Automatic download didn't finish: {err[:200]}")

    def show_dialog(self):
        if self.info is None:
            return
        if getattr(self, "staged", None):
            if self.win.worker is not None and self.win.worker.isRunning():
                QMessageBox.information(self.win, "Update", "ClipForge is busy. The update installs automatically "
                                        "the next time you open ClipForge.")
                return
            try:
                if self.win.pipeline.project.source is not None:
                    self.win.pipeline.project.save()
            except Exception:  # noqa: BLE001
                pass
            updater.finish(self.staged)
            self.win._quitting_for_update = True
            QTimer.singleShot(200, self.win.close)
            return
        UpdateDialog(self.win, self.info).exec()


# =============================================================================== first launch & notes
class WelcomeDialog(QDialog):
    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("Welcome to ClipForge")
        self.resize(640, 500)
        s = win.pipeline.settings
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"<div style='font-size:17pt;font-weight:700'>Welcome to ClipForge {__version__}</div>"))
        lay.addWidget(_hint("Here's what is ready on this computer and what still needs a one-time download. "
                            "You can start right away: missing AI models download automatically the first time "
                            "they're needed, or all at once now."))
        st = mm.status(s.models_dir)
        missing = [m for m in st if not m["installed"]]
        lines = ["✅ Program, built-in Python and FFmpeg video engine"]
        lines += [f"{'✅' if m['installed'] else '⬇'} {m['name']}" + ("" if m["installed"] else
                                                                      f" — {m['download_mb']} MB to download")
                  for m in st]
        import importlib.util
        lines.append(("✅" if importlib.util.find_spec("open_clip") else "○") +
                     " Visual understanding (optional, about 2 GB; install from AI Models)")
        lines.append("○ Ollama language model (optional, free; from ollama.com — strongly recommended)")
        box = QPlainTextEdit("\n".join(lines))
        box.setReadOnly(True)
        lay.addWidget(box, 1)
        lay.addWidget(_hint("Use only footage you own or have written permission to edit and publish. "
                            "ClipForge never downloads private, members-only or DRM-protected videos."))
        row = QHBoxLayout()
        row.addStretch(1)
        later = QPushButton("Start using ClipForge")
        later.clicked.connect(self.accept)
        row.addWidget(later)
        if missing:
            get = QPushButton(f"Download AI models now ({sum(m['download_mb'] for m in missing)} MB)")
            get.setObjectName("primary")
            get.clicked.connect(self._get)
            row.addWidget(get)
        lay.addLayout(row)

    def _get(self):
        self.accept()
        dlg = ModelsDialog(self.win)
        QTimer.singleShot(200, dlg.download_missing)
        dlg.exec()


def show_boot_notes(win) -> None:
    """Messages left by the launcher or the updater, shown once."""
    p = app_dir() / "boot_notes.json"
    try:
        notes = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    try:
        p.unlink()
    except OSError:
        pass
    rb = notes.get("rolled_back")
    if rb:
        QMessageBox.warning(win, "Update rolled back",
                            f"ClipForge {rb.get('from')} could not start, so ClipForge automatically went back to "
                            f"version {rb.get('to')}. Your projects, settings and models were not changed.\n\n"
                            f"Reason: {rb.get('reason', '')[:400]}")
        return
    up = notes.get("updated")
    if up and up.get("to") == __version__:
        QMessageBox.information(win, "ClipForge updated", f"ClipForge was updated to {__version__}.\n\n"
                                + (up.get("notes") or "")[:1500])


def after_start(win) -> None:
    """Called once the main window is visible."""
    show_boot_notes(win)
    s = win.pipeline.settings
    if not s.first_run_done:
        s.first_run_done = True
        s.save()
        if not os.environ.get("CLIPFORGE_NO_WELCOME"):
            WelcomeDialog(win).exec()
    elif not os.environ.get("CLIPFORGE_NO_REOPEN"):
        try:
            win.reopen_last_project()
        except Exception:  # noqa: BLE001  (never block start-up)
            pass
    win.updates.start()
