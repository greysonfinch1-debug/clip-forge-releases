"""Background execution so the window never freezes during analysis or rendering."""
from __future__ import annotations

import traceback

from PySide6.QtCore import QThread, Signal


class Worker(QThread):
    progress = Signal(str, float, str)   # stage, fraction, message
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs

    def run(self):
        from ..activity import log as alog

        name = getattr(self.fn, "__name__", "task")
        alog(f"--- start: {name}")
        try:
            res = self.fn(*self.args, progress=self._emit, **self.kwargs)
            alog(f"--- done: {name}")
            self.done.emit(res)
        except Exception as e:  # noqa: BLE001
            alog(f"--- FAILED: {name}: {type(e).__name__}: {str(e)[:1500]}")
            from ..core.ingest import IngestError
            from ..providers.base import ProviderUnavailable

            msg = str(e) or type(e).__name__
            expected = isinstance(e, (PermissionError, IngestError, ProviderUnavailable, FileNotFoundError, ValueError,
                                      AssertionError)) or "Cancelled" in msg
            if not expected:
                # unexpected: keep the details (shown, and saved for troubleshooting)
                tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
                try:
                    from ..config import app_dir

                    with open(app_dir() / "error_log.txt", "a", encoding="utf-8") as f:
                        f.write(tb + "\n")
                except OSError:
                    pass
                msg += "\n\nDetails were saved to error_log.txt in the ClipForge data folder.\n\n" + tb[-1200:]
            self.failed.emit(msg)

    def _emit(self, stage: str, frac: float, msg: str):
        from ..activity import log as alog

        alog(f"[{stage}] {msg}", key="progress")      # each new step message, once
        self.progress.emit(stage, float(frac), msg or "")
