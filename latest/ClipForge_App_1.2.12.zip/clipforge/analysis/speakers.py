"""Speaker identification (who spoke when) for the transcript.

Only the parts of the stream that matter are processed: the windows around candidate
moments (plus a margin). On a 3-hour stream that is a small fraction of the audio, which
makes this step several times faster than diarizing everything. Speakers found in
different windows are linked by comparing voice embeddings, so "S1" means the same voice
everywhere. Results (segments, covered time, voice prints) are cached per source and model,
so new topics only process windows not seen before.
"""
from __future__ import annotations

import numpy as np

from ..core.cache import SourceCache
from ..core.ffmpeg import read_wav_segment
from ..core.models import Transcript

VERSION = 3   # 3 (1.2.9): voices re-checked per sentence-length segment
MAX_WINDOW = 600.0       # longest piece handed to the diarizer at once (memory)
LINK_SIM = 0.55          # cosine similarity above which two window-speakers are the same voice
MIN_SPEECH = 1.0         # seconds of speech needed before a voice gets its own label
MARGIN = 10.0
LONG_SEG = 2.0           # segments this long get their own voice print (shorter ones are too noisy)
SAME_VOICE = 0.42        # average similarity for two segments' voices to be one person
                         # (measured: same person >= 0.57, different people <= 0.27 on 2-5 s segments)


def _merge(windows: list[tuple[float, float]]) -> list[tuple[float, float]]:
    out: list[list[float]] = []
    for a, b in sorted(windows):
        if out and a <= out[-1][1] + 1.0:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def _subtract(windows, covered):
    """Parts of ``windows`` not yet in ``covered`` (both sorted, merged)."""
    out = []
    for a, b in windows:
        cur = a
        for c0, c1 in covered:
            if c1 <= cur or c0 >= b:
                continue
            if c0 > cur:
                out.append((cur, min(c0, b)))
            cur = max(cur, c1)
        if cur < b:
            out.append((cur, b))
    return [(a, b) for a, b in out if b - a >= 2.0]


class _VoiceBook:
    def __init__(self, embs=None, weights=None):
        self.embs = [np.array(e, np.float32) for e in (embs or [])]
        self.w = list(weights or [])

    def assign(self, emb: np.ndarray, secs: float) -> int | None:
        best, best_sim = -1, -1.0
        for i, e in enumerate(self.embs):
            sim = float(e @ emb)
            if sim > best_sim:
                best, best_sim = i, sim
        if best >= 0 and best_sim >= LINK_SIM:
            v = self.embs[best] * self.w[best] + emb * min(secs, 20)
            self.embs[best] = v / (np.linalg.norm(v) + 1e-9)
            self.w[best] += min(secs, 20)
            return best
        if secs >= MIN_SPEECH:
            self.embs.append(emb)
            self.w.append(min(secs, 20))
            return len(self.embs) - 1
        return None


def regroup_by_voice(segs: list[tuple[float, float, int]], chunk: np.ndarray, sr: int, diarizer
                     ) -> list[tuple[float, float, int]]:
    """Check the diarizer's speaker groups against each long segment's own voice print.

    The diarizer's clustering sometimes puts two different people under one label (most often
    in short windows with only a few sentences). Every segment of LONG_SEG seconds or more is
    voice-printed and the segments are grouped by average similarity; short segments follow
    the group most of their original label's long segments went to."""
    long = [i for i, (a, b, _) in enumerate(segs) if b - a >= LONG_SEG]
    if len(long) < 2:
        return segs
    E = np.stack([diarizer.embed(chunk[int(segs[i][0] * sr):int(segs[i][1] * sr)], sr) for i in long])
    S = E @ E.T
    clusters = [[k] for k in range(len(long))]
    while len(clusters) > 1:   # average-linkage agglomerative clustering
        best, pair = -1.0, None
        for x in range(len(clusters)):
            for y in range(x + 1, len(clusters)):
                v = float(S[np.ix_(clusters[x], clusters[y])].mean())
                if v > best:
                    best, pair = v, (x, y)
        if best < SAME_VOICE or pair is None:
            break
        x, y = pair
        clusters[x] += clusters.pop(y)
    of_long = {long[k]: c for c, members in enumerate(clusters) for k in members}
    votes: dict[int, dict[int, float]] = {}
    for i, c in of_long.items():
        a, b, spk = segs[i]
        votes.setdefault(spk, {}).setdefault(c, 0.0)
        votes[spk][c] += b - a
    nxt = len(clusters)
    label_cluster: dict[int, int] = {}
    for spk in {k for _, _, k in segs}:
        if spk in votes:
            label_cluster[spk] = max(votes[spk], key=votes[spk].get)
        else:
            label_cluster[spk], nxt = nxt, nxt + 1
    return [(a, b, of_long.get(i, label_cluster[spk])) for i, (a, b, spk) in enumerate(segs)]


def diarize_windows(wav: str, windows, diarizer, book: _VoiceBook, progress=None, cancel=None
                    ) -> list[tuple[float, float, str]]:
    sr = 16000
    pieces = []
    for a, b in windows:
        t = a
        while t < b:
            pieces.append((t, min(b, t + MAX_WINDOW)))
            t += MAX_WINDOW
    total = sum(b - a for a, b in pieces) or 1.0
    done = 0.0
    out: list[tuple[float, float, str]] = []
    for a, b in pieces:
        if cancel and cancel():
            raise RuntimeError("Cancelled")
        chunk, _ = read_wav_segment(wav, a, b)
        if len(chunk) < sr:
            continue
        segs = regroup_by_voice(diarizer.diarize(chunk, sr), chunk, sr, diarizer)
        local: dict[int, list[tuple[float, float]]] = {}
        for s0, s1, spk in segs:
            local.setdefault(spk, []).append((s0, s1))
        mapping: dict[int, int] = {}
        for spk, spans in sorted(local.items(), key=lambda kv: -sum(y - x for x, y in kv[1])):
            secs = sum(y - x for x, y in spans)
            parts, got = [], 0.0
            for x, y in sorted(spans, key=lambda s: -(s[1] - s[0])):
                parts.append(chunk[int(x * sr):int(y * sr)])
                got += y - x
                if got >= 20:
                    break
            if not parts:
                continue
            g = book.assign(diarizer.embed(np.concatenate(parts), sr), secs)
            if g is not None:
                mapping[spk] = g
        out += [(a + s0, a + s1, f"S{mapping[spk] + 1}") for s0, s1, spk in segs if spk in mapping]
        done += b - a
        if progress:
            progress(done / total, "Identifying speakers")
    return out


def apply_speakers(transcript: Transcript, segs: list[tuple[float, float, str]]) -> int:
    """Label each sentence/word with the speaker who overlaps it most. Returns #speakers used."""
    if not segs:
        return 0
    segs = sorted(segs)
    starts = np.array([s[0] for s in segs])
    used = set()
    for s in transcript.sentences:
        votes: dict[str, float] = {}
        i0 = max(0, int(np.searchsorted(starts, s.start - 30)))
        for a, b, spk in segs[i0:]:
            if a > s.end:
                break
            ov = min(b, s.end) - max(a, s.start)
            if ov > 0:
                votes[spk] = votes.get(spk, 0.0) + ov
        if votes:
            s.speaker = max(votes, key=votes.get)
            used.add(s.speaker)
            for w in s.words:
                w.speaker = s.speaker
    return len(used)


def get_speakers(wav: str, duration: float, cache: SourceCache, transcript: Transcript, diarizer,
                 windows: list[tuple[float, float]] | None = None, progress=None, cancel=None) -> int:
    """Diarize ``windows`` (default: the whole stream) that aren't cached yet, then label the
    transcript. Returns the number of distinct voices in the labelled parts."""
    if diarizer is None or not transcript.sentences:
        return 0
    data = cache.load_json("speakers.json")
    if not data or data.get("version") != VERSION or data.get("model") != diarizer.model_id:
        data = {"version": VERSION, "model": diarizer.model_id, "segments": [], "covered": [], "voices": [],
                "weights": []}
    want = [(0.0, duration)] if windows is None else \
        [(max(0.0, a - MARGIN), min(duration or b + MARGIN, b + MARGIN)) for a, b in windows]
    todo = _subtract(_merge(want), _merge([tuple(c) for c in data["covered"]]))
    if todo:
        book = _VoiceBook(data["voices"], data["weights"])
        new = diarize_windows(wav, todo, diarizer, book, progress, cancel)
        data["segments"] = sorted([tuple(x) for x in data["segments"]] + new)
        data["covered"] = _merge([tuple(c) for c in data["covered"]] + todo)
        data["voices"] = [e.tolist() for e in book.embs]
        data["weights"] = book.w
        cache.save_json("speakers.json", data)
    # S1 = whoever talks most (the streamer): their captions keep the main colour
    order = sorted(range(len(data["weights"])), key=lambda i: -data["weights"][i])
    rename = {f"S{i + 1}": f"S{rank + 1}" for rank, i in enumerate(order)}
    return apply_speakers(transcript, [(a, b, rename.get(spk, spk)) for a, b, spk in data["segments"]])
