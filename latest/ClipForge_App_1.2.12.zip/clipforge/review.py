"""Objective review of a finished Short: what a human reviewer checks first, measured.

    clipforge-cli review <video.mp4> [--out folder]

Produces in the output folder:
  <name>_contact.jpg   one frame every second (for looking at framing, captions, facecam, cuts)
  <name>_audio.png     loudness over time, narration/dialogue/silence visible at a glance
  <name>_review.json   all measurements below
Measurements:
  * streams: resolution, fps, codecs, duration of video vs audio (A/V length mismatch in ms)
  * black frames (ffmpeg blackdetect) and frozen video (freezedetect) outside intended holds
  * silences > 0.6 s (awkward gaps), loudness range, true peak, loud spikes > 8 LU above the Short
  * caption checks from the sidecar plan (if present): overlaps, chunks shorter than 0.25 s,
    captions past the end
  * clip checks from the plan: duplicate / overlapping source ranges
These don't replace watching the video; they catch the problems people notice most.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

from .core import ffmpeg as ff


def _run(args: list[str]) -> str:
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=ff._NO_WINDOW)
    return r.stdout + r.stderr


def probe(path: Path) -> dict:
    out = _run([ff.ffprobe_bin(), "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)])
    try:
        d = json.loads(out[out.index("{"):])
    except ValueError:
        return {"error": out[-300:]}
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), {})
    num, den = (v.get("avg_frame_rate") or "0/1").split("/")
    return {"width": v.get("width"), "height": v.get("height"), "fps": round(float(num) / max(1.0, float(den)), 2),
            "vcodec": v.get("codec_name"), "acodec": a.get("codec_name"),
            "v_duration": float(v.get("duration") or 0), "a_duration": float(a.get("duration") or 0),
            "duration": float(d.get("format", {}).get("duration") or 0)}


def detect(path: Path) -> dict:
    """black/frozen frames, silences and loudness in one decoding pass each."""
    vout = _run([ff.ffmpeg_bin(), "-hide_banner", "-nostats", "-i", str(path), "-map", "0:v:0",
                 "-vf", "blackdetect=d=0.1:pic_th=0.95,freezedetect=n=0.002:d=1.5", "-f", "null", "-"])
    blacks = [(float(a), float(b)) for a, b in re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", vout)]
    fz_s = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", vout)]
    fz_e = [float(x) for x in re.findall(r"freeze_end: ([\d.]+)", vout)]
    freezes = list(zip(fz_s, fz_e + [None] * (len(fz_s) - len(fz_e))))
    aout = _run([ff.ffmpeg_bin(), "-hide_banner", "-nostats", "-i", str(path), "-map", "0:a:0",
                 "-af", "silencedetect=n=-45dB:d=0.6,ebur128=peak=true", "-f", "null", "-"])
    sil_s = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", aout)]
    sil_e = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", aout)]
    silences = list(zip(sil_s, sil_e + [None] * (len(sil_s) - len(sil_e))))
    moments = [float(x) for x in re.findall(r"M:\s*(-?[\d.]+|-inf)", aout.replace("M: -inf", "M: -120"))]
    integ = re.findall(r"I:\s+(-?[\d.]+) LUFS", aout)
    # loud spikes: momentary loudness (400 ms) more than 8 LU above the whole Short for >= 0.3 s
    # (a scream or explosion that will blast the viewer); normal speech rises and pauses don't count
    ref = float(integ[-1]) if integ else -14.0
    jumps, run = [], 0
    for k, m in enumerate(moments):
        run = run + 1 if m > ref + 8.0 else 0
        if run == 3:
            jumps.append(round((k - 2) / 10, 1))
    tp = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", aout)
    lra = re.findall(r"LRA:\s+([\d.]+) LU", aout)
    return {"black_frames": blacks, "frozen": freezes, "silences": silences,
            "loudness_jumps_s": _merge_times(jumps),
            "integrated_lufs": float(integ[-1]) if integ else None, "true_peak_db": float(tp[-1]) if tp else None,
            "loudness_range_lu": float(lra[-1]) if lra else None, "_momentary": moments}


def _merge_times(ts: list[float], gap: float = 1.0) -> list[float]:
    out = []
    for t in ts:
        if not out or t - out[-1] > gap:
            out.append(t)
    return out


def contact_sheet(path: Path, out: Path, duration: float, cols: int = 8) -> Path:
    n = max(1, int(duration))
    rows = (n + cols - 1) // cols
    _run([ff.ffmpeg_bin(), "-hide_banner", "-y", "-i", str(path), "-vf",
          f"fps=1,scale=180:-2,drawtext=text='%{{pts\\:hms}}':x=4:y=4:fontsize=14:fontcolor=yellow:box=1:boxcolor=black@0.6,"
          f"tile={cols}x{rows}:padding=4:margin=4", "-frames:v", "1", "-q:v", "4", str(out)])
    if not out.exists():   # drawtext needs a font: retry without the time stamps
        _run([ff.ffmpeg_bin(), "-hide_banner", "-y", "-i", str(path), "-vf",
              f"fps=1,scale=180:-2,tile={cols}x{rows}:padding=4:margin=4", "-frames:v", "1", "-q:v", "4", str(out)])
    return out


def audio_plot(moments: list[float], out: Path, silences: list, duration: float) -> Path | None:
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    W, H = 1200, 220
    im = Image.new("RGB", (W, H), (20, 22, 28))
    d = ImageDraw.Draw(im)
    dur = max(0.1, duration)
    for s, e in silences:
        e = dur if e is None else e
        d.rectangle([int(s / dur * W), 0, int(e / dur * W), H], fill=(70, 30, 30))
    for db, y in ((-14, None), (-23, None), (-40, None)):
        yy = int((0 - db) / 60 * H)
        d.line([0, yy, W, yy], fill=(60, 60, 70))
        d.text((4, yy - 12), f"{db} LUFS", fill=(150, 150, 160))
    pts = [(int(k / 10 / dur * W), int(min(60, max(0, -m)) / 60 * H)) for k, m in enumerate(moments)]
    if len(pts) > 1:
        d.line(pts, fill=(255, 200, 40), width=2)
    for t in range(0, int(dur) + 1, 5):
        d.text((int(t / dur * W) + 2, H - 14), f"{t}s", fill=(150, 150, 160))
    im.save(out)
    return out


def plan_checks(plan: dict, duration: float) -> dict:
    caps = plan.get("captions") or []
    overlaps, too_short, past_end = 0, 0, 0
    caps = sorted(caps, key=lambda c: c["start"])
    for a, b in zip(caps, caps[1:]):
        if b["start"] < a["end"] - 0.02:
            overlaps += 1
    for c in caps:
        if c["end"] - c["start"] < 0.25:
            too_short += 1
        if c["end"] > duration + 0.05:
            past_end += 1
    story = plan.get("story") or []
    dup = 0
    for i, a in enumerate(story):
        for b in story[i + 1:]:
            ov = min(a["end"], b["end"]) - max(a["start"], b["start"])
            if ov > 0.5:
                dup += 1
    narr = plan.get("narration") or []
    return {"captions": len(caps), "caption_overlaps": overlaps, "caption_too_short": too_short,
            "caption_past_end": past_end, "clips": len(story), "duplicate_or_overlapping_clips": dup,
            "narration_lines": len(narr),
            "narration_words": sum(len(str(n.get("text", "")).split()) for n in narr)}


def review(video: str, out_dir: str = "", plan: dict | None = None, intended_holds: list | None = None) -> dict:
    v = Path(video)
    out = Path(out_dir) if out_dir else v.parent
    out.mkdir(parents=True, exist_ok=True)
    info = probe(v)
    det = detect(v)
    moments = det.pop("_momentary")
    res = {"file": v.name, **info, **det}
    res["av_length_mismatch_ms"] = round(abs(info.get("v_duration", 0) - info.get("a_duration", 0)) * 1000)
    holds = intended_holds or []

    def unintended(spans):
        bad = []
        for s, e in spans:
            e = info["duration"] if e is None else e
            if not any(hs - 0.2 <= s and e <= he + 0.2 for hs, he in holds):
                bad.append([round(s, 2), round(e, 2)])
        return bad
    res["unintended_black"] = unintended(det["black_frames"])
    res["unintended_frozen"] = unintended(det["frozen"])
    res["long_silences"] = [[round(s, 2), round(e if e is not None else info["duration"], 2)]
                            for s, e in det["silences"] if (e or info["duration"]) - s >= 1.0]
    if plan:
        res["plan"] = plan_checks(plan, info["duration"])
    res["contact_sheet"] = contact_sheet(v, out / f"{v.stem}_contact.jpg", info["duration"]).name
    p = audio_plot(moments, out / f"{v.stem}_audio.png", det["silences"], info["duration"])
    res["audio_plot"] = p.name if p else None
    flags = []
    if info.get("width") != 1080 or info.get("height") != 1920:
        flags.append(f"resolution {info.get('width')}x{info.get('height')} (expected 1080x1920)")
    if res["av_length_mismatch_ms"] > 50:
        flags.append(f"audio/video length differ by {res['av_length_mismatch_ms']} ms")
    if res["unintended_black"]:
        flags.append(f"black frames at {res['unintended_black']}")
    if res["unintended_frozen"]:
        flags.append(f"frozen picture at {res['unintended_frozen']}")
    if res["long_silences"]:
        flags.append(f"silence ≥1 s at {res['long_silences']}")
    if res["loudness_jumps_s"]:
        flags.append(f"loud spikes (>8 LU above the rest) at {res['loudness_jumps_s']} s")
    if det["true_peak_db"] is not None and det["true_peak_db"] > -0.5:
        flags.append(f"true peak {det['true_peak_db']} dBTP (clipping risk)")
    if plan:
        pc = res["plan"]
        for k in ("caption_overlaps", "caption_past_end", "duplicate_or_overlapping_clips"):
            if pc[k]:
                flags.append(f"{k.replace('_', ' ')}: {pc[k]}")
    res["flags"] = flags
    (out / f"{v.stem}_review.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    return res


def main(argv=None) -> int:
    import argparse

    ap = argparse.ArgumentParser(prog="clipforge-cli review")
    ap.add_argument("video")
    ap.add_argument("--out", default="")
    ap.add_argument("--plan", default="", help="project .json to check captions/clips against")
    a = ap.parse_args(argv)
    plan = None
    if a.plan:
        plan = json.loads(Path(a.plan).read_text(encoding="utf-8")).get("plan")
    r = review(a.video, a.out, plan)
    print(json.dumps({k: v for k, v in r.items() if k not in ("silences", "black_frames", "frozen")}, indent=1))
    return 1 if r["flags"] else 0


if __name__ == "__main__":
    sys.exit(main())
