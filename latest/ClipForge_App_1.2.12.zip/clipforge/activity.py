"""A plain, timestamped activity log (%APPDATA%\\ClipForge\\logs\\activity.log) so a stuck or
failed step can be diagnosed afterwards: every step's progress messages, the video streams
chosen, warnings from the downloader and FFmpeg's last lines when it fails."""
from __future__ import annotations

import threading
import time

_lock = threading.Lock()
_last: dict[str, str] = {}
MAX_BYTES = 2_000_000


def log(msg: str, key: str | None = None) -> None:
    """Append one line. With ``key``, an identical repeat of the previous message is skipped."""
    if key is not None:
        if _last.get(key) == msg:
            return
        _last[key] = msg
    try:
        from .config import app_dir

        d = app_dir() / "logs"
        d.mkdir(parents=True, exist_ok=True)
        f = d / "activity.log"
        with _lock:
            if f.exists() and f.stat().st_size > MAX_BYTES:
                f.replace(d / "activity.old.log")
            with open(f, "a", encoding="utf-8") as fh:
                for line in str(msg).splitlines() or [""]:
                    fh.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except OSError:
        pass


class YdlLogger:
    """Sends yt-dlp's messages to the activity log instead of the console."""

    def debug(self, msg):
        if not msg.startswith("[debug]") and "[download]" not in msg:
            log(f"yt-dlp: {msg}", key="ydl")

    def info(self, msg):
        self.debug(msg)

    def warning(self, msg):
        log(f"yt-dlp WARNING: {msg}")

    def error(self, msg):
        log(f"yt-dlp ERROR: {msg}")
