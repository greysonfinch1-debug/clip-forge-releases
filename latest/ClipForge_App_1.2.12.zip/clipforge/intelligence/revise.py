"""'Any changes?' — edit a finished Short by typing what you want.

    ops, how, notes = plan_changes(request, pipeline)      # understand the request
    done, skipped = apply_changes(pipeline, ops)            # change the project (undo via snapshot())

The request is turned into a small list of explicit edit operations (remove/move/swap/add/trim a
clip, change the length, edit/remove/add/rewrite narration, switch the hook, voice, captions,
music, title…). With a language model (Ollama or an API) any wording works; without one, a
rule-based reader understands common phrasings ("remove clip 3", "swap 1 and 2", "make it
shorter", "faster voice", "bigger captions", "put back the crash clip"…). Every operation is
validated before it is applied and the user gets a plain list of what changed and what didn't.
"""
from __future__ import annotations

import copy
import dataclasses
import re
from typing import Optional

from ..core.models import HookOption, NarrationLine, StoryItem

OP_NAMES = ("remove_clip", "add_clip", "move_clip", "swap_clips", "replace_clip", "trim_clip", "set_length",
            "edit_line", "remove_line", "add_line", "rewrite_script", "no_narration", "next_hook", "set_hook",
            "set_title", "set_context_text", "voice", "voice_speed", "voice_volume", "caption_size",
            "caption_color", "music_volume", "music_off", "original_volume", "end_message", "transitions",
            "layout", "punch_up")

SYSTEM = """You turn a video creator's change request into edit operations for a vertical Short.
Reply with ONE JSON object: {"ops": [...], "reply": "one short sentence to the user"}.
Use ONLY these operations (clip and line numbers are the 1-based numbers shown in the state):
 {"op":"remove_clip","clip":N}
 {"op":"add_clip","candidate":"A".."Z","position":N}      (position optional; candidates are unused clips)
 {"op":"move_clip","clip":N,"to":M}
 {"op":"swap_clips","a":N,"b":M}
 {"op":"replace_clip","clip":N}                           (swap in the best unused alternative)
 {"op":"trim_clip","clip":N,"cut_start":S,"cut_end":S}    (seconds removed; negative = extend)
 {"op":"set_length","seconds":S}
 {"op":"edit_line","line":N,"text":"..."}
 {"op":"remove_line","line":N}
 {"op":"add_line","clip":N,"text":"...","position":"before"|"after"}
 {"op":"rewrite_script","style":"what the user wants (e.g. funnier, shorter, more hype)"}
 {"op":"no_narration"}
 {"op":"next_hook"}
 {"op":"set_hook","headline":"...","opening_line":"..."}
 {"op":"set_title","text":"..."}
 {"op":"set_context_text","clip":N,"text":"..."}
 {"op":"voice","voice":"<voice id from the list>"}
 {"op":"voice_speed","value":0.8-1.4}
 {"op":"voice_volume","db":-6..6}                         (relative change)
 {"op":"caption_size","value":40-140}
 {"op":"caption_color","color":"#RRGGBB"}
 {"op":"music_volume","db":-10..10}                       (relative change)
 {"op":"music_off"}
 {"op":"original_volume","db":-10..10}                    (relative change, the stream's own audio)
 {"op":"end_message","text":"..."}
 {"op":"transitions","value":"quick"|"none"}
 {"op":"layout","value":"smart"|"blur-fill"|"center"|"facecam-split"}
Rules: do exactly what was asked, nothing more. Narration must only describe what happens in the
clips (never invent quotes or events). If part of the request is impossible with these operations,
leave it out and say so in "reply". Clip numbers refer to the CURRENT order; apply ops in order."""

PROMPT = """CURRENT SHORT
{state}

CHANGE REQUEST: {request}

JSON only."""

ORDINALS = {"first": 1, "1st": 1, "second": 2, "2nd": 2, "third": 3, "3rd": 3, "fourth": 4, "4th": 4,
            "fifth": 5, "5th": 5, "sixth": 6, "6th": 6, "seventh": 7, "7th": 7, "eighth": 8, "8th": 8,
            "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8}


# ----------------------------------------------------------------------------- state description
def unused_candidates(pipe, limit: int = 12) -> list:
    used = {it.cid for it in pipe.project.plan.story}
    pool = [c for c in pipe.project.candidates if c.cid not in used and (c.final_score > 0 or c.excluded)]
    pool.sort(key=lambda c: (not c.excluded, -c.final_score))   # removed-by-user first: "put it back"
    return pool[:limit]


def describe_state(pipe) -> str:
    plan = pipe.project.plan
    by_id = {c.cid: c for c in pipe.project.candidates}
    out = [f"Target length: {plan.target_seconds:.0f}s. Current clips total "
           f"{sum(it.end - it.start for it in plan.story):.0f}s.", "CLIPS (in order):"]
    for i, it in enumerate(plan.story, 1):
        c = by_id.get(it.cid)
        desc = (c.description or c.why_matches or "") if c else ""
        out.append(f" {i}. [{it.end - it.start:.0f}s, {it.role or 'clip'}] {desc[:140]}")
    un = unused_candidates(pipe)
    if un:
        out.append("UNUSED CLIPS (can be added):")
        for k, c in enumerate(un):
            tag = " (removed earlier)" if c.excluded else ""
            out.append(f" {chr(65 + k)}. [{c.duration:.0f}s, score {c.final_score:.1f}]{tag} "
                       f"{(c.description or c.why_matches or '')[:120]}")
    out.append("NARRATION LINES:")
    for i, ln in enumerate(plan.narration, 1):
        out.append(f" {i}. (clip {ln.item_index + 1}, {ln.position}) \"{ln.text}\"")
    if plan.hooks:
        h = plan.hooks[plan.chosen_hook]
        out.append(f"HOOK: \"{h.headline}\" / \"{h.opening_line}\" ({len(plan.hooks)} hook options)")
    out.append(f"TITLE: {plan.title}")
    v, es = pipe.settings.voice, pipe.settings.edit
    from ..providers.tts import VOICE_LABELS

    out.append(f"VOICE: {v.voice} at speed {v.speed:.2f}. Voices: " +
               ", ".join(f"{k} ({d.split('(')[-1].rstrip(')')})" for k, d in VOICE_LABELS.items()))
    out.append(f"CAPTIONS: size {es.caption_size}, colour {es.caption_color}. Music: "
               f"{'on' if es.music_path else 'none'}. Layout: {es.crop_mode}. Transitions: {es.transitions}.")
    return "\n".join(out)


# ----------------------------------------------------------------------------- understanding the request
def plan_changes(request: str, pipe) -> tuple[list[dict], str, str]:
    """-> (ops, how, reply). Uses the language model when available, else the rule-based reader."""
    request = request.strip()
    if not request:
        return [], "none", ""
    llm = pipe.services.llm()
    if pipe.services.llm_available():
        try:
            d = llm.complete_json(SYSTEM, PROMPT.format(state=describe_state(pipe), request=request), max_tokens=900)
            ops = [o for o in (d.get("ops") or []) if isinstance(o, dict) and o.get("op") in OP_NAMES]
            if ops or d.get("reply"):
                return ops, "llm", str(d.get("reply") or "")
        except Exception:  # noqa: BLE001  (fall back to rules)
            pass
    ops, unknown = parse_rules(request, pipe)
    reply = ""
    if any(o.get("op") == "punch_up" for o in ops):
        reply = ("That was a general request, so I made it punchier: a different hook, slightly faster voice, bigger "
                 "captions and snappier cuts. Use Undo if you don't like it, or ask for something specific "
                 "(e.g. \"remove clip 2\").")
    if unknown:
        reply = ("I couldn't work out: " + "; ".join(f"\"{u}\"" for u in unknown) +
                 (". With the free Ollama language model installed, I understand any wording."
                  if not pipe.services.llm_available() else ""))
    return ops, "rules", reply


def _num(tok: str) -> Optional[int]:
    tok = tok.lower().strip(".,")
    if tok.isdigit():
        return int(tok)
    return ORDINALS.get(tok)


def _clip_ref(text: str, n_clips: int) -> list[int]:
    """All clip numbers mentioned: 'clip 3', 'third clip', '3rd one', 'last clip', 'clips 2 and 4'."""
    t = text.lower()
    refs = []
    for m in re.finditer(r"\b(?:clips?|parts?|scenes?|shots?|moments?|segments?)\s*#?\s*(\d+)"
                         r"(?:\s*(?:,|and|&)\s*(\d+))*", t):
        refs += [int(x) for x in re.findall(r"\d+", m.group(0))]
    for m in re.finditer(r"\b(first|second|third|fourth|fifth|sixth|seventh|eighth|1st|2nd|3rd|4th|5th|6th|7th|8th)"
                         r"\s+(?:clip|part|scene|shot|moment|segment|one)\b", t):
        refs.append(ORDINALS[m.group(1)])
    if re.search(r"\blast\s+(?:clip|part|scene|shot|moment|segment|one)\b", t):
        refs.append(n_clips)
    if re.search(r"\b(?:opening|intro)\s+(?:clip|scene|shot)\b", t):
        refs.append(1)
    return [r for r in refs if r >= 1]


def _line_ref(text: str) -> Optional[int]:
    m = re.search(r"\b(?:line|sentence)\s*#?\s*(\d+)", text.lower())
    if m:
        return int(m.group(1))
    m = re.search(r"\b(first|second|third|fourth|fifth|last)\s+(?:line|sentence)", text.lower())
    if m:
        return -1 if m.group(1) == "last" else ORDINALS[m.group(1)]
    return None


def _quoted(text: str) -> str:
    m = re.search(r"[\"“”']([^\"“”']{2,})[\"“”']", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"\b(?:to|say|says|saying|:)\s+(.{3,})$", text, re.I)
    return m.group(1).strip().strip(".") if m else ""


def _match_candidate(text: str, pipe) -> Optional[str]:
    """'put back the crash clip' -> the unused clip whose description fits best."""
    un = unused_candidates(pipe)
    if not un:
        return None
    m = re.search(r"\b(?:clip|candidate|option)\s+([a-l])\b", text, re.I)
    if m:
        k = ord(m.group(1).upper()) - 65
        if k < len(un):
            return un[k].cid
    words = {w for w in re.findall(r"[a-z]{4,}", text.lower())} - {
        "back", "clip", "that", "this", "with", "where", "from", "the", "please", "again", "removed", "into",
        "video", "short", "put", "bring", "add", "include", "deleted", "took", "earlier", "before", "there"}
    best, best_s = None, 0
    for c in un:
        d = (c.description + " " + c.why_matches).lower()
        s = sum(1 for w in words if w in d)
        if s > best_s:
            best, best_s = c, s
    if best is not None:
        return best.cid
    removed = [c for c in un if c.excluded]
    return removed[0].cid if removed else None


def _split_clauses(text: str) -> list[str]:
    quoted: list[str] = []

    def hide(m):
        quoted.append(m.group(0))
        return f"\x00{len(quoted) - 1}\x00"
    text = re.sub(r"[\"“][^\"“”]*[\"”]", hide, text)
    parts = re.split(r"(?:[.;\n!]+\s*|,\s*(?:and\s+|then\s+)?|\s+and\s+then\s+|\s+then\s+|"
                     r"\s+and\s+(?=(?:also\s+)?(?:remove|delete|drop|cut|move|swap|switch|put|add|bring|make|"
                     r"change|use|replace|trim|shorten|turn|lower|raise|speed|slow|get|take|set|give)\b))", text)
    out = []
    for p in parts:
        if p and len(p.strip()) > 2:
            out.append(re.sub(r"\x00(\d+)\x00", lambda m: quoted[int(m.group(1))], p.strip()))
    return out


def parse_rules(request: str, pipe) -> tuple[list[dict], list[str]]:
    plan = pipe.project.plan
    n = len(plan.story)
    ops: list[dict] = []
    unknown: list[str] = []
    for cl in _split_clauses(request):
        t = cl.lower()
        got = _parse_clause(cl, t, n, pipe)
        if got:
            ops += got
        else:
            unknown.append(cl)
    return ops, unknown


def _parse_clause(cl: str, t: str, n: int, pipe) -> list[dict]:
    clips = _clip_ref(t, n)
    # --- put a clip back / add one
    if (re.search(r"\b(put|bring|add)\b.*\b(back|in|again)\b", t) or re.search(r"\b(re-?add|include|restore)\b", t)
            or re.search(r"\b(add|insert)\b", t)) and not re.search(
                r"\b(line|sentence|narration|caption|subtitle|music|text|effect|transition)s?\b", t):
        cid = _match_candidate(cl, pipe)
        if not cid:
            return [{"op": "add_clip", "cid": None}]
        if cid:
            pos = None
            if re.search(r"\b(start|beginning|first|front|open)\b", t):
                pos = 1
            elif re.search(r"\b(end|last|finish)\b", t):
                pos = n + 1
            return [{"op": "add_clip", "cid": cid, "position": pos}]
    # --- swap
    if re.search(r"\b(swap|switch|flip|exchange)\b", t):
        nums = clips or [int(x) for x in re.findall(r"\b(\d+)\b", t) if int(x) >= 1]
        if len(nums) >= 2:
            return [{"op": "swap_clips", "a": nums[0], "b": nums[1]}]
    # --- move
    if re.search(r"\b(move|put|place|start with|open with|end with|finish with)\b", t) and clips:
        c = clips[0]
        if re.search(r"\b(start with|open with)\b", t) or re.search(r"\b(to|at)\s+the\s+(start|beginning|front)\b|"
                                                                     r"\bfirst\b(?!\s+clip)", t):
            return [{"op": "move_clip", "clip": c, "to": 1}]
        if re.search(r"\b(end with|finish with)\b", t) or re.search(r"\b(to|at)\s+the\s+end\b|\blast\b(?!\s+clip)", t):
            return [{"op": "move_clip", "clip": c, "to": n}]
        m = re.search(r"\b(?:to|into)\s+(?:position|spot|place|slot)?\s*#?(\d+)\b", t)
        if m and int(m.group(1)) != c:
            return [{"op": "move_clip", "clip": c, "to": int(m.group(1))}]
        m = re.search(r"\b(before|after)\s+(?:clip\s*)?(\d+)\b", t)
        if m:
            other = int(m.group(2))
            to = other if m.group(1) == "before" else other + 1
            if c < to:
                to -= 1
            return [{"op": "move_clip", "clip": c, "to": max(1, min(n, to))}]
    # --- replace
    if re.search(r"\b(replace|different|another|other)\b", t) and clips and not re.search(r"\b(line|hook|voice)\b", t):
        return [{"op": "replace_clip", "clip": c} for c in clips]
    # --- trim
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:s|sec|secs|seconds?)\b", t)
    if clips and re.search(r"\b(trim|cut|shorten|remove|chop|start|end)\b", t) and m and \
            re.search(r"\b(start|beginning|end|ending|off)\b", t):
        s = float(m.group(1))
        start = bool(re.search(r"\b(start|beginning|front)\b", t))
        end = bool(re.search(r"\b(end|ending)\b", t))
        longer = bool(re.search(r"\b(longer|extend|more|earlier|later)\b", t)) and not \
            re.search(r"\b(trim|cut|shorten|chop)\b", t)
        sign = -1 if longer else 1
        return [{"op": "trim_clip", "clip": clips[0], "cut_start": sign * s if start or not end else 0.0,
                 "cut_end": sign * s if end else 0.0}]
    # --- remove clip(s)
    if clips and re.search(r"\b(remove|delete|drop|cut|get rid of|take out|lose|ditch|skip|don'?t (?:want|like)|"
                           r"hate|boring)\b", t) and not re.search(r"\b(line|sentence|narration|caption)\b", t):
        return [{"op": "remove_clip", "clip": c} for c in sorted(set(clips), reverse=True)]
    # --- length
    m = re.search(r"\b(?:to|under|about|around|max|maximum|only|exactly|be|at)?\s*(\d{2,3})\s*(?:s|sec|secs|seconds?)\b",
                  t)
    if m and re.search(r"\b(long|length|shorter|longer|under|seconds?|secs?|make it|make the video|total|duration)\b",
                       t) and not clips:
        return [{"op": "set_length", "seconds": float(m.group(1))}]
    if re.search(r"\b(way|much|a lot)\s+shorter\b", t):
        return [{"op": "set_length", "seconds": "x0.6"}]
    if re.search(r"\bshorter\b|\btoo long\b", t) and not re.search(r"\b(line|narration|script|caption|hook)\b", t):
        return [{"op": "set_length", "seconds": "x0.8"}]
    if re.search(r"\blonger\b|\btoo short\b", t) and not re.search(r"\b(line|narration|script|caption)\b", t):
        return [{"op": "set_length", "seconds": "x1.25"}]
    # --- narration
    if re.search(r"\b(no|remove (?:all|the)|without|get rid of (?:the|all)?)\s*(?:the\s+)?(narration|voice ?over|"
                 r"talking|narrator|commentary|script)\b", t) and not re.search(r"\bline\b", t):
        return [{"op": "no_narration"}]
    ln = _line_ref(t)
    if ln is not None:
        if re.search(r"\b(remove|delete|drop|cut|get rid of)\b", t):
            return [{"op": "remove_line", "line": ln}]
        txt = _quoted(cl)
        if txt and re.search(r"\b(change|make|say|rewrite|replace|set|edit)\b", t):
            return [{"op": "edit_line", "line": ln, "text": txt}]
    if re.search(r"\b(less|fewer)\s+(narration|talking|voice ?over|lines|commentary)\b", t):
        return [{"op": "rewrite_script", "style": "much shorter: fewer and shorter lines"}]
    m = re.search(r"\b(?:script|narration|voice ?over|lines|commentary|wording)\b.*\b(funnier|more hype|hype|"
                  r"more exciting|shorter|calmer|more serious|more dramatic|better|punchier|simpler)\b|"
                  r"\b(funnier|more hype|more exciting|punchier|more dramatic)\b.*\b(script|narration|lines|voice ?over)",
                  t)
    if m or re.search(r"\b(rewrite|redo|re-?write)\b.*\b(script|narration|lines|voice ?over)\b", t):
        return [{"op": "rewrite_script", "style": cl}]
    # --- hook / title / end message
    if re.search(r"\bhook\b", t):
        txt = _quoted(cl)
        if txt and re.search(r"\b(to|say|says)\b", t):
            return [{"op": "set_hook", "headline": txt, "opening_line": ""}]
        return [{"op": "next_hook"}]
    if re.search(r"\btitle\b", t):
        txt = _quoted(cl)
        if txt:
            return [{"op": "set_title", "text": txt}]
    if re.search(r"\bend (?:message|text|screen)\b", t):
        txt = _quoted(cl)
        if txt:
            return [{"op": "end_message", "text": txt}]
    # --- voice
    from ..providers.tts import VOICE_LABELS

    for vid, desc in VOICE_LABELS.items():
        name = desc.split(" (")[0].lower()
        if re.search(rf"\b{re.escape(name)}\b", t) and re.search(r"\bvoice|use|switch|change|narrator\b", t):
            return [{"op": "voice", "voice": vid}]
    if re.search(r"\b(female|woman|girl|lady)\b", t) and re.search(r"\bvoice|narrator|narration\b", t):
        return [{"op": "voice", "voice": "af_heart"}]
    if re.search(r"\b(male|man|guy|dude)\b", t) and re.search(r"\bvoice|narrator|narration\b", t):
        return [{"op": "voice", "voice": "am_michael"}]
    if re.search(r"\b(british|uk|english accent)\b", t):
        return [{"op": "voice", "voice": "bm_george"}]
    if re.search(r"\bdeep(er)?\b", t) and re.search(r"\bvoice|narrator\b", t):
        return [{"op": "voice", "voice": "am_onyx"}]
    if re.search(r"\b(talk|speak|voice|narrat\w*|read)\b.*\bfaster\b|\bfaster\b.*\b(voice|narrat\w*|talk)", t):
        return [{"op": "voice_speed", "value": "+0.1"}]
    if re.search(r"\b(talk|speak|voice|narrat\w*|read)\b.*\bslower\b|\bslower\b.*\b(voice|narrat\w*|talk)", t):
        return [{"op": "voice_speed", "value": "-0.1"}]
    loud = re.search(r"\b(louder|turn (?:\w+ )*up|up|raise|boost|increase|more)\b", t)
    quiet = re.search(r"\b(quieter|softer|turn (?:\w+ )*down|down|lower|reduce|less|too loud)\b", t)
    if re.search(r"\bmusic\b", t):
        if re.search(r"\b(no|remove|off|without|stop|get rid)\b", t):
            return [{"op": "music_off"}]
        if loud or quiet:
            return [{"op": "music_volume", "db": 4 if loud else -4}]
    if re.search(r"\b(game|stream|original|background|gameplay)\s*(audio|sound|volume)?\b", t) and (loud or quiet):
        return [{"op": "original_volume", "db": 3 if loud else -3}]
    if re.search(r"\b(voice|narrat\w*|narrator)\b", t) and (loud or quiet):
        return [{"op": "voice_volume", "db": 3 if loud else -3}]
    # --- captions
    if re.search(r"\b(captions?|subtitles?|subs|text)\b", t):
        if re.search(r"\b(bigger|larger|huge|increase|bolder)\b", t):
            return [{"op": "caption_size", "value": "+12"}]
        if re.search(r"\b(smaller|tiny|decrease|less big)\b", t):
            return [{"op": "caption_size", "value": "-12"}]
        colours = {"yellow": "#FFD400", "white": "#FFFFFF", "red": "#FF3B30", "green": "#34C759", "blue": "#2F8CFF",
                   "orange": "#FF9500", "pink": "#FF4FA3", "purple": "#AF52DE", "cyan": "#32D9F2", "black": "#000000"}
        for k, v in colours.items():
            if k in t:
                return [{"op": "caption_color", "color": v}]
    # --- vague "make it better" requests: a clear, undoable punch-up instead of nothing
    if re.search(r"\b(cooler|better|more (?:exciting|hype|epic|interesting|engaging|fun)|hype|punchier|"
                 r"spice it up|more energy|more energetic|less boring|boring|more viral|pop more|livelier)\b", t):
        ops = [{"op": "voice_speed", "value": "+0.06"}, {"op": "caption_size", "value": "+8"},
               {"op": "transitions", "value": "quick"}, {"op": "punch_up"}]
        if len(pipe.project.plan.hooks) > 1:
            ops.insert(0, {"op": "next_hook"})
        return ops
    # --- style
    if re.search(r"\b(hard cuts?|no transitions?|no fades?)\b", t):
        return [{"op": "transitions", "value": "none"}]
    if re.search(r"\b(transitions?|fades?|cross-?fade)\b", t) and not re.search(r"\bno\b", t):
        return [{"op": "transitions", "value": "quick"}]
    if re.search(r"\b(facecam|webcam|face cam)\b", t):
        return [{"op": "layout", "value": "facecam-split"}]
    if re.search(r"\b(full frame|whole screen|blur(red)? (fill|background))\b", t):
        return [{"op": "layout", "value": "blur-fill"}]
    if re.search(r"\b(zoom(ed)? in|crop|fill the screen)\b", t):
        return [{"op": "layout", "value": "center"}]
    return []


# ----------------------------------------------------------------------------- applying
def snapshot(pipe) -> dict:
    """Everything an edit can change, for Undo."""
    return {"plan": copy.deepcopy(pipe.project.plan),
            "cands": {c.cid: (c.included, c.locked, c.excluded) for c in pipe.project.candidates},
            "edit": dataclasses.replace(pipe.settings.edit), "voice": dataclasses.replace(pipe.settings.voice)}


def restore(pipe, snap: dict) -> None:
    pipe.project.plan = snap["plan"]
    for c in pipe.project.candidates:
        if c.cid in snap["cands"]:
            c.included, c.locked, c.excluded = snap["cands"][c.cid]
    pipe.settings.edit, pipe.settings.voice = snap["edit"], snap["voice"]
    pipe.settings.save()
    pipe.edit_timeline = None


def _rel(cur: float, v, lo: float, hi: float) -> float:
    """Absolute number, or a relative change written as '+0.1' / '-12' / 'x0.8'."""
    s = str(v).strip()
    try:
        if s.startswith("x"):
            out = cur * float(s[1:])
        elif s.startswith(("+", "-")):
            out = cur + float(s)
        else:
            out = float(s)
    except ValueError:
        out = cur
    return max(lo, min(hi, out))


def _move_lines_for_reorder(plan, order: list[int]) -> None:
    """order[new_index] = old_index. Narration lines follow their clip."""
    new_of = {old: new for new, old in enumerate(order)}
    keep = []
    for ln in plan.narration:
        if ln.item_index in new_of:
            ln.item_index = new_of[ln.item_index]
            keep.append(ln)
    keep.sort(key=lambda ln: (ln.item_index, {"before": 0, "over-start": 1, "after": 2}.get(ln.position, 1)))
    plan.narration = keep


def _reset_audio(lines) -> None:
    for ln in lines:
        ln.audio_path, ln.duration = "", 0.0


def apply_changes(pipe, ops: list[dict]) -> tuple[list[str], list[str]]:
    plan = pipe.project.plan
    by_id = {c.cid: c for c in pipe.project.candidates}
    done: list[str] = []
    skipped: list[str] = []
    settings_changed = False
    rewrite_style = ""

    def clip_no(v) -> Optional[int]:
        try:
            i = int(v) - 1
        except (TypeError, ValueError):
            return None
        return i if 0 <= i < len(plan.story) else None

    for op in ops:
        kind = op.get("op")
        try:
            if kind == "remove_clip":
                i = clip_no(op.get("clip"))
                if i is None or len(plan.story) <= 1:
                    skipped.append(f"Remove clip {op.get('clip')}: " + ("that's the only clip" if i is not None
                                                                          else "no such clip"))
                    continue
                it = plan.story.pop(i)
                c = by_id.get(it.cid)
                if c:
                    c.included, c.locked, c.excluded = False, False, True
                order = [k if k < i else k + 1 for k in range(len(plan.story))]
                plan.narration = [ln for ln in plan.narration if ln.item_index != i]
                _move_lines_for_reorder(plan, order)
                done.append(f"Removed clip {i + 1} ({_short(c)})")
            elif kind == "add_clip":
                cid = op.get("cid")
                if not cid and op.get("candidate"):
                    un = unused_candidates(pipe)
                    k = ord(str(op["candidate"]).strip().upper()[:1]) - 65
                    cid = un[k].cid if 0 <= k < len(un) else None
                c = by_id.get(cid) if cid else None
                if c is None:
                    skipped.append("Add a clip: " + ("there are no unused clips to add — analyse with a broader "
                                                     "topic or more clips on page 1" if not unused_candidates(pipe)
                                                     else "couldn't tell which clip you meant (try 'add clip B' "
                                                          "using the letters in the Candidate Clips list)"))
                    continue
                pos = op.get("position")
                pos = len(plan.story) if pos in (None, "", 0) else max(0, min(len(plan.story), int(pos) - 1))
                plan.story.insert(pos, StoryItem(cid=c.cid, role="added", start=c.start, end=c.end))
                c.included, c.locked, c.excluded = True, True, False
                for ln in plan.narration:
                    if ln.item_index >= pos:
                        ln.item_index += 1
                done.append(f"Added a clip at position {pos + 1} ({_short(c)})")
            elif kind == "move_clip":
                i, j = clip_no(op.get("clip")), clip_no(op.get("to"))
                if i is None or j is None or i == j:
                    skipped.append(f"Move clip {op.get('clip')} to {op.get('to')}: not possible")
                    continue
                order = list(range(len(plan.story)))
                order.insert(j, order.pop(i))
                plan.story = [plan.story[k] for k in order]
                _move_lines_for_reorder(plan, order)
                done.append(f"Moved clip {i + 1} to position {j + 1}")
            elif kind == "swap_clips":
                a, b = clip_no(op.get("a")), clip_no(op.get("b"))
                if a is None or b is None or a == b:
                    skipped.append(f"Swap clips {op.get('a')} and {op.get('b')}: not possible")
                    continue
                order = list(range(len(plan.story)))
                order[a], order[b] = order[b], order[a]
                plan.story = [plan.story[k] for k in order]
                _move_lines_for_reorder(plan, order)
                done.append(f"Swapped clips {a + 1} and {b + 1}")
            elif kind == "replace_clip":
                i = clip_no(op.get("clip"))
                alt = next((c for c in unused_candidates(pipe, 40) if not c.excluded and c.final_score > 0), None)
                if i is None or alt is None:
                    skipped.append(f"Replace clip {op.get('clip')}: " + ("no such clip" if i is None
                                                                           else "no unused clips left"))
                    continue
                old = by_id.get(plan.story[i].cid)
                if old:
                    old.included, old.locked, old.excluded = False, False, True
                plan.story[i] = StoryItem(cid=alt.cid, role=plan.story[i].role, start=alt.start, end=alt.end)
                alt.included, alt.locked = True, True
                for ln in plan.narration:          # old narration described the old clip
                    if ln.item_index == i:
                        ln.text = ""
                plan.narration = [ln for ln in plan.narration if ln.text]
                done.append(f"Replaced clip {i + 1} with: {_short(alt)}")
                rewrite_style = rewrite_style or "keep the same style; describe the new clip accurately"
            elif kind == "trim_clip":
                i = clip_no(op.get("clip"))
                if i is None:
                    skipped.append(f"Trim clip {op.get('clip')}: no such clip")
                    continue
                it = plan.story[i]
                c = by_id.get(it.cid)
                cs, ce = float(op.get("cut_start") or 0), float(op.get("cut_end") or 0)
                lo = max(0.0, (c.start - 15) if c else it.start - 15)
                dur = pipe.project.source.duration if pipe.project.source else 1e9
                ns, ne = max(lo, it.start + cs), min(dur, it.end - ce)
                if ne - ns < 2.0:
                    skipped.append(f"Trim clip {i + 1}: it would be shorter than 2 seconds")
                    continue
                it.start, it.end = ns, ne
                parts = []
                if cs:
                    parts.append(f"{'cut' if cs > 0 else 'added'} {abs(cs):.1f}s at the start")
                if ce:
                    parts.append(f"{'cut' if ce > 0 else 'added'} {abs(ce):.1f}s at the end")
                done.append(f"Clip {i + 1}: " + " and ".join(parts) + f" (now {ne - ns:.1f}s)")
            elif kind == "set_length":
                total = sum(it.end - it.start for it in plan.story)
                target = _rel(total if str(op.get("seconds", "")).startswith("x") else plan.target_seconds,
                              op.get("seconds"), 10, 180)
                plan.target_seconds = target
                msg = _fit_length(pipe, target)
                done.append(f"Target length {target:.0f}s: {msg}")
            elif kind == "edit_line":
                k = _line_no(plan, op.get("line"))
                text = str(op.get("text") or "").strip()
                if k is None or not text:
                    skipped.append(f"Edit line {op.get('line')}: no such line")
                    continue
                plan.narration[k].text = text[:220]
                _reset_audio([plan.narration[k]])
                done.append(f"Narration line {k + 1} is now: \"{text[:80]}\"")
            elif kind == "remove_line":
                k = _line_no(plan, op.get("line"))
                if k is None:
                    skipped.append(f"Remove line {op.get('line')}: no such line")
                    continue
                gone = plan.narration.pop(k)
                done.append(f"Removed narration line {k + 1} (\"{gone.text[:60]}\")")
            elif kind == "add_line":
                i = clip_no(op.get("clip"))
                text = str(op.get("text") or "").strip()
                if i is None or not text:
                    skipped.append("Add a narration line: needs a clip number and the text")
                    continue
                pos = "after" if str(op.get("position")) == "after" else "before"
                plan.narration.append(NarrationLine(text=text[:220], position=pos, item_index=i))
                _move_lines_for_reorder(plan, list(range(len(plan.story))))
                done.append(f"Added a narration line to clip {i + 1}: \"{text[:80]}\"")
            elif kind == "rewrite_script":
                rewrite_style = str(op.get("style") or "better")
            elif kind == "no_narration":
                plan.narration = []
                done.append("Removed all narration (the clips play with their original audio and captions)")
            elif kind == "next_hook":
                if len(plan.hooks) < 2:
                    skipped.append("Different hook: there's only one hook option")
                    continue
                k = (plan.chosen_hook + 1) % len(plan.hooks)
                pipe.choose_hook(k)
                done.append(f"Switched to hook {k + 1}: \"{plan.hooks[k].headline}\"")
            elif kind == "set_hook":
                head = str(op.get("headline") or "").strip()
                line = str(op.get("opening_line") or "").strip()
                if not head and not line:
                    skipped.append("Change the hook: no new text given")
                    continue
                cur = plan.hooks[plan.chosen_hook] if plan.hooks else HookOption(headline="", opening_line="")
                plan.hooks.append(HookOption(headline=head or cur.headline, opening_line=line or cur.opening_line,
                                             rationale="written by you"))
                pipe.choose_hook(len(plan.hooks) - 1)
                done.append(f"New hook: \"{head or cur.headline}\"" + (f" / \"{line}\"" if line else ""))
            elif kind == "set_title":
                plan.title = str(op.get("text") or plan.title).strip()[:100]
                done.append(f"Title: \"{plan.title}\"")
            elif kind == "set_context_text":
                i = clip_no(op.get("clip"))
                if i is None:
                    skipped.append("On-screen text: no such clip")
                    continue
                plan.story[i].context_text = str(op.get("text") or "")[:60]
                done.append(f"Clip {i + 1} on-screen text: \"{plan.story[i].context_text}\"")
            elif kind == "voice":
                from ..providers.tts import VOICE_LABELS

                v = str(op.get("voice") or "")
                if v not in VOICE_LABELS:
                    skipped.append(f"Voice '{v}': not one of the available voices")
                    continue
                pipe.settings.voice.voice = v
                _reset_audio(plan.narration)
                settings_changed = True
                done.append(f"Voice: {VOICE_LABELS[v]}")
            elif kind == "voice_speed":
                vs = pipe.settings.voice
                vs.speed = round(_rel(vs.speed, op.get("value"), 0.75, 1.45), 2)
                _reset_audio(plan.narration)
                settings_changed = True
                done.append(f"Voice speed: {vs.speed:.2f}×")
            elif kind == "voice_volume":
                vs = pipe.settings.voice
                vs.volume_db = _rel(vs.volume_db, f"{float(op.get('db') or 0):+}", -12, 9)
                _reset_audio(plan.narration)
                settings_changed = True
                done.append(f"Voice level: {vs.volume_db:+.0f} dB")
            elif kind == "caption_size":
                es = pipe.settings.edit
                es.caption_size = int(_rel(es.caption_size, op.get("value"), 40, 140))
                settings_changed = True
                done.append(f"Caption size: {es.caption_size}")
            elif kind == "caption_color":
                col = str(op.get("color") or "")
                if not re.fullmatch(r"#[0-9A-Fa-f]{6}", col):
                    skipped.append(f"Caption colour '{col}': not a colour")
                    continue
                pipe.settings.edit.caption_color = col.upper()
                settings_changed = True
                done.append(f"Caption colour: {col.upper()}")
            elif kind == "music_volume":
                es = pipe.settings.edit
                if not es.music_path:
                    skipped.append("Music level: there's no music (add a licensed track on page 5)")
                    continue
                es.music_db = _rel(es.music_db, f"{float(op.get('db') or 0):+}", -40, -6)
                settings_changed = True
                done.append(f"Music level: {es.music_db:.0f} dB")
            elif kind == "music_off":
                pipe.settings.edit.music_path = ""
                settings_changed = True
                done.append("Music removed")
            elif kind == "original_volume":
                es = pipe.settings.edit
                es.original_audio_db = _rel(es.original_audio_db, f"{float(op.get('db') or 0):+}", -20, 6)
                settings_changed = True
                done.append(f"Stream audio level: {es.original_audio_db:+.0f} dB")
            elif kind == "end_message":
                pipe.settings.edit.end_message = str(op.get("text") or "")[:60]
                settings_changed = True
                done.append(f"End message: \"{pipe.settings.edit.end_message}\"")
            elif kind == "transitions":
                v = op.get("value")
                if v not in ("quick", "none"):
                    continue
                pipe.settings.edit.transitions = v
                settings_changed = True
                done.append("Transitions: " + ("quick cross-fades" if v == "quick" else "hard cuts"))
            elif kind == "punch_up":
                es = pipe.settings.edit
                changed = []
                if not es.flash_forward_hook:
                    es.flash_forward_hook = True
                    changed.append("opens with a flash-forward of the best moment")
                if not es.sfx_enabled:
                    es.sfx_enabled = True
                    changed.append("whoosh/pop effects on")
                if es.caption_highlight.upper() != "#FFD400":
                    es.caption_highlight = "#FFD400"
                    changed.append("yellow highlight on key words")
                settings_changed = True
                if changed:
                    done.append("Punch-up: " + ", ".join(changed))
            elif kind == "layout":
                v = op.get("value")
                if v not in ("smart", "blur-fill", "center", "facecam-split"):
                    continue
                pipe.settings.edit.crop_mode = v
                settings_changed = True
                done.append(f"Layout: {v}")
        except Exception as e:  # noqa: BLE001  (one bad op never breaks the others)
            skipped.append(f"{kind}: {e}")

    if rewrite_style:
        msg = rewrite_narration(pipe, rewrite_style)
        (done if msg.startswith("Rewrote") or msg.startswith("Wrote") else skipped).append(msg)
    if settings_changed:
        pipe.settings.save()
    if done:
        pipe.edit_timeline = None
        plan.overlays = [o for o in plan.overlays if o.kind != "emphasis"] if any(
            d.startswith(("Removed clip", "Added a clip", "Moved", "Swapped", "Replaced", "Target")) for d in done) \
            else plan.overlays
    return done, skipped


def _line_no(plan, v) -> Optional[int]:
    try:
        k = int(v)
    except (TypeError, ValueError):
        return None
    k = len(plan.narration) if k == -1 else k
    return k - 1 if 1 <= k <= len(plan.narration) else None


def _short(c) -> str:
    if c is None:
        return "clip"
    d = (c.description or c.why_matches or "").strip()
    return (d[:70] + "…") if len(d) > 70 else (d or f"{c.duration:.0f}s clip")


def _fit_length(pipe, target: float) -> str:
    """Drop the weakest clips (never the opening one) or add the best unused ones to get close to target."""
    plan = pipe.project.plan
    by_id = {c.cid: c for c in pipe.project.candidates}
    total = lambda: sum(it.end - it.start for it in plan.story)  # noqa: E731
    removed, added = 0, 0
    while total() > target * 1.08 and len(plan.story) > 1:
        idx = min(range(1, len(plan.story)), key=lambda k: by_id[plan.story[k].cid].final_score
                  if plan.story[k].cid in by_id else 0)
        it = plan.story[idx]
        if total() - (it.end - it.start) < target * 0.6:     # removing would overshoot: trim instead
            over = total() - target
            longest = max(range(len(plan.story)), key=lambda k: plan.story[k].end - plan.story[k].start)
            li = plan.story[longest]
            cut = min(over, (li.end - li.start) - 4.0)
            if cut > 0.5:
                li.end -= cut / 2
                li.start += cut / 2
            break
        plan.story.pop(idx)
        c = by_id.get(it.cid)
        if c:
            c.included, c.locked = False, False
        plan.narration = [ln for ln in plan.narration if ln.item_index != idx]
        for ln in plan.narration:
            if ln.item_index > idx:
                ln.item_index -= 1
        removed += 1
    while total() < target * 0.85:
        alt = next((c for c in unused_candidates(pipe, 40) if not c.excluded and c.final_score > 0
                    and c.duration <= target - total() + 8), None)
        if alt is None:
            break
        plan.story.append(StoryItem(cid=alt.cid, role="added", start=alt.start, end=alt.end))
        alt.included, alt.locked = True, True
        added += 1
    parts = []
    if removed:
        parts.append(f"removed {removed} weaker clip{'s' if removed > 1 else ''}")
    if added:
        parts.append(f"added {added} clip{'s' if added > 1 else ''}")
    return (", ".join(parts) or "trimmed to fit") + f"; now about {total():.0f}s"


def rewrite_narration(pipe, style: str) -> str:
    """Rewrite the narration in the requested style (language model), keeping it factual."""
    plan = pipe.project.plan
    if not pipe.services.llm_available():
        if "shorter" in style or "fewer" in style:
            if len(plan.narration) > 2:
                plan.narration = [plan.narration[0], plan.narration[-1]]
                return "Rewrote the narration: kept only the opening and closing lines"
        return ("Rewrite the narration: needs the free Ollama language model (AI Models → Download missing Ollama "
                "models). You can also edit lines yourself on page 4, or type e.g. 'change line 2 to \"...\"'.")
    try:
        pipe.write_script() if not plan.narration else None
        by_id = {c.cid: c for c in pipe.project.candidates}
        clips = "\n".join(f"{i + 1}. {(by_id[it.cid].description if it.cid in by_id else '')[:160]}"
                          for i, it in enumerate(plan.story))
        lines = "\n".join(f"{i + 1}. (clip {ln.item_index + 1}, {ln.position}) {ln.text}"
                          for i, ln in enumerate(plan.narration))
        d = pipe.services.llm().complete_json(
            "You rewrite the voice-over of a vertical gameplay Short. Keep every line short (max ~14 words), "
            "spoken, and strictly about what happens in its clip; never invent quotes or events. Reply with JSON "
            '{"lines":[{"clip":N,"position":"before"|"over-start"|"after","text":"..."}]}',
            f"CLIPS:\n{clips}\n\nCURRENT NARRATION:\n{lines or '(none)'}\n\nWHAT THE CREATOR WANTS: {style}\n\nJSON only.",
            max_tokens=900)
        new = []
        for x in d.get("lines") or []:
            try:
                i = int(x.get("clip")) - 1
            except (TypeError, ValueError):
                continue
            t = str(x.get("text") or "").strip()
            if 0 <= i < len(plan.story) and t:
                pos = x.get("position") if x.get("position") in ("before", "over-start", "after") else "before"
                new.append(NarrationLine(text=t[:220], position=pos, item_index=i))
        if not new:
            return "Rewrite the narration: the language model didn't return usable lines (nothing changed)"
        plan.narration = new
        _move_lines_for_reorder(plan, list(range(len(plan.story))))
        return f"Rewrote the narration ({len(new)} lines)"
    except Exception as e:  # noqa: BLE001
        return f"Rewrite the narration: {e}"
