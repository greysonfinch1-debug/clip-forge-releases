"""The narration-driven / hybrid workflow, run by ``Pipeline`` (same project, cache, cancel,
progress, rendering and export as clip-driven Shorts).

  create_plan       prompt → brief → (moments) → narration sections → footage for each section
  prepare_edit      voice the narration, fit the footage to it, build the shared timeline,
                    captions and on-screen text
  regenerate        one section at a time: rewrite its words, find different footage, replace
                    one shot, change pacing or tone — everything else is kept
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from ..core.cache import SourceCache
from ..core.ingest import Ingestor
from ..core.models import (HookOption, LibraryItem, NarrationLine, Plan, RightsRecord, Section, Shot, TopicSpec,
                           VideoSource)
from . import library as lib_mod
from . import matcher as match_mod
from . import narration as narr_mod
from . import research
from .brief import brief_from_production, understand_brief
from .timeline import PAD_AFTER, PAD_BEFORE, build, fit_shots

LOW_RES = 600       # below this picture height, footage is shown whole (blur-fill), not cropped

if TYPE_CHECKING:
    from ..pipeline import Pipeline

NO_WRITER = ("A narration-driven video needs a script. The AI language model (Ollama) isn't running, so "
             "ClipForge can't write one about your topic. Either start Ollama (AI Models, bottom left), or click "
             "'Your script, sources and more footage' under the prompt, paste your own script and tick "
             "'Use this as the narration, word for word'.")


# ------------------------------------------------------------------ library
def add_library_video(pipe: "Pipeline", path: str = "", url: str = "", role: str = "broll",
                      rights: Optional[RightsRecord] = None, progress=None) -> LibraryItem:
    """Add a video to the project's footage library: it is prepared and analysed once (cached)."""
    ing = Ingestor(progress=(lambda f, m: progress("ingest", f, m)) if progress else None, cancel=pipe._cancelled,
                   analysis_height=pipe.settings.vision.analysis_height)
    src = ing.from_url(url) if url else ing.from_file(path)
    cache = SourceCache(src.source_id)
    if rights is not None and rights.confirmed:
        cache.save_json("rights.json", rights.to_dict())
    proj = pipe.project
    proj.library = [x for x in proj.library if x.source_id != src.source_id]
    item = LibraryItem(source_id=src.source_id, path=src.path or "", url=src.url or "", title=src.title or "",
                       role=role, duration=src.duration)
    proj.library.append(item)
    cache.save_json("library_source.json", src.to_dict())
    pipe.log(f"Footage library: added '{item.title}' as {lib_mod.ROLES.get(role, role)}")
    return item


def _library_source(item: LibraryItem) -> Optional[VideoSource]:
    d = SourceCache(item.source_id).load_json("library_source.json")
    if not d:
        return None
    src = VideoSource.from_dict(d)
    r = SourceCache(item.source_id).load_json("rights.json")
    if r:
        src.rights = RightsRecord.from_dict(r)
    return src


def footage(pipe: "Pipeline", progress=None) -> list[lib_mod.SourceFootage]:
    """The main video plus every library video, analysed (from the cache when possible)."""
    out = []
    if pipe.project.source is not None:
        if pipe.transcript is None:
            pipe.analyze_signals(progress)
        src = pipe.project.source
        probs = src.rights.problems(False)
        out.append(lib_mod.SourceFootage(src=src, role="main", transcript=pipe.transcript, audio=pipe.audio,
                                         visual=pipe.visual, rights_ok=not probs, rights_problems=probs))
    for k, item in enumerate(pipe.project.library):
        if pipe.project.source is not None and item.source_id == pipe.project.source.source_id:
            continue
        src = _library_source(item)
        if src is None:
            pipe.log(f"Footage library: '{item.title}' is missing its preparation; add it again")
            continue
        if progress:
            progress("library", k / max(1, len(pipe.project.library)), f"Analysing library video {k + 1}: {item.title[:40]}")
        f = lib_mod.analyse_source(src, pipe.services, pipe.settings, progress, pipe._cancelled)
        f.role = item.role
        out.append(f)
    pipe._footage = out
    return out


# ------------------------------------------------------------------ plan
def create_plan(pipe: "Pipeline", prompt: str, target_seconds: float, mode: str = "auto", style: str = "",
                pacing: str = "", script: str = "", notes: str = "", urls: Optional[list[str]] = None,
                use_my_script: bool = False, progress=None, production=None):
    """Build a narration-driven or hybrid plan. Returns the plan's brief (mode 'clip' means the
    caller should run the clip-driven workflow instead)."""
    pipe.services.retry_llm()
    llm = pipe.services.llm()
    pipe.used["llm"] = pipe.services.status["llm"].active
    from . import expand as expand_mod

    direction = expand_mod.for_writer(production) if production is not None else ""
    if direction:      # the approved production brief already understood the request
        brief = brief_from_production(prompt, production, mode, style)
    else:
        brief = understand_brief(prompt, llm, mode, style)
    if pacing in ("slow", "normal", "fast"):
        brief.pacing = pacing
    if script.strip() and (use_my_script or pipe.used["llm"] == "rules"):
        brief.script_source, brief.user_script = "user", script.strip()
        if use_my_script and brief.mode == "clip" and mode in ("", "auto"):
            # a pasted script to narrate is a narration-driven video, whatever words the prompt used
            brief.mode, brief.mode_reason = "narration", "you supplied your own narration to use"
    elif script.strip():
        brief.notes = script.strip()            # with a writer available, pasted text is treated as notes
    brief.notes = (brief.notes + "\n" + notes).strip() if notes.strip() else brief.notes
    brief.source_urls = [u for u in (urls or []) if u.strip()]
    pipe.log(f"Video type: {brief.mode} ({brief.mode_reason}); style {brief.style or '-'}, pacing {brief.pacing}")
    if brief.mode == "clip":
        return brief
    if progress:
        progress("plan", 0.02, "Reading the footage library")
    fl = footage(pipe, progress)
    index = lib_mod.build_index(fl)
    pipe._index = index
    if not len(index):
        bad = [f"{f.src.title}: {', '.join(f.rights_problems)}" for f in fl if not f.rights_ok]
        raise PermissionError("No footage can be used yet: record how you have permission to use each video "
                              "(Page 1 for the main video; the library list for the others).\n" + "\n".join(bad))
    vision = pipe.services.vision()
    summary = lib_mod.describe_library(index, vision)
    pipe.used["visual_match"] = index.vision_model or "none (no picture model)"
    moments = []
    if brief.mode == "hybrid" and pipe.project.source is not None:
        if progress:
            progress("plan", 0.1, "Finding real moments for the hybrid video")
        keep_plan = pipe.project.plan
        pipe.find_moments(brief.subject or prompt, max(20.0, target_seconds * 0.5), 0, progress, direction=direction)
        moments = sorted([c for c in pipe.project.candidates if c.included], key=lambda c: -c.final_score)[:4]
        pipe.project.plan = keep_plan
    if pipe._cancelled():
        raise RuntimeError("Cancelled")
    if progress:
        progress("story", 0.3, "Writing the narration" if brief.script_source != "user" else "Reading your script")
    sources_text, problems = research.source_material(brief.notes, brief.source_urls)
    for p in problems:
        pipe.log("Sources: " + p)
    if brief.script_source != "user" and _about_the_video(prompt) and pipe.transcript is not None:
        # "what happens in this stream": what is actually said in it is the only evidence the writer gets
        sources_text = (sources_text + "\n\n" + transcript_excerpts(pipe.transcript)).strip()
    secs, extras, how = narr_mod.write_sections(prompt, brief, llm, target_seconds, summary, sources_text, moments,
                                               pipe.transcript, direction=direction,
                                               outro=getattr(pipe.settings.edit, "spoken_outro", True))
    if how == "none":
        raise ValueError(NO_WRITER)
    pipe.used["script"] = how
    if progress:
        progress("story", 0.7, "Choosing footage for each part of the narration")
    durations = [_est(s, moments) for s in secs]
    rep = match_mod.match_sections(secs, index, vision, durations, brief.pacing, brief.visual_style,
                                   topic=_topic(brief, prompt), reserved=_reserved(pipe, secs, moments),
                                   footage=brief.footage)
    for n in rep.notes:
        pipe.log("Footage: " + n)
    plan = Plan(topic=TopicSpec(raw=prompt, summary=brief.subject or prompt, search=brief.subject),
                target_seconds=target_seconds, brief=brief, sections=secs)
    plan.title = extras.get("title") or _title(brief, prompt)
    plan.description = extras.get("description") or f"{plan.title}."
    plan.sources_note = extras.get("sources_note") or ""
    plan.hooks = [HookOption(headline=_headline(plan.title), opening_line=secs[0].text if secs else "", score=6)]
    plan.narration = _lines(secs)
    pipe.project.plan = plan
    pipe.project.meta["analysed"] = True
    notes = list(rep.notes)
    es = pipe.settings.edit
    if brief.music and brief.music != "none" and not (es.music_path and Path(es.music_path).exists()):
        notes.append("The prompt asks for music, but no music is set up. ClipForge doesn't include music: choose "
                     "your own music file or folder on step 5 (Edit & Captions).")
    pipe.project.meta["match_notes"] = notes
    pipe.edit_timeline = None
    pipe.mark_made("candidates", "story", "script")
    pipe.project.save()
    if progress:
        progress("story", 1.0, f"Plan ready: {sum(s.kind == 'narration' for s in secs)} narrated parts"
                 + (f", {sum(s.kind == 'moment' for s in secs)} real moments" if moments else ""))
    return brief


_THIS_VIDEO = re.compile(r"\b(?:this|my|the|his|her|their)\s+(?:video|stream|vod|recording|broadcast|livestream)\b|"
                         r"\bwhat\s+happen|\bthe\s+streamer\b", re.I)


def _about_the_video(prompt: str) -> bool:
    return bool(_THIS_VIDEO.search(prompt or ""))


def transcript_excerpts(tr, limit: int = 3000) -> str:
    """Evenly spread sentences of the main video's transcript, with times (what people say in it)."""
    sens = [x for x in tr.sentences if len(x.text.split()) >= 4]
    if not sens:
        return ""
    step = max(1, len(sens) // max(1, limit // 90))
    lines, n = [], 0
    for x in sens[::step]:
        ln = f"[{int(x.start // 60)}:{int(x.start % 60):02d}] {x.text.strip()}"
        if n + len(ln) > limit:
            break
        lines.append(ln)
        n += len(ln) + 1
    return ("[Source: what people say in the main video (transcript excerpts). These are the only facts you may "
            "state about the video itself; it only tells you what was said, not what is on screen.]\n" + "\n".join(lines))


def _topic(brief, prompt: str) -> str:
    """The whole video's subject, plus the footage the prompt asked for ("the cartoon footage")."""
    t = (brief.subject or prompt).strip()
    return f"{t}, {brief.footage}" if getattr(brief, "footage", "") else t


def _reserved(pipe: "Pipeline", secs: list[Section], moments) -> list:
    """The real moments' footage (it plays with its own sound elsewhere in the video)."""

    main = pipe.project.source.source_id if pipe.project.source else ""
    by = {c.cid: c for c in (moments or pipe.project.candidates)}
    return [Shot(source_id=main, start=by[s.cid].start, end=by[s.cid].end) for s in secs
            if s.kind == "moment" and s.cid in by]


def _est(sec: Section, moments) -> float:
    if sec.kind == "moment":
        c = next((m for m in moments if m.cid == sec.cid), None)
        return c.duration if c else 0.0
    return len(sec.text.split()) / narr_mod.WORDS_PER_SECOND + PAD_BEFORE + PAD_AFTER


def _lines(secs: list[Section]) -> list[NarrationLine]:
    return [NarrationLine(text=s.text, item_index=i) for i, s in enumerate(secs) if s.kind == "narration" and s.text]


def _title(brief, prompt: str) -> str:
    t = (brief.subject or prompt).strip().rstrip(".")
    return (t[:1].upper() + t[1:])[:60]


_HEAD_STOP = {"a", "an", "the", "of", "in", "on", "at", "to", "for", "and", "or", "with", "about", "from", "by",
              "one", "big", "your", "my", "is", "are", "that", "this"}


def _headline(title: str, max_words: int = 10) -> str:
    """The on-screen headline: the whole title when it's short (it wraps to two lines), otherwise
    its first clause, never cut in the middle of a phrase ("… IN ONE BIG")."""
    words = title.split()
    if len(words) > max_words:
        first = []
        for m in re.finditer(r",\s+|\s+(?:and|because|that|so|which|while)\s+|\s+[-\u2014]\s+", title):
            head = title[:m.start()]
            if head.count("'") % 2 == 0 and head.count('"') % 2 == 0 and 3 <= len(head.split()) <= max_words:
                first = head.split()
                break
        if first:
            words = first
        else:
            words = words[:max_words]
            while len(words) > 3 and words[-1].lower().strip(",.'\"") in _HEAD_STOP:
                words = words[:-1]
    return " ".join(words).upper().strip(" ,.")


def sync_narration(pipe: "Pipeline") -> None:
    """After sections were edited or rewritten: narration lines follow the sections."""
    plan = pipe.project.plan
    old = {(ln.item_index, ln.text): ln for ln in plan.narration}
    new = []
    for i, s in enumerate(plan.sections):
        if s.kind == "narration" and s.text.strip():
            ln = old.get((i, s.text)) or NarrationLine(text=s.text, item_index=i)
            ln.item_index = i
            new.append(ln)
    plan.narration = new
    if plan.sections and plan.hooks:
        plan.hooks[0].opening_line = plan.sections[0].text
    pipe.edit_timeline = None


def sections_from_lines(pipe: "Pipeline") -> None:
    """Narration edited on the voice page (step 4) goes back into the parts on step 2."""
    plan = pipe.project.plan
    by: dict[int, list[str]] = {}
    for ln in plan.narration:
        by.setdefault(ln.item_index, []).append(ln.text)
    for i, s in enumerate(plan.sections):
        if s.kind != "narration":
            continue
        t = " ".join(by.get(i, [])).strip()
        if t and t != s.text:
            s.text, s.edited, s.audio_path, s.duration = t, True, "", 0.0
    pipe.edit_timeline = None


# ------------------------------------------------------------------ edit
def prepare_edit(pipe: "Pipeline", progress=None):
    """Voice → exact durations → fit footage → timeline → captions and on-screen text."""
    from .. import cancel as _cancel
    from ..render.captions import build_captions, default_overlays
    from ..render.voice import narration_word_times, synthesize_lines
    from ..core.models import Overlay

    plan = pipe.project.plan
    pr = (lambda st: (lambda f, m: progress(st, f, m))) if progress else (lambda st: None)
    sync_narration(pipe)
    if getattr(pipe, "_footage", None) is None:
        footage(pipe, progress)
    fl = {f.source_id: f for f in pipe._footage}
    v = pipe.voice_settings()
    tts = pipe.services.tts(pr("models"))
    _cancel.check()
    synthesize_lines(plan.narration, tts, v.voice, v.speed, v.volume_db, pipe.cache, pr("voice"))
    pipe.used["voice"] = f"{tts.name}:{v.voice}"
    _cancel.check()
    try:
        trans = pipe.services.transcriber()
    except Exception:  # noqa: BLE001
        trans = None
    if progress:
        progress("voice", 0.95, "Timing the narration captions…")
    by_index = {ln.item_index: ln for ln in plan.narration}
    words = {}
    for i, ln in by_index.items():
        _cancel.check()
        words[i] = narration_word_times(ln, trans)
    from .. import resources as _res

    if _res.release_models_between_stages():
        pipe.services.release("transcriber")
    # fit each section's footage to its real narration length
    src_len = {sid: float(f.src.duration or (f.visual.times[-1] if len(f.visual.times) else 0)) for sid, f in fl.items()}
    T = pipe.settings.edit.transition_seconds if pipe.settings.edit.transitions != "none" else 0.0
    for i, s in enumerate(plan.sections):
        if s.kind != "narration":
            continue
        ln = by_index.get(i)
        s.duration = ln.duration if ln else 0.0
        prev = plan.sections[i - 1] if i > 0 else None
        cont = bool(s.continue_visual and prev is not None and prev.kind == "narration" and prev.shots and s.shots
                    and s.shots[0].source_id == prev.shots[-1].source_id)
        total = (T if i > 0 and not cont else 0.0) + PAD_BEFORE + s.duration + PAD_AFTER
        if not s.shots:
            continue
        s.shots = fit_shots(s.shots, total, src_len)
        if cont:      # carry on exactly where the previous part's last shot ends
            a, d0 = prev.shots[-1].end, s.shots[0].duration
            if a + d0 <= src_len.get(s.shots[0].source_id, 1e9):
                s.shots[0] = Shot(source_id=s.shots[0].source_id, start=round(a, 3), end=round(a + d0, 3),
                                  score=s.shots[0].score, why=s.shots[0].why, locked=s.shots[0].locked)
    # full-quality footage for every shot and moment
    if progress:
        progress("download", 0.0, "Getting the footage")
    moments = {c.cid: c for c in pipe.project.candidates}
    files = _footage_files(pipe, fl, moments, progress)
    layouts = {}
    wide = pipe.settings.edit.crop_mode == "blur-fill" or "wide" in (plan.brief.visual_style or "")
    for sid, f in fl.items():
        # supporting footage fills the vertical frame (cropped around the action) and never shows a
        # streamer's webcam stacked on top; "wide shots" / blur-fill keep the whole picture instead.
        # Low-resolution footage keeps the whole picture too: a vertical crop of 360p would be
        # blown up about five times and look blurry.
        low = 0 < (f.src.height or 0) < LOW_RES
        layouts[sid] = ("blur-fill" if (wide or low) else "center", None)
    main = pipe.project.source.source_id if pipe.project.source else ""
    tl = build(plan.sections, by_index, words, files, {sid: f.transcript for sid, f in fl.items()}, moments, main,
               layouts, T)
    if progress:
        progress("edit", 0.6, "Captions and on-screen text")
    chunks = build_captions(tl, [words.get(p.line.item_index, []) for p in tl.narration], pipe.settings.edit, [])
    old_edits = {(c.kind, round(c.start, 1)): c for c in plan.captions if c.edited}
    for c in chunks:
        e = old_edits.get((c.kind, round(c.start, 1)))
        if e is not None:
            c.words, c.edited = e.words, True
    plan.captions = chunks
    ovs = default_overlays(plan, tl, pipe.settings.edit)
    for i, s in enumerate(plan.sections):
        if s.label and i < len(tl.item_spans) and s.kind == "narration":
            a = tl.item_spans[i][0] + 0.3
            if i == 0 and ovs and ovs[0].kind == "headline":
                a = max(a, ovs[0].t_end)
            ovs.append(Overlay(s.label, "context", a, a + 2.6))
    plan.overlays = ovs
    pipe.edit_timeline = tl
    pipe._best_src = {}
    pipe._creative_profiles = {}
    for sid, f in fl.items():
        for path, _o, _e in files.get(sid, []):
            pipe._creative_profiles[path] = f.visual
    pipe.mark_made("edit")
    pipe.log(f"Edit ready ({plan.brief.mode}): {tl.duration:.1f}s, {len(tl.narration)} narrated parts, "
             f"{sum(1 for g in tl.segments if g.kind == 'broll')} shots, "
             f"{sum(1 for g in tl.segments if g.kind == 'clip')} real moments")
    return tl


def _footage_files(pipe: "Pipeline", fl: dict, moments: dict, progress=None) -> dict[str, list[tuple[str, float, float]]]:
    """Local full-quality media for each source: the file itself, or pieces fetched from a link."""
    plan = pipe.project.plan
    need: dict[str, list[tuple[float, float]]] = {}
    main = pipe.project.source.source_id if pipe.project.source else ""
    for s in plan.sections:
        if s.kind == "moment" and s.cid in moments:
            c = moments[s.cid]
            need.setdefault(main, []).append((max(0.0, c.start - 0.5), c.end + 0.5))
        for sh in s.shots:
            need.setdefault(sh.source_id, []).append((max(0.0, sh.start - 0.5), sh.end + 1.0))
    files: dict[str, list[tuple[str, float, float]]] = {}
    for sid, ranges in need.items():
        f = fl.get(sid)
        if f is None:
            raise FileNotFoundError(f"A video used in the plan is no longer in the library ({sid})")
        src = f.src
        if src.kind == "file" and src.path and Path(src.path).exists():
            files[sid] = [(src.path, 0.0, float(src.duration or 1e9))]
            continue
        ranges = _merge(ranges)
        ing = Ingestor(progress=(lambda fr, m: progress("download", fr, m)) if progress else None,
                       cancel=pipe._cancelled)
        got = ing.fetch_sections(src, ranges, fps=pipe.settings.edit.fps)
        files[sid] = [(got[r], r[0], r[1]) for r in ranges]
    return files


def _merge(ranges: list[tuple[float, float]], gap: float = 4.0) -> list[tuple[float, float]]:
    out: list[list[float]] = []
    for a, b in sorted(ranges):
        if out and a - out[-1][1] <= gap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(round(a, 2), round(b, 2)) for a, b in out]


# ------------------------------------------------------------------ regenerate one part
def _index(pipe: "Pipeline"):
    if getattr(pipe, "_index", None) is None:
        pipe._index = lib_mod.build_index(footage(pipe))
    return pipe._index


def find_different_footage(pipe: "Pipeline", i: int, shot: int = -1) -> None:
    plan = pipe.project.plan
    s = plan.sections[i]
    d = sum(x.duration for x in s.shots) or _est(s, [])
    match_mod.rematch_section(plan.sections, i, _index(pipe), pipe.services.vision(), d, plan.brief.pacing,
                              plan.brief.visual_style, only_shot=shot, topic=_topic(plan.brief, plan.topic.raw),
                              footage=plan.brief.footage,
                              reserved=_reserved(pipe, plan.sections, None))
    for sh in s.shots:
        sh.locked = False
    pipe.edit_timeline = None
    pipe.project.save()


def rewrite_section(pipe: "Pipeline", i: int, instruction: str = "") -> None:
    plan = pipe.project.plan
    pipe.services.retry_llm()
    llm = pipe.services.llm()
    if pipe.services.status["llm"].active == "rules":
        raise ValueError("Rewriting a part needs the AI language model (Ollama). You can still edit the words "
                         "yourself in the table.")
    text, _ = research.source_material(plan.brief.notes, plan.brief.source_urls)
    if not narr_mod.rewrite_section(plan.sections, i, plan.topic.raw, plan.brief, llm, instruction, text):
        raise ValueError("The language model didn't return a usable rewrite; try again or edit the words yourself.")
    s = plan.sections[i]
    if not (s.shots and all(sh.locked for sh in s.shots)):     # footage the user chose to keep stays
        find_different_footage(pipe, i)
    sync_narration(pipe)
    pipe.project.save()


def change_pacing(pipe: "Pipeline", pacing: str) -> None:
    plan = pipe.project.plan
    plan.brief.pacing = pacing
    secs = plan.sections
    durs = [sum(x.duration for x in s.shots) or _est(s, []) for s in secs]
    match_mod.match_sections(secs, _index(pipe), pipe.services.vision(), durs, pacing, plan.brief.visual_style,
                             topic=_topic(plan.brief, plan.topic.raw), reserved=_reserved(pipe, secs, None),
                             footage=plan.brief.footage)
    pipe.edit_timeline = None
    pipe.project.save()


def change_tone(pipe: "Pipeline", style: str, tone: str = "") -> None:
    """Rewrite every section the user hasn't edited by hand, in a new style."""
    plan = pipe.project.plan
    pipe.services.retry_llm()
    pipe.services.llm()
    if pipe.services.status["llm"].active == "rules":
        raise ValueError("Rewriting in another style needs the AI language model (Ollama). Nothing was changed.")
    plan.brief.style, plan.brief.tone = style or plan.brief.style, tone or plan.brief.tone
    for i, s in enumerate(plan.sections):
        if s.kind == "narration" and not s.edited:
            rewrite_section(pipe, i, f"Rewrite in a {plan.brief.style} style" + (f", {tone}" if tone else ""))


def rights_problems(pipe: "Pipeline") -> list[str]:
    """Every video whose pictures or sound appear in the plan must have its permission recorded."""
    plan = pipe.project.plan
    used = {sh.source_id for s in plan.sections for sh in s.shots}
    if any(s.kind == "moment" for s in plan.sections) and pipe.project.source is not None:
        used.add(pipe.project.source.source_id)
    out = []
    fl = {f.source_id: f for f in (getattr(pipe, "_footage", None) or footage(pipe))}
    for sid in sorted(used):
        f = fl.get(sid)
        if f is None:
            out.append(f"{sid}: not in the library any more")
        elif f.rights_problems:
            out.append(f"{f.src.title or sid}: " + "; ".join(f.rights_problems))
    return out
