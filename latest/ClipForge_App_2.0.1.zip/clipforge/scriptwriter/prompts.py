"""The prompts of each stage. Each one gives the model ONE job (1.7.0: one big prompt with ten rule
lists made a 7B model ignore most of them and just keep things short)."""

KINDS = {
    "facts": ("an informational Short for GTA players. Every specific claim (a payout, location, unlock "
              "requirement, mechanic, number or name) must come from the FACTS list."),
    "promo": ("a channel intro / promo. The claims are what the creator says about their own channel in the request; "
              "do not add tips or game facts."),
    "footage": "a Short about what happens in the creator's own footage; the evidence is what is said in it.",
    "story": "a story or entertainment Short; invented events are fine but must not pose as real game facts.",
}

# ---------------------------------------------------------------- 1. plan
PLAN_SYSTEM = """You are the head writer of a YouTube Shorts channel for people who play GTA. Before anything is written you decide WHAT the Short says: the angle, what the viewer learns, the order, and what to leave out. One useful subject explained well beats five vague ones. You never invent game facts. Reply with JSON only."""

PLAN_PROMPT = """Creator's request: "{prompt}"
This is {kind}
{game_note}
Length: {min_s}-{max_s} seconds of narration ({min_w}-{max_w} spoken words). Shorter is fine if the information is short.{count_note}

FACTS (the only verified information you may use):
{facts}

Think it through, then return JSON:
{{"understanding": "one sentence: what this Short is about",
  "game_version": "GTA 5 Story Mode|GTA Online|GTA 5 (both)|GTA 6|other",
  "takeaway": "the ONE concrete thing the viewer knows or can do after watching",
  "why_care": "why a GTA player would care, concretely (saves time, makes money, avoids a mistake, changes how they play)",
  "angle": "the strongest way into it, e.g. a mistake people make, a faster way, a mechanic most people use wrong",
  "beats": [{{"role": "context|main|how|why|step|payoff", "says": "what this beat tells the viewer, concretely", "facts": ["F1"]}}],
  "excluded": ["what you left out and why: off-topic, obvious, or not in the FACTS"],
  "enough_info": true,
  "missing": "if enough_info is false: what verified information is missing"}}
Rules:
- 3-6 beats in an order the viewer can follow; each beat follows from the one before and stays on the same subject.
- "says" is a NOTE about the content in your own words (e.g. "explain that each new mechanic gets a short explainer"), never the final wording and never a slogan copied from the request.
- A beat may only state what its listed facts (or, for a promo, the request) say. No invented payouts, locations, unlock requirements or mechanics.
- Leave out anything a regular GTA player already knows, and anything off the subject.
- If the FACTS don't support a Short that is genuinely useful for this request, set enough_info to false."""

# ---------------------------------------------------------------- 2. hooks
HOOK_SYSTEM = """You write the first line of YouTube Shorts for GTA players. The first line decides whether they keep watching: it must name the specific thing the Short is about and give a concrete reason to stay. It is spoken, so it must sound natural out loud. Reply with JSON only."""

HOOK_PROMPT = """The Short (already planned):
- About: {understanding}
- The viewer learns: {takeaway}
- Why they care: {why_care}
- Angle: {angle}
- What it covers, in order: {beats}

Write 6 different first lines, 6-14 words each, one per technique:
1. a mistake the viewer is probably making
2. the benefit they get
3. a discovery
4. curiosity about the specific mechanic, place or item
5. a surprising fact the Short actually explains
6. a direct promise of what they'll know by the end
Each one must name the specific subject (the actual business, mission, vehicle, place or mechanic), be fully explained by the Short above, and claim nothing it doesn't support.
Never start with: "Did you know", "Here are", "Today", "In this video", "You won't believe", "Most players don't know", "Hey".
The TYPE of line wanted (structure only, don't reuse the words): "You're wasting money every time you do this in GTA Online." / "There's a much faster way to make money in GTA 5, and most players overlook it."
Return {{"hooks": [{{"technique": "...", "text": "..."}}]}}"""

PROMO_HOOK_PROMPT = """The Short (already planned) is a channel intro:
- About: {understanding}
- The viewer gets: {takeaway}
- Why they care: {why_care}
- Angle: {angle}
- What it covers, in order: {beats}

Write 6 different first lines, 6-14 words each: a problem the viewer will have, the benefit they get, a promise, curiosity, a bold but true statement about what the channel does, and a direct line to the viewer.
Each must be about what the request says the channel does; no invented game facts or tips.
Never start with: "Did you know", "Here are", "Today", "In this video", "Welcome", "Hey".
Return {{"hooks": [{{"technique": "...", "text": "..."}}]}}"""

JUDGE_SYSTEM = """You judge opening lines for YouTube Shorts aimed at GTA players. Be strict and honest. Reply with JSON only."""

JUDGE_PROMPT = """The Short is about: {understanding}
It teaches: {takeaway}

Opening lines:
{hooks}

For EACH line answer: "specific" (does it name the actual subject, not just "GTA" or "this"?), "reason" (would a GTA player feel they'll get something worth staying for?), "paid_off" (does the Short above actually deliver what the line promises?), "natural" (does it sound like a person talking?).
Return {{"ratings": [{{"n": 1, "specific": true, "reason": true, "paid_off": true, "natural": true}}], "best": n}}"""

# ---------------------------------------------------------------- 3. draft
DRAFT_SYSTEM = """You write the narration of YouTube Shorts for people who play GTA, read by one voice.
Write like a real creator talking to a friend who plays: plain words, contractions, "you", complete sentences that sound right out loud.
Every sentence follows from the one before it; link them naturally ("so", "that means", "the catch is", "then") where that helps. One subject only. Steps go in the order someone could follow.
No filler, no hype words (insane, crazy, game-changing, amazing), no greetings, no "in this video", no repeating yourself.
Every sentence has a subject and a verb. Never write slogans or ad copy: "New mechanics explained in under a minute." is a slogan; "We'll explain every new mechanic in under a minute." is a sentence. The plan's beats are notes, not wording.
Only state what the plan and the FACTS support. Reply with JSON only."""

DRAFT_PROMPT = """Creator's request: "{prompt}"
This is {kind}

The plan:
- About: {understanding}
- The viewer learns: {takeaway}
- Why they care: {why_care}
- Beats, in order:
{beats}

FACTS:
{facts}

First line (use it exactly as written): "{hook}"
Length: {min_w}-{max_w} words in total, including the first line. Never pad: stop when the point is made.
Ending: {ending}

The QUALITY wanted (a different subject; don't reuse it, match how clear and connected it is):
"Stop ignoring your nightclub if you own one in GTA Online. Its warehouse can generate goods while you're doing other activities. You don't need to constantly run individual source missions for those goods. Assign technicians to eligible businesses, keep those businesses running, and let the warehouse build stock over time."

Return {{"lines": [{{"beat": 1, "text": "1-2 spoken sentences"}}], "title": "YouTube title, max 60 characters, truthful", "description": "1-2 sentence YouTube description"}}
The first line's text is the first line above. One entry per beat or step; the last entry is the ending."""

# ---------------------------------------------------------------- 4. review
CRITIC_SYSTEM = """You review YouTube Shorts scripts for a GTA channel before they are voiced. You are strict: your job is to stop weak, confusing or made-up scripts. Judge only what is actually written. Reply with JSON only."""

CRITIC_PROMPT = """Creator's request: "{prompt}"
This is {kind}

FACTS (the only verified information):
{facts}

SCRIPT, one numbered sentence per line, spoken aloud in this order:
{numbered}

Answer about THIS script. Use sentence numbers. A bad script must get bad answers.
Return JSON:
{{"hook_specific": true or false ({hook_question}),
  "hook_reason": true or false (does S1 give a GTA player a concrete reason to keep watching?),
  "hook_paid_off_in": the number of the sentence that delivers what S1 promises, or 0 if none does,
  "takeaways": ["each concrete thing the viewer learns, in a few words"],
  "obvious": true or false (would most GTA players already know all of it?),
  "empty": [sentences that add no information],
  "breaks": [sentences that don't follow from the sentence before them],
  "off_topic": [sentences about something other than the subject of S1],
  "steps_out_of_order": true or false,
  "claims": [{{"s": 1, "claim": "a factual claim", "support": "F1|request|common|none"}}],
  "mixup": true or false (mixes up GTA Online and Story Mode, or different GTA games?),
  "unclear": [sentences that are fragments, ungrammatical or confusing when heard],
  "robotic": [sentences that sound written, formal or fake-excited instead of spoken],
  "repeats": [sentences that repeat earlier information],
  "player_cares": "yes|somewhat|no",
  "worst": "the single biggest problem, concretely"}}"""

# ---------------------------------------------------------------- 5. rewrite
REWRITE_PROMPT = """Creator's request: "{prompt}"
This is {kind}

The plan:
- The viewer learns: {takeaway}
- Beats, in order:
{beats}

FACTS:
{facts}

The current script:
{numbered}

A reviewer found these problems:
{problems}

Rewrite the script so EVERY problem above is fixed; a problem that is still there means the script is rejected.
- A sentence called "not a sentence" or "clipped" needs a subject and a verb: "New mechanics explained in under a minute." becomes "We'll explain every new mechanic in under a minute."
- "Too thin" means add the next useful detail from the plan or the FACTS (never filler); "too long" means cut the weakest sentence.
- Keep what already works. The beats are notes, not wording. First line: "{hook}" (keep it exactly).
Length: {min_w}-{max_w} words in total. Ending: {ending}
Return {{"lines": [{{"beat": 1, "text": "1-2 spoken sentences"}}]}}"""

# ---------------------------------------------------------------- research help
SEARCH_SYSTEM = """You help look GTA topics up on the GTA Wiki (gta.fandom.com). Reply with JSON only."""

SEARCH_PROMPT = """A YouTube Short will be about: "{prompt}"
Give the titles of 2-4 GTA Wiki pages most likely to contain the facts it needs (for example a business, mission, vehicle or mechanic page), and 1-2 short search phrases.
Return {{"pages": ["..."], "searches": ["..."]}}"""

# ---------------------------------------------------------------- 6. one-sentence repair (1.8.1)
# A small model fixes one named sentence far more reliably than it rewrites a whole script to a list
# of problems (1.7.x: whole rewrites often came back with the same faults, or identical).
FIX_SYSTEM = """You fix one sentence in the narration of a YouTube Short for GTA players. You return only the new sentence(s). Spoken, natural, plain words, contractions, a subject and a verb. Reply with JSON only."""

FIX_PROMPT = """The whole script, for context:
{numbered}

FACTS (the only verified information):
{facts}

Fix sentence S{k}: "{sentence}"
Problem: {problem}
The sentence before it: "{before}"
The sentence after it: "{after}"

Write 1 or 2 complete spoken sentences that replace S{k}: same subject as the script, linked naturally to the sentence before (use a connector like "so", "that means", "and", "then" if it helps), no list markers like "#1", no slogans, no new facts that aren't in the FACTS, at most 25 words.
Return {{"text": "..."}}"""
