"""The script writer (1.7.0): plan → hooks → draft → review → rewrite → pass or reject.

Why it is built this way (what the user's videos showed, 1.6.x):
  * one prompt carried a dozen rule lists; a 7B model can't follow them all, so it obeyed "be short"
    and wrote fragments ("Fly in restricted airspace, avoid radar.");
  * nothing decided what the video was FOR before sentences were written, so lines didn't connect;
  * the old check counted words and patterns, so "Deal with trash truck, get pros on this." scored
    10/10 for narration.

Here every stage is one focused call. The review asks concrete questions about numbered sentences
(is S3 connected to S2? which claims have no source?) and the score is computed from the answers,
then lowered by checks that need no AI (``rules``). Nothing a model says can raise a score above
what those checks allow. A script that doesn't reach the thresholds is rewritten with the exact
problems; after ``max_rounds`` it is rejected instead of being turned into a video.
"""
from __future__ import annotations

import copy
import re
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..providers.base import ProviderUnavailable
from . import prompts as P
from . import rules

THRESHOLDS = {"hook": 8.0, "information": 8.0, "logic": 9.0, "accuracy": 9.0, "natural": 8.0, "clarity": 8.0,
              "relevance": 7.0, "pacing": 7.0}
AREAS = ["hook", "information", "accuracy", "logic", "clarity", "natural", "relevance", "pacing", "retention"]
WORDS_PER_SECOND = 2.6
MAX_ROUNDS = 3


class ScriptRejected(ValueError):
    """The script didn't pass the quality check; no video is made from it."""


@dataclass
class Attempt:
    label: str
    lines: list[str]
    scores: dict
    problems: list[str]
    passed: bool
    hook: str = ""
    seconds: float = 0.0

    def to_dict(self) -> dict:
        return {"label": self.label, "lines": self.lines, "scores": self.scores, "problems": self.problems,
                "passed": self.passed, "hook": self.hook, "seconds": round(self.seconds, 1)}


@dataclass
class ScriptResult:
    ok: bool
    lines: list[str] = field(default_factory=list)
    title: str = ""
    description: str = ""
    kind: str = "facts"
    plan: dict = field(default_factory=dict)
    hooks: list[dict] = field(default_factory=list)
    attempts: list[Attempt] = field(default_factory=list)
    reason: str = ""
    facts: list[dict] = field(default_factory=list)
    seconds: float = 0.0

    @property
    def best(self) -> Optional[Attempt]:
        return best_attempt(self.attempts)

    def to_dict(self) -> dict:
        b = self.best
        return {"ok": self.ok, "kind": self.kind, "reason": self.reason, "lines": self.lines, "title": self.title,
                "plan": self.plan, "hooks": self.hooks, "facts": self.facts,
                "attempts": [a.to_dict() for a in self.attempts], "scores": b.scores if b else {},
                "seconds": round(self.seconds, 1)}

    def report(self) -> str:
        """What happened, in words (for the log, the rejection message and the benchmark)."""
        out = []
        if self.plan:
            out.append(f"Plan: {self.plan.get('understanding', '')}")
            out.append(f"  Viewer learns: {self.plan.get('takeaway', '')}")
        for a in self.attempts:
            sc = ", ".join(f"{k} {a.scores.get(k, 0):.1f}" for k in AREAS if k in a.scores)
            out.append(f"{a.label}: {'PASSED' if a.passed else 'failed'} ({sc})")
            for p in a.problems[:8]:
                out.append(f"  - {p}")
        if not self.ok and self.reason:
            out.append("Rejected: " + self.reason)
        return "\n".join(out)


def best_attempt(attempts: list[Attempt]) -> Optional[Attempt]:
    if not attempts:
        return None

    def key(a: Attempt):
        ok = sum(1 for k, t in THRESHOLDS.items() if a.scores.get(k, 0) >= t)
        short = sum(max(0.0, t - a.scores.get(k, 0)) for k, t in THRESHOLDS.items())
        return (a.passed, ok, -short)

    return max(attempts, key=key)


# ------------------------------------------------------------------ what kind of Short this is
_PROMO = re.compile(r"\b(channel|intro(?:duc\w*)? (?:video|to)|trailer|teaser|promo\w*|welcome to|subscribe|"
                    r"follow (?:us|me|my|the channel)|what (?:we|i) (?:do|post|offer|provide|cover)|why (?:you should )?"
                    r"follow)\b", re.I)
_FOOTAGE = re.compile(r"\b(?:this|my|the|his|her|their)\s+(?:video|stream|vod|recording|broadcast|livestream)\b|"
                      r"\bwhat\s+happen|\bthe\s+streamer\b", re.I)
_GTA = re.compile(r"\bgta\b|grand theft auto|los santos", re.I)


def classify(prompt: str, category: str = "") -> str:
    if _PROMO.search(prompt or ""):
        return "promo"
    if _FOOTAGE.search(prompt or ""):
        return "footage"
    if category in ("story", "entertainment"):
        return "story"
    return "facts"


def game_note(prompt: str) -> str:
    low = (prompt or "").lower()
    if re.search(r"\b(gta|grand theft auto)\s*(6|vi)\b", low):
        return ("Game: GTA 6. Treat gameplay details as unconfirmed unless the FACTS confirm them; never present "
                "speculation as fact.")
    if "gta online" in low or re.search(r"\bonline\b", low) and _GTA.search(low):
        return "Game: GTA Online (not Story Mode). Only mechanics that work in GTA Online."
    if "story mode" in low:
        return "Game: GTA 5 Story Mode (not GTA Online)."
    if _GTA.search(low):
        return ("Game: GTA 5. Say clearly whether something is Story Mode or GTA Online when it matters; never mix "
                "them up.")
    return ""


_NUMW = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}


def requested_count(prompt: str) -> int:
    pat = re.compile(r"\b(\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:\w+\s+){0,2}?(tips?|"
                     r"secrets?|ways?|things|facts?|mistakes?|reasons?|methods?|steps?|tricks?|features?|details?)\b",
                     re.I)
    m = None
    for x in pat.finditer(prompt or ""):
        before = (prompt or "")[max(0, x.start() - 20):x.start()].lower()
        if not re.search(r"(gta|grand theft auto|season|part|mk|iphone|chapter|episode)\s*$", before):
            m = x
            break
    if not m:
        return 0
    v = m.group(1).lower()
    n = int(v) if v.isdigit() else _NUMW[v]
    return n if 1 < n <= 10 else 0


def requested_ending(prompt: str) -> str:
    m = re.search(r"\bend(?:s|ing)?\s+(?:it\s+)?(?:with|on)\s*:?\s*[\"“]([^\"”]{3,120})[\"”]", prompt or "", re.I)
    return m.group(1).strip() if m else ""


def requested_hook(prompt: str) -> str:
    m = re.search(r"hook[^\n\"“]{0,40}[\"“]([^\"”]{6,200})[\"”]", prompt or "", re.I)
    return m.group(1).strip() if m else ""


def word_range(seconds: float) -> tuple[int, int]:
    mx = max(45, int(seconds * WORDS_PER_SECOND))
    return max(35, int(mx * 0.55)), mx


def facts_block(facts: list[dict], sources_text: str, kind: str) -> str:
    if facts:
        return "\n".join(f"F{k}. {f['fact']}" + (f" [{f['source']}]" if f.get("source") else "")
                         for k, f in enumerate(facts, 1))
    if sources_text.strip():
        return sources_text.strip()[:3500]
    if kind == "promo":
        return "(none needed: use only what the creator's request says about the channel)"
    if kind == "story":
        return "(none: a story)"
    return "(none found)"


# ------------------------------------------------------------------ the writer
class Writer:
    def __init__(self, llm, log: Optional[Callable[[str], None]] = None, critic=None, max_rounds: int = MAX_ROUNDS,
                 progress: Optional[Callable[[float, str], None]] = None):
        self.llm, self.critic = llm, critic or llm
        self.log = log or (lambda m: None)
        self.max_rounds = max_rounds
        self.progress = progress or (lambda f, m: None)

    # ---------------------------------------------------------- one model call, at its own temperature
    def _ask(self, system: str, user: str, max_tokens: int, temperature: float, model=None) -> dict:
        m = copy.copy(model or self.llm)
        if hasattr(m, "temperature"):
            m.temperature = temperature
        if hasattr(m, "on_text"):
            m.on_text = None
        d = m.complete_json(system, user, max_tokens=max_tokens)
        return d if isinstance(d, dict) else {}

    # ---------------------------------------------------------- 1. plan
    def plan(self, ctx: dict) -> dict:
        d = self._ask(P.PLAN_SYSTEM, P.PLAN_PROMPT.format(**ctx), 1200, 0.3)
        beats = []
        for b in d.get("beats") or []:
            if isinstance(b, dict) and str(b.get("says") or "").strip():
                beats.append({"role": str(b.get("role") or "main")[:12], "says": str(b["says"]).strip()[:300],
                              "facts": [str(x) for x in (b.get("facts") or []) if str(x).strip()][:4]})
            elif isinstance(b, str) and b.strip():
                beats.append({"role": "main", "says": b.strip()[:300], "facts": []})
        d["beats"] = beats[:7]
        d["enough_info"] = str(d.get("enough_info", True)).lower() not in ("false", "0", "no")
        for k in ("understanding", "takeaway", "why_care", "angle", "game_version", "missing"):
            d[k] = " ".join(str(d.get(k) or "").split())[:300]
        return d

    @staticmethod
    def beats_text(plan: dict) -> str:
        return "\n".join(f"  {k}. ({b['role']}) {b['says']}" + (f" [{', '.join(b['facts'])}]" if b["facts"] else "")
                         for k, b in enumerate(plan.get("beats") or [], 1))

    # ---------------------------------------------------------- 2. hooks
    def hooks(self, plan: dict, kind: str) -> list[dict]:
        tpl = P.PROMO_HOOK_PROMPT if kind == "promo" else P.HOOK_PROMPT
        beats = "; ".join(b["says"] for b in plan.get("beats") or [])[:700]
        d = self._ask(P.HOOK_SYSTEM, tpl.format(understanding=plan.get("understanding", ""),
                                                takeaway=plan.get("takeaway", ""), why_care=plan.get("why_care", ""),
                                                angle=plan.get("angle", ""), beats=beats), 700, 0.9)
        hooks = []
        for h in d.get("hooks") or []:
            t = h.get("text") if isinstance(h, dict) else h
            t = " ".join(str(t or "").split()).strip(' "')
            if t and t.lower() not in (x["text"].lower() for x in hooks):
                hooks.append({"text": t, "technique": str(h.get("technique", "") if isinstance(h, dict) else "")[:40]})
        if not hooks:
            return []
        subject = {w.lower() for w in rules.words(plan.get("understanding", "") + " " + plan.get("takeaway", ""))
                   if len(w) > 3} - {"about", "that", "this", "with", "they", "their", "what", "your", "players",
                                     "player", "short", "video", "viewer", "learn", "learns"}
        for h in hooks:
            fs = rules.check([h["text"]], h["text"], "", "", 1, 999, "promo")
            h["rule"] = 10.0 - sum(f.penalty for f in fs if f.area == "hook")
            h["on_subject"] = bool(subject & {w.lower() for w in rules.words(h["text"])})
            h["problems"] = [f.message for f in fs if f.area == "hook"]
        try:
            listing = "\n".join(f"{k}. {h['text']}" for k, h in enumerate(hooks, 1))
            j = self._ask(P.JUDGE_SYSTEM, P.JUDGE_PROMPT.format(understanding=plan.get("understanding", ""),
                                                                takeaway=plan.get("takeaway", ""), hooks=listing),
                          700, 0.1, self.critic)
            rated = {}
            for r in j.get("ratings") or []:
                if isinstance(r, dict):
                    try:
                        rated[int(r.get("n"))] = r
                    except (TypeError, ValueError):
                        continue
            best = int(j.get("best") or 0) if str(j.get("best") or "").isdigit() else 0
        except (ProviderUnavailable, ValueError):
            rated, best = {}, 0
        for k, h in enumerate(hooks, 1):
            r = rated.get(k, {})
            yes = sum(1 for q in ("specific", "reason", "paid_off", "natural") if str(r.get(q)).lower() == "true")
            h["judge"] = yes
            h["score"] = round(h["rule"] + yes * 1.5 + (1.0 if h["on_subject"] else -2.0) + (1.0 if k == best else 0.0),
                               2)
        hooks.sort(key=lambda h: -h["score"])
        return hooks

    # ---------------------------------------------------------- 3. draft / 5. rewrite
    @staticmethod
    def _lines(d: dict, hook: str) -> list[str]:
        out = []
        for x in d.get("lines") or d.get("script") or []:
            t = x.get("text") if isinstance(x, dict) else x
            t = " ".join(str(t or "").split())
            if t:
                out.append(t)
        if not out:
            return []
        if hook:
            first = rules.sentences(out[0])
            if not first or _sim(first[0], hook) < 0.6:
                if _sim(out[0], hook) >= 0.6:
                    out[0] = hook
                else:
                    out.insert(0, hook)
            elif first[0] != hook:
                out[0] = " ".join([hook] + first[1:])
        return out

    def draft(self, ctx: dict, plan: dict, hook: str) -> tuple[list[str], dict]:
        d = self._ask(P.DRAFT_SYSTEM, P.DRAFT_PROMPT.format(**ctx, understanding=plan.get("understanding", ""),
                                                            takeaway=plan.get("takeaway", ""),
                                                            why_care=plan.get("why_care", ""),
                                                            beats=self.beats_text(plan), hook=hook), 1400, 0.6)
        return self._lines(d, hook), d

    def rewrite(self, ctx: dict, plan: dict, hook: str, lines: list[str], problems: list[str]) -> list[str]:
        d = self._ask(P.DRAFT_SYSTEM, P.REWRITE_PROMPT.format(
            **ctx, takeaway=plan.get("takeaway", ""), beats=self.beats_text(plan), numbered=numbered(lines),
            problems="\n".join(f"- {p}" for p in problems[:12]), hook=hook), 1400, 0.4)
        return self._lines(d, hook)

    # ---------------------------------------------------------- 4. review
    def review(self, ctx: dict, lines: list[str], hook: str, evidence: str, kind: str) -> tuple[dict, list[str], dict]:
        sents = rules.sentences(" ".join(lines))
        n = len(sents)
        try:
            raw = self._ask(P.CRITIC_SYSTEM, P.CRITIC_PROMPT.format(prompt=ctx["prompt"], kind=ctx["kind"],
                                                                    facts=ctx["facts"], numbered=numbered_sents(sents)),
                            1500, 0.1, self.critic)
        except ValueError:
            raw = {}
        found = rules.check(lines, hook, evidence, ctx["prompt"], ctx["min_w"], ctx["max_w"], kind, ctx.get("end_text", ""))
        scores, problems = score(raw, found, sents, kind, ctx.get("n_facts", 0))
        return scores, problems, raw

    # ---------------------------------------------------------- the whole thing
    def write(self, prompt: str, kind: str, facts: list[dict], sources_text: str, narration_seconds: float,
              category: str = "", creator_notes: str = "") -> ScriptResult:
        t0 = time.time()
        min_w, max_w = word_range(narration_seconds)
        count = requested_count(prompt)
        end_text = requested_ending(prompt)
        ending = (f'end with exactly: "{end_text}"' if end_text else
                  "one last useful takeaway or payoff line, then a short call to action that fits the topic "
                  "(at most 6 words, e.g. \"Follow for more GTA tips.\")")
        ctx = {"prompt": prompt + (f"\nCreator's notes: {creator_notes[:1500]}" if creator_notes else ""),
               "kind": P.KINDS.get(kind, P.KINDS["facts"]), "game_note": game_note(prompt),
               "min_s": int(min_w / WORDS_PER_SECOND), "max_s": int(max_w / WORDS_PER_SECOND), "min_w": min_w,
               "max_w": max_w, "facts": facts_block(facts, sources_text, kind), "ending": ending, "end_text": end_text,
               "n_facts": len(facts),
               "count_note": (f"\nThe request asks for {count} items: give each one its own beat, in an order that "
                              f"builds, with a link between them." if count else "")}
        res = ScriptResult(ok=False, kind=kind, facts=facts)
        evidence = sources_text + "\n" + "\n".join(f["fact"] for f in facts)
        if kind == "facts" and not facts and not sources_text.strip() and _GTA.search(prompt or ""):
            res.reason = ("No verified information was found for this topic (the GTA Wiki and Wikipedia lookups found "
                          "nothing usable, or they couldn't be reached). Add your own notes or a link with the facts, "
                          "or pick a different topic.")
            res.seconds = time.time() - t0
            return res
        self.progress(0.05, "Planning the Short: angle, what the viewer learns, order")
        plan = self.plan(ctx)
        res.plan = plan
        self.log(f"Script plan: {plan.get('understanding', '')[:160]} | learns: {plan.get('takeaway', '')[:160]}")
        if not plan.get("beats"):
            res.reason = "The plan came back empty (the language model didn't answer usefully)."
            res.seconds = time.time() - t0
            return res
        if not plan.get("enough_info") and kind == "facts":
            res.reason = ("Not enough verified information for a useful Short on this: "
                          + (plan.get("missing") or "the facts found don't cover it") + ".")
            res.seconds = time.time() - t0
            return res
        self.progress(0.25, "Writing and ranking hooks")
        own = requested_hook(prompt)
        hooks = [{"text": own, "technique": "the creator's own", "score": 99.0, "problems": []}] if own else \
            self.hooks(plan, kind)
        res.hooks = hooks
        if not hooks:
            res.reason = "No hook came back from the language model."
            res.seconds = time.time() - t0
            return res
        hook_i = 0
        hook = hooks[0]["text"]
        self.log(f"Script hook: \"{hook}\" (best of {len(hooks)})")
        self.progress(0.4, "Writing the script")
        lines, d = self.draft(ctx, plan, hook)
        res.title = str(d.get("title") or "")[:100]
        res.description = str(d.get("description") or "")[:500]
        label = "draft"
        for rnd in range(self.max_rounds + 1):
            if not lines:
                break
            self.progress(0.55 + rnd * 0.1, "Checking the script" if rnd == 0 else f"Checking rewrite {rnd}")
            t1 = time.time()
            sc, problems, _raw = self.review(ctx, lines, hook, evidence, kind)
            passed = all(sc.get(k, 0) >= t for k, t in THRESHOLDS.items())
            res.attempts.append(Attempt(label, list(lines), sc, problems, passed, hook, time.time() - t1))
            self.log(f"Script check ({label}): " + ("passed" if passed else "failed") + " — "
                     + ", ".join(f"{k} {sc.get(k, 0):.1f}" for k in THRESHOLDS))
            if passed or rnd == self.max_rounds:
                break
            # a weak hook: try the next-best one rather than asking for a "better hook"
            if sc.get("hook", 10) < THRESHOLDS["hook"] and not own and hook_i + 1 < len(hooks):
                hook_i += 1
                hook = hooks[hook_i]["text"]
                problems = problems + [f'The first line is now: "{hook}". Make the script deliver what it promises.']
            label = f"rewrite {rnd + 1}"
            self.progress(0.6 + rnd * 0.1, f"Rewriting the weak parts ({rnd + 1}/{self.max_rounds})")
            new = self.rewrite(ctx, plan, hook, lines, problems)
            lines = new or lines
        b = res.best
        res.seconds = time.time() - t0
        if b and b.passed:
            res.ok, res.lines = True, b.lines
            return res
        res.lines = b.lines if b else []
        low = [f"{k} {b.scores.get(k, 0):.1f}/10 (needs {t:.0f})" for k, t in THRESHOLDS.items()
               if b and b.scores.get(k, 0) < t]
        res.reason = (f"The script didn't reach the quality bar after {max(0, len(res.attempts) - 1)} rewrite(s): "
                      + "; ".join(low) + ". Main problems: " + "; ".join((b.problems if b else [])[:4]))
        return res


# ------------------------------------------------------------------ scoring
def numbered(lines: list[str]) -> str:
    return "\n".join(f"{k}. {t}" for k, t in enumerate(lines, 1))


def numbered_sents(sents: list[str]) -> str:
    return "\n".join(f"S{k}. {t}" for k, t in enumerate(sents, 1))


def _sim(a: str, b: str) -> float:
    x, y = {w.lower() for w in rules.words(a)}, {w.lower() for w in rules.words(b)}
    return len(x & y) / max(1, min(len(x), len(y))) if x and y else 0.0


def _nums(v, n: int) -> list[int]:
    out = []
    for x in v if isinstance(v, list) else []:
        try:
            k = int(str(x).strip().lstrip("Ss").split(".")[0])
        except ValueError:
            continue
        if 1 <= k <= n and k not in out:
            out.append(k)
    return out


def _true(v) -> bool:
    return str(v).strip().lower() in ("true", "yes", "1")


def score(raw: dict, found: list, sents: list[str], kind: str, n_facts: int) -> tuple[dict, list[str]]:
    """Scores out of 10 from the reviewer's concrete answers, lowered by the rule findings.
    Returns (scores, problems for the rewrite)."""
    n = len(sents)
    q = lambda k: f'S{k} ("{sents[k - 1][:90]}")'  # noqa: E731
    probs: list[str] = []
    s = {a: 10.0 for a in AREAS}
    have = bool(raw)
    if not have:
        probs.append("the reviewer gave no usable answer, so only the automatic checks ran")
        for a in ("hook", "information", "logic", "accuracy"):
            s[a] = 7.0                    # unknown is not a pass
    # hook
    if have and not _true(raw.get("hook_specific")):
        s["hook"] -= 3
        probs.append("S1 (the hook) doesn't name the specific thing the Short is about")
    if have and not _true(raw.get("hook_reason")):
        s["hook"] -= 3
        probs.append("S1 (the hook) gives no concrete reason to keep watching")
    try:
        paid = int(str(raw.get("hook_paid_off_in", 0)).lstrip("Ss") or 0)
    except ValueError:
        paid = 0
    if have and not 2 <= paid <= n:
        s["hook"] -= 3
        probs.append("nothing in the script delivers what the hook promises")
    # information
    takes = [t for t in raw.get("takeaways") or [] if str(t).strip()] if have else []
    if have and not takes:
        s["information"] = 3.0
        probs.append("the viewer learns nothing concrete")
    if have and _true(raw.get("obvious")):
        s["information"] -= 3
        probs.append("it's all things most GTA players already know: use a less obvious fact")
    for k in _nums(raw.get("empty"), n):
        s["information"] -= 2
        probs.append(f"{q(k)} adds no information: cut it or replace it with a fact")
    # logic
    for k in _nums(raw.get("breaks"), n):
        if k > 1:
            s["logic"] -= 2.5
            probs.append(f"{q(k)} doesn't follow from the sentence before it: connect it or reorder")
    for k in _nums(raw.get("off_topic"), n):
        if k > 1:
            s["logic"] -= 2.5
            probs.append(f"{q(k)} is about something else than the hook's subject: remove it")
    if have and _true(raw.get("steps_out_of_order")):
        s["logic"] -= 2
        probs.append("the steps are out of order: put them in the order a player would do them")
    # accuracy
    if kind not in ("story", "promo"):
        common = 0
        for c in raw.get("claims") or []:
            if not isinstance(c, dict):
                continue
            sup = str(c.get("support") or "").strip().lower()
            k = _nums([c.get("s")], n)
            where = q(k[0]) if k else "a sentence"
            if sup in ("none", "", "unsupported", "no"):
                s["accuracy"] -= 4
                probs.append(f"{where} claims \"{str(c.get('claim'))[:80]}\", which isn't in the FACTS: remove it or "
                             f"replace it with a listed fact")
            elif sup.startswith("common"):
                common += 1
            elif sup.startswith("f") and n_facts:
                try:
                    if not 1 <= int(sup.lstrip("f").split()[0]) <= n_facts:
                        s["accuracy"] -= 3
                        probs.append(f"{where} cites a fact that doesn't exist")
                except ValueError:
                    pass
        if common > 2:
            s["accuracy"] -= 1.0 * (common - 2)
            probs.append(f"{common} claims rest on 'common knowledge' instead of the FACTS")
    if have and _true(raw.get("mixup")):
        s["accuracy"] -= 4
        probs.append("it mixes up GTA Online and Story Mode (or different GTA games)")
    # clarity / natural
    for k in _nums(raw.get("unclear"), n):
        s["clarity"] -= 2
        probs.append(f"{q(k)} is unclear or ungrammatical when heard: rewrite it as a full spoken sentence")
    for k in _nums(raw.get("robotic"), n):
        s["natural"] -= 1.5
        probs.append(f"{q(k)} sounds written or fake-excited: say it the way a person would")
    for k in _nums(raw.get("repeats"), n):
        if k > 1:
            s["natural"] -= 2
            probs.append(f"{q(k)} repeats earlier information: cut it")
    # relevance
    pc = str(raw.get("player_cares") or "").strip().lower() if have else "somewhat"
    s["relevance"] = {"yes": 10.0, "somewhat": 7.0, "no": 3.0}.get(pc, 7.0)
    if pc == "no":
        probs.append("a GTA player wouldn't care about this as written")
    # rules (only lower)
    for f in found:
        area = f.area if f.area in s else "natural"
        s[area] -= f.penalty
        probs.append(f.message if not f.sentence else f"S{f.sentence}: {f.message}")
    if have and str(raw.get("worst") or "").strip():
        probs.insert(0, "Biggest problem: " + " ".join(str(raw["worst"]).split())[:200])
    for a in s:
        s[a] = round(max(0.0, min(10.0, s[a])), 1)
    s["retention"] = round((s["hook"] + s["information"] + s["logic"] + s["natural"]) / 4, 1)
    out, seen = [], set()
    for p in probs:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return s, out
